import { PrismaService } from "@/database/prisma.service";
import { ApiResponse } from "@nos/shared-types";
export declare class HealthService {
    private readonly prisma;
    private readonly logger;
    constructor(prisma: PrismaService);
    getSystemStatus(requestId?: string): Promise<ApiResponse>;
}
