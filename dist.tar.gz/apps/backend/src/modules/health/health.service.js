"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var HealthService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.HealthService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../database/prisma.service");
const shared_types_1 = require("@nos/shared-types");
let HealthService = HealthService_1 = class HealthService {
    prisma;
    logger = new common_1.Logger(HealthService_1.name);
    constructor(prisma) {
        this.prisma = prisma;
    }
    async getSystemStatus(requestId) {
        let dbStatus = shared_types_1.SystemStatus.HEALTHY;
        let dbMessage = "PostgreSQL database operational";
        try {
            await this.prisma.$queryRaw `SELECT 1`;
        }
        catch (e) {
            this.logger.warn("Health diagnostics check: Database connection unresponsive.");
            dbStatus = shared_types_1.SystemStatus.DEGRADED;
            dbMessage = "Database connectivity degraded or unreachable";
        }
        return {
            success: true,
            data: {
                status: dbStatus,
                service: "nos-backend-fastify",
                uptime: process.uptime(),
                database: {
                    status: dbStatus,
                    message: dbMessage,
                },
            },
            timestamp: new Date().toISOString(),
            requestId,
        };
    }
};
exports.HealthService = HealthService;
exports.HealthService = HealthService = HealthService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], HealthService);
//# sourceMappingURL=health.service.js.map