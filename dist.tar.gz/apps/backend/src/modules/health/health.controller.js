"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.HealthController = void 0;
const openapi = require("@nestjs/swagger");
const common_1 = require("@nestjs/common");
const terminus_1 = require("@nestjs/terminus");
const prisma_service_1 = require("../../database/prisma.service");
const swagger_1 = require("@nestjs/swagger");
let HealthController = class HealthController {
    health;
    prismaHealth;
    prisma;
    constructor(health, prismaHealth, prisma) {
        this.health = health;
        this.prismaHealth = prismaHealth;
        this.prisma = prisma;
    }
    check() {
        return {
            status: "ok",
            uptime: process.uptime(),
            timestamp: new Date().toISOString(),
            version: "1.0.0",
        };
    }
    async checkReady(res) {
        try {
            const result = await this.health.check([
                () => this.prismaHealth.pingCheck("database", this.prisma),
            ]);
            return res.status(common_1.HttpStatus.OK).send(result);
        }
        catch (error) {
            return res.status(common_1.HttpStatus.SERVICE_UNAVAILABLE).send({
                status: "error",
                info: { database: { status: "down" } },
                error: "Database not reachable",
                details: error.response?.details || error.message,
            });
        }
    }
    checkLive(res) {
        if (global.isShuttingDown) {
            return res
                .status(common_1.HttpStatus.INTERNAL_SERVER_ERROR)
                .send({ status: "shutting_down" });
        }
        return res.status(common_1.HttpStatus.OK).send({ status: "up" });
    }
};
exports.HealthController = HealthController;
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: "Basic connectivity check" }),
    openapi.ApiResponse({ status: 200 }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], HealthController.prototype, "check", null);
__decorate([
    (0, common_1.Get)("ready"),
    (0, terminus_1.HealthCheck)(),
    (0, swagger_1.ApiOperation)({ summary: "Readiness probe (Database connectivity)" }),
    openapi.ApiResponse({ status: 200, type: Object }),
    __param(0, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], HealthController.prototype, "checkReady", null);
__decorate([
    (0, common_1.Get)("live"),
    (0, swagger_1.ApiOperation)({ summary: "Liveness probe (Process health)" }),
    openapi.ApiResponse({ status: 200, type: Object }),
    __param(0, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], HealthController.prototype, "checkLive", null);
exports.HealthController = HealthController = __decorate([
    (0, swagger_1.ApiTags)("Health"),
    (0, common_1.Controller)("health"),
    __metadata("design:paramtypes", [terminus_1.HealthCheckService,
        terminus_1.PrismaHealthIndicator,
        prisma_service_1.PrismaService])
], HealthController);
//# sourceMappingURL=health.controller.js.map