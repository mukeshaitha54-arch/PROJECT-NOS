import { HealthCheckService, PrismaHealthIndicator } from "@nestjs/terminus";
import { PrismaService } from "../../database/prisma.service";
declare global {
    var isShuttingDown: boolean;
}
export declare class HealthController {
    private health;
    private prismaHealth;
    private prisma;
    constructor(health: HealthCheckService, prismaHealth: PrismaHealthIndicator, prisma: PrismaService);
    check(): {
        status: string;
        uptime: number;
        timestamp: string;
        version: string;
    };
    checkReady(res: any): Promise<any>;
    checkLive(res: any): any;
}
