"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var DeviceTimelineQueryService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeviceTimelineQueryService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma/prisma.service");
let DeviceTimelineQueryService = DeviceTimelineQueryService_1 = class DeviceTimelineQueryService {
    prisma;
    logger = new common_1.Logger(DeviceTimelineQueryService_1.name);
    constructor(prisma) {
        this.prisma = prisma;
    }
    async getTimeline(params) {
        const { deviceId, page, limit } = params;
        const skip = (page - 1) * limit;
        const device = await this.prisma.device.findUnique({
            where: { id: deviceId },
        });
        if (!device) {
            throw new common_1.NotFoundException(`Device with ID [${deviceId}] not found.`);
        }
        const [total, events] = await Promise.all([
            this.prisma.deviceTimelineEvent.count({ where: { deviceId } }),
            this.prisma.deviceTimelineEvent.findMany({
                where: { deviceId },
                orderBy: { timestamp: "desc" },
                skip,
                take: limit,
            }),
        ]);
        const data = events.map((event) => ({
            id: event.id,
            deviceId: event.deviceId,
            eventType: event.eventType,
            severity: event.severity,
            title: event.title,
            detail: event.detail,
            description: event.detail || event.title,
            actor: event.actorName || event.actorId || "System",
            actorId: event.actorId,
            actorName: event.actorName,
            relatedId: event.relatedId,
            relatedType: event.relatedType,
            metadata: event.metadata || {},
            timestamp: event.timestamp,
            createdAt: event.timestamp,
        }));
        return {
            success: true,
            data,
            meta: {
                total,
                page,
                limit,
            },
        };
    }
};
exports.DeviceTimelineQueryService = DeviceTimelineQueryService;
exports.DeviceTimelineQueryService = DeviceTimelineQueryService = DeviceTimelineQueryService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], DeviceTimelineQueryService);
//# sourceMappingURL=device-timeline.service.js.map