"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeviceModule = void 0;
const common_1 = require("@nestjs/common");
const device_controller_1 = require("./device.controller");
const device_timeline_controller_1 = require("./device-timeline.controller");
const device_service_1 = require("./device.service");
const device_timeline_service_1 = require("./services/device-timeline.service");
const device_timeline_service_2 = require("./device-timeline.service");
const timeline_handler_1 = require("./handlers/timeline.handler");
const prisma_device_repository_1 = require("../../database/repositories/prisma-device.repository");
const prisma_heartbeat_repository_1 = require("../../database/repositories/prisma-heartbeat.repository");
const token_device_authenticator_service_1 = require("../../common/services/token-device-authenticator.service");
const device_repository_interface_1 = require("../../common/repositories/device.repository.interface");
const heartbeat_repository_interface_1 = require("../../common/repositories/heartbeat.repository.interface");
const device_authenticator_interface_1 = require("../../common/services/device-authenticator.interface");
const fleet_module_1 = require("../fleet/fleet.module");
let DeviceModule = class DeviceModule {
};
exports.DeviceModule = DeviceModule;
exports.DeviceModule = DeviceModule = __decorate([
    (0, common_1.Module)({
        imports: [(0, common_1.forwardRef)(() => fleet_module_1.FleetModule)],
        controllers: [device_controller_1.DeviceController, device_timeline_controller_1.DeviceTimelineController],
        providers: [
            device_service_1.DeviceService,
            device_timeline_service_1.DeviceTimelineService,
            device_timeline_service_2.DeviceTimelineQueryService,
            timeline_handler_1.TimelineHandler,
            { provide: device_repository_interface_1.IDeviceRepositoryToken, useClass: prisma_device_repository_1.PrismaDeviceRepository },
            { provide: heartbeat_repository_interface_1.IHeartbeatRepositoryToken, useClass: prisma_heartbeat_repository_1.PrismaHeartbeatRepository },
            {
                provide: device_authenticator_interface_1.IDeviceAuthenticatorToken,
                useClass: token_device_authenticator_service_1.TokenDeviceAuthenticatorService,
            },
        ],
        exports: [
            device_service_1.DeviceService,
            device_timeline_service_1.DeviceTimelineService,
            device_timeline_service_2.DeviceTimelineQueryService,
            device_repository_interface_1.IDeviceRepositoryToken,
            heartbeat_repository_interface_1.IHeartbeatRepositoryToken,
            device_authenticator_interface_1.IDeviceAuthenticatorToken,
        ],
    })
], DeviceModule);
//# sourceMappingURL=device.module.js.map