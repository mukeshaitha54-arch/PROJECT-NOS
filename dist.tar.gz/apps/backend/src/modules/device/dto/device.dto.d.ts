import { RegisterDevicePayload, HeartbeatPayload } from "@nos/shared-types";
export declare class RegisterDeviceDto implements RegisterDevicePayload {
    uuid: string;
    hostname: string;
    deviceName: string;
    os: string;
    osVersion: string;
    architecture: string;
    agentVersion: string;
    registrationKey?: string;
    organizationId?: string;
}
export declare class HeartbeatProcessDto {
    pid?: number;
    name?: string;
    processName?: string;
    memoryBytes?: number;
    memoryMb?: number;
    cpuTimeSec?: number;
    threads?: number;
    status?: string;
}
export declare class HeartbeatDto implements HeartbeatPayload {
    deviceId?: string;
    cpuUsage: number;
    ramUsage: number;
    uptime: number;
    ipAddress: string;
    timestamp: string;
    hostname?: string;
    os?: string;
    status?: string;
    runningProcesses?: number;
    activeConnections?: number;
    diskReadSpeed?: number;
    diskWriteSpeed?: number;
    networkUploadSpeed?: number;
    networkDownloadSpeed?: number;
    processes?: HeartbeatProcessDto[];
}
