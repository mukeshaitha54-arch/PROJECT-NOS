"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.HeartbeatDto = exports.HeartbeatProcessDto = exports.RegisterDeviceDto = void 0;
const openapi = require("@nestjs/swagger");
const swagger_1 = require("@nestjs/swagger");
const class_validator_1 = require("class-validator");
const class_transformer_1 = require("class-transformer");
class RegisterDeviceDto {
    uuid;
    hostname;
    deviceName;
    os;
    osVersion;
    architecture;
    agentVersion;
    registrationKey;
    organizationId;
    static _OPENAPI_METADATA_FACTORY() {
        return { uuid: { required: true, type: () => String }, hostname: { required: true, type: () => String }, deviceName: { required: true, type: () => String }, os: { required: true, type: () => String }, osVersion: { required: true, type: () => String }, architecture: { required: true, type: () => String }, agentVersion: { required: true, type: () => String }, registrationKey: { required: false, type: () => String }, organizationId: { required: false, type: () => String } };
    }
}
exports.RegisterDeviceDto = RegisterDeviceDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        example: "a1b2c3d4-e5f6-7a8b-9c0d-e1f2a3b4c5d6",
        description: "Unique Hardware GUID or machine UUID",
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], RegisterDeviceDto.prototype, "uuid", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        example: "WIN-SRV-CORE-01",
        description: "Machine hostname or FQDN",
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], RegisterDeviceDto.prototype, "hostname", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        example: "Primary Enterprise Domain Server",
        description: "Friendly monitoring device title",
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], RegisterDeviceDto.prototype, "deviceName", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        example: "Windows Server 2022 Datacenter",
        description: "Operating system flavor",
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], RegisterDeviceDto.prototype, "os", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        example: "10.0.20348",
        description: "Operating system version or kernel build",
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], RegisterDeviceDto.prototype, "osVersion", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        example: "X64",
        description: "Processor architecture (X64, Arm64)",
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], RegisterDeviceDto.prototype, "architecture", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        example: "2.0.0-phase2a",
        description: "NOS Monitoring Agent release version",
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], RegisterDeviceDto.prototype, "agentVersion", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: "NOS-ABCD-1234-5678-9012",
        description: "Registration Key to authenticate and associate with an organization",
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], RegisterDeviceDto.prototype, "registrationKey", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: "org-uuid",
        description: "Optional explicit organization ID for operational acceptance tests",
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], RegisterDeviceDto.prototype, "organizationId", void 0);
class HeartbeatProcessDto {
    pid;
    name;
    processName;
    memoryBytes;
    memoryMb;
    cpuTimeSec;
    threads;
    status;
    static _OPENAPI_METADATA_FACTORY() {
        return { pid: { required: false, type: () => Number }, name: { required: false, type: () => String }, processName: { required: false, type: () => String }, memoryBytes: { required: false, type: () => Number }, memoryMb: { required: false, type: () => Number }, cpuTimeSec: { required: false, type: () => Number }, threads: { required: false, type: () => Number }, status: { required: false, type: () => String } };
    }
}
exports.HeartbeatProcessDto = HeartbeatProcessDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 1234 }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], HeartbeatProcessDto.prototype, "pid", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "chrome.exe" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], HeartbeatProcessDto.prototype, "name", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "chrome" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], HeartbeatProcessDto.prototype, "processName", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 104857600 }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], HeartbeatProcessDto.prototype, "memoryBytes", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 100.5 }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], HeartbeatProcessDto.prototype, "memoryMb", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 15.2 }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], HeartbeatProcessDto.prototype, "cpuTimeSec", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 12 }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], HeartbeatProcessDto.prototype, "threads", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "Running" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], HeartbeatProcessDto.prototype, "status", void 0);
class HeartbeatDto {
    deviceId;
    cpuUsage;
    ramUsage;
    uptime;
    ipAddress;
    timestamp;
    hostname;
    os;
    status;
    runningProcesses;
    activeConnections;
    diskReadSpeed;
    diskWriteSpeed;
    networkUploadSpeed;
    networkDownloadSpeed;
    processes;
    static _OPENAPI_METADATA_FACTORY() {
        return { deviceId: { required: false, type: () => String }, cpuUsage: { required: true, type: () => Number, minimum: 0, maximum: 100 }, ramUsage: { required: true, type: () => Number, minimum: 0, maximum: 100 }, uptime: { required: true, type: () => Number, minimum: 0 }, ipAddress: { required: true, type: () => String }, timestamp: { required: true, type: () => String }, hostname: { required: false, type: () => String }, os: { required: false, type: () => String }, status: { required: false, type: () => String }, runningProcesses: { required: false, type: () => Number, minimum: 0 }, activeConnections: { required: false, type: () => Number, minimum: 0 }, diskReadSpeed: { required: false, type: () => Number, minimum: 0 }, diskWriteSpeed: { required: false, type: () => Number, minimum: 0 }, networkUploadSpeed: { required: false, type: () => Number, minimum: 0 }, networkDownloadSpeed: { required: false, type: () => Number, minimum: 0 }, processes: { required: false, type: () => [require("./device.dto").HeartbeatProcessDto] } };
    }
}
exports.HeartbeatDto = HeartbeatDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: "device-id-uuid-string",
        description: "Optional explicit device ID (otherwise derived from secure auth token)",
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], HeartbeatDto.prototype, "deviceId", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        example: 14.5,
        description: "Current CPU load percentage (0.0 to 100.0)",
    }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    (0, class_validator_1.Max)(100),
    __metadata("design:type", Number)
], HeartbeatDto.prototype, "cpuUsage", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        example: 62.8,
        description: "Current Memory utilization percentage (0.0 to 100.0)",
    }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    (0, class_validator_1.Max)(100),
    __metadata("design:type", Number)
], HeartbeatDto.prototype, "ramUsage", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        example: 86400.5,
        description: "Total system operational continuous uptime in seconds",
    }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], HeartbeatDto.prototype, "uptime", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        example: "192.168.10.45",
        description: "Agent originating IPv4 or IPv6 network address",
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], HeartbeatDto.prototype, "ipAddress", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        example: "2026-07-25T17:00:00.000Z",
        description: "Heartbeat sample timestamp in ISO 8601 format",
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], HeartbeatDto.prototype, "timestamp", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: "WIN-SRV-CORE-01",
        description: "Optional diagnostic hostname mirror",
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], HeartbeatDto.prototype, "hostname", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: "Windows Server 2022",
        description: "Optional diagnostic OS mirror",
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], HeartbeatDto.prototype, "os", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: "online",
        description: "Agent operational health status (online, error, critical)",
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], HeartbeatDto.prototype, "status", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: 214,
        description: "Number of running OS processes",
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], HeartbeatDto.prototype, "runningProcesses", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: 48,
        description: "Number of active TCP connections",
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], HeartbeatDto.prototype, "activeConnections", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: 12.5,
        description: "Disk read speed in MB/s",
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], HeartbeatDto.prototype, "diskReadSpeed", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: 3.2,
        description: "Disk write speed in MB/s",
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], HeartbeatDto.prototype, "diskWriteSpeed", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: 1.4,
        description: "Network upload speed in Mbps",
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], HeartbeatDto.prototype, "networkUploadSpeed", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: 8.7,
        description: "Network download speed in Mbps",
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], HeartbeatDto.prototype, "networkDownloadSpeed", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        description: "Snapshot of active top OS processes",
        type: [HeartbeatProcessDto],
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => HeartbeatProcessDto),
    __metadata("design:type", Array)
], HeartbeatDto.prototype, "processes", void 0);
//# sourceMappingURL=device.dto.js.map