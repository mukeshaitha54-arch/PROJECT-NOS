"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeviceController = void 0;
const openapi = require("@nestjs/swagger");
const common_1 = require("@nestjs/common");
const throttler_1 = require("@nestjs/throttler");
const swagger_1 = require("@nestjs/swagger");
const device_service_1 = require("./device.service");
const device_dto_1 = require("./dto/device.dto");
const device_auth_guard_1 = require("./guards/device-auth.guard");
const current_device_decorator_1 = require("./decorators/current-device.decorator");
const current_user_decorator_1 = require("../../common/decorators/current-user.decorator");
const jwt_auth_guard_1 = require("../../common/guards/jwt-auth.guard");
const optional_jwt_auth_guard_1 = require("../../common/guards/optional-jwt-auth.guard");
const alert_rule_engine_service_1 = require("../alerts/alert-rule-engine.service");
let DeviceController = class DeviceController {
    deviceService;
    alertRuleEngine;
    constructor(deviceService, alertRuleEngine) {
        this.deviceService = deviceService;
        this.alertRuleEngine = alertRuleEngine;
    }
    async register(dto, req) {
        const ipAddress = req.ip || req.socket.remoteAddress;
        const data = await this.deviceService.register(dto, ipAddress);
        return {
            success: true,
            message: "Monitoring agent successfully registered with NOS Zero-Trust control plane.",
            data,
        };
    }
    async heartbeat(device, dto) {
        const data = await this.deviceService.recordHeartbeat(device, dto);
        if (dto.status && dto.status.toLowerCase() !== "online") {
            const orgId = device.tenantId ||
                device.organizationId ||
                "default-org";
            this.alertRuleEngine
                .evaluateTelemetry(device.id, orgId, {
                cpu: 100,
                ram: 100,
                disk: 100,
                network: 999999999,
                timestamp: new Date(),
            })
                .catch((err) => { });
        }
        return {
            success: true,
            message: "Heartbeat recorded.",
            data,
        };
    }
    async getMe(device) {
        const data = await this.deviceService.getDeviceProfile(device);
        return {
            success: true,
            data,
        };
    }
    async getStatus(user) {
        const organizationId = user?.organizationId || user?.organization?.id || undefined;
        const data = await this.deviceService.getPlatformStatus(organizationId);
        return {
            success: true,
            data,
        };
    }
    async getUnassignedDevices(orgId) {
        const data = await this.deviceService.getUnassignedDevices(orgId);
        return {
            success: true,
            data,
        };
    }
    async claimDevice(id, organizationId, teamId, departmentId, user) {
        if (!user)
            throw new common_1.UnauthorizedException("Must be logged in to claim device");
        const data = await this.deviceService.claimDevice(id, organizationId, user.id, teamId, departmentId);
        return {
            success: true,
            message: "Device claimed successfully.",
            data,
        };
    }
    async getDeviceById(id, user) {
        const organizationId = user?.organizationId || user?.organization?.id || undefined;
        const data = await this.deviceService.getDeviceById(id, organizationId);
        return {
            success: true,
            data,
        };
    }
    async setMaintenanceMode(id, enabled) {
        const data = await this.deviceService.setMaintenanceMode(id, enabled);
        return {
            success: true,
            message: enabled
                ? "Device placed in maintenance mode."
                : "Device maintenance mode disabled.",
            data,
        };
    }
    async retireDevice(id) {
        const data = await this.deviceService.retireDevice(id);
        return {
            success: true,
            message: "Device retired.",
            data,
        };
    }
    async downloadAgent(req, res) {
        const installerPath = require("path").join(process.cwd(), "..", "..", "apps", "installer", "NOS.Installer", "bin", "Release", "net8.0-windows", "win-x64", "publish", "NOS.Installer.exe");
        if (require("fs").existsSync(installerPath)) {
            return res.download(installerPath, "NOS_Agent_Installer.exe");
        }
        return res
            .status(404)
            .send({ success: false, message: "Installer not compiled or missing." });
    }
    async bulkUpdateStatus(deviceIds, status) {
        const data = await this.deviceService.bulkUpdateStatus(deviceIds, status);
        return {
            success: true,
            message: `Bulk updated status for ${data.updatedCount} devices.`,
            data,
        };
    }
};
exports.DeviceController = DeviceController;
__decorate([
    (0, common_1.Post)("register"),
    (0, common_1.HttpCode)(common_1.HttpStatus.CREATED),
    (0, swagger_1.ApiOperation)({
        summary: "Register a new monitoring agent",
        description: "Provisions unique device hardware identity and returns registration token.",
    }),
    (0, swagger_1.ApiResponse)({
        status: 201,
        description: "Device registered successfully; returns deviceId and registrationToken.",
    }),
    (0, swagger_1.ApiResponse)({
        status: 400,
        description: "Invalid device payload parameters.",
    }),
    openapi.ApiResponse({ status: common_1.HttpStatus.CREATED }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [device_dto_1.RegisterDeviceDto, Object]),
    __metadata("design:returntype", Promise)
], DeviceController.prototype, "register", null);
__decorate([
    (0, common_1.Post)("heartbeat"),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, common_1.UseGuards)(device_auth_guard_1.DeviceAuthGuard),
    (0, swagger_1.ApiOperation)({
        summary: "Agent diagnostic heartbeat ingestion (Every 30 seconds)",
        description: "Records basic CPU/RAM operational health and refreshes Last Seen timer.",
    }),
    (0, swagger_1.ApiHeader)({
        name: "X-Device-Token",
        required: true,
        description: "Cryptographic agent registration credentials",
    }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: "Heartbeat ingested and device status marked ONLINE.",
    }),
    (0, swagger_1.ApiResponse)({
        status: 401,
        description: "Missing or unrecognized device authentication token.",
    }),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK }),
    __param(0, (0, current_device_decorator_1.CurrentDevice)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, device_dto_1.HeartbeatDto]),
    __metadata("design:returntype", Promise)
], DeviceController.prototype, "heartbeat", null);
__decorate([
    (0, common_1.Get)("me"),
    (0, common_1.UseGuards)(device_auth_guard_1.DeviceAuthGuard),
    (0, swagger_1.ApiOperation)({
        summary: "Retrieve authenticated device profile",
        description: "Returns current registered device details and latest recorded heartbeat.",
    }),
    (0, swagger_1.ApiHeader)({
        name: "X-Device-Token",
        required: true,
        description: "Cryptographic agent registration credentials",
    }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: "Device identity profile returned successfully.",
    }),
    (0, swagger_1.ApiResponse)({ status: 401, description: "Unauthorized agent session." }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, current_device_decorator_1.CurrentDevice)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], DeviceController.prototype, "getMe", null);
__decorate([
    (0, common_1.Get)("status"),
    (0, common_1.UseGuards)(optional_jwt_auth_guard_1.OptionalJwtAuthGuard),
    (0, swagger_1.ApiOperation)({
        summary: "Retrieve real-time platform device status and heartbeat roster",
        description: "Returns devices scoped to the authenticated user's organization. Unauthenticated requests return all devices (legacy).",
    }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: "Platform heartbeat status retrieved successfully.",
    }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], DeviceController.prototype, "getStatus", null);
__decorate([
    (0, common_1.Get)("unassigned/:orgId"),
    (0, swagger_1.ApiOperation)({ summary: "Retrieve unassigned devices for an organization" }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: "Unassigned devices retrieved successfully.",
    }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)("orgId")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], DeviceController.prototype, "getUnassignedDevices", null);
__decorate([
    (0, common_1.Post)(":id/claim"),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({ summary: "Claim an unassigned device" }),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK }),
    __param(0, (0, common_1.Param)("id")),
    __param(1, (0, common_1.Body)("organizationId")),
    __param(2, (0, common_1.Body)("teamId")),
    __param(3, (0, common_1.Body)("departmentId")),
    __param(4, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String, Object]),
    __metadata("design:returntype", Promise)
], DeviceController.prototype, "claimDevice", null);
__decorate([
    (0, common_1.Get)(":id"),
    (0, common_1.UseGuards)(optional_jwt_auth_guard_1.OptionalJwtAuthGuard),
    (0, swagger_1.ApiOperation)({
        summary: "Retrieve specific registered machine profile by primary DB ID or UUID",
        description: "Returns complete hardware profile and latest diagnostic heartbeat sample for target device.",
    }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: "Device profile and heartbeat retrieved successfully.",
    }),
    (0, swagger_1.ApiResponse)({ status: 404, description: "Device not found in registry." }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)("id")),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], DeviceController.prototype, "getDeviceById", null);
__decorate([
    (0, common_1.Post)(":id/maintenance"),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({
        summary: "Toggle device maintenance mode",
        description: "Places device in maintenance mode to suspend alert rule evaluations during scheduled servicing.",
    }),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK }),
    __param(0, (0, common_1.Param)("id")),
    __param(1, (0, common_1.Body)("enabled")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Boolean]),
    __metadata("design:returntype", Promise)
], DeviceController.prototype, "setMaintenanceMode", null);
__decorate([
    (0, common_1.Post)(":id/retire"),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({ summary: "Retire device from active monitoring roster" }),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK }),
    __param(0, (0, common_1.Param)("id")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], DeviceController.prototype, "retireDevice", null);
__decorate([
    (0, common_1.Get)("download"),
    (0, swagger_1.ApiOperation)({ summary: "Download the NOS Windows Agent Installer" }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: "Returns the installer executable.",
    }),
    openapi.ApiResponse({ status: 200, type: Object }),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], DeviceController.prototype, "downloadAgent", null);
__decorate([
    (0, common_1.Post)("bulk/status"),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({ summary: "Bulk update status for multiple devices" }),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK }),
    __param(0, (0, common_1.Body)("deviceIds")),
    __param(1, (0, common_1.Body)("status")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Array, Object]),
    __metadata("design:returntype", Promise)
], DeviceController.prototype, "bulkUpdateStatus", null);
exports.DeviceController = DeviceController = __decorate([
    (0, throttler_1.SkipThrottle)(),
    (0, throttler_1.SkipThrottle)({ default: true, auth: true, telemetry: true }),
    (0, swagger_1.ApiTags)("Device Onboarding & Heartbeat (Phase 2A)"),
    (0, common_1.Controller)("device"),
    __metadata("design:paramtypes", [device_service_1.DeviceService,
        alert_rule_engine_service_1.AlertRuleEngineService])
], DeviceController);
//# sourceMappingURL=device.controller.js.map