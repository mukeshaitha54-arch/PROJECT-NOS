"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var DeviceTimelineService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeviceTimelineService = void 0;
const common_1 = require("@nestjs/common");
const device_timeline_repository_interface_1 = require("../../../common/repositories/device-timeline.repository.interface");
let DeviceTimelineService = DeviceTimelineService_1 = class DeviceTimelineService {
    timelineRepo;
    logger = new common_1.Logger(DeviceTimelineService_1.name);
    constructor(timelineRepo) {
        this.timelineRepo = timelineRepo;
    }
    async logEvent(dto) {
        try {
            const event = await this.timelineRepo.append(dto);
            this.logger.debug(`[Timeline] Logged ${dto.eventType} for device ${dto.deviceId}: "${dto.title}"`);
            return event;
        }
        catch (err) {
            this.logger.error(`[Timeline] Failed to log event for device ${dto.deviceId}: ${err?.message}`);
            throw err;
        }
    }
    async getPaginatedTimeline(options) {
        return this.timelineRepo.getPaginated(options);
    }
    async getRecentTimeline(deviceId, limit = 10) {
        return this.timelineRepo.getRecent(deviceId, limit);
    }
};
exports.DeviceTimelineService = DeviceTimelineService;
exports.DeviceTimelineService = DeviceTimelineService = DeviceTimelineService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(device_timeline_repository_interface_1.IDeviceTimelineRepository)),
    __metadata("design:paramtypes", [Object])
], DeviceTimelineService);
//# sourceMappingURL=device-timeline.service.js.map