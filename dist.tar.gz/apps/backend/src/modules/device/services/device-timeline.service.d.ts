import { IDeviceTimelineRepository, CreateTimelineEventDto, TimelineEventDto, TimelineQueryOptions, PaginatedTimelineResponse } from "../../../common/repositories/device-timeline.repository.interface";
export declare class DeviceTimelineService {
    private readonly timelineRepo;
    private readonly logger;
    constructor(timelineRepo: IDeviceTimelineRepository);
    logEvent(dto: CreateTimelineEventDto): Promise<TimelineEventDto>;
    getPaginatedTimeline(options: TimelineQueryOptions): Promise<PaginatedTimelineResponse>;
    getRecentTimeline(deviceId: string, limit?: number): Promise<TimelineEventDto[]>;
}
