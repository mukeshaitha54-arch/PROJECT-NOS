"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeviceTimelineController = void 0;
const openapi = require("@nestjs/swagger");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const jwt_auth_guard_1 = require("../auth/guards/jwt-auth.guard");
const tenant_guard_1 = require("../auth/guards/tenant.guard");
const device_timeline_service_1 = require("./device-timeline.service");
let DeviceTimelineController = class DeviceTimelineController {
    timelineService;
    constructor(timelineService) {
        this.timelineService = timelineService;
    }
    async getDeviceTimeline(deviceId, page, limit) {
        const pageNum = Number(page) && Number(page) > 0 ? Number(page) : 1;
        const limitNum = Number(limit) && Number(limit) > 0 ? Number(limit) : 20;
        return this.timelineService.getTimeline({
            deviceId,
            page: pageNum,
            limit: limitNum,
        });
    }
};
exports.DeviceTimelineController = DeviceTimelineController;
__decorate([
    (0, common_1.Get)(":deviceId/timeline"),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({
        summary: "Get paginated audit and event timeline for a specific device",
    }),
    (0, swagger_1.ApiParam)({ name: "deviceId", description: "Unique ID of the device" }),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK }),
    __param(0, (0, common_1.Param)("deviceId")),
    __param(1, (0, common_1.Query)("page")),
    __param(2, (0, common_1.Query)("limit")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Number, Number]),
    __metadata("design:returntype", Promise)
], DeviceTimelineController.prototype, "getDeviceTimeline", null);
exports.DeviceTimelineController = DeviceTimelineController = __decorate([
    (0, swagger_1.ApiTags)("Device Timeline & Events"),
    (0, common_1.Controller)("device"),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, tenant_guard_1.TenantGuard),
    (0, swagger_1.ApiBearerAuth)(),
    __metadata("design:paramtypes", [device_timeline_service_1.DeviceTimelineQueryService])
], DeviceTimelineController);
//# sourceMappingURL=device-timeline.controller.js.map