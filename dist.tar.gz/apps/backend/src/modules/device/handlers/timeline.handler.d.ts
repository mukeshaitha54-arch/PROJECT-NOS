import { DeviceTimelineService } from "../services/device-timeline.service";
import { DeviceRegisteredEvent, DeviceReconnectedEvent, HeartbeatReceivedEvent, DeviceOfflineEvent, DeviceMaintenanceEvent, DeviceRetiredEvent, DeviceClaimedEvent, DeviceBulkStatusEvent, InventoryUpdatedEvent } from "../../../common/events/domain-events";
export declare class TimelineHandler {
    private readonly timelineService;
    private readonly logger;
    constructor(timelineService: DeviceTimelineService);
    onDeviceRegistered(event: DeviceRegisteredEvent): Promise<void>;
    onDeviceReconnected(event: DeviceReconnectedEvent): Promise<void>;
    onHeartbeatReceived(event: HeartbeatReceivedEvent): Promise<void>;
    onDeviceOffline(event: DeviceOfflineEvent): Promise<void>;
    onDeviceMaintenance(event: DeviceMaintenanceEvent): Promise<void>;
    onDeviceRetired(event: DeviceRetiredEvent): Promise<void>;
    onDeviceClaimed(event: DeviceClaimedEvent): Promise<void>;
    onBulkStatus(event: DeviceBulkStatusEvent): Promise<void>;
    onInventoryUpdated(event: InventoryUpdatedEvent): Promise<void>;
}
