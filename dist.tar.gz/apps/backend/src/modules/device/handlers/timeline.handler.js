"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var TimelineHandler_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.TimelineHandler = void 0;
const common_1 = require("@nestjs/common");
const event_emitter_1 = require("@nestjs/event-emitter");
const device_timeline_service_1 = require("../services/device-timeline.service");
const domain_events_1 = require("../../../common/events/domain-events");
let TimelineHandler = TimelineHandler_1 = class TimelineHandler {
    timelineService;
    logger = new common_1.Logger(TimelineHandler_1.name);
    constructor(timelineService) {
        this.timelineService = timelineService;
    }
    async onDeviceRegistered(event) {
        try {
            await this.timelineService.logEvent({
                deviceId: event.deviceId,
                eventType: "REGISTERED",
                severity: "INFO",
                title: "Agent Registered",
                detail: `Monitoring agent registered for host ${event.hostname} (${event.os} ${event.architecture}, Agent v${event.agentVersion}).`,
                metadata: {
                    os: event.os,
                    osVersion: event.osVersion,
                    agentVersion: event.agentVersion,
                    correlationId: event.correlationId,
                },
            });
        }
        catch (err) {
            this.logger.error(`Timeline write failed for ${event.eventType}: ${err.message}`);
        }
    }
    async onDeviceReconnected(event) {
        try {
            await this.timelineService.logEvent({
                deviceId: event.deviceId,
                eventType: "ONLINE",
                severity: "SUCCESS",
                title: "Agent Reconnected",
                detail: `Agent re-established Zero-Trust session from host ${event.hostname}.`,
                metadata: { correlationId: event.correlationId },
            });
        }
        catch (err) {
            this.logger.error(`Timeline write failed for ${event.eventType}: ${err.message}`);
        }
    }
    async onHeartbeatReceived(event) {
        try {
            if (event.wasOffline) {
                await this.timelineService.logEvent({
                    deviceId: event.deviceId,
                    eventType: "ONLINE",
                    severity: "SUCCESS",
                    title: "Device Reconnected",
                    detail: `Device returned ONLINE via live heartbeat ingestion (${event.ipAddress}).`,
                    metadata: {
                        ipAddress: event.ipAddress,
                        cpuUsage: event.cpuUsage,
                        ramUsage: event.ramUsage,
                        correlationId: event.correlationId,
                    },
                });
            }
        }
        catch (err) {
            this.logger.error(`Timeline write failed for ${event.eventType}: ${err.message}`);
        }
    }
    async onDeviceOffline(event) {
        try {
            await this.timelineService.logEvent({
                deviceId: event.deviceId,
                eventType: "OFFLINE",
                severity: "WARNING",
                title: "Device Offline",
                detail: `Device marked OFFLINE: ${event.reason}.`,
                metadata: { correlationId: event.correlationId },
            });
        }
        catch (err) {
            this.logger.error(`Timeline write failed for ${event.eventType}: ${err.message}`);
        }
    }
    async onDeviceMaintenance(event) {
        try {
            await this.timelineService.logEvent({
                deviceId: event.deviceId,
                eventType: event.enabled ? "MAINTENANCE_START" : "MAINTENANCE_END",
                severity: "INFO",
                title: event.enabled
                    ? "Maintenance Mode Enabled"
                    : "Maintenance Mode Disabled",
                detail: event.enabled
                    ? `Device placed in maintenance mode by ${event.actorName || "operator"}. Alert evaluation suspended.`
                    : `Device resumed active operational monitoring.`,
                actorId: event.actorId,
                actorName: event.actorName,
                metadata: { correlationId: event.correlationId },
            });
        }
        catch (err) {
            this.logger.error(`Timeline write failed for ${event.eventType}: ${err.message}`);
        }
    }
    async onDeviceRetired(event) {
        try {
            await this.timelineService.logEvent({
                deviceId: event.deviceId,
                eventType: "OFFLINE",
                severity: "WARNING",
                title: "Device Retired",
                detail: `Device retired from active operations by ${event.actorName || "administrator"}.`,
                actorId: event.actorId,
                actorName: event.actorName,
                metadata: { correlationId: event.correlationId },
            });
        }
        catch (err) {
            this.logger.error(`Timeline write failed for ${event.eventType}: ${err.message}`);
        }
    }
    async onDeviceClaimed(event) {
        try {
            await this.timelineService.logEvent({
                deviceId: event.deviceId,
                eventType: "SYSTEM_EVENT",
                severity: "SUCCESS",
                title: "Device Claimed",
                detail: `Device was claimed and assigned to a team/department by operator.`,
                actorId: event.claimedByUserId,
                metadata: {
                    teamId: event.teamId,
                    departmentId: event.departmentId,
                    correlationId: event.correlationId,
                },
            });
        }
        catch (err) {
            this.logger.error(`Timeline write failed for ${event.eventType}: ${err.message}`);
        }
    }
    async onBulkStatus(event) {
        try {
            await this.timelineService.logEvent({
                deviceId: event.deviceId,
                eventType: event.newStatus === "MAINTENANCE"
                    ? "MAINTENANCE_START"
                    : "CONFIG_CHANGE",
                severity: "INFO",
                title: `Bulk Status Update: ${event.newStatus}`,
                detail: `Status updated to ${event.newStatus} via bulk operations toolbar.`,
                actorId: event.actorId,
                actorName: event.actorName,
                metadata: { correlationId: event.correlationId },
            });
        }
        catch (err) {
            this.logger.error(`Timeline write failed for ${event.eventType}: ${err.message}`);
        }
    }
    async onInventoryUpdated(event) {
        try {
            await this.timelineService.logEvent({
                deviceId: event.deviceId,
                eventType: event.diffDetected ? "INVENTORY_DIFF" : "INVENTORY_UPDATED",
                severity: event.diffDetected ? "WARNING" : "INFO",
                title: event.diffDetected
                    ? "Inventory Change Detected"
                    : "Inventory Snapshot Updated",
                detail: event.changeSummary ||
                    `Inventory version ${event.inventoryVersion} recorded.`,
                metadata: {
                    inventoryVersion: event.inventoryVersion,
                    fingerprint: event.fingerprint,
                    correlationId: event.correlationId,
                },
            });
        }
        catch (err) {
            this.logger.error(`Timeline write failed for ${event.eventType}: ${err.message}`);
        }
    }
};
exports.TimelineHandler = TimelineHandler;
__decorate([
    (0, event_emitter_1.OnEvent)(domain_events_1.DomainEventNames.DEVICE_REGISTERED),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [domain_events_1.DeviceRegisteredEvent]),
    __metadata("design:returntype", Promise)
], TimelineHandler.prototype, "onDeviceRegistered", null);
__decorate([
    (0, event_emitter_1.OnEvent)(domain_events_1.DomainEventNames.DEVICE_RECONNECTED),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [domain_events_1.DeviceReconnectedEvent]),
    __metadata("design:returntype", Promise)
], TimelineHandler.prototype, "onDeviceReconnected", null);
__decorate([
    (0, event_emitter_1.OnEvent)(domain_events_1.DomainEventNames.HEARTBEAT_RECEIVED),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [domain_events_1.HeartbeatReceivedEvent]),
    __metadata("design:returntype", Promise)
], TimelineHandler.prototype, "onHeartbeatReceived", null);
__decorate([
    (0, event_emitter_1.OnEvent)(domain_events_1.DomainEventNames.DEVICE_OFFLINE),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [domain_events_1.DeviceOfflineEvent]),
    __metadata("design:returntype", Promise)
], TimelineHandler.prototype, "onDeviceOffline", null);
__decorate([
    (0, event_emitter_1.OnEvent)(domain_events_1.DomainEventNames.DEVICE_MAINTENANCE),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [domain_events_1.DeviceMaintenanceEvent]),
    __metadata("design:returntype", Promise)
], TimelineHandler.prototype, "onDeviceMaintenance", null);
__decorate([
    (0, event_emitter_1.OnEvent)(domain_events_1.DomainEventNames.DEVICE_RETIRED),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [domain_events_1.DeviceRetiredEvent]),
    __metadata("design:returntype", Promise)
], TimelineHandler.prototype, "onDeviceRetired", null);
__decorate([
    (0, event_emitter_1.OnEvent)(domain_events_1.DomainEventNames.DEVICE_CLAIMED),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [domain_events_1.DeviceClaimedEvent]),
    __metadata("design:returntype", Promise)
], TimelineHandler.prototype, "onDeviceClaimed", null);
__decorate([
    (0, event_emitter_1.OnEvent)(domain_events_1.DomainEventNames.DEVICE_BULK_STATUS),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [domain_events_1.DeviceBulkStatusEvent]),
    __metadata("design:returntype", Promise)
], TimelineHandler.prototype, "onBulkStatus", null);
__decorate([
    (0, event_emitter_1.OnEvent)(domain_events_1.DomainEventNames.INVENTORY_UPDATED),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [domain_events_1.InventoryUpdatedEvent]),
    __metadata("design:returntype", Promise)
], TimelineHandler.prototype, "onInventoryUpdated", null);
exports.TimelineHandler = TimelineHandler = TimelineHandler_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [device_timeline_service_1.DeviceTimelineService])
], TimelineHandler);
//# sourceMappingURL=timeline.handler.js.map