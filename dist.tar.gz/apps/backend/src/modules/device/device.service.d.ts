import { EventEmitter2 } from "@nestjs/event-emitter";
import { Device, DeviceStatus } from "@prisma/client";
import { RegisterDeviceDto, HeartbeatDto } from "./dto/device.dto";
import { IDeviceRepository } from "../../common/repositories/device.repository.interface";
import { IHeartbeatRepository } from "../../common/repositories/heartbeat.repository.interface";
import { IDeviceAuthenticator } from "../../common/services/device-authenticator.interface";
import { HeartbeatPresenceService } from "../realtime/services/heartbeat-presence.service";
import { DeviceTimelineService } from "./services/device-timeline.service";
import { RegistrationKeyService } from "../fleet/services/registration-key.service";
import { RegisterDeviceResponse, HeartbeatResponse, DeviceStatusResponse, Device as SharedDevice, Heartbeat as SharedHeartbeat } from "@nos/shared-types";
export declare class DeviceService {
    private readonly deviceRepository;
    private readonly heartbeatRepository;
    private readonly authenticator;
    private readonly heartbeatPresence;
    private readonly timelineService;
    private readonly registrationKeyService;
    private readonly eventEmitter;
    private readonly logger;
    private readonly STALE_HEARTBEAT_THRESHOLD_MS;
    constructor(deviceRepository: IDeviceRepository, heartbeatRepository: IHeartbeatRepository, authenticator: IDeviceAuthenticator, heartbeatPresence: HeartbeatPresenceService, timelineService: DeviceTimelineService, registrationKeyService: RegistrationKeyService, eventEmitter: EventEmitter2);
    getUnassignedDevices(organizationId: string): Promise<SharedDevice[]>;
    claimDevice(deviceId: string, organizationId: string, claimedByUserId: string, teamId?: string, departmentId?: string): Promise<SharedDevice>;
    register(dto: RegisterDeviceDto, ipAddress?: string): Promise<RegisterDeviceResponse>;
    recordHeartbeat(device: Device, dto: HeartbeatDto): Promise<HeartbeatResponse>;
    getDeviceProfile(device: Device): Promise<SharedDevice & {
        lastHeartbeat?: SharedHeartbeat | null;
        latestHeartbeat?: SharedHeartbeat | null;
    }>;
    getPlatformStatus(organizationId?: string): Promise<DeviceStatusResponse>;
    getDeviceById(id: string, organizationId?: string): Promise<SharedDevice & {
        lastHeartbeat?: SharedHeartbeat | null;
        latestHeartbeat?: SharedHeartbeat | null;
    }>;
    setMaintenanceMode(deviceId: string, enabled: boolean, actorId?: string, actorName?: string): Promise<SharedDevice>;
    retireDevice(deviceId: string, actorId?: string, actorName?: string): Promise<SharedDevice>;
    bulkUpdateStatus(deviceIds: string[], status: DeviceStatus, actorId?: string, actorName?: string): Promise<{
        updatedCount: number;
    }>;
    getDeviceTimeline(deviceId: string, page?: number, limit?: number): Promise<import("../../common/repositories/device-timeline.repository.interface").PaginatedTimelineResponse>;
    setTelemetryPause(deviceId: string, organizationId: string, paused: boolean): Promise<SharedDevice>;
    private sanitizeDevice;
    private sanitizeHeartbeat;
}
