import { Request } from "express";
import { Device } from "@prisma/client";
import { DeviceService } from "./device.service";
import { RegisterDeviceDto, HeartbeatDto } from "./dto/device.dto";
import { AlertRuleEngineService } from "../alerts/alert-rule-engine.service";
export declare class DeviceController {
    private readonly deviceService;
    private readonly alertRuleEngine;
    constructor(deviceService: DeviceService, alertRuleEngine: AlertRuleEngineService);
    register(dto: RegisterDeviceDto, req: Request): Promise<{
        success: boolean;
        message: string;
        data: import("@nos/shared-types").RegisterDeviceResponse;
    }>;
    heartbeat(device: Device, dto: HeartbeatDto): Promise<{
        success: boolean;
        message: string;
        data: import("@nos/shared-types").HeartbeatResponse;
    }>;
    getMe(device: Device): Promise<{
        success: boolean;
        data: import("@nos/shared-types").Device & {
            lastHeartbeat?: import("@nos/shared-types").Heartbeat | null;
            latestHeartbeat?: import("@nos/shared-types").Heartbeat | null;
        };
    }>;
    getStatus(user?: any): Promise<{
        success: boolean;
        data: import("@nos/shared-types").DeviceStatusResponse;
    }>;
    getUnassignedDevices(orgId: string): Promise<{
        success: boolean;
        data: import("@nos/shared-types").Device[];
    }>;
    claimDevice(id: string, organizationId: string, teamId?: string, departmentId?: string, user?: any): Promise<{
        success: boolean;
        message: string;
        data: import("@nos/shared-types").Device;
    }>;
    getDeviceById(id: string, user?: any): Promise<{
        success: boolean;
        data: import("@nos/shared-types").Device & {
            lastHeartbeat?: import("@nos/shared-types").Heartbeat | null;
            latestHeartbeat?: import("@nos/shared-types").Heartbeat | null;
        };
    }>;
    setMaintenanceMode(id: string, enabled: boolean): Promise<{
        success: boolean;
        message: string;
        data: import("@nos/shared-types").Device;
    }>;
    retireDevice(id: string): Promise<{
        success: boolean;
        message: string;
        data: import("@nos/shared-types").Device;
    }>;
    downloadAgent(req: Request, res: any): Promise<any>;
    bulkUpdateStatus(deviceIds: string[], status: any): Promise<{
        success: boolean;
        message: string;
        data: {
            updatedCount: number;
        };
    }>;
}
