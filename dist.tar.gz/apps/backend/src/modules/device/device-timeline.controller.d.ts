import { DeviceTimelineQueryService } from "./device-timeline.service";
export declare class DeviceTimelineController {
    private readonly timelineService;
    constructor(timelineService: DeviceTimelineQueryService);
    getDeviceTimeline(deviceId: string, page?: number, limit?: number): Promise<{
        success: boolean;
        data: {
            id: string;
            deviceId: string;
            eventType: import("@prisma/client").$Enums.TimelineEventType;
            severity: import("@prisma/client").$Enums.TimelineSeverity;
            title: string;
            detail: string;
            description: string;
            actor: string;
            actorId: string;
            actorName: string;
            relatedId: string;
            relatedType: string;
            metadata: string | number | true | import("@prisma/client/runtime/library").JsonObject | import("@prisma/client/runtime/library").JsonArray;
            timestamp: Date;
            createdAt: Date;
        }[];
        meta: {
            total: number;
            page: number;
            limit: number;
        };
    }>;
}
