export declare class DeviceModule {
}
