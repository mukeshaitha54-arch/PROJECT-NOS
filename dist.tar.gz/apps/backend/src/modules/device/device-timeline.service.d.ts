import { PrismaService } from "../prisma/prisma.service";
export interface DeviceTimelineParams {
    deviceId: string;
    page: number;
    limit: number;
}
export declare class DeviceTimelineQueryService {
    private readonly prisma;
    private readonly logger;
    constructor(prisma: PrismaService);
    getTimeline(params: DeviceTimelineParams): Promise<{
        success: boolean;
        data: {
            id: string;
            deviceId: string;
            eventType: import("@prisma/client").$Enums.TimelineEventType;
            severity: import("@prisma/client").$Enums.TimelineSeverity;
            title: string;
            detail: string;
            description: string;
            actor: string;
            actorId: string;
            actorName: string;
            relatedId: string;
            relatedType: string;
            metadata: string | number | true | import("@prisma/client/runtime/library").JsonObject | import("@prisma/client/runtime/library").JsonArray;
            timestamp: Date;
            createdAt: Date;
        }[];
        meta: {
            total: number;
            page: number;
            limit: number;
        };
    }>;
}
