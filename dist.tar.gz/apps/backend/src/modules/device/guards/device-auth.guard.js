"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeviceAuthGuard = void 0;
const common_1 = require("@nestjs/common");
const device_authenticator_interface_1 = require("../../../common/services/device-authenticator.interface");
const device_repository_interface_1 = require("../../../common/repositories/device.repository.interface");
let DeviceAuthGuard = class DeviceAuthGuard {
    authenticator;
    deviceRepository;
    constructor(authenticator, deviceRepository) {
        this.authenticator = authenticator;
        this.deviceRepository = deviceRepository;
    }
    async canActivate(context) {
        const request = context.switchToHttp().getRequest();
        const headers = request.headers;
        const device = await this.authenticator.authenticate(headers, this.deviceRepository);
        if (!device) {
            throw new common_1.UnauthorizedException("Invalid or missing Device Authentication Token. Please register agent or provide X-Device-Token header.");
        }
        request.device = device;
        return true;
    }
};
exports.DeviceAuthGuard = DeviceAuthGuard;
exports.DeviceAuthGuard = DeviceAuthGuard = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(device_authenticator_interface_1.IDeviceAuthenticatorToken)),
    __param(1, (0, common_1.Inject)(device_repository_interface_1.IDeviceRepositoryToken)),
    __metadata("design:paramtypes", [Object, Object])
], DeviceAuthGuard);
//# sourceMappingURL=device-auth.guard.js.map