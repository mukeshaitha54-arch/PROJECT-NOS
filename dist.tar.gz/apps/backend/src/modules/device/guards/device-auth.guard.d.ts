import { CanActivate, ExecutionContext } from "@nestjs/common";
import { IDeviceAuthenticator } from "../../../common/services/device-authenticator.interface";
import { IDeviceRepository } from "../../../common/repositories/device.repository.interface";
export declare class DeviceAuthGuard implements CanActivate {
    private readonly authenticator;
    private readonly deviceRepository;
    constructor(authenticator: IDeviceAuthenticator, deviceRepository: IDeviceRepository);
    canActivate(context: ExecutionContext): Promise<boolean>;
}
