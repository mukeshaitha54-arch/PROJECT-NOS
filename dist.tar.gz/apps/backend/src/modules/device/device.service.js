"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var DeviceService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeviceService = void 0;
const common_1 = require("@nestjs/common");
const event_emitter_1 = require("@nestjs/event-emitter");
const crypto = require("crypto");
const client_1 = require("@prisma/client");
const device_repository_interface_1 = require("../../common/repositories/device.repository.interface");
const heartbeat_repository_interface_1 = require("../../common/repositories/heartbeat.repository.interface");
const device_authenticator_interface_1 = require("../../common/services/device-authenticator.interface");
const heartbeat_presence_service_1 = require("../realtime/services/heartbeat-presence.service");
const device_timeline_service_1 = require("./services/device-timeline.service");
const registration_key_service_1 = require("../fleet/services/registration-key.service");
const domain_events_1 = require("../../common/events/domain-events");
const device_processes_store_1 = require("../../common/stores/device-processes.store");
const device_telemetry_paused_store_1 = require("../../common/stores/device-telemetry-paused.store");
let DeviceService = DeviceService_1 = class DeviceService {
    deviceRepository;
    heartbeatRepository;
    authenticator;
    heartbeatPresence;
    timelineService;
    registrationKeyService;
    eventEmitter;
    logger = new common_1.Logger(DeviceService_1.name);
    STALE_HEARTBEAT_THRESHOLD_MS = 90 * 1000;
    constructor(deviceRepository, heartbeatRepository, authenticator, heartbeatPresence, timelineService, registrationKeyService, eventEmitter) {
        this.deviceRepository = deviceRepository;
        this.heartbeatRepository = heartbeatRepository;
        this.authenticator = authenticator;
        this.heartbeatPresence = heartbeatPresence;
        this.timelineService = timelineService;
        this.registrationKeyService = registrationKeyService;
        this.eventEmitter = eventEmitter;
    }
    async getUnassignedDevices(organizationId) {
        const allDevices = await this.deviceRepository.findAll(organizationId);
        const devices = allDevices.filter((d) => d.claimStatus === "UNASSIGNED");
        return devices.map((d) => this.sanitizeDevice(d));
    }
    async claimDevice(deviceId, organizationId, claimedByUserId, teamId, departmentId) {
        const device = await this.deviceRepository.findById(deviceId);
        if (!device || device.organizationId !== organizationId) {
            throw new common_1.NotFoundException("Device not found or not in this organization");
        }
        const updatedDevice = await this.deviceRepository.update(deviceId, {
            claimStatus: "CLAIMED",
        });
        this.eventEmitter.emit("device.claimed", new domain_events_1.DeviceClaimedEvent(organizationId, device.id, claimedByUserId, teamId, departmentId));
        return this.sanitizeDevice(updatedDevice);
    }
    async register(dto, ipAddress) {
        this.logger.log(`Registering monitoring agent UUID [${dto.uuid}] Hostname [${dto.hostname}] (${dto.os})`);
        let organizationId = dto.organizationId;
        if (dto.registrationKey) {
            const regKey = await this.registrationKeyService.validateKey(dto.registrationKey);
            organizationId = regKey.organizationId;
            this.registrationKeyService
                .incrementKeyUsage(regKey.id, ipAddress)
                .catch((err) => {
                this.logger.error(`Failed to increment registration key usage: ${err.message}`, err.stack);
            });
        }
        const rawToken = crypto.randomBytes(32).toString("hex");
        const tokenHash = crypto
            .createHash("sha256")
            .update(rawToken)
            .digest("hex");
        const existing = await this.deviceRepository.findByUuid(dto.uuid);
        const isNew = !existing;
        let device;
        if (existing) {
            this.logger.log(`Agent UUID [${dto.uuid}] recognized. Refreshing cryptographic token and metadata.`);
            device = await this.deviceRepository.update(existing.id, {
                hostname: dto.hostname,
                deviceName: dto.deviceName,
                os: dto.os,
                osVersion: dto.osVersion,
                architecture: dto.architecture,
                agentVersion: dto.agentVersion,
                status: client_1.DeviceStatus.ONLINE,
                lastSeen: new Date(),
                tokenHash: tokenHash,
                organizationId: organizationId || existing.organizationId,
            });
        }
        else {
            if (!organizationId)
                throw new common_1.BadRequestException("A valid registration key is required...");
            device = await this.deviceRepository.create({
                uuid: dto.uuid,
                hostname: dto.hostname,
                deviceName: dto.deviceName,
                os: dto.os,
                osVersion: dto.osVersion,
                architecture: dto.architecture,
                agentVersion: dto.agentVersion,
                status: client_1.DeviceStatus.ONLINE,
                organizationId: organizationId,
                tokenHash: tokenHash,
                lastSeen: new Date(),
            });
        }
        const sanitized = this.sanitizeDevice(device);
        if (isNew) {
            this.eventEmitter.emit("device.registered", new domain_events_1.DeviceRegisteredEvent(device.organizationId || "default-org", device.id, dto.hostname, dto.os, dto.osVersion, dto.architecture, dto.agentVersion));
        }
        else if (existing.status !== client_1.DeviceStatus.ONLINE) {
            this.eventEmitter.emit("device.reconnected", new domain_events_1.DeviceReconnectedEvent(device.organizationId || "default-org", device.id, dto.hostname));
        }
        return {
            deviceId: device.id,
            token: rawToken,
            registrationToken: rawToken,
            device: sanitized,
        };
    }
    async recordHeartbeat(device, dto) {
        this.logger.debug(`Heartbeat ingested from Agent [${device.hostname}] (${dto.ipAddress}): CPU ${dto.cpuUsage}%, RAM ${dto.ramUsage}%`);
        const wasOffline = device.status === client_1.DeviceStatus.OFFLINE;
        const updatedDevice = await this.deviceRepository.update(device.id, {
            status: client_1.DeviceStatus.ONLINE,
            lastSeen: new Date(),
            ...(dto.hostname && { hostname: dto.hostname }),
            ...(dto.os && { os: dto.os }),
        });
        const timestampDate = !isNaN(Date.parse(dto.timestamp))
            ? new Date(dto.timestamp)
            : new Date();
        const heartbeat = await this.heartbeatRepository.create({
            deviceId: device.id,
            cpuUsage: dto.cpuUsage,
            ramUsage: dto.ramUsage,
            uptime: dto.uptime,
            ipAddress: dto.ipAddress,
            timestamp: timestampDate,
        });
        if (dto.processes &&
            Array.isArray(dto.processes) &&
            dto.processes.length > 0) {
            const cleanProcs = dto.processes
                .filter((p) => p &&
                (p.pid !== undefined ||
                    p.Pid !== undefined ||
                    p.processId !== undefined) &&
                (p.name || p.Name || p.processName || p.ProcessName))
                .map((p) => ({
                pid: Number(p.pid ?? p.Pid ?? p.processId),
                name: String(p.name ?? p.Name ?? p.processName ?? p.ProcessName ?? "process"),
                processName: String(p.processName ?? p.ProcessName ?? p.name ?? p.Name ?? "process"),
                memoryBytes: Number(p.memoryBytes ?? p.MemoryBytes ?? 0),
                memoryMb: Number(p.memoryMb ??
                    p.MemoryMb ??
                    (p.memoryBytes || p.MemoryBytes
                        ? Math.round(((p.memoryBytes ?? p.MemoryBytes) / (1024 * 1024)) * 10) / 10
                        : 0)),
                cpuTimeSec: Number(p.cpuTimeSec ?? p.CpuTimeSec ?? 0),
                threads: Number(p.threads ?? p.Threads ?? 1),
                status: String(p.status ?? p.Status ?? "Running"),
            }));
            if (cleanProcs.length > 0) {
                device_processes_store_1.deviceLiveProcessesStore.set(device.id, cleanProcs);
                if (device.uuid) {
                    device_processes_store_1.deviceLiveProcessesStore.set(device.uuid, cleanProcs);
                }
            }
        }
        await this.heartbeatPresence.processHeartbeat(device.id, dto.ipAddress, dto.cpuUsage, dto.ramUsage, dto.uptime, undefined, dto.runningProcesses, dto.activeConnections, dto.diskReadSpeed, dto.diskWriteSpeed, dto.networkUploadSpeed, dto.networkDownloadSpeed, dto.processes);
        this.eventEmitter.emit("heartbeat.received", new domain_events_1.HeartbeatReceivedEvent(device.organizationId || "default-org", device.id, dto.ipAddress, dto.cpuUsage, dto.ramUsage, dto.uptime, wasOffline, undefined, dto.runningProcesses, dto.activeConnections, dto.diskReadSpeed, dto.diskWriteSpeed, dto.networkUploadSpeed, dto.networkDownloadSpeed, dto.processes));
        return {
            success: true,
            status: updatedDevice.status,
            lastSeen: (updatedDevice.lastSeen || new Date()).toISOString(),
            heartbeatId: heartbeat.id,
            telemetryPaused: device_telemetry_paused_store_1.deviceTelemetryPausedStore.get(updatedDevice.id) ??
                device_telemetry_paused_store_1.deviceTelemetryPausedStore.get(updatedDevice.uuid) ??
                false,
        };
    }
    async getDeviceProfile(device) {
        const latestHeartbeat = await this.heartbeatRepository.findLatestByDeviceId(device.id);
        return {
            ...this.sanitizeDevice(device),
            lastHeartbeat: latestHeartbeat
                ? this.sanitizeHeartbeat(latestHeartbeat)
                : null,
            latestHeartbeat: latestHeartbeat
                ? this.sanitizeHeartbeat(latestHeartbeat)
                : null,
        };
    }
    async getPlatformStatus(organizationId) {
        const devices = await this.deviceRepository.findAll(organizationId);
        const now = new Date().getTime();
        const heartbeatMap = devices.length > 0
            ? await this.heartbeatRepository.findLatestForDevices(devices.map((d) => d.id))
            : new Map();
        let totalOnline = 0;
        let totalOffline = 0;
        let totalDegraded = 0;
        const staleDeviceIds = [];
        const deviceResults = devices.map((d) => {
            let currentStatus = d.status;
            const lastSeenMs = d.lastSeen ? d.lastSeen.getTime() : 0;
            const isStale = now - lastSeenMs > this.STALE_HEARTBEAT_THRESHOLD_MS;
            if (currentStatus === client_1.DeviceStatus.ONLINE && isStale) {
                currentStatus = client_1.DeviceStatus.OFFLINE;
                staleDeviceIds.push(d.id);
                this.eventEmitter.emit("device.offline", new domain_events_1.DeviceOfflineEvent(d.organizationId || "default-org", d.id, "3 consecutive missed heartbeat windows (stale sweep)"));
            }
            if (currentStatus === client_1.DeviceStatus.ONLINE)
                totalOnline++;
            else if (currentStatus === client_1.DeviceStatus.DEGRADED)
                totalDegraded++;
            else
                totalOffline++;
            const latestHeartbeat = heartbeatMap.get(d.id) || null;
            return {
                ...this.sanitizeDevice({ ...d, status: currentStatus }),
                lastHeartbeat: latestHeartbeat
                    ? this.sanitizeHeartbeat(latestHeartbeat)
                    : null,
                latestHeartbeat: latestHeartbeat
                    ? this.sanitizeHeartbeat(latestHeartbeat)
                    : null,
            };
        });
        if (staleDeviceIds.length > 0) {
            staleDeviceIds.forEach((id) => {
                this.deviceRepository
                    .update(id, { status: client_1.DeviceStatus.OFFLINE })
                    .catch(() => { });
            });
        }
        return {
            devices: deviceResults,
            summary: {
                totalRegistered: devices.length,
                totalOnline,
                totalOffline,
                totalDegraded,
            },
            timestamp: new Date().toISOString(),
        };
    }
    async getDeviceById(id, organizationId) {
        const device = await this.deviceRepository.findById(id);
        if (!device) {
            throw new common_1.NotFoundException(`Monitored agent node with primary UUID [${id}] not found in platform inventory.`);
        }
        if (organizationId &&
            device.organizationId &&
            device.organizationId !== organizationId) {
            throw new common_1.NotFoundException(`Monitored agent node with primary UUID [${id}] not found in platform inventory.`);
        }
        const latestHeartbeat = await this.heartbeatRepository.findLatestByDeviceId(device.id);
        return {
            ...this.sanitizeDevice(device),
            lastHeartbeat: latestHeartbeat
                ? this.sanitizeHeartbeat(latestHeartbeat)
                : null,
            latestHeartbeat: latestHeartbeat
                ? this.sanitizeHeartbeat(latestHeartbeat)
                : null,
        };
    }
    async setMaintenanceMode(deviceId, enabled, actorId, actorName) {
        const device = await this.deviceRepository.findById(deviceId);
        if (!device)
            throw new common_1.NotFoundException(`Device [${deviceId}] not found.`);
        const newStatus = enabled ? client_1.DeviceStatus.MAINTENANCE : client_1.DeviceStatus.ONLINE;
        const updated = await this.deviceRepository.update(deviceId, {
            status: newStatus,
        });
        this.eventEmitter.emit("device.maintenance", new domain_events_1.DeviceMaintenanceEvent(device.organizationId || "default-org", deviceId, enabled, actorId, actorName));
        return this.sanitizeDevice(updated);
    }
    async retireDevice(deviceId, actorId, actorName) {
        const device = await this.deviceRepository.findById(deviceId);
        if (!device)
            throw new common_1.NotFoundException(`Device [${deviceId}] not found.`);
        const updated = await this.deviceRepository.update(deviceId, {
            status: client_1.DeviceStatus.OFFLINE,
        });
        this.eventEmitter.emit("device.retired", new domain_events_1.DeviceRetiredEvent(device.organizationId || "default-org", deviceId, actorId, actorName));
        return this.sanitizeDevice(updated);
    }
    async bulkUpdateStatus(deviceIds, status, actorId, actorName) {
        let count = 0;
        for (const id of deviceIds) {
            try {
                const device = await this.deviceRepository.findById(id);
                await this.deviceRepository.update(id, { status });
                count++;
                this.eventEmitter.emit("device.bulk_status", new domain_events_1.DeviceBulkStatusEvent(device?.organizationId || "default-org", id, status, actorId, actorName));
            }
            catch (e) {
                this.logger.warn(`Failed to bulk update status for device ${id}: ${e?.message}`);
            }
        }
        return { updatedCount: count };
    }
    async getDeviceTimeline(deviceId, page = 1, limit = 20) {
        const device = await this.deviceRepository.findById(deviceId);
        if (!device)
            throw new common_1.NotFoundException(`Device [${deviceId}] not found.`);
        return this.timelineService.getPaginatedTimeline({ deviceId, page, limit });
    }
    async setTelemetryPause(deviceId, organizationId, paused) {
        const device = await this.deviceRepository.findById(deviceId);
        if (!device ||
            (device.organizationId && device.organizationId !== organizationId)) {
            throw new common_1.NotFoundException(`Device [${deviceId}] not found or access denied.`);
        }
        device_telemetry_paused_store_1.deviceTelemetryPausedStore.set(deviceId, paused);
        if (device.uuid) {
            device_telemetry_paused_store_1.deviceTelemetryPausedStore.set(device.uuid, paused);
        }
        this.logger.log(`Telemetry ${paused ? "PAUSED" : "RESUMED"} for device [${device.hostname}] (${deviceId})`);
        this.eventEmitter.emit("device.telemetry.status", new domain_events_1.DeviceTelemetryStatusEvent(device.organizationId || "default-org", deviceId, paused));
        return this.sanitizeDevice(device);
    }
    sanitizeDevice(device) {
        return {
            id: device.id,
            uuid: device.uuid,
            hostname: device.hostname,
            deviceName: device.deviceName,
            os: device.os,
            osVersion: device.osVersion,
            architecture: device.architecture,
            agentVersion: device.agentVersion,
            status: device.status,
            telemetryPaused: device_telemetry_paused_store_1.deviceTelemetryPausedStore.get(device.id) ??
                device_telemetry_paused_store_1.deviceTelemetryPausedStore.get(device.uuid) ??
                false,
            lastSeen: device.lastSeen ? device.lastSeen.toISOString() : null,
            registeredAt: device.registeredAt.toISOString(),
            organizationId: device.organizationId,
            createdAt: device.createdAt.toISOString(),
            updatedAt: device.updatedAt.toISOString(),
        };
    }
    sanitizeHeartbeat(hb) {
        return {
            id: hb.id,
            deviceId: hb.deviceId,
            cpuUsage: hb.cpuUsage,
            ramUsage: hb.ramUsage,
            uptime: hb.uptime,
            ipAddress: hb.ipAddress,
            timestamp: hb.timestamp instanceof Date
                ? hb.timestamp.toISOString()
                : String(hb.timestamp),
        };
    }
};
exports.DeviceService = DeviceService;
exports.DeviceService = DeviceService = DeviceService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(device_repository_interface_1.IDeviceRepositoryToken)),
    __param(1, (0, common_1.Inject)(heartbeat_repository_interface_1.IHeartbeatRepositoryToken)),
    __param(2, (0, common_1.Inject)(device_authenticator_interface_1.IDeviceAuthenticatorToken)),
    __param(5, (0, common_1.Inject)((0, common_1.forwardRef)(() => registration_key_service_1.RegistrationKeyService))),
    __metadata("design:paramtypes", [Object, Object, Object, heartbeat_presence_service_1.HeartbeatPresenceService,
        device_timeline_service_1.DeviceTimelineService,
        registration_key_service_1.RegistrationKeyService,
        event_emitter_1.EventEmitter2])
], DeviceService);
//# sourceMappingURL=device.service.js.map