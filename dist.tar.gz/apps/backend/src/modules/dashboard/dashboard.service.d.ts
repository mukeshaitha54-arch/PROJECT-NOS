import { IDashboardRepository } from "../../common/repositories/dashboard.repository.interface";
import { ISocketPublisher } from "../../common/services/socket-publisher.interface";
import { DashboardDevicesQueryDto, DashboardHistoryQueryDto } from "./dto/dashboard.dto";
import { DashboardOverviewResponse, PaginatedDashboardDevicesResponse, DashboardDeviceDetailResponse, PaginatedTelemetryResponse } from "@nos/shared-types";
export declare class DashboardService {
    private readonly repository;
    private readonly socketPublisher;
    private readonly logger;
    constructor(repository: IDashboardRepository, socketPublisher: ISocketPublisher);
    publishOverviewRefresh(organizationId: string): Promise<void>;
    getOverview(organizationId: string): Promise<DashboardOverviewResponse>;
    getDevices(organizationId: string, query: DashboardDevicesQueryDto): Promise<PaginatedDashboardDevicesResponse>;
    getDeviceById(organizationId: string, id: string): Promise<DashboardDeviceDetailResponse>;
    getDeviceHistory(organizationId: string, deviceId: string, query: DashboardHistoryQueryDto): Promise<PaginatedTelemetryResponse>;
    private toTelemetrySnapshotDto;
}
