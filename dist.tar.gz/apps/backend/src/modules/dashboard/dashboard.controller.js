"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DashboardController = void 0;
const openapi = require("@nestjs/swagger");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const dashboard_service_1 = require("./dashboard.service");
const dashboard_dto_1 = require("./dto/dashboard.dto");
const jwt_auth_guard_1 = require("../../common/guards/jwt-auth.guard");
const current_tenant_decorator_1 = require("../../common/decorators/current-tenant.decorator");
let DashboardController = class DashboardController {
    dashboardService;
    constructor(dashboardService) {
        this.dashboardService = dashboardService;
    }
    async getOverview(tenant) {
        const data = await this.dashboardService.getOverview(tenant.organizationId);
        return {
            success: true,
            data,
            timestamp: new Date().toISOString(),
        };
    }
    async getDevices(tenant, query) {
        const data = await this.dashboardService.getDevices(tenant.organizationId, query);
        return {
            success: true,
            data,
            meta: {
                page: data.page,
                limit: data.limit,
                total: data.total,
                totalPages: data.totalPages,
            },
            timestamp: new Date().toISOString(),
        };
    }
    async getDeviceById(tenant, id) {
        const data = await this.dashboardService.getDeviceById(tenant.organizationId, id);
        return {
            success: true,
            data,
            timestamp: new Date().toISOString(),
        };
    }
    async getDeviceHistory(tenant, deviceId, query) {
        const data = await this.dashboardService.getDeviceHistory(tenant.organizationId, deviceId, query);
        return {
            success: true,
            data,
            meta: {
                page: data.page,
                limit: data.limit,
                total: data.total,
                totalPages: data.totalPages,
            },
            timestamp: new Date().toISOString(),
        };
    }
};
exports.DashboardController = DashboardController;
__decorate([
    (0, common_1.Get)("overview"),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({
        summary: "Retrieve high-level device infrastructure summary stats",
    }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: "Operational monitoring overview returned successfully.",
    }),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK }),
    __param(0, (0, current_tenant_decorator_1.CurrentTenant)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], DashboardController.prototype, "getOverview", null);
__decorate([
    (0, common_1.Get)("devices"),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({
        summary: "Retrieve paginated and filterable operational device table records",
    }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: "Paginated device table returned successfully.",
    }),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK }),
    __param(0, (0, current_tenant_decorator_1.CurrentTenant)()),
    __param(1, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, dashboard_dto_1.DashboardDevicesQueryDto]),
    __metadata("design:returntype", Promise)
], DashboardController.prototype, "getDevices", null);
__decorate([
    (0, common_1.Get)("device/:id"),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({
        summary: "Retrieve comprehensive real-time device diagnostic profile",
    }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: "Device operational detail retrieved successfully.",
    }),
    (0, swagger_1.ApiResponse)({
        status: 404,
        description: "Target device identifier not found.",
    }),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK }),
    __param(0, (0, current_tenant_decorator_1.CurrentTenant)()),
    __param(1, (0, common_1.Param)("id")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], DashboardController.prototype, "getDeviceById", null);
__decorate([
    (0, common_1.Get)("history/:deviceId"),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({
        summary: "Retrieve historical raw time-series telemetry snapshots within custom date range",
    }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: "Paginated historical telemetry retrieved successfully.",
    }),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK }),
    __param(0, (0, current_tenant_decorator_1.CurrentTenant)()),
    __param(1, (0, common_1.Param)("deviceId")),
    __param(2, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, dashboard_dto_1.DashboardHistoryQueryDto]),
    __metadata("design:returntype", Promise)
], DashboardController.prototype, "getDeviceHistory", null);
exports.DashboardController = DashboardController = __decorate([
    (0, swagger_1.ApiTags)("Dashboard - Operational Monitoring"),
    (0, common_1.Controller)("dashboard"),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    __metadata("design:paramtypes", [dashboard_service_1.DashboardService])
], DashboardController);
//# sourceMappingURL=dashboard.controller.js.map