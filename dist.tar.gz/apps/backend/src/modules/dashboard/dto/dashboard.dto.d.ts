export declare class DashboardDevicesQueryDto {
    page?: number;
    limit?: number;
    search?: string;
    status?: string;
    os?: string;
}
export declare class DashboardHistoryQueryDto {
    from?: string;
    to?: string;
    page?: number;
    limit?: number;
}
