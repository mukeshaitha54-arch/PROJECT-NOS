import { DashboardService } from "./dashboard.service";
import { DashboardDevicesQueryDto, DashboardHistoryQueryDto } from "./dto/dashboard.dto";
import { TenantContext } from "@nos/shared-types";
import { ApiResponse, DashboardOverviewResponse, PaginatedDashboardDevicesResponse, DashboardDeviceDetailResponse, PaginatedTelemetryResponse } from "@nos/shared-types";
export declare class DashboardController {
    private readonly dashboardService;
    constructor(dashboardService: DashboardService);
    getOverview(tenant: TenantContext): Promise<ApiResponse<DashboardOverviewResponse>>;
    getDevices(tenant: TenantContext, query: DashboardDevicesQueryDto): Promise<ApiResponse<PaginatedDashboardDevicesResponse>>;
    getDeviceById(tenant: TenantContext, id: string): Promise<ApiResponse<DashboardDeviceDetailResponse>>;
    getDeviceHistory(tenant: TenantContext, deviceId: string, query: DashboardHistoryQueryDto): Promise<ApiResponse<PaginatedTelemetryResponse>>;
}
