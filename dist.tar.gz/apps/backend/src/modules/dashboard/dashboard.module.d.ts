export declare class DashboardModule {
}
