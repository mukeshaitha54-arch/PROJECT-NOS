"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var DashboardService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.DashboardService = void 0;
const common_1 = require("@nestjs/common");
const dashboard_repository_interface_1 = require("../../common/repositories/dashboard.repository.interface");
const socket_publisher_interface_1 = require("../../common/services/socket-publisher.interface");
const shared_types_1 = require("@nos/shared-types");
let DashboardService = DashboardService_1 = class DashboardService {
    repository;
    socketPublisher;
    logger = new common_1.Logger(DashboardService_1.name);
    constructor(repository, socketPublisher) {
        this.repository = repository;
        this.socketPublisher = socketPublisher;
    }
    async publishOverviewRefresh(organizationId) {
        const overview = await this.getOverview(organizationId);
        await this.socketPublisher.emitDashboardUpdated({
            overview,
            timestamp: new Date().toISOString(),
        });
    }
    async getOverview(organizationId) {
        const counts = await this.repository.getOverviewCounts(organizationId);
        return {
            totalDevices: counts.total,
            online: counts.online,
            offline: counts.offline,
            critical: counts.critical,
            warning: counts.warning,
            degraded: counts.degraded,
            maintenance: counts.maintenance,
            lastUpdated: new Date().toISOString(),
        };
    }
    async getDevices(organizationId, query) {
        const page = query.page || 1;
        const limit = query.limit || 20;
        const skip = (page - 1) * limit;
        const { devices, total } = await this.repository.getDeviceRows({
            organizationId,
            skip,
            take: limit,
            search: query.search,
            status: query.status,
            os: query.os,
        });
        const rows = devices.map((d) => {
            let cpu = 0;
            let ram = 0;
            let disk = 0;
            let uploadSpeed = 0;
            let downloadSpeed = 0;
            let ipAddress = "0.0.0.0";
            let activeConnections = 0;
            if (d.latestSnapshot) {
                cpu = Math.round(d.latestSnapshot.cpuUsage * 10) / 10;
                ram = Math.round(d.latestSnapshot.memoryUsagePercent * 10) / 10;
                disk = Math.round(d.latestSnapshot.diskUsagePercent * 10) / 10;
                uploadSpeed = Math.round(d.latestSnapshot.networkUploadSpeed || 0);
                downloadSpeed = Math.round(d.latestSnapshot.networkDownloadSpeed || 0);
                ipAddress = d.latestSnapshot.ipAddress || "0.0.0.0";
                activeConnections = d.latestSnapshot.activeConnections || 0;
            }
            else if (d.latestHeartbeat) {
                cpu = Math.round(d.latestHeartbeat.cpuUsage * 10) / 10;
                ram = Math.round(d.latestHeartbeat.ramUsage * 10) / 10;
                ipAddress = d.latestHeartbeat.ipAddress || "0.0.0.0";
            }
            return {
                id: d.id,
                uuid: d.uuid,
                hostname: d.hostname,
                status: d.status,
                cpu,
                ram,
                disk,
                network: {
                    uploadSpeed,
                    downloadSpeed,
                    ipAddress,
                    activeConnections,
                },
                lastSeen: d.lastSeen ? d.lastSeen.toISOString() : null,
                os: d.os,
                osVersion: d.osVersion,
                agentVersion: d.agentVersion,
            };
        });
        return {
            devices: rows,
            total,
            page,
            limit,
            totalPages: Math.ceil(total / limit) || 1,
        };
    }
    async getDeviceById(organizationId, id) {
        const raw = await this.repository.getDeviceDetail(organizationId, id);
        if (!raw || !raw.device) {
            throw new common_1.NotFoundException(`Monitored device with identifier [${id}] not found in control plane.`);
        }
        const { device, currentSnapshot, latestHeartbeat } = raw;
        const currentCpu = currentSnapshot
            ? Math.round(currentSnapshot.cpuUsage * 10) / 10
            : latestHeartbeat
                ? Math.round(latestHeartbeat.cpuUsage * 10) / 10
                : 0;
        const currentRam = currentSnapshot
            ? Math.round(currentSnapshot.memoryUsagePercent * 10) / 10
            : latestHeartbeat
                ? Math.round(latestHeartbeat.ramUsage * 10) / 10
                : 0;
        const currentDisk = currentSnapshot
            ? Math.round(currentSnapshot.diskUsagePercent * 10) / 10
            : 0;
        const currentNetwork = {
            uploadSpeed: currentSnapshot
                ? Math.round(currentSnapshot.networkUploadSpeed || 0)
                : 0,
            downloadSpeed: currentSnapshot
                ? Math.round(currentSnapshot.networkDownloadSpeed || 0)
                : 0,
            bytesSent: currentSnapshot ? currentSnapshot.bytesSent : 0,
            bytesReceived: currentSnapshot ? currentSnapshot.bytesReceived : 0,
            activeConnections: currentSnapshot
                ? currentSnapshot.activeConnections || 0
                : 0,
            ipAddress: currentSnapshot
                ? currentSnapshot.ipAddress
                : latestHeartbeat
                    ? latestHeartbeat.ipAddress
                    : "0.0.0.0",
            macAddress: currentSnapshot
                ? currentSnapshot.macAddress
                : "00:00:00:00:00:00",
        };
        const uptime = currentSnapshot
            ? currentSnapshot.systemUptime
            : latestHeartbeat
                ? latestHeartbeat.uptime
                : 0;
        const deviceStatus = device.status;
        let systemStatus = "HEALTHY";
        if (deviceStatus === shared_types_1.DeviceStatus.CRITICAL) {
            systemStatus = "CRITICAL";
        }
        else if (deviceStatus === shared_types_1.DeviceStatus.DEGRADED ||
            currentCpu > 85 ||
            currentRam > 88 ||
            currentDisk > 92) {
            systemStatus = "WARNING";
        }
        else if (deviceStatus === shared_types_1.DeviceStatus.OFFLINE) {
            systemStatus = "OFFLINE";
        }
        else if (deviceStatus === shared_types_1.DeviceStatus.MAINTENANCE) {
            systemStatus = "MAINTENANCE";
        }
        const cleanedDevice = {
            ...device,
            lastSeen: device.lastSeen ? device.lastSeen.toISOString() : null,
            registeredAt: device.registeredAt
                ? device.registeredAt.toISOString()
                : new Date(0).toISOString(),
            createdAt: device.createdAt
                ? device.createdAt.toISOString()
                : new Date(0).toISOString(),
            updatedAt: device.updatedAt
                ? device.updatedAt.toISOString()
                : new Date(0).toISOString(),
            tokenHash: undefined,
        };
        return {
            device: cleanedDevice,
            currentSnapshot: currentSnapshot
                ? this.toTelemetrySnapshotDto(currentSnapshot)
                : null,
            latestHeartbeat: latestHeartbeat
                ? {
                    id: latestHeartbeat.id,
                    deviceId: latestHeartbeat.deviceId,
                    cpuUsage: latestHeartbeat.cpuUsage,
                    ramUsage: latestHeartbeat.ramUsage,
                    uptime: latestHeartbeat.uptime,
                    ipAddress: latestHeartbeat.ipAddress,
                    timestamp: latestHeartbeat.timestamp instanceof Date
                        ? latestHeartbeat.timestamp.toISOString()
                        : String(latestHeartbeat.timestamp),
                }
                : null,
            currentCpu,
            currentRam,
            currentDisk,
            currentNetwork,
            deviceStatus,
            uptime,
            systemStatus,
            lastUpdated: new Date().toISOString(),
        };
    }
    async getDeviceHistory(organizationId, deviceId, query) {
        const page = query.page || 1;
        const limit = query.limit || 50;
        const skip = (page - 1) * limit;
        const fromDate = query.from ? new Date(query.from) : undefined;
        const toDate = query.to ? new Date(query.to) : undefined;
        const { snapshots, total } = await this.repository.getTelemetryHistory(organizationId, deviceId, {
            from: fromDate,
            to: toDate,
            skip,
            take: limit,
        });
        const dtos = snapshots.map((s) => this.toTelemetrySnapshotDto(s));
        return {
            snapshots: dtos,
            total,
            page,
            limit,
            totalPages: Math.ceil(total / limit) || 1,
        };
    }
    toTelemetrySnapshotDto(record) {
        return {
            id: record.id,
            deviceId: record.deviceId,
            cpuUsage: Number(record.cpuUsage),
            cpuTemperature: Number(record.cpuTemperature || 0),
            cpuFrequency: Number(record.cpuFrequency || 0),
            logicalProcessors: Number(record.logicalProcessors || 1),
            physicalProcessors: Number(record.physicalProcessors || 1),
            memoryUsed: Number(record.memoryUsed),
            memoryFree: Number(record.memoryFree),
            memoryTotal: Number(record.memoryTotal),
            memoryUsagePercent: Number(record.memoryUsagePercent),
            diskReadSpeed: Number(record.diskReadSpeed || 0),
            diskWriteSpeed: Number(record.diskWriteSpeed || 0),
            diskUsagePercent: Number(record.diskUsagePercent),
            diskFree: Number(record.diskFree),
            diskTotal: Number(record.diskTotal),
            networkUploadSpeed: Number(record.networkUploadSpeed || 0),
            networkDownloadSpeed: Number(record.networkDownloadSpeed || 0),
            bytesSent: Number(record.bytesSent || 0),
            bytesReceived: Number(record.bytesReceived || 0),
            activeConnections: Number(record.activeConnections || 0),
            runningProcesses: Number(record.runningProcesses || 0),
            runningServices: Number(record.runningServices || 0),
            systemUptime: Number(record.systemUptime),
            bootTime: record.bootTime instanceof Date
                ? record.bootTime.toISOString()
                : String(record.bootTime),
            ipAddress: record.ipAddress,
            gateway: record.gateway || "0.0.0.0",
            dns: record.dns || "8.8.8.8",
            macAddress: record.macAddress || "00:00:00:00:00:00",
            timestamp: record.timestamp instanceof Date
                ? record.timestamp.toISOString()
                : String(record.timestamp),
        };
    }
};
exports.DashboardService = DashboardService;
exports.DashboardService = DashboardService = DashboardService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(dashboard_repository_interface_1.IDashboardRepository)),
    __param(1, (0, common_1.Inject)(socket_publisher_interface_1.ISocketPublisherToken)),
    __metadata("design:paramtypes", [Object, Object])
], DashboardService);
//# sourceMappingURL=dashboard.service.js.map