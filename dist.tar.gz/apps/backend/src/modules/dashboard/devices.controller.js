"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DevicesController = void 0;
const openapi = require("@nestjs/swagger");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const event_emitter_1 = require("@nestjs/event-emitter");
const jwt_auth_guard_1 = require("../../common/guards/jwt-auth.guard");
const current_tenant_decorator_1 = require("../../common/decorators/current-tenant.decorator");
const prisma_service_1 = require("../../database/prisma.service");
const device_processes_store_1 = require("../../common/stores/device-processes.store");
const device_telemetry_paused_store_1 = require("../../common/stores/device-telemetry-paused.store");
const domain_events_1 = require("../../common/events/domain-events");
let DevicesController = class DevicesController {
    prisma;
    eventEmitter;
    constructor(prisma, eventEmitter) {
        this.prisma = prisma;
        this.eventEmitter = eventEmitter;
    }
    async getDevices(tenant) {
        const orgId = tenant.organizationId;
        this.prisma.device
            .updateMany({
            where: { organizationId: orgId, tenantId: { not: orgId } },
            data: { tenantId: orgId },
        })
            .catch(() => { });
        const devices = await this.prisma.device.findMany({
            where: {
                OR: [{ tenantId: orgId }, { organizationId: orgId }],
            },
            orderBy: { lastSeen: "desc" },
            include: {
                telemetrySnapshots: {
                    orderBy: { timestamp: "desc" },
                    take: 1,
                },
                heartbeats: {
                    orderBy: { timestamp: "desc" },
                    take: 1,
                },
            },
        });
        const serialized = devices.map((device) => {
            const snap = device.telemetrySnapshots[0] || null;
            const hb = device.heartbeats?.[0] || null;
            return {
                ...device,
                telemetryPaused: device_telemetry_paused_store_1.deviceTelemetryPausedStore.get(device.id) ??
                    device_telemetry_paused_store_1.deviceTelemetryPausedStore.get(device.uuid) ??
                    false,
                latestSnapshot: snap
                    ? {
                        ...snap,
                        bytesSent: snap.bytesSent ? Number(snap.bytesSent) : 0,
                        bytesReceived: snap.bytesReceived
                            ? Number(snap.bytesReceived)
                            : 0,
                    }
                    : null,
                latestHeartbeat: hb,
                lastHeartbeat: hb,
                heartbeats: hb ? [hb] : [],
                telemetrySnapshots: undefined,
            };
        });
        return {
            success: true,
            data: serialized,
        };
    }
    async getStats(tenant) {
        const orgId = tenant.organizationId;
        const devices = await this.prisma.device.findMany({
            where: {
                OR: [{ tenantId: orgId }, { organizationId: orgId }],
            },
            select: { status: true },
        });
        const stats = {
            total: devices.length,
            online: devices.filter((d) => d.status === "ONLINE").length,
            offline: devices.filter((d) => d.status === "OFFLINE").length,
            warning: devices.filter((d) => d.status === "DEGRADED").length,
            critical: devices.filter((d) => d.status === "CRITICAL").length,
        };
        const alerts = await this.prisma.alert.count({
            where: {
                tenantId: orgId,
                createdAt: {
                    gte: new Date(new Date().setHours(0, 0, 0, 0)),
                },
            },
        });
        return {
            success: true,
            data: { ...stats, alertsToday: alerts },
        };
    }
    async getDeviceById(tenant, id) {
        const orgId = tenant.organizationId;
        const device = await this.prisma.device.findFirst({
            where: {
                id,
                OR: [{ tenantId: orgId }, { organizationId: orgId }],
            },
            include: {
                inventory: true,
            },
        });
        if (!device) {
            throw new common_1.NotFoundException("Device not found");
        }
        const latestSnapshot = await this.prisma.telemetrySnapshot.findFirst({
            where: { deviceId: id },
            orderBy: { timestamp: "desc" },
        });
        const latestHeartbeat = await this.prisma.heartbeat.findFirst({
            where: { deviceId: id },
            orderBy: { timestamp: "desc" },
        });
        const serializeSnap = (snap) => snap
            ? {
                ...snap,
                bytesSent: snap.bytesSent ? Number(snap.bytesSent) : 0,
                bytesReceived: snap.bytesReceived ? Number(snap.bytesReceived) : 0,
            }
            : null;
        return {
            success: true,
            data: {
                ...device,
                telemetryPaused: device_telemetry_paused_store_1.deviceTelemetryPausedStore.get(device.id) ??
                    device_telemetry_paused_store_1.deviceTelemetryPausedStore.get(device.uuid) ??
                    false,
                latestSnapshot: serializeSnap(latestSnapshot),
                latestHeartbeat,
                lastHeartbeat: latestHeartbeat,
            },
        };
    }
    async getTelemetry(tenant, id, range = "1h") {
        const orgId = tenant.organizationId;
        const device = await this.prisma.device.findFirst({
            where: { id, OR: [{ tenantId: orgId }, { organizationId: orgId }] },
        });
        if (!device)
            throw new common_1.NotFoundException("Device not found");
        let gte = new Date();
        switch (range) {
            case "1h":
                gte.setHours(gte.getHours() - 1);
                break;
            case "6h":
                gte.setHours(gte.getHours() - 6);
                break;
            case "24h":
                gte.setHours(gte.getHours() - 24);
                break;
            case "7d":
                gte.setDate(gte.getDate() - 7);
                break;
            case "30d":
                gte.setDate(gte.getDate() - 30);
                break;
            default:
                gte.setHours(gte.getHours() - 1);
        }
        const telemetry = await this.prisma.telemetrySnapshot.findMany({
            where: {
                deviceId: id,
                timestamp: { gte },
            },
            orderBy: { timestamp: "asc" },
            take: 60,
        });
        return {
            success: true,
            data: telemetry,
        };
    }
    async getProcesses(tenant, id) {
        const orgId = tenant.organizationId;
        const device = await this.prisma.device.findFirst({
            where: {
                OR: [{ id }, { uuid: id }],
                ...(orgId
                    ? { AND: [{ OR: [{ tenantId: orgId }, { organizationId: orgId }] }] }
                    : {}),
            },
        });
        if (!device)
            throw new common_1.NotFoundException("Device not found");
        const live = device_processes_store_1.deviceLiveProcessesStore.get(device.id) ||
            (device.uuid ? device_processes_store_1.deviceLiveProcessesStore.get(device.uuid) : null);
        if (live && Array.isArray(live) && live.length > 0) {
            const validLive = live
                .filter((p) => p &&
                (p.pid !== undefined ||
                    p.Pid !== undefined ||
                    p.processId !== undefined) &&
                (p.name || p.Name || p.processName || p.ProcessName))
                .map((p) => ({
                pid: Number(p.pid ?? p.Pid ?? p.processId),
                name: String(p.name ?? p.Name ?? p.processName ?? p.ProcessName ?? "process"),
                processName: String(p.processName ?? p.ProcessName ?? p.name ?? p.Name ?? "process"),
                memoryBytes: Number(p.memoryBytes ?? p.MemoryBytes ?? 0),
                memoryMb: Number(p.memoryMb ??
                    p.MemoryMb ??
                    (p.memoryBytes || p.MemoryBytes
                        ? Math.round(((p.memoryBytes ?? p.MemoryBytes) / (1024 * 1024)) * 10) / 10
                        : 0)),
                cpuTimeSec: Number(p.cpuTimeSec ?? p.CpuTimeSec ?? 0),
                threads: Number(p.threads ?? p.Threads ?? 1),
                status: String(p.status ?? p.Status ?? "Running"),
            }));
            if (validLive.length > 0) {
                return {
                    success: true,
                    data: validLive,
                };
            }
        }
        return {
            success: true,
            data: [],
        };
    }
    async getServices(tenant, id) {
        const orgId = tenant.organizationId;
        const device = await this.prisma.device.findFirst({
            where: {
                OR: [{ id }, { uuid: id }],
                ...(orgId
                    ? { AND: [{ OR: [{ tenantId: orgId }, { organizationId: orgId }] }] }
                    : {}),
            },
        });
        if (!device)
            throw new common_1.NotFoundException("Device not found");
        const services = await this.prisma.windowsService.findMany({
            where: {
                deviceInventory: {
                    OR: [
                        { deviceId: device.id },
                        ...(device.uuid ? [{ deviceId: device.uuid }] : []),
                    ],
                },
            },
            orderBy: { displayName: "asc" },
        });
        return {
            success: true,
            data: services,
        };
    }
    async getSoftware(tenant, id) {
        const orgId = tenant.organizationId;
        const device = await this.prisma.device.findFirst({
            where: {
                OR: [{ id }, { uuid: id }],
                ...(orgId
                    ? { AND: [{ OR: [{ tenantId: orgId }, { organizationId: orgId }] }] }
                    : {}),
            },
        });
        if (!device)
            throw new common_1.NotFoundException("Device not found");
        const software = await this.prisma.installedSoftware.findMany({
            where: {
                deviceInventory: {
                    OR: [
                        { deviceId: device.id },
                        ...(device.uuid ? [{ deviceId: device.uuid }] : []),
                    ],
                },
            },
            orderBy: { name: "asc" },
        });
        return {
            success: true,
            data: software,
        };
    }
    async getAlerts(tenant, id) {
        const orgId = tenant.organizationId;
        const device = await this.prisma.device.findFirst({
            where: { id, OR: [{ tenantId: orgId }, { organizationId: orgId }] },
        });
        if (!device)
            throw new common_1.NotFoundException("Device not found");
        const alerts = await this.prisma.alert.findMany({
            where: { deviceId: id },
            orderBy: { createdAt: "desc" },
        });
        return {
            success: true,
            data: alerts,
        };
    }
    async getHeartbeats(tenant, id) {
        const orgId = tenant.organizationId;
        const device = await this.prisma.device.findFirst({
            where: { id, OR: [{ tenantId: orgId }, { organizationId: orgId }] },
        });
        if (!device)
            throw new common_1.NotFoundException("Device not found");
        const heartbeats = await this.prisma.heartbeat.findMany({
            where: { deviceId: id },
            orderBy: { timestamp: "desc" },
            take: 50,
        });
        return {
            success: true,
            data: heartbeats,
        };
    }
    async deleteDevice(tenant, id) {
        const device = await this.prisma.device.findFirst({
            where: {
                OR: [{ id }, { uuid: id }],
            },
        });
        if (!device) {
            throw new common_1.NotFoundException("Device not found");
        }
        const deviceId = device.id;
        await Promise.allSettled([
            this.prisma.telemetrySnapshot.deleteMany({ where: { deviceId } }),
            this.prisma.heartbeat.deleteMany({ where: { deviceId } }),
            this.prisma.alert.deleteMany({ where: { deviceId } }),
            this.prisma.deviceOwnership.deleteMany({ where: { deviceId } }),
            this.prisma.deviceTransferRequest.deleteMany({ where: { deviceId } }),
            this.prisma.inventoryAuditLog.deleteMany({ where: { deviceId } }),
            this.prisma.deviceTimelineEvent.deleteMany({ where: { deviceId } }),
            this.prisma.maintenanceWindow.deleteMany({ where: { deviceId } }),
            this.prisma.deviceInventory.deleteMany({ where: { deviceId } }),
        ]);
        await this.prisma.device.delete({ where: { id: deviceId } });
        try {
            if (device.organizationId) {
                await this.prisma.organizationQuota.updateMany({
                    where: {
                        organizationId: device.organizationId,
                        currentDevices: { gt: 0 },
                    },
                    data: { currentDevices: { decrement: 1 } },
                });
            }
        }
        catch { }
        return {
            success: true,
            message: `Device ${device.hostname} (${deviceId}) and all associated data deleted permanently.`,
        };
    }
    async pauseTelemetry(tenant, id) {
        const orgId = tenant.organizationId;
        const device = await this.prisma.device.findFirst({
            where: {
                OR: [{ id }, { uuid: id }],
                AND: [{ OR: [{ tenantId: orgId }, { organizationId: orgId }] }],
            },
        });
        if (!device) {
            throw new common_1.NotFoundException("Device not found or access denied");
        }
        device_telemetry_paused_store_1.deviceTelemetryPausedStore.set(device.id, true);
        if (device.uuid) {
            device_telemetry_paused_store_1.deviceTelemetryPausedStore.set(device.uuid, true);
        }
        this.eventEmitter.emit("device.telemetry.status", new domain_events_1.DeviceTelemetryStatusEvent(device.organizationId || orgId, device.id, true));
        return {
            success: true,
            data: {
                id: device.id,
                telemetryPaused: true,
                message: "Telemetry collection has been paused.",
            },
        };
    }
    async resumeTelemetry(tenant, id) {
        const orgId = tenant.organizationId;
        const device = await this.prisma.device.findFirst({
            where: {
                OR: [{ id }, { uuid: id }],
                AND: [{ OR: [{ tenantId: orgId }, { organizationId: orgId }] }],
            },
        });
        if (!device) {
            throw new common_1.NotFoundException("Device not found or access denied");
        }
        device_telemetry_paused_store_1.deviceTelemetryPausedStore.set(device.id, false);
        if (device.uuid) {
            device_telemetry_paused_store_1.deviceTelemetryPausedStore.set(device.uuid, false);
        }
        this.eventEmitter.emit("device.telemetry.status", new domain_events_1.DeviceTelemetryStatusEvent(device.organizationId || orgId, device.id, false));
        return {
            success: true,
            data: {
                id: device.id,
                telemetryPaused: false,
                message: "Telemetry collection has been resumed.",
            },
        };
    }
};
exports.DevicesController = DevicesController;
__decorate([
    (0, common_1.Get)(),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({ summary: "List all devices with latest snapshot" }),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK }),
    __param(0, (0, current_tenant_decorator_1.CurrentTenant)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], DevicesController.prototype, "getDevices", null);
__decorate([
    (0, common_1.Get)("stats"),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({ summary: "Fleet statistics" }),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK }),
    __param(0, (0, current_tenant_decorator_1.CurrentTenant)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], DevicesController.prototype, "getStats", null);
__decorate([
    (0, common_1.Get)(":id"),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({ summary: "Single device details" }),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK }),
    __param(0, (0, current_tenant_decorator_1.CurrentTenant)()),
    __param(1, (0, common_1.Param)("id")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], DevicesController.prototype, "getDeviceById", null);
__decorate([
    (0, common_1.Get)(":id/telemetry"),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({ summary: "Aggregated telemetry" }),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK }),
    __param(0, (0, current_tenant_decorator_1.CurrentTenant)()),
    __param(1, (0, common_1.Param)("id")),
    __param(2, (0, common_1.Query)("range")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String]),
    __metadata("design:returntype", Promise)
], DevicesController.prototype, "getTelemetry", null);
__decorate([
    (0, common_1.Get)(":id/processes"),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({ summary: "Current processes" }),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK }),
    __param(0, (0, current_tenant_decorator_1.CurrentTenant)()),
    __param(1, (0, common_1.Param)("id")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], DevicesController.prototype, "getProcesses", null);
__decorate([
    (0, common_1.Get)(":id/services"),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({ summary: "Windows services" }),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK }),
    __param(0, (0, current_tenant_decorator_1.CurrentTenant)()),
    __param(1, (0, common_1.Param)("id")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], DevicesController.prototype, "getServices", null);
__decorate([
    (0, common_1.Get)(":id/software"),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({ summary: "Installed software" }),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK }),
    __param(0, (0, current_tenant_decorator_1.CurrentTenant)()),
    __param(1, (0, common_1.Param)("id")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], DevicesController.prototype, "getSoftware", null);
__decorate([
    (0, common_1.Get)(":id/alerts"),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({ summary: "Alert history" }),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK }),
    __param(0, (0, current_tenant_decorator_1.CurrentTenant)()),
    __param(1, (0, common_1.Param)("id")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], DevicesController.prototype, "getAlerts", null);
__decorate([
    (0, common_1.Get)(":id/heartbeats"),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({ summary: "Heartbeat history" }),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK }),
    __param(0, (0, current_tenant_decorator_1.CurrentTenant)()),
    __param(1, (0, common_1.Param)("id")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], DevicesController.prototype, "getHeartbeats", null);
__decorate([
    (0, common_1.Delete)(":id"),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({ summary: "Delete a device and all its data" }),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK }),
    __param(0, (0, current_tenant_decorator_1.CurrentTenant)()),
    __param(1, (0, common_1.Param)("id")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], DevicesController.prototype, "deleteDevice", null);
__decorate([
    (0, common_1.Post)(":id/telemetry/pause"),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({ summary: "Pause telemetry collection for a device" }),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK }),
    __param(0, (0, current_tenant_decorator_1.CurrentTenant)()),
    __param(1, (0, common_1.Param)("id")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], DevicesController.prototype, "pauseTelemetry", null);
__decorate([
    (0, common_1.Post)(":id/telemetry/resume"),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({ summary: "Resume telemetry collection for a device" }),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK }),
    __param(0, (0, current_tenant_decorator_1.CurrentTenant)()),
    __param(1, (0, common_1.Param)("id")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], DevicesController.prototype, "resumeTelemetry", null);
exports.DevicesController = DevicesController = __decorate([
    (0, swagger_1.ApiTags)("Frontend Dashboard Devices API"),
    (0, common_1.Controller)("devices"),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        event_emitter_1.EventEmitter2])
], DevicesController);
//# sourceMappingURL=devices.controller.js.map