"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var InventorySearchService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.InventorySearchService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma/prisma.service");
let InventorySearchService = InventorySearchService_1 = class InventorySearchService {
    prisma;
    logger = new common_1.Logger(InventorySearchService_1.name);
    constructor(prisma) {
        this.prisma = prisma;
    }
    async search(params) {
        const { tenantId, query, category, deviceId, page, limit } = params;
        const skip = (page - 1) * limit;
        const tenantFilter = tenantId && tenantId !== "default-org"
            ? { organizationId: tenantId }
            : {};
        if (category === "SERVICES") {
            const where = {};
            where.deviceInventory = {
                device: { ...tenantFilter, ...(deviceId ? { id: deviceId } : {}) },
            };
            if (query) {
                where.OR = [
                    { serviceName: { contains: query, mode: "insensitive" } },
                    { displayName: { contains: query, mode: "insensitive" } },
                ];
            }
            const [total, items] = await Promise.all([
                this.prisma.windowsService.count({ where }),
                this.prisma.windowsService.findMany({
                    where,
                    skip,
                    take: limit,
                    include: { deviceInventory: { include: { device: true } } },
                }),
            ]);
            const data = items.map((i) => ({
                id: i.id,
                deviceId: i.deviceInventory?.deviceId,
                hostname: i.deviceInventory?.device?.hostname || "Unknown",
                serviceName: i.serviceName,
                displayName: i.displayName,
                status: i.status,
                startType: i.startType,
                osEdition: i.deviceInventory?.device?.os || "Unknown",
            }));
            return { success: true, data, meta: { total, page, limit } };
        }
        else if (category === "SECURITY") {
            const where = {
                ...tenantFilter,
                ...(deviceId ? { id: deviceId } : {}),
            };
            if (query) {
                where.hostname = { contains: query, mode: "insensitive" };
            }
            where.inventory = { isNot: null };
            const [total, devices] = await Promise.all([
                this.prisma.device.count({ where }),
                this.prisma.device.findMany({
                    where,
                    skip,
                    take: limit,
                    include: { inventory: { include: { security: true } } },
                }),
            ]);
            const data = devices
                .filter((d) => d.inventory?.security)
                .map((d) => ({
                id: d.inventory.security.id,
                deviceId: d.id,
                hostname: d.hostname,
                defenderEnabled: d.inventory.security.windowsDefenderEnabled,
                firewallEnabled: d.inventory.security.firewallEnabled,
                bitLockerStatus: d.inventory.security.bitLockerEnabled
                    ? "Enabled"
                    : "Disabled",
                tpmVersion: d.inventory.security.tpmVersion,
                osEdition: d.os || "Unknown",
            }));
            return { success: true, data, meta: { total: data.length, page, limit } };
        }
        else if (category === "CHANGES") {
            const where = { ...(deviceId ? { deviceId } : {}) };
            if (query) {
                where.changeDetails = { contains: query, mode: "insensitive" };
            }
            const [total, items] = await Promise.all([
                this.prisma.inventoryAuditLog.count({ where }),
                this.prisma.inventoryAuditLog.findMany({
                    where,
                    orderBy: { timestamp: "desc" },
                    skip,
                    take: limit,
                    include: { device: true },
                }),
            ]);
            const data = items.map((i) => ({
                id: i.id,
                deviceId: i.deviceId,
                hostname: i.device?.hostname || "Unknown",
                action: i.action,
                details: i.changeDetails,
                timestamp: i.timestamp,
                osEdition: i.device?.os || "Unknown",
            }));
            return { success: true, data, meta: { total, page, limit } };
        }
        else {
            const where = {};
            where.deviceInventory = {
                device: { ...tenantFilter, ...(deviceId ? { id: deviceId } : {}) },
            };
            if (query) {
                where.OR = [
                    { name: { contains: query, mode: "insensitive" } },
                    { publisher: { contains: query, mode: "insensitive" } },
                    { version: { contains: query, mode: "insensitive" } },
                ];
            }
            const [total, items] = await Promise.all([
                this.prisma.installedSoftware.count({ where }),
                this.prisma.installedSoftware.findMany({
                    where,
                    skip,
                    take: limit,
                    include: { deviceInventory: { include: { device: true } } },
                }),
            ]);
            const data = items.map((i) => ({
                id: i.id,
                deviceId: i.deviceInventory?.deviceId,
                hostname: i.deviceInventory?.device?.hostname || "Unknown",
                softwareName: i.name,
                publisher: i.publisher || "Unknown",
                version: i.version || "0.0.0",
                installDate: i.installDate,
                osEdition: i.deviceInventory?.device?.os || "Unknown",
            }));
            return { success: true, data, meta: { total, page, limit } };
        }
    }
};
exports.InventorySearchService = InventorySearchService;
exports.InventorySearchService = InventorySearchService = InventorySearchService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], InventorySearchService);
//# sourceMappingURL=inventory-search.service.js.map