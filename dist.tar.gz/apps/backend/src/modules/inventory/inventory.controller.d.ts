import { InventoryService } from "./inventory.service";
import { SubmitInventoryRequestDto, InventoryQueryDto } from "./dto/inventory.dto";
import { Device } from "@prisma/client";
import { ApiResponse, CompleteInventoryResponse, HardwareInventoryResponse, SoftwareInventoryResponse, NetworkInventoryResponse, SecurityInventoryResponse, InventoryHealthResponse } from "@nos/shared-types";
export declare class InventoryController {
    private readonly inventoryService;
    constructor(inventoryService: InventoryService);
    submitInventory(device: Device, dto: SubmitInventoryRequestDto): Promise<ApiResponse<CompleteInventoryResponse>>;
    getHealth(): Promise<ApiResponse<InventoryHealthResponse>>;
    getHardware(deviceId: string): Promise<ApiResponse<HardwareInventoryResponse>>;
    getSoftware(deviceId: string, query: InventoryQueryDto): Promise<ApiResponse<SoftwareInventoryResponse>>;
    getNetwork(deviceId: string): Promise<ApiResponse<NetworkInventoryResponse>>;
    getSecurity(deviceId: string): Promise<ApiResponse<SecurityInventoryResponse>>;
    triggerScan(deviceId: string): Promise<ApiResponse<{
        deviceId: string;
        status: string;
        message: string;
    }>>;
    getCompleteInventory(deviceId: string): Promise<ApiResponse<CompleteInventoryResponse>>;
}
