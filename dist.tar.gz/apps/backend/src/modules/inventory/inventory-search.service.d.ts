import { PrismaService } from "../prisma/prisma.service";
export interface InventorySearchParams {
    tenantId: string;
    query: string;
    category: string;
    deviceId?: string;
    page: number;
    limit: number;
}
export declare class InventorySearchService {
    private readonly prisma;
    private readonly logger;
    constructor(prisma: PrismaService);
    search(params: InventorySearchParams): Promise<{
        success: boolean;
        data: {
            id: string;
            deviceId: string;
            hostname: string;
            serviceName: string;
            displayName: string;
            status: string;
            startType: string;
            osEdition: string;
        }[];
        meta: {
            total: number;
            page: number;
            limit: number;
        };
    } | {
        success: boolean;
        data: {
            id: string;
            deviceId: string;
            hostname: string;
            defenderEnabled: boolean;
            firewallEnabled: boolean;
            bitLockerStatus: string;
            tpmVersion: string;
            osEdition: string;
        }[];
        meta: {
            total: number;
            page: number;
            limit: number;
        };
    } | {
        success: boolean;
        data: {
            id: string;
            deviceId: string;
            hostname: string;
            action: string;
            details: string;
            timestamp: Date;
            osEdition: string;
        }[];
        meta: {
            total: number;
            page: number;
            limit: number;
        };
    } | {
        success: boolean;
        data: {
            id: string;
            deviceId: string;
            hostname: string;
            softwareName: string;
            publisher: string;
            version: string;
            installDate: string;
            osEdition: string;
        }[];
        meta: {
            total: number;
            page: number;
            limit: number;
        };
    }>;
}
