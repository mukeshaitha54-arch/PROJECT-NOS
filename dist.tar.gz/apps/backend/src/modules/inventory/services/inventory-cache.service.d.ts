export declare class InventoryCacheService {
    private readonly logger;
    private readonly cache;
    private readonly DEFAULT_TTL_MS;
    constructor();
    get<T>(key: string): T | null;
    set<T>(key: string, value: T, ttlMs?: number): void;
    invalidate(keyPrefix: string): void;
    clear(): void;
    private cleanup;
}
