"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var InventoryCacheService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.InventoryCacheService = void 0;
const common_1 = require("@nestjs/common");
let InventoryCacheService = InventoryCacheService_1 = class InventoryCacheService {
    logger = new common_1.Logger(InventoryCacheService_1.name);
    cache = new Map();
    DEFAULT_TTL_MS = 5 * 60 * 1000;
    constructor() {
        setInterval(() => this.cleanup(), 60000).unref();
    }
    get(key) {
        const entry = this.cache.get(key);
        if (!entry)
            return null;
        if (Date.now() > entry.expiresAt) {
            this.cache.delete(key);
            return null;
        }
        return entry.value;
    }
    set(key, value, ttlMs = this.DEFAULT_TTL_MS) {
        const expiresAt = Date.now() + ttlMs;
        this.cache.set(key, { value, expiresAt });
    }
    invalidate(keyPrefix) {
        for (const key of this.cache.keys()) {
            if (key.startsWith(keyPrefix)) {
                this.cache.delete(key);
            }
        }
    }
    clear() {
        this.cache.clear();
    }
    cleanup() {
        const now = Date.now();
        for (const [key, entry] of this.cache.entries()) {
            if (now > entry.expiresAt) {
                this.cache.delete(key);
            }
        }
    }
};
exports.InventoryCacheService = InventoryCacheService;
exports.InventoryCacheService = InventoryCacheService = InventoryCacheService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [])
], InventoryCacheService);
//# sourceMappingURL=inventory-cache.service.js.map