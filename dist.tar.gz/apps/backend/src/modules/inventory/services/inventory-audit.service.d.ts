import { SubmitInventoryPayload, DeviceInventoryDto } from "@nos/shared-types";
import { IInventoryRepository } from "../../../common/repositories/inventory.repository.interface";
export declare class InventoryAuditService {
    private readonly logger;
    calculateAssetFingerprint(payload: SubmitInventoryPayload): string;
    detectAndLogDifferences(deviceId: string, previous: DeviceInventoryDto | null, nextPayload: SubmitInventoryPayload, repository: IInventoryRepository): Promise<void>;
}
