"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.InventoryController = void 0;
const openapi = require("@nestjs/swagger");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const inventory_service_1 = require("./inventory.service");
const inventory_dto_1 = require("./dto/inventory.dto");
const device_auth_guard_1 = require("../device/guards/device-auth.guard");
const current_device_decorator_1 = require("../device/decorators/current-device.decorator");
const throttler_1 = require("@nestjs/throttler");
let InventoryController = class InventoryController {
    inventoryService;
    constructor(inventoryService) {
        this.inventoryService = inventoryService;
    }
    async submitInventory(device, dto) {
        const data = await this.inventoryService.submitInventory(dto, device?.id || dto.deviceId);
        return {
            success: true,
            data,
            timestamp: new Date().toISOString(),
        };
    }
    async getHealth() {
        const data = await this.inventoryService.getHealthDiagnostics();
        return {
            success: true,
            data,
            timestamp: new Date().toISOString(),
        };
    }
    async getHardware(deviceId) {
        const data = await this.inventoryService.getHardwareInventory(deviceId);
        return {
            success: true,
            data,
            timestamp: new Date().toISOString(),
        };
    }
    async getSoftware(deviceId, query) {
        const data = await this.inventoryService.getSoftwareInventory(deviceId, query);
        return {
            success: true,
            data,
            timestamp: new Date().toISOString(),
        };
    }
    async getNetwork(deviceId) {
        const data = await this.inventoryService.getNetworkInventory(deviceId);
        return {
            success: true,
            data,
            timestamp: new Date().toISOString(),
        };
    }
    async getSecurity(deviceId) {
        const data = await this.inventoryService.getSecurityInventory(deviceId);
        return {
            success: true,
            data,
            timestamp: new Date().toISOString(),
        };
    }
    async triggerScan(deviceId) {
        const data = await this.inventoryService.triggerManualScan(deviceId);
        return {
            success: true,
            data,
            timestamp: new Date().toISOString(),
        };
    }
    async getCompleteInventory(deviceId) {
        const data = await this.inventoryService.getCompleteInventory(deviceId);
        return {
            success: true,
            data,
            timestamp: new Date().toISOString(),
        };
    }
};
exports.InventoryController = InventoryController;
__decorate([
    (0, common_1.Post)(),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, common_1.UseGuards)(device_auth_guard_1.DeviceAuthGuard),
    (0, swagger_1.ApiOperation)({
        summary: "Upload comprehensive device asset inventory",
        description: "Ingests hardware, installed software, Windows services, startup applications, security state, and system capabilities. Protected via X-Device-Token.",
    }),
    (0, swagger_1.ApiHeader)({
        name: "X-Device-Token",
        required: true,
        description: "Cryptographic device authentication token",
    }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: "Inventory successfully validated and persisted.",
    }),
    (0, swagger_1.ApiResponse)({
        status: 401,
        description: "Invalid or missing X-Device-Token.",
    }),
    (0, swagger_1.ApiResponse)({
        status: 503,
        description: "Inventory engine disabled via feature flags.",
    }),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK }),
    __param(0, (0, current_device_decorator_1.CurrentDevice)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, inventory_dto_1.SubmitInventoryRequestDto]),
    __metadata("design:returntype", Promise)
], InventoryController.prototype, "submitInventory", null);
__decorate([
    (0, common_1.Get)("health"),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({
        summary: "Retrieve inventory diagnostic health and freshness metrics",
        description: "Returns versioning, agent compliance, and scan freshness diagnostics across the enterprise topology.",
    }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: "Diagnostic health data returned successfully.",
    }),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], InventoryController.prototype, "getHealth", null);
__decorate([
    (0, common_1.Get)("hardware/:deviceId"),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({
        summary: "Retrieve hardware asset specification (CPU, Motherboard, RAM, Disks, GPUs)",
    }),
    (0, swagger_1.ApiParam)({
        name: "deviceId",
        required: true,
        description: "Target Node Primary Key UUID",
    }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: "Hardware inventory returned successfully.",
    }),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK }),
    __param(0, (0, common_1.Param)("deviceId")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], InventoryController.prototype, "getHardware", null);
__decorate([
    (0, common_1.Get)("software/:deviceId"),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({
        summary: "Retrieve paginated installed software, Windows services, and startup applications",
    }),
    (0, swagger_1.ApiParam)({
        name: "deviceId",
        required: true,
        description: "Target Node Primary Key UUID",
    }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: "Software and service inventory returned successfully.",
    }),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK }),
    __param(0, (0, common_1.Param)("deviceId")),
    __param(1, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, inventory_dto_1.InventoryQueryDto]),
    __metadata("design:returntype", Promise)
], InventoryController.prototype, "getSoftware", null);
__decorate([
    (0, common_1.Get)("network/:deviceId"),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({
        summary: "Retrieve network interface parameters and active IP configurations",
    }),
    (0, swagger_1.ApiParam)({
        name: "deviceId",
        required: true,
        description: "Target Node Primary Key UUID",
    }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: "Network adapter inventory returned successfully.",
    }),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK }),
    __param(0, (0, common_1.Param)("deviceId")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], InventoryController.prototype, "getNetwork", null);
__decorate([
    (0, common_1.Get)("security/:deviceId"),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({
        summary: "Retrieve hardware security compliance and system virtualization capability flags",
    }),
    (0, swagger_1.ApiParam)({
        name: "deviceId",
        required: true,
        description: "Target Node Primary Key UUID",
    }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: "Security and capability inventory returned successfully.",
    }),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK }),
    __param(0, (0, common_1.Param)("deviceId")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], InventoryController.prototype, "getSecurity", null);
__decorate([
    (0, common_1.Post)("scan/:deviceId"),
    (0, common_1.HttpCode)(common_1.HttpStatus.ACCEPTED),
    (0, swagger_1.ApiOperation)({
        summary: "Trigger manual inventory diagnostic re-scan for a monitored node",
        description: "Records scan invocation request in control plane audit log. Future monitoring agents will consume and execute without direct remote shelling.",
    }),
    (0, swagger_1.ApiParam)({
        name: "deviceId",
        required: true,
        description: "Target Node Primary Key UUID",
    }),
    (0, swagger_1.ApiResponse)({
        status: 202,
        description: "Scan request scheduled successfully.",
    }),
    openapi.ApiResponse({ status: common_1.HttpStatus.ACCEPTED }),
    __param(0, (0, common_1.Param)("deviceId")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], InventoryController.prototype, "triggerScan", null);
__decorate([
    (0, common_1.Get)(":deviceId"),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({
        summary: "Retrieve complete asset profile and recent audit difference logs",
    }),
    (0, swagger_1.ApiParam)({
        name: "deviceId",
        required: true,
        description: "Target Node Primary Key UUID",
    }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: "Complete device inventory profile returned successfully.",
    }),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK }),
    __param(0, (0, common_1.Param)("deviceId")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], InventoryController.prototype, "getCompleteInventory", null);
exports.InventoryController = InventoryController = __decorate([
    (0, swagger_1.ApiTags)("Inventory - Asset & Discovery Engine"),
    (0, throttler_1.SkipThrottle)(),
    (0, throttler_1.SkipThrottle)({ default: true, auth: true, telemetry: true }),
    (0, common_1.Controller)("inventory"),
    __metadata("design:paramtypes", [inventory_service_1.InventoryService])
], InventoryController);
//# sourceMappingURL=inventory.controller.js.map