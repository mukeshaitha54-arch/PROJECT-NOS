"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.InventorySearchController = void 0;
const openapi = require("@nestjs/swagger");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const jwt_auth_guard_1 = require("../auth/guards/jwt-auth.guard");
const tenant_guard_1 = require("../auth/guards/tenant.guard");
const current_tenant_decorator_1 = require("../../common/decorators/current-tenant.decorator");
const inventory_search_service_1 = require("./inventory-search.service");
let InventorySearchController = class InventorySearchController {
    searchService;
    constructor(searchService) {
        this.searchService = searchService;
    }
    async search(tenant, q, query, category, tab, deviceId, page, limit) {
        const tenantId = tenant?.organizationId || "default-org";
        const searchTerm = q !== undefined ? q : query || "";
        const categoryTerm = category !== undefined ? category : tab || "SOFTWARE";
        const pageNum = Number(page) && Number(page) > 0 ? Number(page) : 1;
        const limitNum = Number(limit) && Number(limit) > 0 ? Number(limit) : 20;
        return this.searchService.search({
            tenantId,
            query: searchTerm,
            category: categoryTerm.toUpperCase(),
            deviceId,
            page: pageNum,
            limit: limitNum,
        });
    }
};
exports.InventorySearchController = InventorySearchController;
__decorate([
    (0, common_1.Get)(),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({
        summary: "Search asset inventory by software name, publisher, version with pagination and tenant scoping",
    }),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK, type: Object }),
    __param(0, (0, current_tenant_decorator_1.CurrentTenant)()),
    __param(1, (0, common_1.Query)("q")),
    __param(2, (0, common_1.Query)("query")),
    __param(3, (0, common_1.Query)("category")),
    __param(4, (0, common_1.Query)("tab")),
    __param(5, (0, common_1.Query)("deviceId")),
    __param(6, (0, common_1.Query)("page")),
    __param(7, (0, common_1.Query)("limit")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, String, String, String, Number, Number]),
    __metadata("design:returntype", Promise)
], InventorySearchController.prototype, "search", null);
exports.InventorySearchController = InventorySearchController = __decorate([
    (0, swagger_1.ApiTags)("Inventory - Search Engine"),
    (0, common_1.Controller)("inventory/search"),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, tenant_guard_1.TenantGuard),
    (0, swagger_1.ApiBearerAuth)(),
    __metadata("design:paramtypes", [inventory_search_service_1.InventorySearchService])
], InventorySearchController);
//# sourceMappingURL=inventory-search.controller.js.map