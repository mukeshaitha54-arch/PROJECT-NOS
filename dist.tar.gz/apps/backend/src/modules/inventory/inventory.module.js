"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.InventoryModule = void 0;
const common_1 = require("@nestjs/common");
const inventory_controller_1 = require("./inventory.controller");
const inventory_search_controller_1 = require("./inventory-search.controller");
const inventory_service_1 = require("./inventory.service");
const inventory_search_service_1 = require("./inventory-search.service");
const inventory_cache_service_1 = require("./services/inventory-cache.service");
const inventory_audit_service_1 = require("./services/inventory-audit.service");
const inventory_repository_interface_1 = require("../../common/repositories/inventory.repository.interface");
const prisma_inventory_repository_1 = require("../../database/repositories/prisma-inventory.repository");
const database_module_1 = require("../../database/database.module");
const device_module_1 = require("../device/device.module");
let InventoryModule = class InventoryModule {
};
exports.InventoryModule = InventoryModule;
exports.InventoryModule = InventoryModule = __decorate([
    (0, common_1.Module)({
        imports: [database_module_1.DatabaseModule, (0, common_1.forwardRef)(() => device_module_1.DeviceModule)],
        controllers: [inventory_controller_1.InventoryController, inventory_search_controller_1.InventorySearchController],
        providers: [
            inventory_service_1.InventoryService,
            inventory_search_service_1.InventorySearchService,
            inventory_cache_service_1.InventoryCacheService,
            inventory_audit_service_1.InventoryAuditService,
            {
                provide: inventory_repository_interface_1.IInventoryRepository,
                useClass: prisma_inventory_repository_1.PrismaInventoryRepository,
            },
        ],
        exports: [inventory_service_1.InventoryService, inventory_search_service_1.InventorySearchService, inventory_repository_interface_1.IInventoryRepository],
    })
], InventoryModule);
//# sourceMappingURL=inventory.module.js.map