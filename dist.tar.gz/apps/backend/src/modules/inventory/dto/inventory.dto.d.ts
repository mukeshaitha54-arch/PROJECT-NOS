import { SubmitInventoryPayload, MemoryModuleDto, DiskDriveDto, GpuDto, NetworkAdapterDto, InstalledSoftwareDto, WindowsServiceDto, StartupApplicationDto, SecurityInventoryDto, DeviceCapabilitiesDto } from "@nos/shared-types";
export declare class MemoryModulePayloadDto implements MemoryModuleDto {
    slot?: string;
    capacityBytes?: number;
    speedMHz?: number;
    manufacturer?: string;
    partNumber?: string;
    serialNumber?: string;
}
export declare class DiskDrivePayloadDto implements DiskDriveDto {
    driveName?: string;
    model?: string;
    serialNumber?: string;
    mediaType?: string;
    sizeBytes?: number;
    fileSystem?: string;
    isSystemDrive?: boolean;
}
export declare class GpuPayloadDto implements GpuDto {
    name?: string;
    manufacturer?: string;
    driverVersion?: string;
    vRamBytes?: number;
    resolution?: string;
}
export declare class NetworkAdapterPayloadDto implements NetworkAdapterDto {
    name?: string;
    description?: string;
    macAddress?: string;
    ipv4?: string;
    ipv6?: string;
    gateway?: string;
    dns?: string;
    speedMbps?: number;
    isWireless?: boolean;
    isPhysical?: boolean;
    isOperational?: boolean;
}
export declare class InstalledSoftwarePayloadDto implements InstalledSoftwareDto {
    name?: string;
    publisher?: string;
    version?: string;
    installDate?: string;
    installLocation?: string;
}
export declare class WindowsServicePayloadDto implements WindowsServiceDto {
    serviceName?: string;
    displayName?: string;
    status?: string;
    startType?: string;
    account?: string;
}
export declare class StartupApplicationPayloadDto implements StartupApplicationDto {
    name?: string;
    command?: string;
    location?: string;
    user?: string;
}
export declare class SecurityInventoryPayloadDto implements SecurityInventoryDto {
    windowsDefenderEnabled?: boolean;
    firewallEnabled?: boolean;
    bitLockerEnabled?: boolean;
    bitLockerDrive?: string;
    secureBootEnabled?: boolean;
    tpmEnabled?: boolean;
    tpmVersion?: string;
}
export declare class DeviceCapabilitiesPayloadDto implements DeviceCapabilitiesDto {
    supportsGPU?: boolean;
    supportsBattery?: boolean;
    supportsTPM?: boolean;
    supportsVirtualization?: boolean;
    supportsDocker?: boolean;
    supportsWSL?: boolean;
    supportsWiFi?: boolean;
    supportsEthernet?: boolean;
    virtualMachineDetection?: boolean;
    vmVendor?: string;
}
export declare class SubmitInventoryRequestDto implements SubmitInventoryPayload {
    deviceId?: string;
    manufacturer?: string;
    model?: string;
    serialNumber?: string;
    motherboard?: string;
    biosVendor?: string;
    biosVersion?: string;
    biosReleaseDate?: string;
    cpuModel?: string;
    cpuVendor?: string;
    physicalCores?: number;
    logicalCores?: number;
    hostname?: string;
    domain?: string;
    workgroup?: string;
    osEdition?: string;
    osBuild?: string;
    architecture?: string;
    agentVersion?: string;
    schemaVersion?: string;
    memoryModules?: MemoryModulePayloadDto[];
    diskDrives?: DiskDrivePayloadDto[];
    gpus?: GpuPayloadDto[];
    networkAdapters?: NetworkAdapterPayloadDto[];
    installedSoftware?: InstalledSoftwarePayloadDto[];
    windowsServices?: WindowsServicePayloadDto[];
    startupApplications?: StartupApplicationPayloadDto[];
    security?: SecurityInventoryPayloadDto;
    capabilities?: DeviceCapabilitiesPayloadDto;
}
export declare class InventoryQueryDto {
    search?: string;
    page?: number;
    limit?: number;
}
