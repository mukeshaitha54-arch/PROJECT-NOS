"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.InventoryQueryDto = exports.SubmitInventoryRequestDto = exports.DeviceCapabilitiesPayloadDto = exports.SecurityInventoryPayloadDto = exports.StartupApplicationPayloadDto = exports.WindowsServicePayloadDto = exports.InstalledSoftwarePayloadDto = exports.NetworkAdapterPayloadDto = exports.GpuPayloadDto = exports.DiskDrivePayloadDto = exports.MemoryModulePayloadDto = void 0;
const openapi = require("@nestjs/swagger");
const class_validator_1 = require("class-validator");
const class_transformer_1 = require("class-transformer");
const swagger_1 = require("@nestjs/swagger");
class MemoryModulePayloadDto {
    slot;
    capacityBytes;
    speedMHz;
    manufacturer;
    partNumber;
    serialNumber;
    static _OPENAPI_METADATA_FACTORY() {
        return { slot: { required: false, type: () => String }, capacityBytes: { required: false, type: () => Number }, speedMHz: { required: false, type: () => Number, minimum: 0 }, manufacturer: { required: false, type: () => String }, partNumber: { required: false, type: () => String }, serialNumber: { required: false, type: () => String } };
    }
}
exports.MemoryModulePayloadDto = MemoryModulePayloadDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "DIMM 1" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], MemoryModulePayloadDto.prototype, "slot", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 17179869184 }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], MemoryModulePayloadDto.prototype, "capacityBytes", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 3200 }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], MemoryModulePayloadDto.prototype, "speedMHz", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "Samsung" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], MemoryModulePayloadDto.prototype, "manufacturer", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "M378A2K43D10-KH2" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], MemoryModulePayloadDto.prototype, "partNumber", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "12345678" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], MemoryModulePayloadDto.prototype, "serialNumber", void 0);
class DiskDrivePayloadDto {
    driveName;
    model;
    serialNumber;
    mediaType;
    sizeBytes;
    fileSystem;
    isSystemDrive;
    static _OPENAPI_METADATA_FACTORY() {
        return { driveName: { required: false, type: () => String }, model: { required: false, type: () => String }, serialNumber: { required: false, type: () => String }, mediaType: { required: false, type: () => String }, sizeBytes: { required: false, type: () => Number }, fileSystem: { required: false, type: () => String }, isSystemDrive: { required: false, type: () => Boolean } };
    }
}
exports.DiskDrivePayloadDto = DiskDrivePayloadDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "C:\\" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], DiskDrivePayloadDto.prototype, "driveName", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "Samsung SSD 980 PRO 1TB" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], DiskDrivePayloadDto.prototype, "model", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "S5GXNF0R123456" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], DiskDrivePayloadDto.prototype, "serialNumber", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "NVMe" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], DiskDrivePayloadDto.prototype, "mediaType", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 1000204886016 }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], DiskDrivePayloadDto.prototype, "sizeBytes", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "NTFS" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], DiskDrivePayloadDto.prototype, "fileSystem", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: true }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], DiskDrivePayloadDto.prototype, "isSystemDrive", void 0);
class GpuPayloadDto {
    name;
    manufacturer;
    driverVersion;
    vRamBytes;
    resolution;
    static _OPENAPI_METADATA_FACTORY() {
        return { name: { required: false, type: () => String }, manufacturer: { required: false, type: () => String }, driverVersion: { required: false, type: () => String }, vRamBytes: { required: false, type: () => Number }, resolution: { required: false, type: () => String } };
    }
}
exports.GpuPayloadDto = GpuPayloadDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "NVIDIA GeForce RTX 4080" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], GpuPayloadDto.prototype, "name", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "NVIDIA" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], GpuPayloadDto.prototype, "manufacturer", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "537.58" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], GpuPayloadDto.prototype, "driverVersion", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 17179869184 }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], GpuPayloadDto.prototype, "vRamBytes", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "3840x2160" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], GpuPayloadDto.prototype, "resolution", void 0);
class NetworkAdapterPayloadDto {
    name;
    description;
    macAddress;
    ipv4;
    ipv6;
    gateway;
    dns;
    speedMbps;
    isWireless;
    isPhysical;
    isOperational;
    static _OPENAPI_METADATA_FACTORY() {
        return { name: { required: false, type: () => String }, description: { required: false, type: () => String }, macAddress: { required: false, type: () => String }, ipv4: { required: false, type: () => String }, ipv6: { required: false, type: () => String }, gateway: { required: false, type: () => String }, dns: { required: false, type: () => String }, speedMbps: { required: false, type: () => Number }, isWireless: { required: false, type: () => Boolean }, isPhysical: { required: false, type: () => Boolean }, isOperational: { required: false, type: () => Boolean } };
    }
}
exports.NetworkAdapterPayloadDto = NetworkAdapterPayloadDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "Intel(R) Ethernet Controller I225-V" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], NetworkAdapterPayloadDto.prototype, "name", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "Gigabit Network Connection" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], NetworkAdapterPayloadDto.prototype, "description", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "00:1B:2C:3D:4E:5F" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], NetworkAdapterPayloadDto.prototype, "macAddress", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "192.168.1.100" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], NetworkAdapterPayloadDto.prototype, "ipv4", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "fe80::21b:2cff:fe3d:4e5f" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], NetworkAdapterPayloadDto.prototype, "ipv6", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "192.168.1.1" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], NetworkAdapterPayloadDto.prototype, "gateway", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "8.8.8.8, 1.1.1.1" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], NetworkAdapterPayloadDto.prototype, "dns", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 2500 }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], NetworkAdapterPayloadDto.prototype, "speedMbps", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], NetworkAdapterPayloadDto.prototype, "isWireless", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: true }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], NetworkAdapterPayloadDto.prototype, "isPhysical", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: true }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], NetworkAdapterPayloadDto.prototype, "isOperational", void 0);
class InstalledSoftwarePayloadDto {
    name;
    publisher;
    version;
    installDate;
    installLocation;
    static _OPENAPI_METADATA_FACTORY() {
        return { name: { required: false, type: () => String }, publisher: { required: false, type: () => String }, version: { required: false, type: () => String }, installDate: { required: false, type: () => String }, installLocation: { required: false, type: () => String } };
    }
}
exports.InstalledSoftwarePayloadDto = InstalledSoftwarePayloadDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "Google Chrome" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], InstalledSoftwarePayloadDto.prototype, "name", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "Google LLC" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], InstalledSoftwarePayloadDto.prototype, "publisher", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "120.0.6099.225" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], InstalledSoftwarePayloadDto.prototype, "version", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "2025-01-15" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], InstalledSoftwarePayloadDto.prototype, "installDate", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "C:\\Program Files\\Google\\Chrome" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], InstalledSoftwarePayloadDto.prototype, "installLocation", void 0);
class WindowsServicePayloadDto {
    serviceName;
    displayName;
    status;
    startType;
    account;
    static _OPENAPI_METADATA_FACTORY() {
        return { serviceName: { required: false, type: () => String }, displayName: { required: false, type: () => String }, status: { required: false, type: () => String }, startType: { required: false, type: () => String }, account: { required: false, type: () => String } };
    }
}
exports.WindowsServicePayloadDto = WindowsServicePayloadDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "Winmgmt" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], WindowsServicePayloadDto.prototype, "serviceName", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "Windows Management Instrumentation" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], WindowsServicePayloadDto.prototype, "displayName", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "Running" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], WindowsServicePayloadDto.prototype, "status", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "Automatic" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], WindowsServicePayloadDto.prototype, "startType", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "LocalSystem" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], WindowsServicePayloadDto.prototype, "account", void 0);
class StartupApplicationPayloadDto {
    name;
    command;
    location;
    user;
    static _OPENAPI_METADATA_FACTORY() {
        return { name: { required: false, type: () => String }, command: { required: false, type: () => String }, location: { required: false, type: () => String }, user: { required: false, type: () => String } };
    }
}
exports.StartupApplicationPayloadDto = StartupApplicationPayloadDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "OneDrive" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], StartupApplicationPayloadDto.prototype, "name", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: "C:\\Program Files\\Microsoft OneDrive\\OneDrive.exe /background",
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], StartupApplicationPayloadDto.prototype, "command", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run",
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], StartupApplicationPayloadDto.prototype, "location", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "Current User" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], StartupApplicationPayloadDto.prototype, "user", void 0);
class SecurityInventoryPayloadDto {
    windowsDefenderEnabled;
    firewallEnabled;
    bitLockerEnabled;
    bitLockerDrive;
    secureBootEnabled;
    tpmEnabled;
    tpmVersion;
    static _OPENAPI_METADATA_FACTORY() {
        return { windowsDefenderEnabled: { required: false, type: () => Boolean }, firewallEnabled: { required: false, type: () => Boolean }, bitLockerEnabled: { required: false, type: () => Boolean }, bitLockerDrive: { required: false, type: () => String }, secureBootEnabled: { required: false, type: () => Boolean }, tpmEnabled: { required: false, type: () => Boolean }, tpmVersion: { required: false, type: () => String } };
    }
}
exports.SecurityInventoryPayloadDto = SecurityInventoryPayloadDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: true }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], SecurityInventoryPayloadDto.prototype, "windowsDefenderEnabled", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: true }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], SecurityInventoryPayloadDto.prototype, "firewallEnabled", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: true }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], SecurityInventoryPayloadDto.prototype, "bitLockerEnabled", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "C:" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], SecurityInventoryPayloadDto.prototype, "bitLockerDrive", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: true }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], SecurityInventoryPayloadDto.prototype, "secureBootEnabled", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: true }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], SecurityInventoryPayloadDto.prototype, "tpmEnabled", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "2.0" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], SecurityInventoryPayloadDto.prototype, "tpmVersion", void 0);
class DeviceCapabilitiesPayloadDto {
    supportsGPU;
    supportsBattery;
    supportsTPM;
    supportsVirtualization;
    supportsDocker;
    supportsWSL;
    supportsWiFi;
    supportsEthernet;
    virtualMachineDetection;
    vmVendor;
    static _OPENAPI_METADATA_FACTORY() {
        return { supportsGPU: { required: false, type: () => Boolean }, supportsBattery: { required: false, type: () => Boolean }, supportsTPM: { required: false, type: () => Boolean }, supportsVirtualization: { required: false, type: () => Boolean }, supportsDocker: { required: false, type: () => Boolean }, supportsWSL: { required: false, type: () => Boolean }, supportsWiFi: { required: false, type: () => Boolean }, supportsEthernet: { required: false, type: () => Boolean }, virtualMachineDetection: { required: false, type: () => Boolean }, vmVendor: { required: false, type: () => String } };
    }
}
exports.DeviceCapabilitiesPayloadDto = DeviceCapabilitiesPayloadDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: true }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], DeviceCapabilitiesPayloadDto.prototype, "supportsGPU", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], DeviceCapabilitiesPayloadDto.prototype, "supportsBattery", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: true }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], DeviceCapabilitiesPayloadDto.prototype, "supportsTPM", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: true }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], DeviceCapabilitiesPayloadDto.prototype, "supportsVirtualization", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: true }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], DeviceCapabilitiesPayloadDto.prototype, "supportsDocker", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: true }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], DeviceCapabilitiesPayloadDto.prototype, "supportsWSL", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: true }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], DeviceCapabilitiesPayloadDto.prototype, "supportsWiFi", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: true }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], DeviceCapabilitiesPayloadDto.prototype, "supportsEthernet", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: false }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], DeviceCapabilitiesPayloadDto.prototype, "virtualMachineDetection", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: null }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], DeviceCapabilitiesPayloadDto.prototype, "vmVendor", void 0);
class SubmitInventoryRequestDto {
    deviceId;
    manufacturer;
    model;
    serialNumber;
    motherboard;
    biosVendor;
    biosVersion;
    biosReleaseDate;
    cpuModel;
    cpuVendor;
    physicalCores;
    logicalCores;
    hostname;
    domain;
    workgroup;
    osEdition;
    osBuild;
    architecture;
    agentVersion;
    schemaVersion;
    memoryModules;
    diskDrives;
    gpus;
    networkAdapters;
    installedSoftware;
    windowsServices;
    startupApplications;
    security;
    capabilities;
    static _OPENAPI_METADATA_FACTORY() {
        return { deviceId: { required: false, type: () => String }, manufacturer: { required: false, type: () => String }, model: { required: false, type: () => String }, serialNumber: { required: false, type: () => String }, motherboard: { required: false, type: () => String }, biosVendor: { required: false, type: () => String }, biosVersion: { required: false, type: () => String }, biosReleaseDate: { required: false, type: () => String }, cpuModel: { required: false, type: () => String }, cpuVendor: { required: false, type: () => String }, physicalCores: { required: false, type: () => Number, minimum: 1 }, logicalCores: { required: false, type: () => Number, minimum: 1 }, hostname: { required: false, type: () => String }, domain: { required: false, type: () => String }, workgroup: { required: false, type: () => String }, osEdition: { required: false, type: () => String }, osBuild: { required: false, type: () => String }, architecture: { required: false, type: () => String }, agentVersion: { required: false, type: () => String }, schemaVersion: { required: false, type: () => String }, memoryModules: { required: false, type: () => [require("./inventory.dto").MemoryModulePayloadDto] }, diskDrives: { required: false, type: () => [require("./inventory.dto").DiskDrivePayloadDto] }, gpus: { required: false, type: () => [require("./inventory.dto").GpuPayloadDto] }, networkAdapters: { required: false, type: () => [require("./inventory.dto").NetworkAdapterPayloadDto] }, installedSoftware: { required: false, type: () => [require("./inventory.dto").InstalledSoftwarePayloadDto] }, windowsServices: { required: false, type: () => [require("./inventory.dto").WindowsServicePayloadDto] }, startupApplications: { required: false, type: () => [require("./inventory.dto").StartupApplicationPayloadDto] }, security: { required: false, type: () => require("./inventory.dto").SecurityInventoryPayloadDto }, capabilities: { required: false, type: () => require("./inventory.dto").DeviceCapabilitiesPayloadDto } };
    }
}
exports.SubmitInventoryRequestDto = SubmitInventoryRequestDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "uuid" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], SubmitInventoryRequestDto.prototype, "deviceId", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "Dell Inc." }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], SubmitInventoryRequestDto.prototype, "manufacturer", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "PowerEdge R750" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], SubmitInventoryRequestDto.prototype, "model", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "CN-12345" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], SubmitInventoryRequestDto.prototype, "serialNumber", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "0X1Y2Z" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], SubmitInventoryRequestDto.prototype, "motherboard", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "American Megatrends Inc." }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], SubmitInventoryRequestDto.prototype, "biosVendor", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "2.14.0" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], SubmitInventoryRequestDto.prototype, "biosVersion", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "2024-05-10" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], SubmitInventoryRequestDto.prototype, "biosReleaseDate", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "Intel Xeon Platinum 8368" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], SubmitInventoryRequestDto.prototype, "cpuModel", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "GenuineIntel" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], SubmitInventoryRequestDto.prototype, "cpuVendor", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 38 }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], SubmitInventoryRequestDto.prototype, "physicalCores", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 76 }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], SubmitInventoryRequestDto.prototype, "logicalCores", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "EDGE-NODE-01" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], SubmitInventoryRequestDto.prototype, "hostname", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "CORP.LOCAL" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], SubmitInventoryRequestDto.prototype, "domain", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "WORKGROUP" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], SubmitInventoryRequestDto.prototype, "workgroup", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "Windows Server 2022 Datacenter" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], SubmitInventoryRequestDto.prototype, "osEdition", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "20348.2227" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], SubmitInventoryRequestDto.prototype, "osBuild", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "x64" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], SubmitInventoryRequestDto.prototype, "architecture", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "2.0.0-phase3" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], SubmitInventoryRequestDto.prototype, "agentVersion", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "1.0.0" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], SubmitInventoryRequestDto.prototype, "schemaVersion", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ type: [MemoryModulePayloadDto] }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => MemoryModulePayloadDto),
    __metadata("design:type", Array)
], SubmitInventoryRequestDto.prototype, "memoryModules", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ type: [DiskDrivePayloadDto] }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => DiskDrivePayloadDto),
    __metadata("design:type", Array)
], SubmitInventoryRequestDto.prototype, "diskDrives", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ type: [GpuPayloadDto] }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => GpuPayloadDto),
    __metadata("design:type", Array)
], SubmitInventoryRequestDto.prototype, "gpus", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ type: [NetworkAdapterPayloadDto] }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => NetworkAdapterPayloadDto),
    __metadata("design:type", Array)
], SubmitInventoryRequestDto.prototype, "networkAdapters", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ type: [InstalledSoftwarePayloadDto] }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => InstalledSoftwarePayloadDto),
    __metadata("design:type", Array)
], SubmitInventoryRequestDto.prototype, "installedSoftware", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ type: [WindowsServicePayloadDto] }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => WindowsServicePayloadDto),
    __metadata("design:type", Array)
], SubmitInventoryRequestDto.prototype, "windowsServices", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ type: [StartupApplicationPayloadDto] }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => StartupApplicationPayloadDto),
    __metadata("design:type", Array)
], SubmitInventoryRequestDto.prototype, "startupApplications", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ type: SecurityInventoryPayloadDto }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.ValidateNested)(),
    (0, class_transformer_1.Type)(() => SecurityInventoryPayloadDto),
    __metadata("design:type", SecurityInventoryPayloadDto)
], SubmitInventoryRequestDto.prototype, "security", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ type: DeviceCapabilitiesPayloadDto }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.ValidateNested)(),
    (0, class_transformer_1.Type)(() => DeviceCapabilitiesPayloadDto),
    __metadata("design:type", DeviceCapabilitiesPayloadDto)
], SubmitInventoryRequestDto.prototype, "capabilities", void 0);
class InventoryQueryDto {
    search;
    page = 1;
    limit = 50;
    static _OPENAPI_METADATA_FACTORY() {
        return { search: { required: false, type: () => String }, page: { required: false, type: () => Number, default: 1, minimum: 1 }, limit: { required: false, type: () => Number, default: 50, minimum: 1 } };
    }
}
exports.InventoryQueryDto = InventoryQueryDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: "Chrome" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], InventoryQueryDto.prototype, "search", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 1, default: 1 }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    (0, class_transformer_1.Type)(() => Number),
    __metadata("design:type", Number)
], InventoryQueryDto.prototype, "page", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 50, default: 50 }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    (0, class_transformer_1.Type)(() => Number),
    __metadata("design:type", Number)
], InventoryQueryDto.prototype, "limit", void 0);
//# sourceMappingURL=inventory.dto.js.map