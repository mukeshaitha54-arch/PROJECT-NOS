"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var InventoryService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.InventoryService = void 0;
const common_1 = require("@nestjs/common");
const event_emitter_1 = require("@nestjs/event-emitter");
const inventory_repository_interface_1 = require("../../common/repositories/inventory.repository.interface");
const inventory_cache_service_1 = require("./services/inventory-cache.service");
const inventory_audit_service_1 = require("./services/inventory-audit.service");
const prisma_service_1 = require("../../database/prisma.service");
const domain_events_1 = require("../../common/events/domain-events");
let InventoryService = InventoryService_1 = class InventoryService {
    repository;
    cache;
    audit;
    prisma;
    eventEmitter;
    logger = new common_1.Logger(InventoryService_1.name);
    constructor(repository, cache, audit, prisma, eventEmitter) {
        this.repository = repository;
        this.cache = cache;
        this.audit = audit;
        this.prisma = prisma;
        this.eventEmitter = eventEmitter;
    }
    checkFeatureFlag() {
        if (process.env.FEATURE_INVENTORY_ENABLED === "false") {
            this.logger.warn("Inventory engine invoked while FEATURE_INVENTORY_ENABLED=false");
            throw new common_1.ServiceUnavailableException("Device Inventory & Asset Discovery Engine is currently disabled by enterprise feature flags.");
        }
    }
    async submitInventory(payload, authenticatedDeviceId) {
        this.checkFeatureFlag();
        const targetDeviceId = authenticatedDeviceId || payload.deviceId;
        if (!targetDeviceId) {
            throw new common_1.NotFoundException("Target device ID is required to register system inventory.");
        }
        const fingerprint = this.audit.calculateAssetFingerprint(payload);
        const { inventory, previousInventory } = await this.repository.upsertInventory(targetDeviceId, payload, fingerprint);
        const diffResult = await this.audit.detectAndLogDifferences(targetDeviceId, previousInventory, payload, this.repository);
        this.cache.invalidate(`inv:${targetDeviceId}`);
        const recentAuditLogs = await this.repository.getRecentAuditLogs(targetDeviceId);
        const device = await this.prisma.device.findUnique({
            where: { id: targetDeviceId },
            select: { organizationId: true },
        });
        this.eventEmitter.emit("inventory.updated", new domain_events_1.InventoryUpdatedEvent(device?.organizationId || "default-org", targetDeviceId, inventory.inventoryVersion || 1, fingerprint, diffResult !== null && diffResult !== undefined, typeof diffResult === "string"
            ? diffResult
            : `Inventory version ${inventory.inventoryVersion || 1} recorded.`));
        return {
            inventory,
            recentAuditLogs,
        };
    }
    async getCompleteInventory(deviceId) {
        this.checkFeatureFlag();
        const cacheKey = `inv:${deviceId}:complete`;
        const cached = this.cache.get(cacheKey);
        if (cached) {
            return cached;
        }
        const inventory = await this.repository.findCompleteInventory(deviceId);
        if (!inventory) {
            throw new common_1.NotFoundException(`No hardware or asset inventory discovered for device ${deviceId}`);
        }
        const recentAuditLogs = await this.repository.getRecentAuditLogs(deviceId);
        const response = { inventory, recentAuditLogs };
        this.cache.set(cacheKey, response);
        return response;
    }
    async getHardwareInventory(deviceId) {
        this.checkFeatureFlag();
        const cacheKey = `inv:${deviceId}:hw`;
        const cached = this.cache.get(cacheKey);
        if (cached)
            return cached;
        const hw = await this.repository.findHardwareInventory(deviceId);
        if (!hw) {
            throw new common_1.NotFoundException(`Hardware asset inventory not found for device ${deviceId}`);
        }
        this.cache.set(cacheKey, hw);
        return hw;
    }
    async getSoftwareInventory(deviceId, query) {
        this.checkFeatureFlag();
        const cacheKey = `inv:${deviceId}:sw:${query.search || "all"}:p${query.page}:l${query.limit}`;
        const cached = this.cache.get(cacheKey);
        if (cached)
            return cached;
        const sw = await this.repository.findSoftwareInventory(deviceId, query.search, query.page, query.limit);
        if (!sw) {
            throw new common_1.NotFoundException(`Software inventory not found for device ${deviceId}`);
        }
        this.cache.set(cacheKey, sw, 60000);
        return sw;
    }
    async getNetworkInventory(deviceId) {
        this.checkFeatureFlag();
        const cacheKey = `inv:${deviceId}:net`;
        const cached = this.cache.get(cacheKey);
        if (cached)
            return cached;
        const net = await this.repository.findNetworkInventory(deviceId);
        if (!net) {
            throw new common_1.NotFoundException(`Network adapter inventory not found for device ${deviceId}`);
        }
        this.cache.set(cacheKey, net);
        return net;
    }
    async getSecurityInventory(deviceId) {
        this.checkFeatureFlag();
        const cacheKey = `inv:${deviceId}:sec`;
        const cached = this.cache.get(cacheKey);
        if (cached)
            return cached;
        const sec = await this.repository.findSecurityInventory(deviceId);
        if (!sec) {
            throw new common_1.NotFoundException(`Security compliance inventory not found for device ${deviceId}`);
        }
        this.cache.set(cacheKey, sec);
        return sec;
    }
    async getHealthDiagnostics(deviceId) {
        this.checkFeatureFlag();
        return this.repository.getInventoryHealth(deviceId);
    }
    async triggerManualScan(deviceId) {
        this.checkFeatureFlag();
        const existing = await this.repository.findCompleteInventory(deviceId);
        if (!existing) {
            throw new common_1.NotFoundException(`Target node ${deviceId} is not registered in asset repository.`);
        }
        await this.repository.createAuditLog(deviceId, "Inventory Refreshed", "Manual diagnostic inventory re-scan triggered from enterprise control plane.");
        this.cache.invalidate(`inv:${deviceId}`);
        return {
            deviceId,
            status: "SCHEDULED",
            message: "Manual inventory scan command triggered. The monitoring agent will consume and execute on its next autonomous lifecycle polling cycle.",
        };
    }
    async searchInventory(query, tab) {
        this.checkFeatureFlag();
        if (tab === "SOFTWARE") {
            const items = await this.prisma.installedSoftware.findMany({
                where: query ? { name: { contains: query, mode: "insensitive" } } : {},
                take: 50,
                include: { deviceInventory: { include: { device: true } } },
            });
            return items.map((i) => ({
                id: i.id,
                deviceId: i.deviceInventory?.deviceId,
                hostname: i.deviceInventory?.device?.hostname,
                softwareName: i.name,
                publisher: i.publisher,
                version: i.version,
                installDate: i.installDate,
                osEdition: i.deviceInventory?.device?.os || "Unknown",
            }));
        }
        else if (tab === "SERVICES") {
            const items = await this.prisma.windowsService.findMany({
                where: query
                    ? { serviceName: { contains: query, mode: "insensitive" } }
                    : {},
                take: 50,
                include: { deviceInventory: { include: { device: true } } },
            });
            return items.map((i) => ({
                id: i.id,
                deviceId: i.deviceInventory?.deviceId,
                hostname: i.deviceInventory?.device?.hostname,
                serviceName: i.serviceName,
                displayName: i.displayName,
                status: i.status,
                startType: i.startType,
                osEdition: i.deviceInventory?.device?.os || "Unknown",
            }));
        }
        else if (tab === "SECURITY") {
            const devices = await this.prisma.device.findMany({
                where: query
                    ? { hostname: { contains: query, mode: "insensitive" } }
                    : {},
                take: 50,
                include: { inventory: { include: { security: true } } },
            });
            return devices
                .filter((d) => d.inventory?.security)
                .map((d) => ({
                id: d.inventory.security.id,
                deviceId: d.id,
                hostname: d.hostname,
                defenderEnabled: d.inventory.security.windowsDefenderEnabled,
                firewallEnabled: d.inventory.security.firewallEnabled,
                bitLockerStatus: d.inventory.security.bitLockerEnabled
                    ? "Enabled"
                    : "Disabled",
                tpmVersion: d.inventory.security.tpmVersion,
                osEdition: d.os,
            }));
        }
        else if (tab === "CHANGES") {
            const items = await this.prisma.inventoryAuditLog.findMany({
                where: query
                    ? { changeDetails: { contains: query, mode: "insensitive" } }
                    : {},
                take: 50,
                include: { device: true },
            });
            return items.map((i) => ({
                id: i.id,
                deviceId: i.deviceId,
                hostname: i.device?.hostname,
                action: i.action,
                details: i.changeDetails,
                timestamp: i.timestamp,
                osEdition: i.device?.os || "Unknown",
            }));
        }
        return [];
    }
};
exports.InventoryService = InventoryService;
exports.InventoryService = InventoryService = InventoryService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(inventory_repository_interface_1.IInventoryRepository)),
    __metadata("design:paramtypes", [Object, inventory_cache_service_1.InventoryCacheService,
        inventory_audit_service_1.InventoryAuditService,
        prisma_service_1.PrismaService,
        event_emitter_1.EventEmitter2])
], InventoryService);
//# sourceMappingURL=inventory.service.js.map