export declare class InventoryModule {
}
