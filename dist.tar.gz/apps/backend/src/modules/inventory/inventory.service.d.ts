import { EventEmitter2 } from "@nestjs/event-emitter";
import { IInventoryRepository } from "../../common/repositories/inventory.repository.interface";
import { InventoryCacheService } from "./services/inventory-cache.service";
import { InventoryAuditService } from "./services/inventory-audit.service";
import { SubmitInventoryPayload, CompleteInventoryResponse, HardwareInventoryResponse, SoftwareInventoryResponse, NetworkInventoryResponse, SecurityInventoryResponse, InventoryHealthResponse } from "@nos/shared-types";
import { InventoryQueryDto } from "./dto/inventory.dto";
import { PrismaService } from "../../database/prisma.service";
export declare class InventoryService {
    private readonly repository;
    private readonly cache;
    private readonly audit;
    private readonly prisma;
    private readonly eventEmitter;
    private readonly logger;
    constructor(repository: IInventoryRepository, cache: InventoryCacheService, audit: InventoryAuditService, prisma: PrismaService, eventEmitter: EventEmitter2);
    private checkFeatureFlag;
    submitInventory(payload: SubmitInventoryPayload, authenticatedDeviceId?: string): Promise<CompleteInventoryResponse>;
    getCompleteInventory(deviceId: string): Promise<CompleteInventoryResponse>;
    getHardwareInventory(deviceId: string): Promise<HardwareInventoryResponse>;
    getSoftwareInventory(deviceId: string, query: InventoryQueryDto): Promise<SoftwareInventoryResponse>;
    getNetworkInventory(deviceId: string): Promise<NetworkInventoryResponse>;
    getSecurityInventory(deviceId: string): Promise<SecurityInventoryResponse>;
    getHealthDiagnostics(deviceId?: string): Promise<InventoryHealthResponse>;
    triggerManualScan(deviceId: string): Promise<{
        deviceId: string;
        status: string;
        message: string;
    }>;
    searchInventory(query: string, tab: string): Promise<{
        id: string;
        deviceId: string;
        hostname: string;
        softwareName: string;
        publisher: string;
        version: string;
        installDate: string;
        osEdition: string;
    }[] | {
        id: string;
        deviceId: string;
        hostname: string;
        serviceName: string;
        displayName: string;
        status: string;
        startType: string;
        osEdition: string;
    }[] | {
        id: string;
        deviceId: string;
        hostname: string;
        defenderEnabled: boolean;
        firewallEnabled: boolean;
        bitLockerStatus: string;
        tpmVersion: string;
        osEdition: string;
    }[] | {
        id: string;
        deviceId: string;
        hostname: string;
        action: string;
        details: string;
        timestamp: Date;
        osEdition: string;
    }[]>;
}
