import { TenantContext } from "@nos/shared-types";
import { InventorySearchService } from "./inventory-search.service";
export declare class InventorySearchController {
    private readonly searchService;
    constructor(searchService: InventorySearchService);
    search(tenant: TenantContext, q?: string, query?: string, category?: string, tab?: string, deviceId?: string, page?: number, limit?: number): Promise<{
        success: boolean;
        data: {
            id: string;
            deviceId: string;
            hostname: string;
            serviceName: string;
            displayName: string;
            status: string;
            startType: string;
            osEdition: string;
        }[];
        meta: {
            total: number;
            page: number;
            limit: number;
        };
    } | {
        success: boolean;
        data: {
            id: string;
            deviceId: string;
            hostname: string;
            defenderEnabled: boolean;
            firewallEnabled: boolean;
            bitLockerStatus: string;
            tpmVersion: string;
            osEdition: string;
        }[];
        meta: {
            total: number;
            page: number;
            limit: number;
        };
    } | {
        success: boolean;
        data: {
            id: string;
            deviceId: string;
            hostname: string;
            action: string;
            details: string;
            timestamp: Date;
            osEdition: string;
        }[];
        meta: {
            total: number;
            page: number;
            limit: number;
        };
    } | {
        success: boolean;
        data: {
            id: string;
            deviceId: string;
            hostname: string;
            softwareName: string;
            publisher: string;
            version: string;
            installDate: string;
            osEdition: string;
        }[];
        meta: {
            total: number;
            page: number;
            limit: number;
        };
    }>;
}
