import { TenantContext } from "@nos/shared-types";
import { AuditLogsService } from "./audit-logs.service";
export declare class AuditLogsController {
    private readonly auditService;
    constructor(auditService: AuditLogsService);
    getAuditLogs(tenant: TenantContext, action?: string, actor?: string, startDate?: string, endDate?: string, page?: number, limit?: number): Promise<{
        success: boolean;
        data: {
            createdAt: Date;
            actor: string;
            userId: string | null;
            ipAddress: string;
            organizationId: string;
            id: string;
            timestamp: Date;
            action: string;
            resourceType: string | null;
            resourceId: string | null;
            browser: string;
            userEmail: string | null;
            reason: string | null;
            correlationId: string;
            details: import("@prisma/client/runtime/library").JsonValue | null;
        }[];
        meta: {
            total: number;
            page: number;
            limit: number;
        };
    }>;
}
