"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var AuditLogsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuditLogsService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma/prisma.service");
let AuditLogsService = AuditLogsService_1 = class AuditLogsService {
    prisma;
    logger = new common_1.Logger(AuditLogsService_1.name);
    constructor(prisma) {
        this.prisma = prisma;
    }
    async getAuditLogs(params) {
        const { tenantId, action, actor, startDate, endDate, page, limit } = params;
        const skip = (page - 1) * limit;
        const where = {};
        if (tenantId && tenantId !== "default-org") {
            where.organizationId = tenantId;
        }
        if (action) {
            where.action = { contains: action, mode: "insensitive" };
        }
        if (actor) {
            where.OR = [
                { userId: { contains: actor, mode: "insensitive" } },
                { userEmail: { contains: actor, mode: "insensitive" } },
            ];
        }
        if (startDate || endDate) {
            where.timestamp = {};
            if (startDate) {
                const parsedStart = new Date(startDate);
                if (!isNaN(parsedStart.getTime())) {
                    where.timestamp.gte = parsedStart;
                }
            }
            if (endDate) {
                const parsedEnd = new Date(endDate);
                if (!isNaN(parsedEnd.getTime())) {
                    where.timestamp.lte = parsedEnd;
                }
            }
            if (Object.keys(where.timestamp).length === 0) {
                delete where.timestamp;
            }
        }
        const [total, items] = await Promise.all([
            this.prisma.auditLog.count({ where }),
            this.prisma.auditLog.findMany({
                where,
                orderBy: { timestamp: "desc" },
                skip,
                take: limit,
            }),
        ]);
        const data = items.map((item) => ({
            ...item,
            createdAt: item.timestamp,
            actor: item.userEmail || item.userId || "System",
        }));
        return {
            success: true,
            data,
            meta: {
                total,
                page,
                limit,
            },
        };
    }
    async log(params) {
        try {
            const orgId = params.tenantId || params.organizationId || "default-org";
            await this.prisma.auditLog.create({
                data: {
                    organizationId: orgId,
                    userId: params.actor,
                    userEmail: params.actor,
                    action: params.action,
                    resourceType: "ALERT_ENGINE",
                    resourceId: params.target,
                    ipAddress: "127.0.0.1",
                    browser: "Alert Rule Engine",
                    details: params.details || {},
                },
            });
        }
        catch (err) {
            this.logger.error(`Error logging action ${params.action}: ${err instanceof Error ? err.message : err}`);
        }
    }
    async logAction(params) {
        return this.log(params);
    }
};
exports.AuditLogsService = AuditLogsService;
exports.AuditLogsService = AuditLogsService = AuditLogsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], AuditLogsService);
//# sourceMappingURL=audit-logs.service.js.map