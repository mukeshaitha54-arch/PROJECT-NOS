import { PrismaService } from "../prisma/prisma.service";
export interface AuditLogQueryParams {
    tenantId: string;
    action?: string;
    actor?: string;
    startDate?: string;
    endDate?: string;
    page: number;
    limit: number;
}
export declare class AuditLogsService {
    private readonly prisma;
    private readonly logger;
    constructor(prisma: PrismaService);
    getAuditLogs(params: AuditLogQueryParams): Promise<{
        success: boolean;
        data: {
            createdAt: Date;
            actor: string;
            userId: string | null;
            ipAddress: string;
            organizationId: string;
            id: string;
            timestamp: Date;
            action: string;
            resourceType: string | null;
            resourceId: string | null;
            browser: string;
            userEmail: string | null;
            reason: string | null;
            correlationId: string;
            details: import("@prisma/client/runtime/library").JsonValue | null;
        }[];
        meta: {
            total: number;
            page: number;
            limit: number;
        };
    }>;
    log(params: {
        action: string;
        actor: string;
        target?: string;
        details?: any;
        tenantId?: string;
        organizationId?: string;
    }): Promise<void>;
    logAction(params: {
        action: string;
        actor: string;
        target?: string;
        details?: any;
        tenantId?: string;
        organizationId?: string;
    }): Promise<void>;
}
