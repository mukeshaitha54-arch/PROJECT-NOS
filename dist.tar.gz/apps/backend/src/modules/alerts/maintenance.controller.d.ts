import { MaintenanceService } from "./services/maintenance.service";
export declare class MaintenanceController {
    private readonly maintenanceService;
    constructor(maintenanceService: MaintenanceService);
    getWindows(enabledOnly?: string): Promise<{
        deviceId: string | null;
        id: string;
        reason: string;
        createdAt: Date;
        updatedAt: Date;
        title: string;
        type: string;
        enabled: boolean;
        deviceGroupId: string | null;
        startTime: Date;
        endTime: Date;
    }[]>;
    getWindow(id: string): Promise<{
        deviceId: string | null;
        id: string;
        reason: string;
        createdAt: Date;
        updatedAt: Date;
        title: string;
        type: string;
        enabled: boolean;
        deviceGroupId: string | null;
        startTime: Date;
        endTime: Date;
    }>;
    createWindow(body: {
        deviceId?: string;
        deviceGroupId?: string;
        title: string;
        startTime: string;
        endTime: string;
        reason: string;
        type?: string;
        enabled?: boolean;
    }): Promise<{
        deviceId: string | null;
        id: string;
        reason: string;
        createdAt: Date;
        updatedAt: Date;
        title: string;
        type: string;
        enabled: boolean;
        deviceGroupId: string | null;
        startTime: Date;
        endTime: Date;
    }>;
    updateWindow(id: string, body: any): Promise<{
        deviceId: string | null;
        id: string;
        reason: string;
        createdAt: Date;
        updatedAt: Date;
        title: string;
        type: string;
        enabled: boolean;
        deviceGroupId: string | null;
        startTime: Date;
        endTime: Date;
    }>;
    deleteWindow(id: string): Promise<{
        success: boolean;
    }>;
}
