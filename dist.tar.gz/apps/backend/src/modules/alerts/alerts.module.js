"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AlertsModule = void 0;
const common_1 = require("@nestjs/common");
const database_module_1 = require("../../database/database.module");
const realtime_module_1 = require("../realtime/realtime.module");
const audit_module_1 = require("../audit/audit.module");
const rule_engine_service_1 = require("./services/rule-engine.service");
const alert_engine_service_1 = require("./services/alert-engine.service");
const alert_history_service_1 = require("./services/alert-history.service");
const maintenance_service_1 = require("./services/maintenance.service");
const alert_health_service_1 = require("./services/alert-health.service");
const notification_service_1 = require("./notification/notification.service");
const alert_rule_engine_service_1 = require("./alert-rule-engine.service");
const rule_validation_service_1 = require("./services/rule-validation.service");
const rule_simulation_service_1 = require("./services/rule-simulation.service");
const rule_metrics_service_1 = require("./services/rule-metrics.service");
const rule_health_service_1 = require("./services/rule-health.service");
const rule_audit_service_1 = require("./services/rule-audit.service");
const queue_service_1 = require("./queues/queue.service");
const escalation_worker_1 = require("./queues/escalation.worker");
const alert_repository_interface_1 = require("../../common/repositories/alert.repository.interface");
const alert_rule_repository_interface_1 = require("../../common/repositories/alert-rule.repository.interface");
const alert_rule_audit_repository_interface_1 = require("../../common/repositories/alert-rule-audit.repository.interface");
const notification_repository_interface_1 = require("../../common/repositories/notification.repository.interface");
const maintenance_repository_interface_1 = require("../../common/repositories/maintenance.repository.interface");
const telemetry_repository_interface_1 = require("../../common/repositories/telemetry.repository.interface");
const prisma_alert_repository_1 = require("../../database/repositories/prisma-alert.repository");
const prisma_alert_rule_repository_1 = require("../../database/repositories/prisma-alert-rule.repository");
const prisma_alert_rule_audit_repository_1 = require("../../database/repositories/prisma-alert-rule-audit.repository");
const prisma_notification_repository_1 = require("../../database/repositories/prisma-notification.repository");
const prisma_maintenance_repository_1 = require("../../database/repositories/prisma-maintenance.repository");
const prisma_telemetry_repository_1 = require("../../database/repositories/prisma-telemetry.repository");
const alerts_controller_1 = require("./alerts.controller");
const maintenance_controller_1 = require("./maintenance.controller");
let AlertsModule = class AlertsModule {
};
exports.AlertsModule = AlertsModule;
exports.AlertsModule = AlertsModule = __decorate([
    (0, common_1.Global)(),
    (0, common_1.Module)({
        imports: [database_module_1.DatabaseModule, realtime_module_1.RealtimeModule, audit_module_1.AuditModule],
        controllers: [alerts_controller_1.AlertsController, maintenance_controller_1.MaintenanceController],
        providers: [
            alert_engine_service_1.AlertEngineService,
            alert_history_service_1.AlertHistoryService,
            maintenance_service_1.MaintenanceService,
            alert_health_service_1.AlertHealthService,
            notification_service_1.NotificationService,
            alert_rule_engine_service_1.AlertRuleEngineService,
            queue_service_1.AlertQueueService,
            escalation_worker_1.EscalationWorker,
            rule_audit_service_1.RuleAuditService,
            rule_metrics_service_1.RuleMetricsService,
            rule_validation_service_1.RuleValidationService,
            rule_simulation_service_1.RuleSimulationService,
            rule_health_service_1.RuleHealthService,
            rule_engine_service_1.RuleEngineService,
            { provide: alert_repository_interface_1.IAlertRepository, useClass: prisma_alert_repository_1.PrismaAlertRepository },
            { provide: alert_rule_repository_interface_1.IAlertRuleRepository, useClass: prisma_alert_rule_repository_1.PrismaAlertRuleRepository },
            {
                provide: alert_rule_audit_repository_interface_1.IAlertRuleAuditRepository,
                useClass: prisma_alert_rule_audit_repository_1.PrismaAlertRuleAuditRepository,
            },
            {
                provide: notification_repository_interface_1.INotificationRepository,
                useClass: prisma_notification_repository_1.PrismaNotificationRepository,
            },
            { provide: maintenance_repository_interface_1.IMaintenanceRepository, useClass: prisma_maintenance_repository_1.PrismaMaintenanceRepository },
            { provide: telemetry_repository_interface_1.ITelemetryRepositoryToken, useClass: prisma_telemetry_repository_1.PrismaTelemetryRepository },
        ],
        exports: [
            rule_engine_service_1.RuleEngineService,
            alert_engine_service_1.AlertEngineService,
            maintenance_service_1.MaintenanceService,
            notification_service_1.NotificationService,
            rule_audit_service_1.RuleAuditService,
            alert_rule_engine_service_1.AlertRuleEngineService,
            alert_repository_interface_1.IAlertRepository,
            alert_rule_repository_interface_1.IAlertRuleRepository,
            maintenance_repository_interface_1.IMaintenanceRepository,
        ],
    })
], AlertsModule);
//# sourceMappingURL=alerts.module.js.map