import { PrismaService } from "../../database/prisma.service";
import { RealtimeGateway as SocketGateway } from "../realtime/realtime.gateway";
import { AuditLogsService as AuditService } from "../audit/audit-logs.service";
export interface TelemetryPayload {
    cpu?: number;
    cpuUsage?: number;
    ram?: number;
    ramUsage?: number;
    memoryUsagePercent?: number;
    disk?: number;
    diskUsagePercent?: number;
    network?: number;
    networkUploadSpeed?: number;
    networkDownloadSpeed?: number;
    timestamp?: string | Date;
    [key: string]: any;
}
export declare class AlertRuleEngineService {
    private readonly prisma;
    private readonly socketGateway;
    private readonly auditService;
    private readonly logger;
    constructor(prisma: PrismaService, socketGateway: SocketGateway, auditService: AuditService);
    evaluateTelemetry(deviceId: string, tenantId: string, telemetry: TelemetryPayload): Promise<void>;
    private createAlert;
    extractMetricValue(metric: string, telemetry: TelemetryPayload): number | null;
    compareThreshold(value: number, operator: string, threshold: number): boolean;
    testRule(ruleId: string, deviceId: string, simulatedValue: number): Promise<{
        wouldTrigger: boolean;
        reason: string;
        durationRequired: number;
        currentDuration: number;
        success?: undefined;
    } | {
        success: boolean;
        wouldTrigger: boolean;
        reason: string;
        durationRequired: number;
        currentDuration: number;
    }>;
}
