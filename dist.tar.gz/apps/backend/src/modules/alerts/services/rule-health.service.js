"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var RuleHealthService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.RuleHealthService = void 0;
const common_1 = require("@nestjs/common");
const alert_rule_repository_interface_1 = require("../../../common/repositories/alert-rule.repository.interface");
const queue_service_1 = require("../queues/queue.service");
let RuleHealthService = RuleHealthService_1 = class RuleHealthService {
    ruleRepo;
    queueService;
    logger = new common_1.Logger(RuleHealthService_1.name);
    startTime = Date.now();
    constructor(ruleRepo, queueService) {
        this.ruleRepo = ruleRepo;
        this.queueService = queueService;
    }
    async checkRuleHealth() {
        const [allRules, conflicts, duplicates] = await Promise.all([
            this.ruleRepo.findMany(false),
            this.ruleRepo.findConflicting(),
            this.ruleRepo.findDuplicates(),
        ]);
        const activeRules = allRules.filter((r) => r.ruleStatus === "ACTIVE" && r.enabled).length;
        const disabledRules = allRules.filter((r) => !r.enabled && r.ruleStatus !== "ARCHIVED").length;
        const archivedRules = allRules.filter((r) => r.ruleStatus === "ARCHIVED").length;
        const rulesWithEvals = allRules.filter((r) => Number(r.evaluationCount) > 0);
        const avgEvaluationMs = rulesWithEvals.length > 0
            ? rulesWithEvals.reduce((sum, r) => sum + r.avgExecMs, 0) /
                rulesWithEvals.length
            : 0;
        const slowRules = allRules
            .filter((r) => r.avgExecMs > 300 && Number(r.evaluationCount) > 5)
            .sort((a, b) => b.avgExecMs - a.avgExecMs)
            .slice(0, 10)
            .map((r) => ({ id: r.id, name: r.name, avgExecMs: r.avgExecMs }));
        const fastRules = allRules
            .filter((r) => r.avgExecMs > 0 && r.avgExecMs < 50 && Number(r.evaluationCount) > 5)
            .sort((a, b) => a.avgExecMs - b.avgExecMs)
            .slice(0, 5)
            .map((r) => ({ id: r.id, name: r.name, avgExecMs: r.avgExecMs }));
        const queues = await this.queueService.getQueueStats();
        const redisHealth = await this.queueService.getRedisHealth();
        const hasConflicts = conflicts.length > 0;
        const hasDuplicates = duplicates.length > 0;
        const hasSlowRules = slowRules.length > 0;
        const redisDown = !redisHealth.connected;
        const overallStatus = redisDown || (hasConflicts && hasDuplicates)
            ? "CRITICAL"
            : hasConflicts || hasDuplicates || hasSlowRules
                ? "DEGRADED"
                : "HEALTHY";
        this.logger.log(`[RuleHealth] Status: ${overallStatus} | Active: ${activeRules} | Conflicts: ${conflicts.length} | Duplicates: ${duplicates.length}`);
        return {
            activeRules,
            disabledRules,
            archivedRules,
            conflictingRules: conflicts.length,
            duplicateRules: duplicates.length,
            avgEvaluationMs: Math.round(avgEvaluationMs * 100) / 100,
            slowRules,
            fastRules,
            queues,
            redis: redisHealth,
            overallStatus,
            lastCheckedAt: new Date().toISOString(),
        };
    }
    async getQueueDashboard() {
        const queues = await this.queueService.getQueueStats();
        const redisHealth = await this.queueService.getRedisHealth();
        const alertQueue = queues.find((q) => q.name === "AlertProcessingQueue") || {
            name: "AlertProcessingQueue",
            waiting: 0,
            active: 0,
            completed: 0,
            failed: 0,
            delayed: 0,
        };
        const notificationQueue = queues.find((q) => q.name === "NotificationQueue") || {
            name: "NotificationQueue",
            waiting: 0,
            active: 0,
            completed: 0,
            failed: 0,
            delayed: 0,
        };
        const retryQueue = queues.find((q) => q.name === "RetryQueue") || {
            name: "RetryQueue",
            waiting: 0,
            active: 0,
            completed: 0,
            failed: 0,
            delayed: 0,
        };
        const deadLetterQueue = queues.find((q) => q.name === "DeadLetterQueue") || {
            name: "DeadLetterQueue",
            waiting: 0,
            active: 0,
            completed: 0,
            failed: 0,
            delayed: 0,
        };
        const totalWaiting = queues.reduce((s, q) => s + q.waiting, 0);
        const totalActive = queues.reduce((s, q) => s + q.active, 0);
        const totalFailed = queues.reduce((s, q) => s + q.failed, 0);
        const healthStatus = !redisHealth.connected || totalFailed > 50
            ? "CRITICAL"
            : totalFailed > 10 || totalWaiting > 100
                ? "DEGRADED"
                : "HEALTHY";
        return {
            alertQueue,
            notificationQueue,
            retryQueue,
            deadLetterQueue,
            redis: {
                connected: redisHealth.connected,
                memoryUsageBytes: redisHealth.memoryUsageBytes,
                latencyMs: redisHealth.latencyMs,
                connectedClients: redisHealth.connectedClients,
                uptimeSeconds: redisHealth.uptime,
                version: "7.x",
            },
            totalWaiting,
            totalActive,
            totalFailed,
            healthStatus,
            lastUpdatedAt: new Date().toISOString(),
        };
    }
};
exports.RuleHealthService = RuleHealthService;
exports.RuleHealthService = RuleHealthService = RuleHealthService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(alert_rule_repository_interface_1.IAlertRuleRepository)),
    __metadata("design:paramtypes", [Object, queue_service_1.AlertQueueService])
], RuleHealthService);
//# sourceMappingURL=rule-health.service.js.map