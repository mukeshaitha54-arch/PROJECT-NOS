"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var RuleEngineService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.RuleEngineService = void 0;
const common_1 = require("@nestjs/common");
const alert_rule_repository_interface_1 = require("../../../common/repositories/alert-rule.repository.interface");
const alert_repository_interface_1 = require("../../../common/repositories/alert.repository.interface");
const rule_audit_service_1 = require("./rule-audit.service");
const rule_metrics_service_1 = require("./rule-metrics.service");
const shared_types_1 = require("@nos/shared-types");
let RuleEngineService = RuleEngineService_1 = class RuleEngineService {
    ruleRepo;
    alertRepo;
    auditService;
    metricsService;
    logger = new common_1.Logger(RuleEngineService_1.name);
    compiledCache = new Map();
    orderedRules = [];
    persistenceTrackers = new Map();
    versionHistory = new Map();
    PRIORITY_ORDER = {
        CRITICAL: 4,
        HIGH: 3,
        NORMAL: 2,
        LOW: 1,
    };
    constructor(ruleRepo, alertRepo, auditService, metricsService) {
        this.ruleRepo = ruleRepo;
        this.alertRepo = alertRepo;
        this.auditService = auditService;
        this.metricsService = metricsService;
    }
    async onModuleInit() {
        await this.seedDefaultTemplates();
        await this.reloadRules();
    }
    async reloadRules() {
        const rules = await this.ruleRepo.findMany(true);
        this.compiledCache.clear();
        for (const rule of rules) {
            const compiled = this.compileRule(rule);
            this.compiledCache.set(rule.id, compiled);
        }
        this.orderedRules = [...this.compiledCache.values()].sort((a, b) => {
            if (b.priority !== a.priority)
                return b.priority - a.priority;
            if (a.metric === "heartbeat" && b.metric !== "heartbeat")
                return -1;
            if (b.metric === "heartbeat" && a.metric !== "heartbeat")
                return 1;
            return 0;
        });
        this.logger.log(`[RuleEngine] Compiled & loaded ${this.orderedRules.length} active rules. ` +
            `Order: ${this.orderedRules.map((r) => `${r.raw.name}[${r.raw.priority}]`).join(", ")}`);
    }
    compileRule(rule) {
        return {
            id: rule.id,
            metric: rule.metric,
            operator: rule.operator,
            threshold: rule.threshold,
            durationSeconds: rule.durationSeconds,
            cooldownSeconds: rule.cooldownSeconds,
            timeoutMs: rule.timeoutMs ?? 500,
            priority: this.PRIORITY_ORDER[rule.priority] || 2,
            scheduleMode: rule.scheduleMode,
            cronExpression: rule.cronExpression,
            businessHoursOnly: rule.businessHoursOnly,
            silentMode: rule.silentMode,
            enabled: rule.enabled,
            ruleStatus: rule.ruleStatus,
            raw: rule,
        };
    }
    evaluate(deviceId, metrics, isBusinessHours = true, currentDate = new Date()) {
        const triggered = [];
        const nowMs = Date.now();
        for (const compiled of this.orderedRules) {
            const execStart = Date.now();
            try {
                if (!this.isScheduleActive(compiled, isBusinessHours, currentDate)) {
                    continue;
                }
                const value = metrics[compiled.metric];
                if (value === undefined)
                    continue;
                let conditionMet = false;
                const evaluationPromise = new Promise((resolve) => {
                    resolve(this.evaluateCondition(Number(value), compiled.operator, compiled.threshold));
                });
                const timeoutPromise = new Promise((_, reject) => setTimeout(() => reject(new Error(`RuleTimeout: ${compiled.id} exceeded ${compiled.timeoutMs}ms`)), compiled.timeoutMs));
                Promise.race([evaluationPromise, timeoutPromise])
                    .then((result) => {
                    conditionMet = result;
                })
                    .catch((err) => {
                    this.logger.warn(`[RuleEngine] ${err.message} — skipping rule "${compiled.raw.name}"`);
                    this.metricsService.recordExecution(compiled.id, compiled.timeoutMs);
                });
                conditionMet = this.evaluateCondition(Number(value), compiled.operator, compiled.threshold);
                const trackerKey = `${deviceId}:${compiled.id}`;
                if (conditionMet) {
                    let startMs = this.persistenceTrackers.get(trackerKey);
                    if (!startMs) {
                        startMs = nowMs;
                        this.persistenceTrackers.set(trackerKey, startMs);
                    }
                    const elapsedSeconds = (nowMs - startMs) / 1000;
                    if (elapsedSeconds >= (compiled.durationSeconds || 0)) {
                        triggered.push({
                            rule: compiled.raw,
                            actualValue: typeof value === "number" ? value : compiled.threshold,
                            reason: `${compiled.raw.name}: ${compiled.metric} ${compiled.operator} ${compiled.threshold} for >=${compiled.durationSeconds}s`,
                        });
                    }
                }
                else {
                    this.persistenceTrackers.delete(trackerKey);
                }
                const execMs = Date.now() - execStart;
                this.metricsService.recordExecution(compiled.id, execMs);
                this.ruleRepo
                    .updatePerformanceMetrics(compiled.id, {
                    execMs,
                    triggered: conditionMet,
                })
                    .catch(() => {
                });
            }
            catch (err) {
                this.logger.error(`[RuleEngine] Rule "${compiled.raw.name}" evaluation failed: ${err.message}`);
                this.metricsService.recordExecution(compiled.id, Date.now() - execStart);
            }
        }
        return triggered;
    }
    evaluateBatch(devices, isBusinessHours = true, currentDate = new Date()) {
        const results = new Map();
        for (const device of devices) {
            const triggered = this.evaluate(device.deviceId, device.metrics, isBusinessHours, currentDate);
            if (triggered.length > 0) {
                results.set(device.deviceId, triggered);
            }
        }
        this.logger.log(`[RuleEngine] Batch: ${devices.length} devices, ${results.size} triggered`);
        return results;
    }
    isScheduleActive(compiled, isBusinessHours, now) {
        const mode = compiled.scheduleMode;
        if (mode === "ALWAYS")
            return true;
        if (mode === "BUSINESS_HOURS")
            return isBusinessHours;
        const hour = now.getHours();
        const dayOfWeek = now.getDay();
        if (mode === "NIGHT")
            return hour < 8 || hour >= 20;
        if (mode === "WEEKEND")
            return dayOfWeek === 0 || dayOfWeek === 6;
        if (mode === "CRON" && compiled.cronExpression) {
            return this.matchCronExpression(compiled.cronExpression, now);
        }
        return true;
    }
    matchCronExpression(cron, now) {
        try {
            const parts = cron.split(" ");
            if (parts.length !== 5)
                return true;
            const [minutePart, hourPart, , , dayOfWeekPart] = parts;
            const minute = now.getMinutes();
            const hour = now.getHours();
            const day = now.getDay();
            const minuteMatch = minutePart === "*" || Number(minutePart) === minute;
            const hourMatch = hourPart === "*" || Number(hourPart) === hour;
            const dayMatch = dayOfWeekPart === "*" ||
                dayOfWeekPart.split(",").map(Number).includes(day);
            return minuteMatch && hourMatch && dayMatch;
        }
        catch {
            return true;
        }
    }
    evaluateCondition(value, operator, threshold) {
        switch (operator) {
            case ">":
                return value > threshold;
            case ">=":
                return value >= threshold;
            case "<":
                return value < threshold;
            case "<=":
                return value <= threshold;
            case "==":
                return value === threshold;
            case "!=":
                return value !== threshold;
            case "MUTATED":
                return Boolean(value);
            default:
                return false;
        }
    }
    async createRule(data, modifier = "System Admin", correlationId, ipAddress, browser) {
        const res = await this.ruleRepo.create({
            ...data,
            createdBy: modifier,
            modifiedBy: modifier,
        });
        this.snapshotVersion(res, modifier);
        await this.auditService.record({
            ruleId: res.id,
            action: "CREATE",
            version: res.version,
            performedBy: modifier,
            reason: `Rule "${res.name}" created`,
            correlationId,
            ipAddress,
            browser,
        });
        const complexity = this.metricsService.computeComplexityScore(res);
        await this.ruleRepo.update(res.id, {
            complexityScore: complexity.score,
        });
        await this.reloadRules();
        return res;
    }
    async updateRule(id, data, modifier = "System Admin", reason, correlationId, ipAddress, browser) {
        const existing = await this.ruleRepo.findById(id);
        if (!existing)
            throw new Error(`Rule ${id} not found`);
        this.snapshotVersion(existing, modifier);
        const updated = await this.ruleRepo.update(id, {
            ...data,
            version: existing.version + 1,
            modifiedBy: modifier,
            publishedAt: new Date(),
        });
        const diffFields = [
            "threshold",
            "severity",
            "cooldownSeconds",
            "durationSeconds",
            "metric",
            "operator",
            "enabled",
            "priority",
            "scheduleMode",
            "timeoutMs",
        ];
        for (const field of diffFields) {
            if (data[field] !== undefined &&
                data[field] !== existing[field]) {
                await this.auditService.recordFieldChange({
                    ruleId: id,
                    field,
                    oldValue: existing[field],
                    newValue: data[field],
                    version: updated.version,
                    performedBy: modifier,
                    reason,
                    correlationId,
                    ipAddress,
                    browser,
                });
            }
        }
        const complexity = this.metricsService.computeComplexityScore(updated);
        const noise = this.metricsService.computeNoiseScore(updated);
        await this.ruleRepo.update(id, {
            complexityScore: complexity.score,
            noiseScore: noise.noiseScore,
        });
        await this.reloadRules();
        return updated;
    }
    async deleteRule(id, performedBy = "System", correlationId) {
        const rule = await this.ruleRepo.findById(id);
        if (rule) {
            await this.auditService.record({
                ruleId: id,
                action: "DELETE",
                version: rule.version,
                performedBy,
                reason: `Rule "${rule.name}" permanently deleted`,
                correlationId,
            });
        }
        const res = await this.ruleRepo.delete(id);
        await this.reloadRules();
        return res;
    }
    async archiveRule(id, performedBy = "System", correlationId) {
        const existing = await this.ruleRepo.findById(id);
        if (!existing)
            throw new Error(`Rule ${id} not found`);
        const archived = await this.ruleRepo.archive(id, performedBy);
        await this.auditService.record({
            ruleId: id,
            action: "ARCHIVE",
            version: existing.version,
            performedBy,
            reason: `Rule "${existing.name}" archived (retained for history)`,
            correlationId,
        });
        await this.reloadRules();
        return archived;
    }
    async cloneRule(id, newName, performedBy = "System", correlationId) {
        const source = await this.ruleRepo.findById(id);
        if (!source)
            throw new Error(`Rule ${id} not found`);
        const cloned = await this.ruleRepo.clone(id, newName, performedBy);
        await this.auditService.record({
            ruleId: cloned.id,
            action: "CLONE",
            version: 1,
            performedBy,
            reason: `Cloned from rule "${source.name}" (${source.id})`,
            correlationId,
        });
        await this.reloadRules();
        return cloned;
    }
    async getRuleDiff(id, fromVersion, toVersion) {
        const current = await this.ruleRepo.findById(id);
        if (!current)
            throw new Error(`Rule ${id} not found`);
        const history = this.versionHistory.get(id) || [];
        if (history.length === 0) {
            return {
                ruleId: id,
                ruleName: current.name,
                fromVersion: current.version - 1,
                toVersion: current.version,
                fromTimestamp: current.createdAt.toISOString(),
                toTimestamp: current.updatedAt.toISOString(),
                diffs: [],
                changedBy: current.modifiedBy || "System",
                changeReason: null,
                totalChanges: 0,
            };
        }
        const vFrom = fromVersion ?? history[0]?.version ?? current.version - 1;
        const vTo = toVersion ?? current.version;
        const snapshotFrom = history.find((s) => s.version === vFrom);
        const stateFrom = snapshotFrom?.snapshot || {};
        const TRACKED_FIELDS = [
            "threshold",
            "severity",
            "cooldownSeconds",
            "durationSeconds",
            "metric",
            "operator",
            "enabled",
            "priority",
            "scheduleMode",
            "timeoutMs",
            "silentMode",
            "businessHoursOnly",
            "name",
            "description",
        ];
        const diffs = TRACKED_FIELDS.map((field) => {
            const oldVal = stateFrom[field] ?? null;
            const newVal = current[field] ?? null;
            return {
                field,
                oldValue: oldVal,
                newValue: newVal,
                changed: String(oldVal) !== String(newVal),
            };
        });
        const changedDiffs = diffs.filter((d) => d.changed);
        return {
            ruleId: id,
            ruleName: current.name,
            fromVersion: vFrom,
            toVersion: vTo,
            fromTimestamp: snapshotFrom?.timestamp.toISOString() ??
                current.createdAt.toISOString(),
            toTimestamp: current.updatedAt.toISOString(),
            diffs,
            changedBy: snapshotFrom?.changedBy || current.modifiedBy || "System",
            changeReason: null,
            totalChanges: changedDiffs.length,
        };
    }
    async getRollbackPreview(id, targetVersion, performedBy = "System") {
        const current = await this.ruleRepo.findById(id);
        if (!current)
            throw new Error(`Rule ${id} not found`);
        const history = this.versionHistory.get(id) || [];
        const targetSnapshot = history.find((s) => s.version === targetVersion);
        if (!targetSnapshot) {
            throw new Error(`Version ${targetVersion} not found in history for rule ${id}`);
        }
        const TRACKED_FIELDS = [
            "threshold",
            "severity",
            "cooldownSeconds",
            "durationSeconds",
            "metric",
            "operator",
            "enabled",
            "priority",
            "scheduleMode",
            "timeoutMs",
        ];
        const differences = TRACKED_FIELDS.map((field) => ({
            field,
            oldValue: current[field] ?? null,
            newValue: targetSnapshot.snapshot[field] ?? null,
            changed: String(current[field]) !==
                String(targetSnapshot.snapshot[field]),
        })).filter((d) => d.changed);
        const warnings = [];
        if (differences.find((d) => d.field === "threshold")) {
            warnings.push("Threshold change may alter alert volume significantly");
        }
        if (differences.find((d) => d.field === "severity")) {
            warnings.push("Severity change will affect escalation and notification routing");
        }
        if (differences.find((d) => d.field === "enabled" && targetSnapshot.snapshot.enabled === false)) {
            warnings.push("Rolling back to disabled state will stop this rule from firing");
        }
        if (current.version - targetVersion > 5) {
            warnings.push(`Rolling back ${current.version - targetVersion} versions — significant configuration divergence`);
        }
        const isRollbackSafe = differences.length <= 3 && !differences.find((d) => d.field === "metric");
        const estimatedImpact = differences.length >= 5
            ? "CRITICAL"
            : differences.length >= 3
                ? "HIGH"
                : differences.length >= 1
                    ? "MEDIUM"
                    : "LOW";
        const mapRule = (r) => ({
            id: r.id,
            version: r.version,
            name: r.name,
            description: r.description,
            metric: r.metric,
            operator: r.operator,
            threshold: r.threshold,
            durationSeconds: r.durationSeconds,
            severity: r.severity,
            priority: r.priority || shared_types_1.AlertRulePriority.NORMAL,
            category: r.category || shared_types_1.AlertRuleCategory.SYSTEM,
            ruleStatus: r.ruleStatus || shared_types_1.AlertRuleStatus.ACTIVE,
            enabled: r.enabled,
            cooldownSeconds: r.cooldownSeconds,
            timeoutMs: r.timeoutMs ?? 500,
            scheduleMode: r.scheduleMode || shared_types_1.AlertRuleScheduleMode.ALWAYS,
            cronExpression: r.cronExpression,
            tags: r.tags,
            templateName: r.templateName,
            silentMode: r.silentMode,
            businessHoursOnly: r.businessHoursOnly,
            dependsOnIds: r.dependsOnIds,
            evaluationCount: Number(r.evaluationCount),
            triggerCount: Number(r.triggerCount),
            suppressionCount: Number(r.suppressionCount),
            deduplicationCount: Number(r.deduplicationCount),
            escalationCount: Number(r.escalationCount),
            avgExecMs: r.avgExecMs,
            maxExecMs: r.maxExecMs,
            minExecMs: r.minExecMs,
            lastEvaluatedAt: r.lastEvaluatedAt?.toISOString() ?? null,
            complexityScore: r.complexityScore || shared_types_1.RuleComplexityScore.SIMPLE,
            noiseScore: r.noiseScore,
            createdBy: r.createdBy,
            modifiedBy: r.modifiedBy,
            owner: r.owner,
            publishedAt: r.publishedAt?.toISOString() ?? null,
            archivedAt: r.archivedAt?.toISOString() ?? null,
            createdAt: r.createdAt.toISOString(),
            updatedAt: r.updatedAt.toISOString(),
        });
        const targetStateRule = {
            ...current,
            ...targetSnapshot.snapshot,
        };
        return {
            ruleId: id,
            ruleName: current.name,
            currentVersion: current.version,
            targetVersion,
            currentState: mapRule(current),
            targetState: mapRule(targetStateRule),
            differences,
            warnings,
            estimatedImpact,
            isRollbackSafe,
        };
    }
    async rollbackToVersion(id, targetVersion, performedBy = "System", correlationId, ipAddress, browser) {
        const preview = await this.getRollbackPreview(id, targetVersion, performedBy);
        const history = this.versionHistory.get(id) || [];
        const targetSnapshot = history.find((s) => s.version === targetVersion);
        if (!targetSnapshot)
            throw new Error(`Version ${targetVersion} not available`);
        const rollbackData = { ...targetSnapshot.snapshot };
        delete rollbackData.id;
        delete rollbackData.createdAt;
        delete rollbackData.version;
        const updated = await this.ruleRepo.update(id, {
            ...rollbackData,
            version: (await this.ruleRepo.findById(id)).version + 1,
            modifiedBy: performedBy,
        });
        await this.auditService.record({
            ruleId: id,
            action: "ROLLBACK",
            version: updated.version,
            performedBy,
            reason: `Rolled back from v${preview.currentVersion} to v${targetVersion}`,
            correlationId,
            ipAddress,
            browser,
        });
        await this.reloadRules();
        return updated;
    }
    async getDependencyGraph() {
        const rules = await this.ruleRepo.findMany(false);
        const ruleMap = new Map(rules.map((r) => [r.id, r]));
        const nodes = [];
        const edges = [];
        const circularPaths = [];
        for (const rule of rules) {
            const depIds = rule.dependsOnIds || [];
            const dependents = rules.filter((r) => (r.dependsOnIds || []).includes(rule.id));
            let depth = 0;
            const queue = [...depIds];
            const visited = new Set();
            while (queue.length > 0) {
                const curr = queue.shift();
                if (visited.has(curr))
                    continue;
                visited.add(curr);
                depth++;
                const parent = ruleMap.get(curr);
                if (parent) {
                    const parentDeps = parent.dependsOnIds || [];
                    queue.push(...parentDeps);
                }
            }
            let hasCircularDep = false;
            for (const depId of depIds) {
                const dep = ruleMap.get(depId);
                if (dep && (dep.dependsOnIds || []).includes(rule.id)) {
                    hasCircularDep = true;
                    circularPaths.push([rule.id, depId, rule.id]);
                }
                edges.push({ from: rule.id, to: depId });
            }
            nodes.push({
                ruleId: rule.id,
                ruleName: rule.name,
                priority: rule.priority || shared_types_1.AlertRulePriority.NORMAL,
                category: rule.category || shared_types_1.AlertRuleCategory.SYSTEM,
                dependsOn: depIds,
                dependents: dependents.map((r) => r.id),
                depth,
                hasCircularDep,
            });
        }
        return {
            nodes,
            edges,
            circularPaths,
            maxDepth: nodes.reduce((max, n) => Math.max(max, n.depth), 0),
            totalNodes: nodes.length,
            totalEdges: edges.length,
        };
    }
    async exportRules(performedBy = "System") {
        const rules = await this.ruleRepo.findMany(false);
        const exportedRules = rules.map((r) => ({
            id: r.id,
            version: r.version,
            name: r.name,
            description: r.description,
            metric: r.metric,
            operator: r.operator,
            threshold: r.threshold,
            durationSeconds: r.durationSeconds,
            severity: r.severity,
            priority: r.priority || shared_types_1.AlertRulePriority.NORMAL,
            category: r.category || shared_types_1.AlertRuleCategory.SYSTEM,
            ruleStatus: r.ruleStatus || shared_types_1.AlertRuleStatus.ACTIVE,
            enabled: r.enabled,
            cooldownSeconds: r.cooldownSeconds,
            timeoutMs: r.timeoutMs ?? 500,
            scheduleMode: r.scheduleMode || shared_types_1.AlertRuleScheduleMode.ALWAYS,
            cronExpression: r.cronExpression,
            tags: r.tags,
            templateName: r.templateName,
            silentMode: r.silentMode,
            businessHoursOnly: r.businessHoursOnly,
            dependsOnIds: r.dependsOnIds,
            evaluationCount: Number(r.evaluationCount),
            triggerCount: Number(r.triggerCount),
            suppressionCount: Number(r.suppressionCount),
            deduplicationCount: Number(r.deduplicationCount),
            escalationCount: Number(r.escalationCount),
            avgExecMs: r.avgExecMs,
            maxExecMs: r.maxExecMs,
            minExecMs: r.minExecMs,
            lastEvaluatedAt: r.lastEvaluatedAt?.toISOString() ?? null,
            complexityScore: r.complexityScore || shared_types_1.RuleComplexityScore.SIMPLE,
            noiseScore: r.noiseScore,
            createdBy: r.createdBy,
            modifiedBy: r.modifiedBy,
            owner: r.owner,
            publishedAt: r.publishedAt?.toISOString() ?? null,
            archivedAt: r.archivedAt?.toISOString() ?? null,
            createdAt: r.createdAt.toISOString(),
            updatedAt: r.updatedAt.toISOString(),
        }));
        for (const rule of rules) {
            await this.auditService.record({
                ruleId: rule.id,
                action: "EXPORT",
                version: rule.version,
                performedBy,
                reason: `Rule exported as part of bulk export (${rules.length} rules)`,
            });
        }
        return {
            exportedAt: new Date().toISOString(),
            exportedBy: performedBy,
            version: "1.0.0",
            totalRules: rules.length,
            rules: exportedRules,
        };
    }
    async importRules(exportData, performedBy = "System", correlationId) {
        let imported = 0;
        let skipped = 0;
        let failed = 0;
        const errors = [];
        const warnings = [];
        for (const rule of exportData.rules) {
            try {
                const existing = await this.ruleRepo.findByName(rule.name);
                if (existing) {
                    skipped++;
                    warnings.push({
                        ruleName: rule.name,
                        message: "Rule with this name already exists — skipped",
                    });
                    continue;
                }
                const created = await this.ruleRepo.create({
                    name: rule.name,
                    description: rule.description,
                    metric: rule.metric,
                    operator: rule.operator,
                    threshold: rule.threshold,
                    durationSeconds: rule.durationSeconds,
                    severity: rule.severity,
                    priority: rule.priority,
                    category: rule.category,
                    ruleStatus: rule.ruleStatus,
                    enabled: false,
                    cooldownSeconds: rule.cooldownSeconds,
                    timeoutMs: rule.timeoutMs,
                    scheduleMode: rule.scheduleMode,
                    cronExpression: rule.cronExpression,
                    tags: rule.tags,
                    templateName: rule.templateName,
                    silentMode: rule.silentMode,
                    businessHoursOnly: rule.businessHoursOnly,
                    dependsOnIds: rule.dependsOnIds,
                    createdBy: performedBy,
                    modifiedBy: performedBy,
                });
                await this.auditService.record({
                    ruleId: created.id,
                    action: "IMPORT",
                    version: 1,
                    performedBy,
                    reason: `Imported from export file (schema v${exportData.version})`,
                    correlationId,
                });
                imported++;
            }
            catch (err) {
                failed++;
                errors.push({ ruleName: rule.name, reason: err.message });
            }
        }
        if (imported > 0)
            await this.reloadRules();
        this.logger.log(`[RuleEngine] Import: ${imported} imported, ${skipped} skipped, ${failed} failed`);
        return { imported, skipped, failed, errors, warnings };
    }
    async searchRules(query) {
        return this.ruleRepo.findManyPaginated({
            name: query.name,
            metric: query.metric,
            severity: query.severity,
            category: query.category,
            tags: query.tags,
            enabled: query.enabled,
            owner: query.owner,
            version: query.version,
            ruleStatus: query.ruleStatus,
            priority: query.priority,
            skip: query.skip ?? 0,
            take: query.take ?? 50,
        });
    }
    async getRules() {
        return this.ruleRepo.findMany(false);
    }
    async getRuleById(id) {
        return this.ruleRepo.findById(id);
    }
    async getCategories() {
        return this.ruleRepo.getCategories();
    }
    async getTags() {
        return this.ruleRepo.getTags();
    }
    snapshotVersion(rule, changedBy) {
        const snapshots = this.versionHistory.get(rule.id) || [];
        snapshots.push({
            ruleId: rule.id,
            version: rule.version,
            snapshot: {
                threshold: rule.threshold,
                severity: rule.severity,
                cooldownSeconds: rule.cooldownSeconds,
                durationSeconds: rule.durationSeconds,
                metric: rule.metric,
                operator: rule.operator,
                enabled: rule.enabled,
                priority: rule.priority,
                scheduleMode: rule.scheduleMode,
                timeoutMs: rule.timeoutMs,
                silentMode: rule.silentMode,
                businessHoursOnly: rule.businessHoursOnly,
                name: rule.name,
                description: rule.description,
            },
            timestamp: new Date(),
            changedBy,
        });
        if (snapshots.length > 20)
            snapshots.shift();
        this.versionHistory.set(rule.id, snapshots);
    }
    async seedDefaultTemplates() {
        const defaults = [
            {
                name: "CPU Critical Spike",
                metric: "cpuUsage",
                operator: ">",
                threshold: 90,
                durationSeconds: 60,
                severity: shared_types_1.AlertSeverity.CRITICAL,
                priority: "CRITICAL",
                category: "PERFORMANCE",
                cooldownSeconds: 300,
                timeoutMs: 200,
                tags: ["CPU", "Performance", "Production"],
                templateName: "CPU Critical",
            },
            {
                name: "Memory Exhaustion Warning",
                metric: "ramUsage",
                operator: ">=",
                threshold: 85,
                durationSeconds: 120,
                severity: shared_types_1.AlertSeverity.HIGH,
                priority: "HIGH",
                category: "PERFORMANCE",
                cooldownSeconds: 600,
                timeoutMs: 200,
                tags: ["MEMORY", "Performance"],
                templateName: "Memory Critical",
            },
            {
                name: "Low Disk Capacity Alert",
                metric: "diskUsage",
                operator: ">=",
                threshold: 90,
                durationSeconds: 30,
                severity: shared_types_1.AlertSeverity.HIGH,
                priority: "HIGH",
                category: "AVAILABILITY",
                cooldownSeconds: 1800,
                timeoutMs: 300,
                tags: ["STORAGE", "Availability"],
                templateName: "Disk Critical",
            },
            {
                name: "Device Heartbeat Lost",
                metric: "heartbeat",
                operator: "==",
                threshold: 0,
                durationSeconds: 30,
                severity: shared_types_1.AlertSeverity.CRITICAL,
                priority: "CRITICAL",
                category: "AVAILABILITY",
                cooldownSeconds: 180,
                timeoutMs: 100,
                tags: ["NETWORK", "Availability"],
                templateName: "Heartbeat Lost",
            },
            {
                name: "Unauthorized Security Posture Mutation",
                metric: "security.defender",
                operator: "==",
                threshold: 0,
                durationSeconds: 0,
                severity: shared_types_1.AlertSeverity.CRITICAL,
                priority: "CRITICAL",
                category: "SECURITY",
                cooldownSeconds: 60,
                timeoutMs: 500,
                tags: ["SECURITY", "Compliance"],
                templateName: "Security Changed",
            },
            {
                name: "Unattended Hardware Inventory Change",
                metric: "inventory.version",
                operator: "MUTATED",
                threshold: 1,
                durationSeconds: 0,
                severity: shared_types_1.AlertSeverity.MEDIUM,
                priority: "NORMAL",
                category: "INVENTORY",
                cooldownSeconds: 300,
                timeoutMs: 300,
                tags: ["INVENTORY", "Compliance"],
                templateName: "Inventory Changed",
            },
        ];
        for (const def of defaults) {
            const existing = await this.ruleRepo.findByName(def.name);
            if (!existing) {
                await this.ruleRepo.create(def);
                this.logger.log(`[RuleEngine] Seeded template: "${def.name}"`);
            }
        }
    }
    async simulateRule(metric, operator, threshold, timeframeHours = 24) {
        return {
            metric,
            operator,
            threshold,
            timeframeHours,
            wouldTriggerCount: 15,
            suppressedCount: 5,
            realAlertsCount: 10,
            affectedDevices: ["server-prod-01", "db-node-01", "edge-gateway-03"],
            estimatedCooldownSavings: "33.3%",
        };
    }
};
exports.RuleEngineService = RuleEngineService;
exports.RuleEngineService = RuleEngineService = RuleEngineService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(alert_rule_repository_interface_1.IAlertRuleRepository)),
    __param(1, (0, common_1.Inject)(alert_repository_interface_1.IAlertRepository)),
    __metadata("design:paramtypes", [Object, Object, rule_audit_service_1.RuleAuditService,
        rule_metrics_service_1.RuleMetricsService])
], RuleEngineService);
//# sourceMappingURL=rule-engine.service.js.map