import { IAlertRuleRepository } from "../../../common/repositories/alert-rule.repository.interface";
import { IAlertRepository } from "../../../common/repositories/alert.repository.interface";
import { ITelemetryRepository } from "../../../common/repositories/telemetry.repository.interface";
import { MaintenanceService } from "./maintenance.service";
import { RuleAuditService } from "./rule-audit.service";
import { RuleTestRequestDto, RuleTestResultDto, RulePreviewDto, DryRunResultDto, ReplayRequestDto, ReplayResultDto } from "@nos/shared-types";
export declare class RuleSimulationService {
    private readonly ruleRepo;
    private readonly alertRepo;
    private readonly telemetryRepo;
    private readonly maintenanceService;
    private readonly auditService;
    private readonly logger;
    private readonly REPLAY_MAX_SAMPLES;
    constructor(ruleRepo: IAlertRuleRepository, alertRepo: IAlertRepository, telemetryRepo: ITelemetryRepository, maintenanceService: MaintenanceService, auditService: RuleAuditService);
    testRule(request: RuleTestRequestDto, performedBy?: string, correlationId?: string, ipAddress?: string, browser?: string): Promise<RuleTestResultDto>;
    previewRule(ruleData: {
        metric: string;
        operator: string;
        threshold: number;
        severity?: string;
        durationSeconds?: number;
        cooldownSeconds?: number;
        dependsOnIds?: string[];
        scheduleMode?: string;
        cronExpression?: string;
    }): Promise<RulePreviewDto>;
    dryRun(ruleData: {
        id?: string;
        name?: string;
        metric: string;
        operator: string;
        threshold: number;
        durationSeconds?: number;
        severity?: string;
        cooldownSeconds?: number;
    }, performedBy?: string, correlationId?: string, ipAddress?: string, browser?: string): Promise<DryRunResultDto>;
    replayHistoricalTelemetry(request: ReplayRequestDto, performedBy?: string, correlationId?: string, ipAddress?: string, browser?: string): Promise<ReplayResultDto>;
    private resolveTimeframe;
    private evaluateCondition;
    private extractMetricFromSnapshot;
    private estimateMetricValue;
    private estimateAffectedDevices;
    private classifyMetric;
    private getTagsForMetric;
}
