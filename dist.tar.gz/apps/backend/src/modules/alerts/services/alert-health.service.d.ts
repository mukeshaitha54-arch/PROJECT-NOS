import { IAlertRepository } from "../../../common/repositories/alert.repository.interface";
import { INotificationRepository } from "../../../common/repositories/notification.repository.interface";
import { AlertHealthResponse } from "@nos/shared-types";
export declare class AlertHealthService {
    private readonly alertRepo;
    private readonly notifRepo;
    private readonly logger;
    private readonly startTime;
    constructor(alertRepo: IAlertRepository, notifRepo: INotificationRepository);
    checkHealth(): Promise<AlertHealthResponse>;
}
