import { IAlertRuleRepository } from "../../../common/repositories/alert-rule.repository.interface";
import { AlertQueueService } from "../queues/queue.service";
import { RuleHealthDto, QueueDashboardDto } from "@nos/shared-types";
export declare class RuleHealthService {
    private readonly ruleRepo;
    private readonly queueService;
    private readonly logger;
    private readonly startTime;
    constructor(ruleRepo: IAlertRuleRepository, queueService: AlertQueueService);
    checkRuleHealth(): Promise<RuleHealthDto>;
    getQueueDashboard(): Promise<QueueDashboardDto>;
}
