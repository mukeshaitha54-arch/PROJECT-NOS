"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var RuleAuditService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.RuleAuditService = void 0;
const common_1 = require("@nestjs/common");
const alert_rule_audit_repository_interface_1 = require("../../../common/repositories/alert-rule-audit.repository.interface");
let RuleAuditService = RuleAuditService_1 = class RuleAuditService {
    auditRepo;
    logger = new common_1.Logger(RuleAuditService_1.name);
    constructor(auditRepo) {
        this.auditRepo = auditRepo;
    }
    async record(data) {
        this.logger.log(`[RuleAudit] ${data.action} on rule ${data.ruleId} v${data.version} by ${data.performedBy}` +
            (data.correlationId ? ` (corr: ${data.correlationId})` : ""));
        return this.auditRepo.create(data);
    }
    async recordFieldChange(params) {
        return this.record({
            ruleId: params.ruleId,
            action: "UPDATE",
            field: params.field,
            oldValue: params.oldValue !== null && params.oldValue !== undefined
                ? String(params.oldValue)
                : null,
            newValue: params.newValue !== null && params.newValue !== undefined
                ? String(params.newValue)
                : null,
            version: params.version,
            performedBy: params.performedBy,
            reason: params.reason,
            correlationId: params.correlationId,
            ipAddress: params.ipAddress,
            browser: params.browser,
        });
    }
    async getAuditTrail(ruleId, skip = 0, take = 50) {
        const [logs, total] = await this.auditRepo.findByRuleId(ruleId, skip, take);
        return {
            entries: logs.map(this.mapToDto),
            total,
        };
    }
    async getByAction(action, skip = 0, take = 50) {
        const [logs, total] = await this.auditRepo.findByAction(action, skip, take);
        return { entries: logs.map(this.mapToDto), total };
    }
    mapToDto(log) {
        return {
            id: log.id,
            ruleId: log.ruleId,
            action: log.action,
            field: log.field,
            oldValue: log.oldValue,
            newValue: log.newValue,
            version: log.version,
            performedBy: log.performedBy,
            reason: log.reason,
            correlationId: log.correlationId,
            ipAddress: log.ipAddress,
            browser: log.browser,
            timestamp: log.timestamp.toISOString(),
        };
    }
};
exports.RuleAuditService = RuleAuditService;
exports.RuleAuditService = RuleAuditService = RuleAuditService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(alert_rule_audit_repository_interface_1.IAlertRuleAuditRepository)),
    __metadata("design:paramtypes", [Object])
], RuleAuditService);
//# sourceMappingURL=rule-audit.service.js.map