"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var AlertHealthService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AlertHealthService = void 0;
const common_1 = require("@nestjs/common");
const alert_repository_interface_1 = require("../../../common/repositories/alert.repository.interface");
const notification_repository_interface_1 = require("../../../common/repositories/notification.repository.interface");
let AlertHealthService = AlertHealthService_1 = class AlertHealthService {
    alertRepo;
    notifRepo;
    logger = new common_1.Logger(AlertHealthService_1.name);
    startTime = Date.now();
    constructor(alertRepo, notifRepo) {
        this.alertRepo = alertRepo;
        this.notifRepo = notifRepo;
    }
    async checkHealth() {
        const [, dlqCount] = await this.notifRepo.findDlqLogs(0, 1);
        const stats = await this.alertRepo.getOverviewStatistics();
        let status = "HEALTHY";
        if (dlqCount > 10 || stats.criticalAlerts > 20) {
            status = "DEGRADED";
        }
        return {
            status,
            redisConnected: true,
            bullmqWorkersActive: true,
            activeQueuedCount: Math.max(0, stats.openAlerts - stats.acknowledgedAlerts),
            dlqCount,
            lastProcessedAt: new Date().toISOString(),
            uptime: Math.floor((Date.now() - this.startTime) / 1000),
        };
    }
};
exports.AlertHealthService = AlertHealthService;
exports.AlertHealthService = AlertHealthService = AlertHealthService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(alert_repository_interface_1.IAlertRepository)),
    __param(1, (0, common_1.Inject)(notification_repository_interface_1.INotificationRepository)),
    __metadata("design:paramtypes", [Object, Object])
], AlertHealthService);
//# sourceMappingURL=alert-health.service.js.map