import { IMaintenanceRepository, MaintenanceWindowCreateInput } from "../../../common/repositories/maintenance.repository.interface";
import { MaintenanceWindow } from "@prisma/client";
export declare class MaintenanceService {
    private readonly maintenanceRepo;
    private readonly logger;
    constructor(maintenanceRepo: IMaintenanceRepository);
    createWindow(input: MaintenanceWindowCreateInput): Promise<MaintenanceWindow>;
    isDeviceInMaintenance(deviceId: string, atTime?: Date): Promise<{
        inMaintenance: boolean;
        activeWindow?: MaintenanceWindow;
    }>;
    getWindows(enabledOnly?: boolean): Promise<MaintenanceWindow[]>;
    getById(id: string): Promise<MaintenanceWindow | null>;
    updateWindow(id: string, data: Partial<MaintenanceWindow>): Promise<MaintenanceWindow>;
    deleteWindow(id: string): Promise<boolean>;
}
