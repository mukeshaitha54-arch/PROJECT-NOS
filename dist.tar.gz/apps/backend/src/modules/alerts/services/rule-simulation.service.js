"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var RuleSimulationService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.RuleSimulationService = void 0;
const common_1 = require("@nestjs/common");
const alert_rule_repository_interface_1 = require("../../../common/repositories/alert-rule.repository.interface");
const alert_repository_interface_1 = require("../../../common/repositories/alert.repository.interface");
const telemetry_repository_interface_1 = require("../../../common/repositories/telemetry.repository.interface");
const maintenance_service_1 = require("./maintenance.service");
const rule_audit_service_1 = require("./rule-audit.service");
const shared_types_1 = require("@nos/shared-types");
let RuleSimulationService = RuleSimulationService_1 = class RuleSimulationService {
    ruleRepo;
    alertRepo;
    telemetryRepo;
    maintenanceService;
    auditService;
    logger = new common_1.Logger(RuleSimulationService_1.name);
    REPLAY_MAX_SAMPLES = 10_000;
    constructor(ruleRepo, alertRepo, telemetryRepo, maintenanceService, auditService) {
        this.ruleRepo = ruleRepo;
        this.alertRepo = alertRepo;
        this.telemetryRepo = telemetryRepo;
        this.maintenanceService = maintenanceService;
        this.auditService = auditService;
    }
    async testRule(request, performedBy = "System", correlationId, ipAddress, browser) {
        const startMs = Date.now();
        const rule = await this.ruleRepo.findById(request.ruleId);
        if (!rule)
            throw new Error(`Rule ${request.ruleId} not found`);
        const { from, to } = this.resolveTimeframe(request.timeframe, request.from, request.to);
        this.logger.log(`[RuleSimulation] Testing rule "${rule.name}" over ${request.timeframe} [${from.toISOString()} → ${to.toISOString()}]`);
        const [alerts] = await this.alertRepo.findMany({
            ruleId: rule.id,
            take: 500,
        });
        const hoursInRange = (to.getTime() - from.getTime()) / (1000 * 60 * 60);
        const alertsInRange = alerts.filter((a) => {
            const createdAt = new Date(a.createdAt).getTime();
            return createdAt >= from.getTime() && createdAt <= to.getTime();
        });
        const baseWouldTrigger = alertsInRange.length > 0
            ? alertsInRange.length * 3
            : Math.max(1, Math.round(hoursInRange * 0.5));
        const cooldownRatio = Math.min(0.9, (rule.cooldownSeconds || 300) / 3600);
        const suppressed = Math.round(baseWouldTrigger * (0.6 + cooldownRatio * 0.2));
        const correlated = Math.round((baseWouldTrigger - suppressed) * 0.15);
        const deduplicated = Math.round((baseWouldTrigger - suppressed) * 0.25);
        const escalated = Math.round((baseWouldTrigger - suppressed) * 0.05);
        const actualFirings = Math.max(0, baseWouldTrigger - suppressed - deduplicated);
        const estimatedNotifications = rule.silentMode ? 0 : actualFirings;
        const estimatedEmails = rule.silentMode
            ? 0
            : Math.round(actualFirings * 0.8);
        const estimatedSocketEvents = baseWouldTrigger;
        const estimatedQueueJobs = actualFirings + estimatedNotifications;
        const noiseReduction = baseWouldTrigger > 0
            ? Math.round(((suppressed + deduplicated) / baseWouldTrigger) * 100)
            : 0;
        const affectedDevices = this.estimateAffectedDevices(rule, alerts);
        await this.auditService.record({
            ruleId: rule.id,
            action: "SIMULATE",
            version: rule.version,
            performedBy,
            reason: `Rule test over ${request.timeframe}`,
            correlationId,
            ipAddress,
            browser,
        });
        const simulationDurationMs = Date.now() - startMs;
        return {
            ruleId: rule.id,
            ruleName: rule.name,
            timeframe: request.timeframe,
            fromDate: from.toISOString(),
            toDate: to.toISOString(),
            wouldTrigger: baseWouldTrigger,
            suppressed,
            correlated,
            deduplicated,
            escalated,
            estimatedNotifications,
            estimatedEmails,
            estimatedSocketEvents,
            estimatedQueueJobs,
            affectedDevices,
            estimatedCooldownSaves: Math.round(suppressed * 0.75),
            noiseReduction,
            simulationDurationMs,
        };
    }
    async previewRule(ruleData) {
        const allRules = await this.ruleRepo.findMany(false);
        const [alerts] = await this.alertRepo.findMany({ take: 200 });
        const totalAlerts = alerts.length;
        const metricCategory = this.classifyMetric(ruleData.metric);
        const deviceEstimate = metricCategory === "cpu" || metricCategory === "ram"
            ? Math.max(5, Math.round(totalAlerts * 0.3))
            : metricCategory === "disk"
                ? Math.max(3, Math.round(totalAlerts * 0.2))
                : metricCategory === "security"
                    ? Math.max(2, Math.round(totalAlerts * 0.1))
                    : Math.max(1, Math.round(totalAlerts * 0.15));
        const threshold = ruleData.threshold;
        const operator = ruleData.operator;
        let volumeMultiplier = 1.0;
        if (operator === ">" && threshold < 50)
            volumeMultiplier = 3.0;
        else if (operator === ">" && threshold < 70)
            volumeMultiplier = 1.5;
        else if (operator === ">" && threshold > 90)
            volumeMultiplier = 0.3;
        const estimatedDailyAlerts = Math.max(1, Math.round(deviceEstimate * volumeMultiplier * 2));
        const estimatedWeeklyAlerts = estimatedDailyAlerts * 7;
        const cooldown = ruleData.cooldownSeconds ?? 300;
        const estimatedSuppression = Math.min(90, Math.round((cooldown / 3600) * 30 + 40));
        const estimatedAlertVolume = Math.max(1, Math.round(estimatedDailyAlerts * (1 - estimatedSuppression / 100)));
        const estimatedCorrelation = Math.round(estimatedAlertVolume * 0.1);
        const estimatedCooldownSaves = Math.round((estimatedDailyAlerts * estimatedSuppression) / 100);
        const severityWeight = {
            CRITICAL: 40,
            HIGH: 30,
            MEDIUM: 20,
            LOW: 10,
            INFO: 5,
        };
        const sev = (ruleData.severity || "MEDIUM").toUpperCase();
        const baseRisk = severityWeight[sev] || 20;
        const volumeRisk = Math.min(40, estimatedAlertVolume * 2);
        const depRisk = (ruleData.dependsOnIds?.length || 0) * 5;
        const riskRating = Math.min(100, baseRisk + volumeRisk + depRisk);
        const estimatedImpact = riskRating >= 75
            ? "CRITICAL"
            : riskRating >= 50
                ? "HIGH"
                : riskRating >= 25
                    ? "MEDIUM"
                    : "LOW";
        const complexDepth = ruleData.dependsOnIds?.length || 0;
        const complexOperator = ["CONTAINS", "NOT_CONTAINS", "MUTATED"].includes(operator)
            ? 2
            : 0;
        const complexSchedule = ruleData.scheduleMode === "CRON"
            ? 2
            : ruleData.scheduleMode !== "ALWAYS"
                ? 1
                : 0;
        const complexScore = complexDepth + complexOperator + complexSchedule;
        const complexityScore = complexScore === 0
            ? shared_types_1.RuleComplexityScore.SIMPLE
            : complexScore <= 2
                ? shared_types_1.RuleComplexityScore.MEDIUM
                : complexScore <= 4
                    ? shared_types_1.RuleComplexityScore.COMPLEX
                    : shared_types_1.RuleComplexityScore.VERY_COMPLEX;
        const noiseScore = Math.min(100, Math.round(estimatedSuppression * 0.3 +
            (estimatedDailyAlerts > 20 ? 40 : estimatedDailyAlerts * 2) +
            (cooldown < 60 ? 20 : cooldown < 300 ? 10 : 0)));
        const affectedTags = this.getTagsForMetric(ruleData.metric);
        return {
            estimatedDevices: deviceEstimate,
            estimatedAlertVolume,
            estimatedSuppression,
            estimatedCorrelation,
            estimatedCooldownSaves,
            estimatedImpact,
            riskRating,
            complexityScore,
            noiseScore,
            affectedTags,
            estimatedDailyAlerts,
            estimatedWeeklyAlerts,
        };
    }
    async dryRun(ruleData, performedBy = "System", correlationId, ipAddress, browser) {
        const startMs = Date.now();
        this.logger.log(`[DryRun] Starting dry run for metric="${ruleData.metric}" ${ruleData.operator} ${ruleData.threshold}`);
        let allSamples = [];
        try {
            const [alerts] = await this.alertRepo.findMany({ take: 200 });
            for (const alert of alerts.slice(0, 50)) {
                allSamples.push({
                    deviceId: alert.deviceId,
                    timestamp: alert.createdAt,
                    [ruleData.metric]: alert.ruleId
                        ? this.estimateMetricValue(ruleData.metric, ruleData.threshold, ruleData.operator)
                        : undefined,
                });
            }
        }
        catch (err) {
            this.logger.warn(`[DryRun] Could not load telemetry samples: ${err?.message}`);
        }
        const logs = [];
        let wouldTriggerCount = 0;
        let suppressedCount = 0;
        const cooldownMap = new Map();
        for (const sample of allSamples) {
            const value = sample[ruleData.metric];
            if (value === undefined || value === null)
                continue;
            const conditionMet = this.evaluateCondition(Number(value), ruleData.operator, ruleData.threshold);
            const cooldownKey = `${sample.deviceId}:${ruleData.metric}`;
            const lastFire = cooldownMap.get(cooldownKey);
            const sampleTime = new Date(sample.timestamp).getTime();
            const inCooldown = lastFire !== undefined &&
                sampleTime - lastFire < (ruleData.cooldownSeconds ?? 300) * 1000;
            const wouldTrigger = conditionMet && !inCooldown;
            const suppressReason = inCooldown ? "In cooldown window" : undefined;
            if (wouldTrigger) {
                wouldTriggerCount++;
                cooldownMap.set(cooldownKey, sampleTime);
            }
            else if (conditionMet && inCooldown) {
                suppressedCount++;
            }
            logs.push({
                deviceId: sample.deviceId,
                metric: ruleData.metric,
                value: Number(value),
                wouldTrigger,
                reason: wouldTrigger
                    ? `${ruleData.metric} ${ruleData.operator} ${ruleData.threshold} = TRUE`
                    : suppressReason ||
                        `${ruleData.metric} ${ruleData.operator} ${ruleData.threshold} = FALSE`,
                timestamp: new Date(sample.timestamp).toISOString(),
            });
            this.logger.debug(`[DryRun] Device ${sample.deviceId}: ${ruleData.metric}=${value} → ${wouldTrigger ? "WOULD TRIGGER" : "NO TRIGGER"}`);
        }
        if (ruleData.id) {
            await this.auditService.record({
                ruleId: ruleData.id,
                action: "DRY_RUN",
                version: 0,
                performedBy,
                reason: `Dry run for ${ruleData.metric} ${ruleData.operator} ${ruleData.threshold}`,
                correlationId,
                ipAddress,
                browser,
            });
        }
        const executionTimeMs = Date.now() - startMs;
        return {
            ruleId: ruleData.id,
            ruleName: ruleData.name,
            stored: false,
            notified: false,
            wouldTriggerCount,
            suppressedCount,
            deduplications: 0,
            logs: logs.slice(0, 100),
            executionTimeMs,
            evaluatedDevices: new Set(allSamples.map((s) => s.deviceId)).size,
            samplesProcessed: allSamples.length,
        };
    }
    async replayHistoricalTelemetry(request, performedBy = "System", correlationId, ipAddress, browser) {
        const startMs = Date.now();
        const rule = await this.ruleRepo.findById(request.ruleId);
        if (!rule)
            throw new Error(`Rule ${request.ruleId} not found`);
        const from = new Date(request.from);
        const to = new Date(request.to);
        this.logger.log(`[Replay] Replaying rule "${rule.name}" against telemetry [${from.toISOString()} → ${to.toISOString()}]`);
        const timeline = [];
        let wouldTriggerCount = 0;
        let suppressedCount = 0;
        let correlatedCount = 0;
        let deduplicatedCount = 0;
        let devicesReplayed = 0;
        let samplesReplayed = 0;
        try {
            const deviceIds = request.deviceIds || [];
            const cooldownMap = new Map();
            const fingerprintMap = new Map();
            if (deviceIds.length === 0) {
                const [alerts] = await this.alertRepo.findMany({ take: 50 });
                const uniqueDeviceIds = [...new Set(alerts.map((a) => a.deviceId))];
                deviceIds.push(...uniqueDeviceIds.slice(0, 20));
            }
            devicesReplayed = deviceIds.length;
            for (const deviceId of deviceIds) {
                const maintenance = await this.maintenanceService.isDeviceInMaintenance(deviceId, from);
                const telemetry = await this.telemetryRepo.findRange({
                    deviceId,
                    from,
                    to,
                    take: Math.min(this.REPLAY_MAX_SAMPLES / Math.max(deviceIds.length, 1), 500),
                });
                for (const snapshot of telemetry.items) {
                    samplesReplayed++;
                    const value = this.extractMetricFromSnapshot(snapshot, rule.metric);
                    if (value === null)
                        continue;
                    const conditionMet = this.evaluateCondition(Number(value), rule.operator, rule.threshold);
                    const snapshotTime = new Date(snapshot.timestamp).getTime();
                    if (!conditionMet)
                        continue;
                    const cooldownKey = `${deviceId}:${rule.id}`;
                    const lastFire = cooldownMap.get(cooldownKey);
                    const inCooldown = lastFire !== undefined &&
                        snapshotTime - lastFire < rule.cooldownSeconds * 1000;
                    if (inCooldown) {
                        suppressedCount++;
                        timeline.push({
                            timestamp: snapshot.timestamp.toISOString(),
                            deviceId,
                            metric: rule.metric,
                            value: Number(value),
                            wouldTrigger: false,
                            suppressReason: `In ${rule.cooldownSeconds}s cooldown window`,
                        });
                        continue;
                    }
                    if (maintenance.inMaintenance) {
                        suppressedCount++;
                        timeline.push({
                            timestamp: snapshot.timestamp.toISOString(),
                            deviceId,
                            metric: rule.metric,
                            value: Number(value),
                            wouldTrigger: false,
                            suppressReason: `Device in maintenance: "${maintenance.activeWindow?.title}"`,
                        });
                        continue;
                    }
                    const fingerprint = `${deviceId}:${rule.metric}:${rule.id}`;
                    if (fingerprintMap.has(fingerprint)) {
                        deduplicatedCount++;
                        timeline.push({
                            timestamp: snapshot.timestamp.toISOString(),
                            deviceId,
                            metric: rule.metric,
                            value: Number(value),
                            wouldTrigger: false,
                            suppressReason: "Deduplicated (fingerprint match)",
                        });
                        continue;
                    }
                    fingerprintMap.set(fingerprint, true);
                    cooldownMap.set(cooldownKey, snapshotTime);
                    wouldTriggerCount++;
                    if (rule.metric !== "heartbeat")
                        correlatedCount++;
                    timeline.push({
                        timestamp: snapshot.timestamp.toISOString(),
                        deviceId,
                        metric: rule.metric,
                        value: Number(value),
                        wouldTrigger: true,
                    });
                }
            }
        }
        catch (err) {
            this.logger.warn(`[Replay] Telemetry replay error: ${err?.message}`);
        }
        await this.auditService.record({
            ruleId: rule.id,
            action: "REPLAY",
            version: rule.version,
            performedBy,
            reason: `Telemetry replay from ${from.toISOString()} to ${to.toISOString()}`,
            correlationId,
            ipAddress,
            browser,
        });
        const executionTimeMs = Date.now() - startMs;
        const estimatedAlertVolume = wouldTriggerCount;
        return {
            ruleId: rule.id,
            ruleName: rule.name,
            from: from.toISOString(),
            to: to.toISOString(),
            stored: false,
            devicesReplayed,
            samplesReplayed,
            wouldTriggerCount,
            suppressedCount,
            correlatedCount,
            deduplicatedCount,
            estimatedAlertVolume,
            executionTimeMs,
            timeline: timeline.slice(0, 200),
        };
    }
    resolveTimeframe(timeframe, customFrom, customTo) {
        const to = new Date();
        let from;
        switch (timeframe) {
            case "LAST_HOUR":
                from = new Date(to.getTime() - 1 * 60 * 60 * 1000);
                break;
            case "LAST_6H":
                from = new Date(to.getTime() - 6 * 60 * 60 * 1000);
                break;
            case "LAST_24H":
                from = new Date(to.getTime() - 24 * 60 * 60 * 1000);
                break;
            case "LAST_7D":
                from = new Date(to.getTime() - 7 * 24 * 60 * 60 * 1000);
                break;
            case "CUSTOM":
                if (!customFrom || !customTo)
                    throw new Error("CUSTOM timeframe requires from and to dates");
                return { from: new Date(customFrom), to: new Date(customTo) };
            default:
                from = new Date(to.getTime() - 24 * 60 * 60 * 1000);
        }
        return { from, to };
    }
    evaluateCondition(value, operator, threshold) {
        switch (operator) {
            case ">":
                return value > threshold;
            case ">=":
                return value >= threshold;
            case "<":
                return value < threshold;
            case "<=":
                return value <= threshold;
            case "==":
                return value === threshold;
            case "!=":
                return value !== threshold;
            case "MUTATED":
                return Boolean(value);
            default:
                return false;
        }
    }
    extractMetricFromSnapshot(snapshot, metric) {
        const metricMap = {
            cpuUsage: "cpuUsage",
            ramUsage: "memoryUsagePercent",
            diskUsage: "diskUsagePercent",
            memoryUsagePercent: "memoryUsagePercent",
            diskUsagePercent: "diskUsagePercent",
            diskReadSpeed: "diskReadSpeed",
            diskWriteSpeed: "diskWriteSpeed",
            networkUploadSpeed: "networkUploadSpeed",
            networkDownloadSpeed: "networkDownloadSpeed",
            activeConnections: "activeConnections",
            runningProcesses: "runningProcesses",
            cpuTemperature: "cpuTemperature",
        };
        const field = metricMap[metric];
        if (!field || snapshot[field] === undefined)
            return null;
        return Number(snapshot[field]);
    }
    estimateMetricValue(metric, threshold, operator) {
        if (operator === ">")
            return threshold + 5;
        if (operator === ">=")
            return threshold;
        if (operator === "<")
            return threshold - 5;
        if (operator === "<=")
            return threshold;
        return threshold;
    }
    estimateAffectedDevices(rule, alerts) {
        const deviceIds = [...new Set(alerts.map((a) => a.deviceId))];
        return deviceIds.slice(0, 10);
    }
    classifyMetric(metric) {
        if (["cpuUsage", "cpuTemperature", "cpuFrequency"].includes(metric))
            return "cpu";
        if (["ramUsage", "memoryUsagePercent"].includes(metric))
            return "ram";
        if ([
            "diskUsage",
            "diskUsagePercent",
            "diskReadSpeed",
            "diskWriteSpeed",
        ].includes(metric))
            return "disk";
        if (["security.defender", "security.firewall", "security.bitlocker"].includes(metric))
            return "security";
        if ([
            "networkUploadSpeed",
            "networkDownloadSpeed",
            "bytesSent",
            "bytesReceived",
        ].includes(metric))
            return "network";
        return "system";
    }
    getTagsForMetric(metric) {
        const tagMap = {
            cpuUsage: ["CPU", "Performance"],
            ramUsage: ["MEMORY", "Performance"],
            diskUsage: ["STORAGE", "Performance"],
            memoryUsagePercent: ["MEMORY", "Performance"],
            diskUsagePercent: ["STORAGE", "Performance"],
            networkUploadSpeed: ["NETWORK", "Performance"],
            networkDownloadSpeed: ["NETWORK", "Performance"],
            "security.defender": ["SECURITY", "Compliance"],
            "security.firewall": ["SECURITY", "Compliance"],
            "inventory.version": ["INVENTORY", "Compliance"],
            heartbeat: ["NETWORK", "Availability"],
        };
        return tagMap[metric] || ["SYSTEM"];
    }
};
exports.RuleSimulationService = RuleSimulationService;
exports.RuleSimulationService = RuleSimulationService = RuleSimulationService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(alert_rule_repository_interface_1.IAlertRuleRepository)),
    __param(1, (0, common_1.Inject)(alert_repository_interface_1.IAlertRepository)),
    __param(2, (0, common_1.Inject)(telemetry_repository_interface_1.ITelemetryRepositoryToken)),
    __metadata("design:paramtypes", [Object, Object, Object, maintenance_service_1.MaintenanceService,
        rule_audit_service_1.RuleAuditService])
], RuleSimulationService);
//# sourceMappingURL=rule-simulation.service.js.map