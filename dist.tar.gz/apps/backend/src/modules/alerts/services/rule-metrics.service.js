"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var RuleMetricsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.RuleMetricsService = void 0;
const common_1 = require("@nestjs/common");
const alert_rule_repository_interface_1 = require("../../../common/repositories/alert-rule.repository.interface");
const shared_types_1 = require("@nos/shared-types");
let RuleMetricsService = RuleMetricsService_1 = class RuleMetricsService {
    ruleRepo;
    logger = new common_1.Logger(RuleMetricsService_1.name);
    execTimeSamples = new Map();
    constructor(ruleRepo) {
        this.ruleRepo = ruleRepo;
    }
    recordExecution(ruleId, execMs) {
        const samples = this.execTimeSamples.get(ruleId) || [];
        samples.push(execMs);
        if (samples.length > 100)
            samples.shift();
        this.execTimeSamples.set(ruleId, samples);
    }
    async getPerformanceMetrics(ruleId) {
        const rule = await this.ruleRepo.findById(ruleId);
        if (!rule)
            throw new Error(`Rule ${ruleId} not found`);
        const evalCount = Number(rule.evaluationCount);
        const triggerCount = Number(rule.triggerCount);
        const suppressionCount = Number(rule.suppressionCount);
        const deduplicationCount = Number(rule.deduplicationCount);
        const escalationCount = Number(rule.escalationCount);
        const samples = this.execTimeSamples.get(ruleId) || [];
        const sorted = [...samples].sort((a, b) => a - b);
        const p95 = sorted.length > 0 ? sorted[Math.floor(sorted.length * 0.95)] : 0;
        const p99 = sorted.length > 0 ? sorted[Math.floor(sorted.length * 0.99)] : 0;
        const triggerRate = evalCount > 0 ? (triggerCount / evalCount) * 100 : 0;
        const suppressionRate = triggerCount > 0 ? (suppressionCount / triggerCount) * 100 : 0;
        const memoryUsageBytes = JSON.stringify(rule).length * 2 + evalCount * 8;
        return {
            ruleId,
            ruleName: rule.name,
            avgExecutionMs: rule.avgExecMs,
            maxExecutionMs: rule.maxExecMs,
            minExecutionMs: rule.minExecMs,
            evaluationCount: evalCount,
            triggerCount,
            suppressionCount,
            correlationCount: 0,
            deduplicationCount,
            escalationCount,
            memoryUsageBytes,
            triggerRate: Math.round(triggerRate * 100) / 100,
            suppressionRate: Math.round(suppressionRate * 100) / 100,
            lastEvaluatedAt: rule.lastEvaluatedAt?.toISOString() ?? null,
            p95ExecutionMs: p95,
            p99ExecutionMs: p99,
        };
    }
    computeComplexityScore(rule) {
        let score = 0;
        const complexMetrics = [
            "security.defender",
            "security.firewall",
            "inventory.version",
        ];
        const conditionComplexity = complexMetrics.includes(rule.metric) ? 25 : 10;
        score += conditionComplexity;
        const operatorWeight = ["CONTAINS", "NOT_CONTAINS", "MUTATED"].includes(rule.operator)
            ? 20
            : 5;
        score += operatorWeight;
        const depIds = rule.dependsOnIds || [];
        const hasDependencies = depIds.length > 0;
        const dependencyDepth = depIds.length;
        score += dependencyDepth * 10;
        const hasCorrelation = rule.metric === "heartbeat";
        if (hasCorrelation)
            score += 15;
        const hasCooldown = (rule.cooldownSeconds || 0) > 0;
        const hasDuration = (rule.durationSeconds || 0) > 0;
        if (hasCooldown)
            score += 5;
        if (hasDuration)
            score += 10;
        const scheduleModeComplexity = rule.scheduleMode === "CRON"
            ? 20
            : rule.scheduleMode === "BUSINESS_HOURS" ||
                rule.scheduleMode === "NIGHT" ||
                rule.scheduleMode === "WEEKEND"
                ? 10
                : 0;
        score += scheduleModeComplexity;
        let complexityScore;
        if (score <= 20)
            complexityScore = shared_types_1.RuleComplexityScore.SIMPLE;
        else if (score <= 45)
            complexityScore = shared_types_1.RuleComplexityScore.MEDIUM;
        else if (score <= 70)
            complexityScore = shared_types_1.RuleComplexityScore.COMPLEX;
        else
            complexityScore = shared_types_1.RuleComplexityScore.VERY_COMPLEX;
        return {
            ruleId: rule.id,
            ruleName: rule.name,
            score: complexityScore,
            scoreValue: Math.min(score, 100),
            factors: {
                conditionComplexity,
                operatorWeight,
                hasDependencies,
                dependencyDepth,
                hasCorrelation,
                hasCooldown,
                hasDuration,
                scheduleModeComplexity,
            },
        };
    }
    computeNoiseScore(rule) {
        const evalCount = Number(rule.evaluationCount) || 1;
        const triggerCount = Number(rule.triggerCount) || 0;
        const suppressionCount = Number(rule.suppressionCount) || 0;
        const deduplicationCount = Number(rule.deduplicationCount) || 0;
        const escalationCount = Number(rule.escalationCount) || 0;
        const deduplicationFactor = Math.min(20, Math.round((deduplicationCount / Math.max(triggerCount, 1)) * 20));
        const suppressionFactor = Math.min(20, Math.round((suppressionCount / Math.max(evalCount, 1)) * 20));
        const cooldownFactor = Math.min(20, Math.max(0, 20 - Math.round(((rule.cooldownSeconds || 300) / 3600) * 20)));
        const correlationFactor = triggerCount > 0 && escalationCount / triggerCount > 0.1 ? 10 : 5;
        const falsePositiveFactor = triggerCount > 10 && escalationCount === 0 ? 15 : 0;
        const maintenanceFactor = suppressionCount > triggerCount ? 10 : 0;
        const noiseScore = Math.min(100, deduplicationFactor +
            suppressionFactor +
            cooldownFactor +
            correlationFactor +
            falsePositiveFactor +
            maintenanceFactor);
        const rating = noiseScore <= 25
            ? "LOW"
            : noiseScore <= 50
                ? "MEDIUM"
                : noiseScore <= 75
                    ? "HIGH"
                    : "CRITICAL";
        const recommendation = rating === "CRITICAL"
            ? "Rule is extremely noisy. Consider increasing threshold, cooldown, or enabling maintenance windows."
            : rating === "HIGH"
                ? "Rule generates significant noise. Review threshold and cooldown settings."
                : rating === "MEDIUM"
                    ? "Rule has moderate noise. Monitor for false positives."
                    : "Rule noise is within acceptable range.";
        return {
            ruleId: rule.id,
            ruleName: rule.name,
            noiseScore,
            rating,
            breakdown: {
                deduplicationFactor,
                suppressionFactor,
                cooldownFactor,
                correlationFactor,
                falsePositiveFactor,
                maintenanceFactor,
            },
            recommendation,
        };
    }
    async getUsageStatistics(ruleId) {
        const rule = await this.ruleRepo.findById(ruleId);
        if (!rule)
            throw new Error(`Rule ${ruleId} not found`);
        const evalCount = Number(rule.evaluationCount);
        const triggerCount = Number(rule.triggerCount);
        const suppressionCount = Number(rule.suppressionCount);
        const deduplicationCount = Number(rule.deduplicationCount);
        const escalationCount = Number(rule.escalationCount);
        const createdAt = rule.createdAt;
        const ageInDays = Math.max(1, (Date.now() - createdAt.getTime()) / (1000 * 60 * 60 * 24));
        const dailyTriggerAverage = Math.round((triggerCount / ageInDays) * 100) / 100;
        const weeklyTriggerAverage = Math.round(dailyTriggerAverage * 7 * 100) / 100;
        const triggerTrend = triggerCount === 0
            ? "STABLE"
            : dailyTriggerAverage > 10
                ? "INCREASING"
                : dailyTriggerAverage > 2
                    ? "STABLE"
                    : "DECREASING";
        return {
            ruleId,
            ruleName: rule.name,
            totalEvaluations: evalCount,
            totalTriggers: triggerCount,
            totalSuppressions: suppressionCount,
            totalDeduplications: deduplicationCount,
            totalEscalations: escalationCount,
            dailyTriggerAverage,
            weeklyTriggerAverage,
            lastTriggeredAt: rule.lastEvaluatedAt?.toISOString() ?? null,
            lastEvaluatedAt: rule.lastEvaluatedAt?.toISOString() ?? null,
            neverTriggered: triggerCount === 0,
            triggerTrend,
        };
    }
    async getRecommendations() {
        const rules = await this.ruleRepo.findMany(false);
        const recommendations = [];
        const seen = new Map();
        for (const rule of rules) {
            const evalCount = Number(rule.evaluationCount);
            const triggerCount = Number(rule.triggerCount);
            const avgExecMs = rule.avgExecMs;
            if (evalCount > 100 && triggerCount === 0) {
                recommendations.push({
                    type: shared_types_1.RuleRecommendationType.NEVER_TRIGGERED,
                    ruleId: rule.id,
                    ruleName: rule.name,
                    message: `Rule "${rule.name}" has been evaluated ${evalCount} times but never triggered. Consider removing or adjusting threshold.`,
                    severity: "WARNING",
                    actionable: true,
                    suggestedAction: "Lower threshold or disable rule",
                });
            }
            if (avgExecMs > 400 && evalCount > 10) {
                recommendations.push({
                    type: shared_types_1.RuleRecommendationType.EXPENSIVE,
                    ruleId: rule.id,
                    ruleName: rule.name,
                    message: `Rule "${rule.name}" averages ${avgExecMs.toFixed(1)}ms execution (near timeout). High performance impact.`,
                    severity: "WARNING",
                    actionable: true,
                    suggestedAction: "Review metric complexity or increase timeoutMs",
                });
            }
            const noise = this.computeNoiseScore(rule);
            if (noise.noiseScore > 70) {
                recommendations.push({
                    type: shared_types_1.RuleRecommendationType.HIGH_NOISE,
                    ruleId: rule.id,
                    ruleName: rule.name,
                    message: `Rule "${rule.name}" noise score is ${noise.noiseScore}/100. Generating excessive alert volume.`,
                    severity: "CRITICAL",
                    actionable: true,
                    suggestedAction: "Increase cooldown, raise threshold, or add maintenance windows",
                });
            }
            const dupKey = `${rule.metric}:${rule.operator}:${rule.threshold}:${rule.durationSeconds}:${rule.severity}`;
            if (seen.has(dupKey)) {
                const firstRuleId = seen.get(dupKey);
                const firstRule = rules.find((r) => r.id === firstRuleId);
                recommendations.push({
                    type: shared_types_1.RuleRecommendationType.REMOVE_DUPLICATE,
                    ruleId: rule.id,
                    ruleName: rule.name,
                    message: `Rule "${rule.name}" is a duplicate of "${firstRule?.name}". Remove one or merge into a single rule.`,
                    severity: "WARNING",
                    actionable: true,
                    suggestedAction: "Archive or delete the duplicate rule",
                    relatedRuleIds: [firstRuleId],
                });
            }
            else {
                seen.set(dupKey, rule.id);
            }
            const sameMetricRules = rules.filter((r) => r.id !== rule.id &&
                r.metric === rule.metric &&
                r.operator === rule.operator);
            for (const other of sameMetricRules) {
                const overlap = Math.abs(rule.threshold - other.threshold) < 5;
                if (overlap) {
                    recommendations.push({
                        type: shared_types_1.RuleRecommendationType.OVERLAPPING,
                        ruleId: rule.id,
                        ruleName: rule.name,
                        message: `Rule "${rule.name}" (threshold: ${rule.threshold}) overlaps with "${other.name}" (threshold: ${other.threshold}) on metric ${rule.metric}`,
                        severity: "INFO",
                        actionable: true,
                        suggestedAction: "Merge overlapping rules or adjust thresholds to avoid duplicates",
                        relatedRuleIds: [other.id],
                    });
                    break;
                }
            }
        }
        this.logger.log(`[RuleMetrics] Generated ${recommendations.length} rule recommendations`);
        return recommendations;
    }
};
exports.RuleMetricsService = RuleMetricsService;
exports.RuleMetricsService = RuleMetricsService = RuleMetricsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(alert_rule_repository_interface_1.IAlertRuleRepository)),
    __metadata("design:paramtypes", [Object])
], RuleMetricsService);
//# sourceMappingURL=rule-metrics.service.js.map