"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var MaintenanceService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.MaintenanceService = void 0;
const common_1 = require("@nestjs/common");
const maintenance_repository_interface_1 = require("../../../common/repositories/maintenance.repository.interface");
let MaintenanceService = MaintenanceService_1 = class MaintenanceService {
    maintenanceRepo;
    logger = new common_1.Logger(MaintenanceService_1.name);
    constructor(maintenanceRepo) {
        this.maintenanceRepo = maintenanceRepo;
    }
    async createWindow(input) {
        this.logger.log(`[Maintenance] Scheduled window "${input.title}" from ${input.startTime} to ${input.endTime} (${input.type || "SCHEDULED"})`);
        return this.maintenanceRepo.create(input);
    }
    async isDeviceInMaintenance(deviceId, atTime = new Date()) {
        const windows = await this.maintenanceRepo.findActiveByDevice(deviceId, atTime);
        if (windows && windows.length > 0) {
            return { inMaintenance: true, activeWindow: windows[0] };
        }
        return { inMaintenance: false };
    }
    async getWindows(enabledOnly = false) {
        return this.maintenanceRepo.findMany(enabledOnly);
    }
    async getById(id) {
        return this.maintenanceRepo.findById(id);
    }
    async updateWindow(id, data) {
        return this.maintenanceRepo.update(id, data);
    }
    async deleteWindow(id) {
        return this.maintenanceRepo.delete(id);
    }
};
exports.MaintenanceService = MaintenanceService;
exports.MaintenanceService = MaintenanceService = MaintenanceService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(maintenance_repository_interface_1.IMaintenanceRepository)),
    __metadata("design:paramtypes", [Object])
], MaintenanceService);
//# sourceMappingURL=maintenance.service.js.map