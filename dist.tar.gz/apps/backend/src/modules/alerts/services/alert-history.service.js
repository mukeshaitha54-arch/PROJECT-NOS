"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var AlertHistoryService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AlertHistoryService = void 0;
const common_1 = require("@nestjs/common");
const alert_repository_interface_1 = require("../../../common/repositories/alert.repository.interface");
let AlertHistoryService = AlertHistoryService_1 = class AlertHistoryService {
    alertRepo;
    logger = new common_1.Logger(AlertHistoryService_1.name);
    constructor(alertRepo) {
        this.alertRepo = alertRepo;
    }
    async recordAction(data) {
        this.logger.log(`[Alert Audit] ${data.action} on alert ${data.alertId} by ${data.performedBy} (Correlation: ${data.correlationId || "none"})`);
        return this.alertRepo.addHistory(data);
    }
    async addOperatorComment(data) {
        const commentRecord = await this.alertRepo.addComment(data);
        await this.recordAction({
            alertId: data.alertId,
            action: data.isPrivate ? "PRIVATE_NOTE_ADDED" : "COMMENT_ADDED",
            performedBy: data.userName,
            comment: data.comment,
        });
        return commentRecord;
    }
    async getHistory(alertId) {
        const alert = await this.alertRepo.findById(alertId);
        return alert?.history || [];
    }
};
exports.AlertHistoryService = AlertHistoryService;
exports.AlertHistoryService = AlertHistoryService = AlertHistoryService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(alert_repository_interface_1.IAlertRepository)),
    __metadata("design:paramtypes", [Object])
], AlertHistoryService);
//# sourceMappingURL=alert-history.service.js.map