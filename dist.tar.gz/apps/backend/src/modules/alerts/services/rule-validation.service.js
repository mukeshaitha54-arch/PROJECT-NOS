"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var RuleValidationService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.RuleValidationService = void 0;
const common_1 = require("@nestjs/common");
const alert_rule_repository_interface_1 = require("../../../common/repositories/alert-rule.repository.interface");
const VALID_METRICS = new Set([
    "cpuUsage",
    "ramUsage",
    "diskUsage",
    "memoryUsagePercent",
    "diskUsagePercent",
    "diskReadSpeed",
    "diskWriteSpeed",
    "networkUploadSpeed",
    "networkDownloadSpeed",
    "activeConnections",
    "runningProcesses",
    "systemUptime",
    "heartbeat",
    "cpuTemperature",
    "cpuFrequency",
    "security.defender",
    "security.firewall",
    "security.bitlocker",
    "inventory.version",
    "bytesSent",
    "bytesReceived",
]);
const VALID_OPERATORS = new Set([
    ">",
    ">=",
    "<",
    "<=",
    "==",
    "!=",
    "MUTATED",
    "CONTAINS",
    "NOT_CONTAINS",
]);
let RuleValidationService = RuleValidationService_1 = class RuleValidationService {
    ruleRepo;
    logger = new common_1.Logger(RuleValidationService_1.name);
    constructor(ruleRepo) {
        this.ruleRepo = ruleRepo;
    }
    async validate(ruleData, excludeRuleId) {
        const errors = [];
        const warnings = [];
        let duplicateOf = null;
        const conflictsWith = [];
        const circularDependencies = [];
        const invalidMetrics = [];
        const impossibleConditions = [];
        if (!ruleData.metric || !VALID_METRICS.has(ruleData.metric)) {
            invalidMetrics.push(ruleData.metric);
            errors.push({
                code: "INVALID_METRIC",
                field: "metric",
                message: `Metric "${ruleData.metric}" is not a recognized telemetry metric. Valid metrics: ${[...VALID_METRICS].join(", ")}`,
            });
        }
        if (!ruleData.operator || !VALID_OPERATORS.has(ruleData.operator)) {
            errors.push({
                code: "INVALID_OPERATOR",
                field: "operator",
                message: `Operator "${ruleData.operator}" is invalid. Valid operators: ${[...VALID_OPERATORS].join(", ")}`,
            });
        }
        const percentageMetrics = [
            "cpuUsage",
            "ramUsage",
            "diskUsage",
            "memoryUsagePercent",
            "diskUsagePercent",
        ];
        if (percentageMetrics.includes(ruleData.metric)) {
            if (ruleData.threshold < 0 || ruleData.threshold > 100) {
                impossibleConditions.push(`${ruleData.metric} threshold must be 0–100 (received ${ruleData.threshold})`);
                errors.push({
                    code: "IMPOSSIBLE_THRESHOLD",
                    field: "threshold",
                    message: `Threshold ${ruleData.threshold} is impossible for metric "${ruleData.metric}" (must be 0–100%)`,
                });
            }
            if (ruleData.threshold >= 100 && ruleData.operator === ">") {
                impossibleConditions.push(`${ruleData.metric} > 100 will never trigger`);
                errors.push({
                    code: "IMPOSSIBLE_CONDITION",
                    field: "threshold",
                    message: `Condition "${ruleData.metric} > 100" can never be satisfied (max is 100%)`,
                });
            }
        }
        if ((ruleData.threshold ?? 0) < 0 &&
            !percentageMetrics.includes(ruleData.metric)) {
            warnings.push({
                code: "NEGATIVE_THRESHOLD",
                field: "threshold",
                message: `Threshold ${ruleData.threshold} is negative — verify this is intentional for metric "${ruleData.metric}"`,
            });
        }
        if ((ruleData.durationSeconds ?? 0) < 0) {
            errors.push({
                code: "INVALID_DURATION",
                field: "durationSeconds",
                message: `durationSeconds cannot be negative`,
            });
        }
        if ((ruleData.cooldownSeconds ?? 300) < 0) {
            errors.push({
                code: "INVALID_COOLDOWN",
                field: "cooldownSeconds",
                message: `cooldownSeconds cannot be negative`,
            });
        }
        if ((ruleData.cooldownSeconds ?? 300) < (ruleData.durationSeconds ?? 0)) {
            warnings.push({
                code: "COOLDOWN_SHORTER_THAN_DURATION",
                field: "cooldownSeconds",
                message: `Cooldown (${ruleData.cooldownSeconds}s) is shorter than duration (${ruleData.durationSeconds}s) — may cause alert storms`,
            });
        }
        const allRules = await this.ruleRepo.findMany(false);
        const existingRules = allRules.filter((r) => r.id !== excludeRuleId);
        const dupKey = `${ruleData.metric}:${ruleData.operator}:${ruleData.threshold}:${ruleData.durationSeconds ?? 0}:${ruleData.severity ?? "MEDIUM"}`;
        for (const existing of existingRules) {
            const existKey = `${existing.metric}:${existing.operator}:${existing.threshold}:${existing.durationSeconds}:${existing.severity}`;
            if (dupKey === existKey) {
                duplicateOf = existing.id;
                errors.push({
                    code: "DUPLICATE_RULE",
                    field: "metric",
                    message: `Rule "${ruleData.name}" is a duplicate of existing rule "${existing.name}" (identical conditions)`,
                    conflictingRuleId: existing.id,
                    conflictingRuleName: existing.name,
                });
                break;
            }
        }
        for (const existing of existingRules) {
            if (existing.metric === ruleData.metric &&
                existing.operator === ruleData.operator &&
                existing.threshold === ruleData.threshold &&
                existing.severity !== (ruleData.severity ?? "MEDIUM")) {
                conflictsWith.push(existing.id);
                warnings.push({
                    code: "CONFLICTING_RULE",
                    field: "severity",
                    message: `Rule "${ruleData.name}" has same conditions as "${existing.name}" but different severity (${ruleData.severity} vs ${existing.severity})`,
                    conflictingRuleId: existing.id,
                    conflictingRuleName: existing.name,
                });
            }
        }
        if (ruleData.dependsOnIds && ruleData.dependsOnIds.length > 0) {
            const ruleMap = new Map();
            for (const r of existingRules) {
                ruleMap.set(r.id, r.dependsOnIds || []);
            }
            const visited = new Set();
            const detectCycle = (nodeId, path) => {
                if (visited.has(nodeId)) {
                    const cycleStart = path.indexOf(nodeId);
                    if (cycleStart !== -1) {
                        circularDependencies.push([...path.slice(cycleStart), nodeId]);
                    }
                    return true;
                }
                visited.add(nodeId);
                const deps = ruleMap.get(nodeId) || [];
                for (const dep of deps) {
                    detectCycle(dep, [...path, nodeId]);
                }
                return false;
            };
            for (const depId of ruleData.dependsOnIds) {
                detectCycle(depId, ["new-rule"]);
            }
            if (circularDependencies.length > 0) {
                errors.push({
                    code: "CIRCULAR_DEPENDENCY",
                    field: "dependsOnIds",
                    message: `Circular dependency detected in rule dependency chain`,
                });
            }
        }
        const nameMatch = existingRules.find((r) => r.name.toLowerCase() === ruleData.name.toLowerCase());
        if (nameMatch && nameMatch.id !== excludeRuleId) {
            errors.push({
                code: "DUPLICATE_NAME",
                field: "name",
                message: `Rule name "${ruleData.name}" is already in use by rule "${nameMatch.name}"`,
                conflictingRuleId: nameMatch.id,
                conflictingRuleName: nameMatch.name,
            });
        }
        const valid = errors.length === 0;
        this.logger.log(`[RuleValidation] Rule "${ruleData.name}": ${valid ? "VALID" : `INVALID (${errors.length} errors, ${warnings.length} warnings)`}`);
        return {
            valid,
            errors,
            warnings,
            duplicateOf,
            conflictsWith: conflictsWith.length > 0 ? conflictsWith : null,
            circularDependencies: circularDependencies.length > 0 ? circularDependencies : undefined,
            invalidMetrics: invalidMetrics.length > 0 ? invalidMetrics : undefined,
            impossibleConditions: impossibleConditions.length > 0 ? impossibleConditions : undefined,
        };
    }
};
exports.RuleValidationService = RuleValidationService;
exports.RuleValidationService = RuleValidationService = RuleValidationService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(alert_rule_repository_interface_1.IAlertRuleRepository)),
    __metadata("design:paramtypes", [Object])
], RuleValidationService);
//# sourceMappingURL=rule-validation.service.js.map