import { IAlertRuleAuditRepository, AlertRuleAuditCreateInput } from "../../../common/repositories/alert-rule-audit.repository.interface";
import { RuleAuditEntryDto } from "@nos/shared-types";
import { AlertRuleAuditLog } from "@prisma/client";
export declare class RuleAuditService {
    private readonly auditRepo;
    private readonly logger;
    constructor(auditRepo: IAlertRuleAuditRepository);
    record(data: AlertRuleAuditCreateInput): Promise<AlertRuleAuditLog>;
    recordFieldChange(params: {
        ruleId: string;
        field: string;
        oldValue: string | number | boolean | null;
        newValue: string | number | boolean | null;
        version: number;
        performedBy: string;
        reason?: string;
        correlationId?: string;
        ipAddress?: string;
        browser?: string;
    }): Promise<AlertRuleAuditLog>;
    getAuditTrail(ruleId: string, skip?: number, take?: number): Promise<{
        entries: RuleAuditEntryDto[];
        total: number;
    }>;
    getByAction(action: string, skip?: number, take?: number): Promise<{
        entries: RuleAuditEntryDto[];
        total: number;
    }>;
    private mapToDto;
}
