import { IAlertRepository } from "../../../common/repositories/alert.repository.interface";
import { AlertHistory, AlertComment } from "@prisma/client";
export declare class AlertHistoryService {
    private readonly alertRepo;
    private readonly logger;
    constructor(alertRepo: IAlertRepository);
    recordAction(data: {
        alertId: string;
        action: string;
        performedBy: string;
        oldValue?: string;
        newValue?: string;
        ipAddress?: string;
        browser?: string;
        correlationId?: string;
        comment?: string;
    }): Promise<AlertHistory>;
    addOperatorComment(data: {
        alertId: string;
        userId: string;
        userName: string;
        comment: string;
        isPrivate?: boolean;
    }): Promise<AlertComment>;
    getHistory(alertId: string): Promise<AlertHistory[]>;
}
