import { IAlertRuleRepository } from "../../../common/repositories/alert-rule.repository.interface";
import { AlertRule } from "@prisma/client";
import { RuleComplexityBreakdownDto, RuleNoiseScoreDto, RuleUsageStatisticsDto, RulePerformanceMetricsDto, RuleRecommendationDto } from "@nos/shared-types";
export declare class RuleMetricsService {
    private readonly ruleRepo;
    private readonly logger;
    private readonly execTimeSamples;
    constructor(ruleRepo: IAlertRuleRepository);
    recordExecution(ruleId: string, execMs: number): void;
    getPerformanceMetrics(ruleId: string): Promise<RulePerformanceMetricsDto>;
    computeComplexityScore(rule: AlertRule): RuleComplexityBreakdownDto;
    computeNoiseScore(rule: AlertRule): RuleNoiseScoreDto;
    getUsageStatistics(ruleId: string): Promise<RuleUsageStatisticsDto>;
    getRecommendations(): Promise<RuleRecommendationDto[]>;
}
