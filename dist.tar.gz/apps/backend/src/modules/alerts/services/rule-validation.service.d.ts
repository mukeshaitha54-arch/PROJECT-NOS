import { IAlertRuleRepository } from "../../../common/repositories/alert-rule.repository.interface";
import { RuleValidationResultDto } from "@nos/shared-types";
export declare class RuleValidationService {
    private readonly ruleRepo;
    private readonly logger;
    constructor(ruleRepo: IAlertRuleRepository);
    validate(ruleData: {
        name: string;
        metric: string;
        operator: string;
        threshold: number;
        durationSeconds?: number;
        severity?: string;
        cooldownSeconds?: number;
        dependsOnIds?: string[];
        enabled?: boolean;
    }, excludeRuleId?: string): Promise<RuleValidationResultDto>;
}
