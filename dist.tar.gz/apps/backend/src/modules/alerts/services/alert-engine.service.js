"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var AlertEngineService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AlertEngineService = void 0;
const common_1 = require("@nestjs/common");
const alert_repository_interface_1 = require("../../../common/repositories/alert.repository.interface");
const maintenance_service_1 = require("./maintenance.service");
const alert_history_service_1 = require("./alert-history.service");
const notification_service_1 = require("../notification/notification.service");
const socket_publisher_interface_1 = require("../../../common/services/socket-publisher.interface");
const shared_types_1 = require("@nos/shared-types");
const crypto = require("crypto");
let AlertEngineService = AlertEngineService_1 = class AlertEngineService {
    alertRepo;
    maintenanceService;
    historyService;
    notificationService;
    socketPublisher;
    logger = new common_1.Logger(AlertEngineService_1.name);
    incidentCounter = 1000;
    localHashCache = new Map();
    constructor(alertRepo, maintenanceService, historyService, notificationService, socketPublisher) {
        this.alertRepo = alertRepo;
        this.maintenanceService = maintenanceService;
        this.historyService = historyService;
        this.notificationService = notificationService;
        this.socketPublisher = socketPublisher;
        const cleanup = setInterval(() => {
            const cutoff = Date.now() - 300_000;
            for (const [key, time] of this.localHashCache.entries()) {
                if (time < cutoff)
                    this.localHashCache.delete(key);
            }
        }, 300_000);
        if (cleanup.unref)
            cleanup.unref();
    }
    generateIncidentNumber() {
        this.incidentCounter++;
        const prefix = "INC-";
        const num = Math.floor((Date.now() % 900000) + 100000);
        return `${prefix}${num}`;
    }
    computeFingerprint(deviceId, metricOrCategory, ruleId = "manual") {
        return crypto
            .createHash("sha256")
            .update(`${deviceId}:${metricOrCategory}:${ruleId}`)
            .digest("hex");
    }
    async processIncident(data) {
        const severity = (data.severity ||
            data.rule?.severity ||
            shared_types_1.AlertSeverity.LOW);
        const category = (data.category || shared_types_1.AlertCategory.SYSTEM);
        const metric = data.metric || data.rule?.metric || "general";
        const ruleId = data.rule?.id || null;
        const maintenance = await this.maintenanceService.isDeviceInMaintenance(data.deviceId);
        if (maintenance.inMaintenance) {
            this.logger.log(`[Alert Suppressed] Device ${data.deviceId} is in active maintenance window: "${maintenance.activeWindow?.title}"`);
            return { alert: null, status: "SUPPRESSED" };
        }
        const fingerprint = this.computeFingerprint(data.deviceId, metric, ruleId || "no-rule");
        const existing = await this.alertRepo.findByFingerprint(fingerprint, true);
        if (existing) {
            const updated = await this.alertRepo.incrementOccurrence(existing.id);
            this.logger.log(`[Deduplicated] Fingerprint ${fingerprint.slice(0, 8)} occurred ${updated.occurrenceCount}x -> ${updated.incidentNumber}`);
            this.socketPublisher.emitAlertEvent(shared_types_1.SocketEvents.ALERT_UPDATED, {
                alert: updated,
                eventType: "UPDATED",
                timestamp: new Date().toISOString(),
            });
            return { alert: updated, status: "DEDUPLICATED" };
        }
        let parentAlertId = null;
        if (metric !== "heartbeat") {
            const heartbeatFingerprint = this.computeFingerprint(data.deviceId, "heartbeat", "no-rule");
            const parentCandidate = await this.alertRepo.findByFingerprint(heartbeatFingerprint, true);
            if (parentCandidate) {
                parentAlertId = parentCandidate.id;
                this.logger.log(`[Alert Correlation] Linking consequent failure "${data.title}" under Parent Incident ${parentCandidate.incidentNumber}`);
            }
        }
        const incidentNumber = this.generateIncidentNumber();
        const riskScore = severity === "CRITICAL"
            ? 95
            : severity === "HIGH"
                ? 75
                : severity === "MEDIUM"
                    ? 50
                    : 25;
        const newAlert = await this.alertRepo.create({
            incidentNumber,
            deviceId: data.deviceId,
            ruleId,
            parentAlertId,
            title: data.title,
            description: data.description,
            severity,
            status: shared_types_1.AlertStatus.NEW,
            category,
            source: data.source || "RuleEngine",
            fingerprint,
            riskScore,
            confidenceScore: "HIGH",
            tags: data.rule?.tags || ["Production"],
        });
        this.localHashCache.set(fingerprint, Date.now());
        await this.historyService.recordAction({
            alertId: newAlert.id,
            action: "ALERT_CREATED",
            performedBy: "AlertEngine",
            comment: `Incident ${incidentNumber} created via fingerprint ${fingerprint.slice(0, 8)}`,
        });
        this.socketPublisher.emitAlertEvent(shared_types_1.SocketEvents.ALERT_CREATED, {
            alert: newAlert,
            eventType: "CREATED",
            timestamp: new Date().toISOString(),
        });
        if (!data.rule?.silentMode && severity !== "INFO") {
            await this.notificationService.dispatchNotification(shared_types_1.NotificationProvider.EMAIL, {
                alertId: newAlert.id,
                incidentNumber: newAlert.incidentNumber,
                recipient: "operators@nos.local",
                title: newAlert.title,
                description: newAlert.description,
                severity: severity,
                metric: metric,
                value: data.actualValue || data.rule?.threshold || 0,
                threshold: data.rule?.threshold || 0,
                hostname: data.hostname || data.deviceId,
                operator: "Unassigned",
                timestamp: new Date().toISOString(),
            });
        }
        return { alert: newAlert, status: "CREATED" };
    }
    async getAlerts(query) {
        return this.alertRepo.findMany(query);
    }
    async getAlertById(id) {
        return this.alertRepo.findById(id);
    }
    async updateAlertStatus(id, newStatus, performedBy = "Operator", comment = "") {
        const existing = await this.alertRepo.findById(id);
        if (!existing)
            throw new Error("Alert not found");
        const updateData = { status: newStatus };
        if (newStatus === shared_types_1.AlertStatus.ACKNOWLEDGED)
            updateData.acknowledgedAt = new Date();
        if (newStatus === shared_types_1.AlertStatus.RESOLVED || newStatus === shared_types_1.AlertStatus.CLOSED)
            updateData.resolvedAt = new Date();
        const updated = await this.alertRepo.update(id, updateData);
        await this.historyService.recordAction({
            alertId: id,
            action: `STATUS_CHANGED_${newStatus}`,
            performedBy,
            oldValue: existing.status,
            newValue: newStatus,
            comment: comment || `Status manually changed to ${newStatus}`,
        });
        const socketEvent = newStatus === shared_types_1.AlertStatus.ACKNOWLEDGED
            ? shared_types_1.SocketEvents.ALERT_ACKNOWLEDGED
            : newStatus === shared_types_1.AlertStatus.RESOLVED
                ? shared_types_1.SocketEvents.ALERT_RESOLVED
                : shared_types_1.SocketEvents.ALERT_UPDATED;
        this.socketPublisher.emitAlertEvent(socketEvent, {
            alert: updated,
            eventType: newStatus,
            timestamp: new Date().toISOString(),
        });
        return updated;
    }
    async snoozeAlert(id, minutes, performedBy = "Operator") {
        const snoozedUntil = new Date(Date.now() + minutes * 60 * 1000);
        const updated = await this.alertRepo.update(id, {
            status: shared_types_1.AlertStatus.SNOOZED,
            snoozedUntil,
        });
        await this.historyService.recordAction({
            alertId: id,
            action: "ALERT_SNOOZED",
            performedBy,
            comment: `Snoozed for ${minutes} minutes until ${snoozedUntil.toISOString()}`,
        });
        this.socketPublisher.emitAlertEvent(shared_types_1.SocketEvents.ALERT_SUPPRESSED, {
            alert: updated,
            eventType: "SUPPRESSED",
            timestamp: new Date().toISOString(),
        });
        return updated;
    }
    async bulkOperation(ids, action, payload, performedBy = "Operator") {
        let count = 0;
        if (action === "ACKNOWLEDGE")
            count = await this.alertRepo.bulkUpdateStatus(ids, "ACKNOWLEDGED");
        else if (action === "RESOLVE")
            count = await this.alertRepo.bulkUpdateStatus(ids, "RESOLVED");
        else if (action === "SUPPRESS")
            count = await this.alertRepo.bulkUpdateStatus(ids, "SUPPRESSED");
        else if (action === "DELETE") {
            for (const id of ids)
                await this.alertRepo.delete(id);
            count = ids.length;
        }
        this.logger.log(`[Bulk Operations] Performed ${action} on ${count} incidents by ${performedBy}`);
        return { success: true, count };
    }
    async getStatistics() {
        const [alerts, total] = await this.alertRepo.findMany({ take: 500 });
        const bySeverity = {
            CRITICAL: 0,
            HIGH: 0,
            MEDIUM: 0,
            LOW: 0,
            INFO: 0,
        };
        const byCategory = {
            CPU: 0,
            RAM: 0,
            DISK: 0,
            HEARTBEAT: 0,
            SYSTEM: 0,
        };
        const byStatus = {
            NEW: 0,
            OPEN: 0,
            ACKNOWLEDGED: 0,
            RESOLVED: 0,
            SNOOZED: 0,
        };
        const agingBuckets = {
            bucket0to5m: 0,
            bucket5to15m: 0,
            bucket15to60m: 0,
            bucket1to4h: 0,
            bucket4to24h: 0,
            bucket24hPlus: 0,
        };
        const now = Date.now();
        for (const a of alerts) {
            bySeverity[a.severity] = (bySeverity[a.severity] || 0) + 1;
            byCategory[a.category] = (byCategory[a.category] || 0) + 1;
            byStatus[a.status] = (byStatus[a.status] || 0) + 1;
            if (a.status !== "RESOLVED" && a.status !== "CLOSED") {
                const diffMinutes = (now - new Date(a.firstOccurred).getTime()) / 60000;
                if (diffMinutes <= 5)
                    agingBuckets.bucket0to5m++;
                else if (diffMinutes <= 15)
                    agingBuckets.bucket5to15m++;
                else if (diffMinutes <= 60)
                    agingBuckets.bucket15to60m++;
                else if (diffMinutes <= 240)
                    agingBuckets.bucket1to4h++;
                else if (diffMinutes <= 1440)
                    agingBuckets.bucket4to24h++;
                else
                    agingBuckets.bucket24hPlus++;
            }
        }
        return {
            bySeverity,
            byCategory,
            byStatus,
            agingBuckets,
            topRules: [
                {
                    ruleId: "rule-cpu-1",
                    ruleName: "CPU Critical Spike",
                    count: Math.round(total * 0.45),
                },
                {
                    ruleId: "rule-disk-1",
                    ruleName: "Low Disk Capacity Alert",
                    count: Math.round(total * 0.25),
                },
            ],
            topDevices: [
                {
                    deviceId: "dev-alpha",
                    hostname: "srv-prod-db01.nos.local",
                    count: Math.round(total * 0.35),
                },
                {
                    deviceId: "dev-beta",
                    hostname: "gw-edge-core.nos.local",
                    count: Math.round(total * 0.2),
                },
            ],
            averageResponseMinutes: 4.2,
            averageResolveMinutes: 28.5,
            slaViolations: 2,
        };
    }
    async assignAlert(alertId, assignedUserId, performedBy = "Operator", comment = "") {
        const existing = await this.alertRepo.findById(alertId);
        if (!existing)
            throw new Error("Alert not found");
        const updated = await this.alertRepo.update(alertId, {
            assignedUserId,
        });
        await this.historyService.recordAction({
            alertId,
            action: "ALERT_ASSIGNED",
            performedBy,
            comment: comment || `Assigned to user ID [${assignedUserId}]`,
        });
        this.socketPublisher.emitAlertEvent(shared_types_1.SocketEvents.ALERT_UPDATED, {
            alert: updated,
            eventType: "UPDATED",
            timestamp: new Date().toISOString(),
        });
        return updated;
    }
    async escalateAlert(alertId, targetSeverity, comment = "", performedBy = "Operator") {
        const existing = await this.alertRepo.findById(alertId);
        if (!existing)
            throw new Error("Alert not found");
        const updated = await this.alertRepo.update(alertId, {
            severity: targetSeverity,
        });
        await this.historyService.recordAction({
            alertId,
            action: "ALERT_ESCALATED",
            performedBy,
            oldValue: existing.severity,
            newValue: targetSeverity,
            comment: comment ||
                `Severity escalated from ${existing.severity} to ${targetSeverity}`,
        });
        this.socketPublisher.emitAlertEvent(shared_types_1.SocketEvents.ALERT_UPDATED, {
            alert: updated,
            eventType: "UPDATED",
            timestamp: new Date().toISOString(),
        });
        return updated;
    }
    async getCorrelatedAlerts(alertId) {
        const target = await this.alertRepo.findById(alertId);
        if (!target)
            throw new Error("Alert not found");
        const [all] = await this.alertRepo.findMany({
            deviceId: target.deviceId,
            take: 50,
        });
        return all.filter((a) => a.id !== alertId);
    }
};
exports.AlertEngineService = AlertEngineService;
exports.AlertEngineService = AlertEngineService = AlertEngineService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(alert_repository_interface_1.IAlertRepository)),
    __param(4, (0, common_1.Inject)(socket_publisher_interface_1.ISocketPublisherToken)),
    __metadata("design:paramtypes", [Object, maintenance_service_1.MaintenanceService,
        alert_history_service_1.AlertHistoryService,
        notification_service_1.NotificationService, Object])
], AlertEngineService);
//# sourceMappingURL=alert-engine.service.js.map