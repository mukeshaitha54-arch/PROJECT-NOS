"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AlertsController = void 0;
const openapi = require("@nestjs/swagger");
const common_1 = require("@nestjs/common");
const alert_engine_service_1 = require("./services/alert-engine.service");
const rule_engine_service_1 = require("./services/rule-engine.service");
const alert_history_service_1 = require("./services/alert-history.service");
const alert_health_service_1 = require("./services/alert-health.service");
const notification_service_1 = require("./notification/notification.service");
const rule_validation_service_1 = require("./services/rule-validation.service");
const rule_simulation_service_1 = require("./services/rule-simulation.service");
const rule_metrics_service_1 = require("./services/rule-metrics.service");
const rule_health_service_1 = require("./services/rule-health.service");
const rule_audit_service_1 = require("./services/rule-audit.service");
const queue_service_1 = require("./queues/queue.service");
const jwt_auth_guard_1 = require("../../common/guards/jwt-auth.guard");
const roles_guard_1 = require("../../common/guards/roles.guard");
const roles_decorator_1 = require("../../common/decorators/roles.decorator");
const alert_rule_engine_service_1 = require("./alert-rule-engine.service");
const shared_types_1 = require("@nos/shared-types");
let AlertsController = class AlertsController {
    alertEngine;
    ruleEngine;
    historyService;
    healthService;
    notificationService;
    validationService;
    simulationService;
    metricsService;
    ruleHealthService;
    auditService;
    queueService;
    alertRuleEngine;
    constructor(alertEngine, ruleEngine, historyService, healthService, notificationService, validationService, simulationService, metricsService, ruleHealthService, auditService, queueService, alertRuleEngine) {
        this.alertEngine = alertEngine;
        this.ruleEngine = ruleEngine;
        this.historyService = historyService;
        this.healthService = healthService;
        this.notificationService = notificationService;
        this.validationService = validationService;
        this.simulationService = simulationService;
        this.metricsService = metricsService;
        this.ruleHealthService = ruleHealthService;
        this.auditService = auditService;
        this.queueService = queueService;
        this.alertRuleEngine = alertRuleEngine;
    }
    async getActiveAlerts(req) {
        const tenantId = req.user?.organizationId || req.user?.tenantId || "default-org";
        const [all] = await this.alertEngine.getAlerts({ take: 500 });
        const active = all.filter((a) => ["NEW", "OPEN", "ACKNOWLEDGED"].includes(a.status));
        return {
            success: true,
            data: active,
            meta: { total: active.length, page: 1, limit: 500 },
        };
    }
    async getOverview() {
        const alerts = await this.alertEngine.getAlerts({ take: 1000 });
        const list = alerts[0];
        const openAlerts = list.filter((a) => a.status === "NEW" || a.status === "OPEN").length;
        const criticalAlerts = list.filter((a) => a.severity === "CRITICAL" &&
            (a.status === "NEW" || a.status === "OPEN")).length;
        const warningAlerts = list.filter((a) => a.severity === "HIGH" || a.severity === "MEDIUM").length;
        const acknowledgedAlerts = list.filter((a) => a.status === "ACKNOWLEDGED").length;
        const resolvedToday = list.filter((a) => a.status === "RESOLVED").length;
        const totalOccurrences = list.reduce((sum, a) => sum + (a.occurrenceCount || 1), 0);
        return {
            totalAlerts: alerts[1],
            openAlerts,
            criticalAlerts,
            warningAlerts,
            acknowledgedAlerts,
            resolvedToday,
            repeatedIncidentCount: Math.max(0, totalOccurrences - alerts[1]),
        };
    }
    async getStatistics() {
        return this.alertEngine.getStatistics();
    }
    async acknowledgeAlert(id, comment, req) {
        const performedBy = req?.user?.email || "Operator";
        return this.alertEngine.updateAlertStatus(id, shared_types_1.AlertStatus.ACKNOWLEDGED, performedBy, comment);
    }
    async resolveAlert(id, comment, req) {
        const performedBy = req?.user?.email || "Operator";
        return this.alertEngine.updateAlertStatus(id, shared_types_1.AlertStatus.RESOLVED, performedBy, comment);
    }
    async closeAlert(id, comment, req) {
        const performedBy = req?.user?.email || "Operator";
        return this.alertEngine.updateAlertStatus(id, shared_types_1.AlertStatus.CLOSED, performedBy, comment);
    }
    async suppressAlert(id, comment, req) {
        const performedBy = req?.user?.email || "Operator";
        return this.alertEngine.updateAlertStatus(id, shared_types_1.AlertStatus.SUPPRESSED, performedBy, comment);
    }
    async assignAlert(id, assignedUserId, comment, req) {
        const performedBy = req?.user?.email || "Operator";
        return this.alertEngine.assignAlert(id, assignedUserId, performedBy, comment);
    }
    async escalateAlert(id, severity, comment, req) {
        const performedBy = req?.user?.email || "Operator";
        return this.alertEngine.escalateAlert(id, severity, comment, performedBy);
    }
    async getCorrelatedAlerts(id) {
        return this.alertEngine.getCorrelatedAlerts(id);
    }
    async getAlertHistory(id) {
        return this.historyService.getHistory(id);
    }
    async getHealth() {
        return this.healthService.checkHealth();
    }
    async simulateRuleLegacy(metric = "cpuUsage", operator = ">", threshold, timeframeHours) {
        return this.simulationService.dryRun({ metric, operator, threshold });
    }
    async simulateRulePost(body) {
        return this.simulationService.dryRun({
            metric: body?.metric ?? "cpuUsage",
            operator: body?.operator ?? ">",
            threshold: Number(body?.threshold ?? 90),
        });
    }
    async getRulesHealth() {
        return this.ruleHealthService.checkRuleHealth();
    }
    async searchRules(name, metric, severity, category, tags, enabled, owner, version, ruleStatus, priority, skip, take) {
        const [rules, total] = await this.ruleEngine.searchRules({
            name,
            metric,
            severity,
            category: category,
            tags: tags ? tags.split(",") : undefined,
            enabled: enabled !== undefined ? enabled === "true" : undefined,
            owner,
            version: version ? parseInt(version) : undefined,
            ruleStatus: ruleStatus,
            priority: priority,
            skip,
            take,
        });
        return { data: rules, pagination: { total, skip, take } };
    }
    async getCategories() {
        return this.ruleEngine.getCategories();
    }
    async getTags() {
        return this.ruleEngine.getTags();
    }
    async getRecommendations() {
        return this.metricsService.getRecommendations();
    }
    async getDependencyGraph() {
        return this.ruleEngine.getDependencyGraph();
    }
    async exportRules(req) {
        const performedBy = req.user?.email || "Unknown";
        return this.ruleEngine.exportRules(performedBy);
    }
    async importRules(body, req) {
        const performedBy = req.user?.email || "Unknown";
        return this.ruleEngine.importRules(body, performedBy);
    }
    async validateRule(body, excludeId) {
        return this.validationService.validate(body, excludeId);
    }
    async previewRule(body) {
        return this.simulationService.previewRule(body);
    }
    async dryRun(body, req) {
        const performedBy = req.user?.email || "System";
        const ipAddress = req.ip || req.headers?.["x-forwarded-for"];
        const browser = req.headers?.["user-agent"];
        return this.simulationService.dryRun(body, performedBy, undefined, ipAddress, browser);
    }
    async getRules() {
        return this.ruleEngine.getRules();
    }
    async createRule(body, req) {
        const performedBy = req.user?.email || "System Admin";
        const ipAddress = req.ip || req.headers?.["x-forwarded-for"];
        const browser = req.headers?.["user-agent"];
        return this.ruleEngine.createRule(body, performedBy, undefined, ipAddress, browser);
    }
    async testRule(id, body, req) {
        const performedBy = req.user?.email || "System";
        const ipAddress = req.ip || req.headers?.["x-forwarded-for"];
        const browser = req.headers?.["user-agent"];
        if (body.simulatedValue !== undefined && body.deviceId) {
            return this.alertRuleEngine.testRule
                ? this.alertRuleEngine.testRule(id, body.deviceId, Number(body.simulatedValue))
                : {
                    wouldTrigger: false,
                    reason: "Test logic not implemented in service",
                    durationRequired: 1,
                    currentDuration: 0,
                };
        }
        return this.simulationService.testRule({
            ruleId: id,
            timeframe: body.timeframe || "LAST_24H",
            from: body.from,
            to: body.to,
        }, performedBy, undefined, ipAddress, browser);
    }
    async getRuleDiff(id, fromVersion, toVersion) {
        return this.ruleEngine.getRuleDiff(id, fromVersion ? parseInt(fromVersion) : undefined, toVersion ? parseInt(toVersion) : undefined);
    }
    async getRollbackPreview(id, version, req) {
        const performedBy = req.user?.email || "System";
        return this.ruleEngine.getRollbackPreview(id, version, performedBy);
    }
    async replayHistoricalTelemetry(id, body, req) {
        const performedBy = req.user?.email || "System";
        const ipAddress = req.ip || req.headers?.["x-forwarded-for"];
        const browser = req.headers?.["user-agent"];
        return this.simulationService.replayHistoricalTelemetry({ ruleId: id, from: body.from, to: body.to, deviceIds: body.deviceIds }, performedBy, undefined, ipAddress, browser);
    }
    async getRuleMetrics(id) {
        return this.metricsService.getPerformanceMetrics(id);
    }
    async getRuleComplexity(id) {
        const rule = await this.ruleEngine.getRuleById(id);
        if (!rule)
            return { error: "Rule not found" };
        return this.metricsService.computeComplexityScore(rule);
    }
    async getRuleNoiseScore(id) {
        const rule = await this.ruleEngine.getRuleById(id);
        if (!rule)
            return { error: "Rule not found" };
        return this.metricsService.computeNoiseScore(rule);
    }
    async getRuleUsageStatistics(id) {
        return this.metricsService.getUsageStatistics(id);
    }
    async getRuleAuditTrail(id, skip, take) {
        return this.auditService.getAuditTrail(id, skip, take);
    }
    async rollbackRule(id, version, body, req) {
        const performedBy = req.user?.email || "System";
        const ipAddress = req.ip || req.headers?.["x-forwarded-for"];
        const browser = req.headers?.["user-agent"];
        return this.ruleEngine.rollbackToVersion(id, version, performedBy, undefined, ipAddress, browser);
    }
    async archiveRule(id, req) {
        const performedBy = req.user?.email || "System";
        return this.ruleEngine.archiveRule(id, performedBy);
    }
    async cloneRule(id, body, req) {
        const performedBy = req.user?.email || "System";
        return this.ruleEngine.cloneRule(id, body.newName, performedBy);
    }
    async updateRule(id, body, req) {
        const performedBy = req.user?.email || "System Admin";
        const ipAddress = req.ip || req.headers?.["x-forwarded-for"];
        const browser = req.headers?.["user-agent"];
        return this.ruleEngine.updateRule(id, body, performedBy, body.reason, undefined, ipAddress, browser);
    }
    async deleteRule(id, req) {
        const performedBy = req.user?.email || "System";
        return { success: await this.ruleEngine.deleteRule(id, performedBy) };
    }
    async getRuleById(id) {
        return this.ruleEngine.getRuleById(id);
    }
    async getDlqLogs(skip, take) {
        const [logs, total] = await this.notificationService.getDlqLogs(skip, take);
        return { logs, total, skip, take };
    }
    async retryDlq(id) {
        return { success: await this.notificationService.retryDlqLog(id) };
    }
    async getQueueDashboard() {
        return this.ruleHealthService.getQueueDashboard();
    }
    async retryQueueJob(queueName, jobId) {
        const retried = await this.queueService.retryFailedJob(queueName, jobId);
        return { retried, queueName, jobId };
    }
    async purgeQueue(queueName) {
        const purged = await this.queueService.purgeQueue(queueName);
        return { purged, queueName };
    }
    async getAlerts(status, severity, category, deviceId, search, tag, skip, take, sortBy, sortOrder) {
        const [alerts, total] = await this.alertEngine.getAlerts({
            status,
            severity,
            category,
            deviceId,
            search,
            tag,
            skip,
            take,
            sortBy,
            sortOrder,
        });
        return { data: alerts, pagination: { total, skip, take } };
    }
    async getAlertById(id) {
        return this.alertEngine.getAlertById(id);
    }
    async getAlertByIdShort(id) {
        return this.alertEngine.getAlertById(id);
    }
    async updateStatus(id, body, req) {
        const performedBy = body.performedBy || req.user?.email || "Operator";
        return this.alertEngine.updateAlertStatus(id, body.status, performedBy, body.comment);
    }
    async snoozeAlert(id, body, req) {
        const performedBy = body.performedBy || req.user?.email || "Operator";
        return this.alertEngine.snoozeAlert(id, body.minutes, performedBy);
    }
    async addComment(id, body, req) {
        return this.historyService.addOperatorComment({
            alertId: id,
            userId: body.userId || req.user?.sub || "admin-01",
            userName: body.userName || req.user?.email || "Operator",
            comment: body.comment,
            isPrivate: body.isPrivate ?? false,
        });
    }
    async bulkOperation(body, req) {
        const performedBy = body.performedBy || req.user?.email || "Operator";
        return this.alertEngine.bulkOperation(body.alertIds, body.action, body.payload, performedBy);
    }
};
exports.AlertsController = AlertsController;
__decorate([
    (0, common_1.Get)("active"),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Request)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "getActiveAlerts", null);
__decorate([
    (0, common_1.Get)("overview"),
    openapi.ApiResponse({ status: 200 }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "getOverview", null);
__decorate([
    (0, common_1.Get)("statistics"),
    openapi.ApiResponse({ status: 200, type: Object }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "getStatistics", null);
__decorate([
    (0, common_1.Patch)("incidents/:id/acknowledge"),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)("id")),
    __param(1, (0, common_1.Body)("comment")),
    __param(2, (0, common_1.Request)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "acknowledgeAlert", null);
__decorate([
    (0, common_1.Patch)("incidents/:id/resolve"),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)("id")),
    __param(1, (0, common_1.Body)("comment")),
    __param(2, (0, common_1.Request)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "resolveAlert", null);
__decorate([
    (0, common_1.Patch)(":id/close"),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)("id")),
    __param(1, (0, common_1.Body)("comment")),
    __param(2, (0, common_1.Request)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "closeAlert", null);
__decorate([
    (0, common_1.Delete)(":id/suppress"),
    (0, roles_decorator_1.Roles)(shared_types_1.UserRole.ADMIN),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)("id")),
    __param(1, (0, common_1.Body)("comment")),
    __param(2, (0, common_1.Request)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "suppressAlert", null);
__decorate([
    (0, common_1.Patch)("incidents/:id/assign"),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)("id")),
    __param(1, (0, common_1.Body)("assignedUserId")),
    __param(2, (0, common_1.Body)("comment")),
    __param(3, (0, common_1.Request)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, Object]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "assignAlert", null);
__decorate([
    (0, common_1.Patch)("incidents/:id/escalate"),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)("id")),
    __param(1, (0, common_1.Body)("severity")),
    __param(2, (0, common_1.Body)("comment")),
    __param(3, (0, common_1.Request)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, Object]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "escalateAlert", null);
__decorate([
    (0, common_1.Get)("incidents/:id/correlated"),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)("id")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "getCorrelatedAlerts", null);
__decorate([
    (0, common_1.Get)("incidents/:id/history"),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)("id")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "getAlertHistory", null);
__decorate([
    (0, common_1.Get)("health"),
    openapi.ApiResponse({ status: 200, type: Object }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "getHealth", null);
__decorate([
    (0, common_1.Get)("simulate"),
    openapi.ApiResponse({ status: 200, type: Object }),
    __param(0, (0, common_1.Query)("metric")),
    __param(1, (0, common_1.Query)("operator")),
    __param(2, (0, common_1.Query)("threshold", new common_1.DefaultValuePipe(90), common_1.ParseIntPipe)),
    __param(3, (0, common_1.Query)("timeframeHours", new common_1.DefaultValuePipe(24), common_1.ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object, Number, Number]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "simulateRuleLegacy", null);
__decorate([
    (0, common_1.Post)("simulate"),
    openapi.ApiResponse({ status: 201, type: Object }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "simulateRulePost", null);
__decorate([
    (0, common_1.Get)("rules/health"),
    openapi.ApiResponse({ status: 200, type: Object }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "getRulesHealth", null);
__decorate([
    (0, common_1.Get)("rules/search"),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Query)("name")),
    __param(1, (0, common_1.Query)("metric")),
    __param(2, (0, common_1.Query)("severity")),
    __param(3, (0, common_1.Query)("category")),
    __param(4, (0, common_1.Query)("tags")),
    __param(5, (0, common_1.Query)("enabled")),
    __param(6, (0, common_1.Query)("owner")),
    __param(7, (0, common_1.Query)("version", new common_1.DefaultValuePipe(undefined))),
    __param(8, (0, common_1.Query)("ruleStatus")),
    __param(9, (0, common_1.Query)("priority")),
    __param(10, (0, common_1.Query)("skip", new common_1.DefaultValuePipe(0), common_1.ParseIntPipe)),
    __param(11, (0, common_1.Query)("take", new common_1.DefaultValuePipe(50), common_1.ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String, String, String, String, String, String, String, Number, Number]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "searchRules", null);
__decorate([
    (0, common_1.Get)("rules/categories"),
    openapi.ApiResponse({ status: 200, type: [String] }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "getCategories", null);
__decorate([
    (0, common_1.Get)("rules/tags"),
    openapi.ApiResponse({ status: 200, type: [String] }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "getTags", null);
__decorate([
    (0, common_1.Get)("rules/recommendations"),
    openapi.ApiResponse({ status: 200, type: [Object] }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "getRecommendations", null);
__decorate([
    (0, common_1.Get)("rules/dependencies"),
    openapi.ApiResponse({ status: 200, type: Object }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "getDependencyGraph", null);
__decorate([
    (0, common_1.Get)("rules/export"),
    openapi.ApiResponse({ status: 200, type: Object }),
    __param(0, (0, common_1.Request)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "exportRules", null);
__decorate([
    (0, common_1.Post)("rules/import"),
    (0, roles_decorator_1.Roles)(shared_types_1.UserRole.ADMIN, shared_types_1.UserRole.SUPER_ADMIN),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK, type: Object }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Request)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "importRules", null);
__decorate([
    (0, common_1.Post)("rules/validate"),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK, type: Object }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Query)("excludeId")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "validateRule", null);
__decorate([
    (0, common_1.Post)("rules/preview"),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK, type: Object }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "previewRule", null);
__decorate([
    (0, common_1.Post)("rules/dry-run"),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK, type: Object }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Request)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "dryRun", null);
__decorate([
    (0, common_1.Get)("rules"),
    openapi.ApiResponse({ status: 200 }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "getRules", null);
__decorate([
    (0, common_1.Post)("rules"),
    (0, common_1.HttpCode)(common_1.HttpStatus.CREATED),
    openapi.ApiResponse({ status: common_1.HttpStatus.CREATED }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Request)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "createRule", null);
__decorate([
    (0, common_1.Post)("rules/:id/test"),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK, type: Object }),
    __param(0, (0, common_1.Param)("id")),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, common_1.Request)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "testRule", null);
__decorate([
    (0, common_1.Get)("rules/:id/diff"),
    openapi.ApiResponse({ status: 200, type: Object }),
    __param(0, (0, common_1.Param)("id")),
    __param(1, (0, common_1.Query)("fromVersion", new common_1.DefaultValuePipe(undefined))),
    __param(2, (0, common_1.Query)("toVersion", new common_1.DefaultValuePipe(undefined))),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "getRuleDiff", null);
__decorate([
    (0, common_1.Get)("rules/:id/rollback-preview/:version"),
    openapi.ApiResponse({ status: 200, type: Object }),
    __param(0, (0, common_1.Param)("id")),
    __param(1, (0, common_1.Param)("version", common_1.ParseIntPipe)),
    __param(2, (0, common_1.Request)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Number, Object]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "getRollbackPreview", null);
__decorate([
    (0, common_1.Post)("rules/:id/replay"),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK, type: Object }),
    __param(0, (0, common_1.Param)("id")),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, common_1.Request)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "replayHistoricalTelemetry", null);
__decorate([
    (0, common_1.Get)("rules/:id/metrics"),
    openapi.ApiResponse({ status: 200, type: Object }),
    __param(0, (0, common_1.Param)("id")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "getRuleMetrics", null);
__decorate([
    (0, common_1.Get)("rules/:id/complexity"),
    openapi.ApiResponse({ status: 200, type: Object }),
    __param(0, (0, common_1.Param)("id")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "getRuleComplexity", null);
__decorate([
    (0, common_1.Get)("rules/:id/noise"),
    openapi.ApiResponse({ status: 200, type: Object }),
    __param(0, (0, common_1.Param)("id")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "getRuleNoiseScore", null);
__decorate([
    (0, common_1.Get)("rules/:id/usage"),
    openapi.ApiResponse({ status: 200, type: Object }),
    __param(0, (0, common_1.Param)("id")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "getRuleUsageStatistics", null);
__decorate([
    (0, common_1.Get)("rules/:id/audit"),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)("id")),
    __param(1, (0, common_1.Query)("skip", new common_1.DefaultValuePipe(0), common_1.ParseIntPipe)),
    __param(2, (0, common_1.Query)("take", new common_1.DefaultValuePipe(50), common_1.ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Number, Number]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "getRuleAuditTrail", null);
__decorate([
    (0, common_1.Post)("rules/:id/rollback/:version"),
    (0, roles_decorator_1.Roles)(shared_types_1.UserRole.ADMIN, shared_types_1.UserRole.SUPER_ADMIN),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK }),
    __param(0, (0, common_1.Param)("id")),
    __param(1, (0, common_1.Param)("version", common_1.ParseIntPipe)),
    __param(2, (0, common_1.Body)()),
    __param(3, (0, common_1.Request)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Number, Object, Object]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "rollbackRule", null);
__decorate([
    (0, common_1.Post)("rules/:id/archive"),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK }),
    __param(0, (0, common_1.Param)("id")),
    __param(1, (0, common_1.Request)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "archiveRule", null);
__decorate([
    (0, common_1.Post)("rules/:id/clone"),
    (0, common_1.HttpCode)(common_1.HttpStatus.CREATED),
    openapi.ApiResponse({ status: common_1.HttpStatus.CREATED }),
    __param(0, (0, common_1.Param)("id")),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, common_1.Request)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "cloneRule", null);
__decorate([
    (0, common_1.Put)("rules/:id"),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)("id")),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, common_1.Request)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "updateRule", null);
__decorate([
    (0, common_1.Delete)("rules/:id"),
    (0, roles_decorator_1.Roles)(shared_types_1.UserRole.ADMIN, shared_types_1.UserRole.SUPER_ADMIN),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)("id")),
    __param(1, (0, common_1.Request)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "deleteRule", null);
__decorate([
    (0, common_1.Get)("rules/:id"),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)("id")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "getRuleById", null);
__decorate([
    (0, common_1.Get)("notifications/dlq"),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Query)("skip", new common_1.DefaultValuePipe(0), common_1.ParseIntPipe)),
    __param(1, (0, common_1.Query)("take", new common_1.DefaultValuePipe(20), common_1.ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Number]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "getDlqLogs", null);
__decorate([
    (0, common_1.Post)("notifications/dlq/:id/retry"),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, common_1.Param)("id")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "retryDlq", null);
__decorate([
    (0, common_1.Get)("queue/dashboard"),
    openapi.ApiResponse({ status: 200, type: Object }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "getQueueDashboard", null);
__decorate([
    (0, common_1.Post)("queue/:queueName/retry/:jobId"),
    (0, roles_decorator_1.Roles)(shared_types_1.UserRole.ADMIN, shared_types_1.UserRole.SUPER_ADMIN),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK }),
    __param(0, (0, common_1.Param)("queueName")),
    __param(1, (0, common_1.Param)("jobId")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "retryQueueJob", null);
__decorate([
    (0, common_1.Delete)("queue/:queueName/purge"),
    (0, roles_decorator_1.Roles)(shared_types_1.UserRole.SUPER_ADMIN),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK }),
    __param(0, (0, common_1.Param)("queueName")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "purgeQueue", null);
__decorate([
    (0, common_1.Get)(),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Query)("status")),
    __param(1, (0, common_1.Query)("severity")),
    __param(2, (0, common_1.Query)("category")),
    __param(3, (0, common_1.Query)("deviceId")),
    __param(4, (0, common_1.Query)("search")),
    __param(5, (0, common_1.Query)("tag")),
    __param(6, (0, common_1.Query)("skip", new common_1.DefaultValuePipe(0), common_1.ParseIntPipe)),
    __param(7, (0, common_1.Query)("take", new common_1.DefaultValuePipe(20), common_1.ParseIntPipe)),
    __param(8, (0, common_1.Query)("sortBy")),
    __param(9, (0, common_1.Query)("sortOrder")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String, String, String, Number, Number, String, String]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "getAlerts", null);
__decorate([
    (0, common_1.Get)(":id/details"),
    openapi.ApiResponse({ status: 200, type: Object }),
    __param(0, (0, common_1.Param)("id")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "getAlertById", null);
__decorate([
    (0, common_1.Get)(":id"),
    openapi.ApiResponse({ status: 200, type: Object }),
    __param(0, (0, common_1.Param)("id")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "getAlertByIdShort", null);
__decorate([
    (0, common_1.Patch)(":id/status"),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)("id")),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, common_1.Request)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "updateStatus", null);
__decorate([
    (0, common_1.Patch)(":id/snooze"),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)("id")),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, common_1.Request)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "snoozeAlert", null);
__decorate([
    (0, common_1.Post)(":id/comment"),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, common_1.Param)("id")),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, common_1.Request)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "addComment", null);
__decorate([
    (0, common_1.Post)("bulk"),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Request)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], AlertsController.prototype, "bulkOperation", null);
exports.AlertsController = AlertsController = __decorate([
    (0, common_1.Controller)("alerts"),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    __metadata("design:paramtypes", [alert_engine_service_1.AlertEngineService,
        rule_engine_service_1.RuleEngineService,
        alert_history_service_1.AlertHistoryService,
        alert_health_service_1.AlertHealthService,
        notification_service_1.NotificationService,
        rule_validation_service_1.RuleValidationService,
        rule_simulation_service_1.RuleSimulationService,
        rule_metrics_service_1.RuleMetricsService,
        rule_health_service_1.RuleHealthService,
        rule_audit_service_1.RuleAuditService,
        queue_service_1.AlertQueueService,
        alert_rule_engine_service_1.AlertRuleEngineService])
], AlertsController);
//# sourceMappingURL=alerts.controller.js.map