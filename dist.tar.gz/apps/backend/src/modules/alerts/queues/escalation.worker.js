"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var EscalationWorker_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.EscalationWorker = void 0;
const common_1 = require("@nestjs/common");
const alert_repository_interface_1 = require("../../../common/repositories/alert.repository.interface");
const alert_history_service_1 = require("../services/alert-history.service");
const socket_publisher_interface_1 = require("../../../common/services/socket-publisher.interface");
const shared_types_1 = require("@nos/shared-types");
let EscalationWorker = EscalationWorker_1 = class EscalationWorker {
    alertRepo;
    historyService;
    socketPublisher;
    logger = new common_1.Logger(EscalationWorker_1.name);
    timer;
    constructor(alertRepo, historyService, socketPublisher) {
        this.alertRepo = alertRepo;
        this.historyService = historyService;
        this.socketPublisher = socketPublisher;
    }
    onModuleInit() {
        this.timer = setInterval(() => this.runEscalationCycle(), 60_000);
        if (this.timer.unref)
            this.timer.unref();
        this.logger.log(`[Escalation Worker] Activated 10m/20m/40m SLA automated escalation pipeline.`);
    }
    onModuleDestroy() {
        if (this.timer)
            clearInterval(this.timer);
    }
    async runEscalationCycle() {
        try {
            const candidates = await this.alertRepo.findEscalationCandidates(10);
            const nowMs = Date.now();
            let escalatedCount = 0;
            for (const alert of candidates) {
                const elapsedMinutes = (nowMs - new Date(alert.firstOccurred).getTime()) / 60_000;
                if (elapsedMinutes >= 40 && alert.severity !== "CRITICAL") {
                    const updated = await this.alertRepo.update(alert.id, {
                        severity: shared_types_1.AlertSeverity.CRITICAL,
                    });
                    await this.historyService.recordAction({
                        alertId: alert.id,
                        action: "AUTO_ESCALATION_CRITICAL",
                        performedBy: "EscalationWorker",
                        oldValue: alert.severity,
                        newValue: "CRITICAL",
                        comment: `Unresolved for ${Math.round(elapsedMinutes)} minutes. Automatically promoted to CRITICAL SLA status.`,
                    });
                    this.socketPublisher.emitAlertEvent(shared_types_1.SocketEvents.ALERT_ESCALATED, {
                        alert: updated,
                        eventType: "ESCALATED",
                        timestamp: new Date().toISOString(),
                    });
                    escalatedCount++;
                }
                else if (elapsedMinutes >= 20 &&
                    elapsedMinutes < 40 &&
                    (!alert.assignedUserId || alert.assignedUserId !== "admin-pool")) {
                    await this.alertRepo.update(alert.id, {
                        assignedUserId: "admin-pool",
                    });
                    await this.historyService.recordAction({
                        alertId: alert.id,
                        action: "AUTO_ASSIGN_ADMIN",
                        performedBy: "EscalationWorker",
                        comment: `Unacknowledged after 20 minutes. Escalated assignment to Senior System Admins.`,
                    });
                    escalatedCount++;
                }
                else if (elapsedMinutes >= 10 &&
                    elapsedMinutes < 20 &&
                    !alert.assignedUserId) {
                    await this.alertRepo.update(alert.id, {
                        assignedUserId: "operator-pool",
                    });
                    await this.historyService.recordAction({
                        alertId: alert.id,
                        action: "AUTO_ASSIGN_OPERATOR",
                        performedBy: "EscalationWorker",
                        comment: `Open for >10 minutes. Assigned to standby Level 1 Operators pool.`,
                    });
                    escalatedCount++;
                }
            }
            if (escalatedCount > 0) {
                this.logger.log(`[Escalation Worker] Processed ${escalatedCount} automated SLA escalations across active alerts.`);
            }
            return escalatedCount;
        }
        catch (err) {
            this.logger.error(`[Escalation Worker] Cycle failure: ${err?.message}`);
            return 0;
        }
    }
};
exports.EscalationWorker = EscalationWorker;
exports.EscalationWorker = EscalationWorker = EscalationWorker_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(alert_repository_interface_1.IAlertRepository)),
    __param(2, (0, common_1.Inject)(socket_publisher_interface_1.ISocketPublisherToken)),
    __metadata("design:paramtypes", [Object, alert_history_service_1.AlertHistoryService, Object])
], EscalationWorker);
//# sourceMappingURL=escalation.worker.js.map