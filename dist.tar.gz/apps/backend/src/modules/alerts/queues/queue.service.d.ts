import { OnModuleDestroy } from "@nestjs/common";
import { RuleHealthQueueInfo } from "@nos/shared-types";
export declare class AlertQueueService implements OnModuleDestroy {
    private readonly logger;
    private redisClient?;
    private alertQueue?;
    private notificationQueue?;
    private dlqQueue?;
    private retryQueue?;
    private isOfflineFallback;
    constructor();
    private initializeQueues;
    enqueueAlertProcessing(data: any): Promise<void>;
    enqueueNotification(data: any): Promise<void>;
    pushToDlq(data: any): Promise<void>;
    getQueueStats(): Promise<RuleHealthQueueInfo[]>;
    getRedisHealth(): Promise<{
        connected: boolean;
        memoryUsageBytes: number;
        latencyMs: number;
        connectedClients: number;
        uptime: number;
    }>;
    retryFailedJob(queueName: string, jobId: string): Promise<boolean>;
    purgeQueue(queueName: string): Promise<number>;
    private getQueueByName;
    private buildOfflineQueueStats;
    onModuleDestroy(): Promise<void>;
}
