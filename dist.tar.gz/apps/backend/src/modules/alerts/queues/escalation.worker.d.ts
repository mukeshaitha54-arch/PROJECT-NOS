import { OnModuleInit, OnModuleDestroy } from "@nestjs/common";
import { IAlertRepository } from "../../../common/repositories/alert.repository.interface";
import { AlertHistoryService } from "../services/alert-history.service";
import { ISocketPublisher } from "../../../common/services/socket-publisher.interface";
export declare class EscalationWorker implements OnModuleInit, OnModuleDestroy {
    private readonly alertRepo;
    private readonly historyService;
    private readonly socketPublisher;
    private readonly logger;
    private timer?;
    constructor(alertRepo: IAlertRepository, historyService: AlertHistoryService, socketPublisher: ISocketPublisher);
    onModuleInit(): void;
    onModuleDestroy(): void;
    runEscalationCycle(): Promise<number>;
}
