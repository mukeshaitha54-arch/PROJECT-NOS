import { NotificationProvider, AlertSeverity } from "@nos/shared-types";
export interface NotificationPayload {
    alertId: string;
    incidentNumber: string;
    recipient: string;
    title: string;
    description: string;
    severity: AlertSeverity;
    metric: string;
    value: number;
    threshold: number;
    hostname: string;
    operator: string;
    timestamp: string;
    customHeaders?: Record<string, string>;
    webhookUrl?: string;
}
export interface INotificationProvider {
    readonly providerType: NotificationProvider;
    send(payload: NotificationPayload): Promise<{
        success: boolean;
        response: string;
    }>;
}
export declare class EmailNotificationProvider implements INotificationProvider {
    readonly providerType = NotificationProvider.EMAIL;
    send(payload: NotificationPayload): Promise<{
        success: boolean;
        response: string;
    }>;
}
export declare class SlackNotificationProvider implements INotificationProvider {
    readonly providerType = NotificationProvider.SLACK;
    send(payload: NotificationPayload): Promise<{
        success: boolean;
        response: string;
    }>;
}
export declare class WebhookNotificationProvider implements INotificationProvider {
    readonly providerType = NotificationProvider.WEBHOOK;
    send(payload: NotificationPayload): Promise<{
        success: boolean;
        response: string;
    }>;
}
export declare class TeamsNotificationProvider implements INotificationProvider {
    readonly providerType = NotificationProvider.TEAMS;
    send(payload: NotificationPayload): Promise<{
        success: boolean;
        response: string;
    }>;
}
export declare class DiscordNotificationProvider implements INotificationProvider {
    readonly providerType = NotificationProvider.DISCORD;
    send(payload: NotificationPayload): Promise<{
        success: boolean;
        response: string;
    }>;
}
export declare class SmsNotificationProvider implements INotificationProvider {
    readonly providerType = NotificationProvider.SMS;
    send(payload: NotificationPayload): Promise<{
        success: boolean;
        response: string;
    }>;
}
export declare class PushNotificationProvider implements INotificationProvider {
    readonly providerType = NotificationProvider.PUSH;
    send(payload: NotificationPayload): Promise<{
        success: boolean;
        response: string;
    }>;
}
export declare function renderNotificationTemplate(template: string, variables: Record<string, string | number>): string;
