"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PushNotificationProvider = exports.SmsNotificationProvider = exports.DiscordNotificationProvider = exports.TeamsNotificationProvider = exports.WebhookNotificationProvider = exports.SlackNotificationProvider = exports.EmailNotificationProvider = void 0;
exports.renderNotificationTemplate = renderNotificationTemplate;
const shared_types_1 = require("@nos/shared-types");
class EmailNotificationProvider {
    providerType = shared_types_1.NotificationProvider.EMAIL;
    async send(payload) {
        const template = `[${payload.severity}] Incident ${payload.incidentNumber} on ${payload.hostname}: ${payload.metric} reached ${payload.value} (threshold ${payload.threshold}) at ${payload.timestamp}. Assigned Operator: ${payload.operator}`;
        console.log(`[EmailProvider] Delivering to ${payload.recipient}: ${template}`);
        return { success: true, response: "250 OK Message accepted for delivery" };
    }
}
exports.EmailNotificationProvider = EmailNotificationProvider;
class SlackNotificationProvider {
    providerType = shared_types_1.NotificationProvider.SLACK;
    async send(payload) {
        console.log(`[SlackProvider] Webhook payload to #operations: ${payload.incidentNumber} - ${payload.title}`);
        return { success: true, response: "ok" };
    }
}
exports.SlackNotificationProvider = SlackNotificationProvider;
class WebhookNotificationProvider {
    providerType = shared_types_1.NotificationProvider.WEBHOOK;
    async send(payload) {
        console.log(`[WebhookProvider] HTTP POST to ${payload.webhookUrl || payload.recipient} for ${payload.incidentNumber}`);
        return { success: true, response: "HTTP 200 Accepted" };
    }
}
exports.WebhookNotificationProvider = WebhookNotificationProvider;
class TeamsNotificationProvider {
    providerType = shared_types_1.NotificationProvider.TEAMS;
    async send(payload) {
        console.log(`[TeamsProvider] Sending Teams Card for ${payload.incidentNumber}`);
        return { success: true, response: "Teams Message Sent" };
    }
}
exports.TeamsNotificationProvider = TeamsNotificationProvider;
class DiscordNotificationProvider {
    providerType = shared_types_1.NotificationProvider.DISCORD;
    async send(payload) {
        console.log(`[DiscordProvider] Sending Discord Embed for ${payload.incidentNumber}`);
        return { success: true, response: "Discord Embed Sent" };
    }
}
exports.DiscordNotificationProvider = DiscordNotificationProvider;
class SmsNotificationProvider {
    providerType = shared_types_1.NotificationProvider.SMS;
    async send(payload) {
        console.log(`[SmsProvider] Sending SMS alert to ${payload.recipient}: ${payload.incidentNumber}`);
        return { success: true, response: "SMS Sent" };
    }
}
exports.SmsNotificationProvider = SmsNotificationProvider;
class PushNotificationProvider {
    providerType = shared_types_1.NotificationProvider.PUSH;
    async send(payload) {
        console.log(`[PushProvider] Sending Mobile Push Notification for ${payload.incidentNumber}`);
        return { success: true, response: "Push Notification Sent" };
    }
}
exports.PushNotificationProvider = PushNotificationProvider;
function renderNotificationTemplate(template, variables) {
    return template.replace(/\{\{\s*(\w+)\s*\}\}/g, (_, key) => {
        return variables[key] !== undefined ? String(variables[key]) : `{{${key}}}`;
    });
}
//# sourceMappingURL=notification-provider.interface.js.map