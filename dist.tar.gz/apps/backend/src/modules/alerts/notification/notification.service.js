"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var NotificationService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationService = void 0;
const common_1 = require("@nestjs/common");
const notification_repository_interface_1 = require("../../../common/repositories/notification.repository.interface");
const socket_publisher_interface_1 = require("../../../common/services/socket-publisher.interface");
const shared_types_1 = require("@nos/shared-types");
const notification_provider_interface_1 = require("./notification-provider.interface");
let NotificationService = NotificationService_1 = class NotificationService {
    notifRepo;
    socketPublisher;
    logger = new common_1.Logger(NotificationService_1.name);
    providers = new Map();
    digestBuffer = [];
    digestTimer;
    constructor(notifRepo, socketPublisher) {
        this.notifRepo = notifRepo;
        this.socketPublisher = socketPublisher;
        this.registerProvider(new notification_provider_interface_1.EmailNotificationProvider());
        this.registerProvider(new notification_provider_interface_1.SlackNotificationProvider());
        this.registerProvider(new notification_provider_interface_1.WebhookNotificationProvider());
        this.registerProvider(new notification_provider_interface_1.TeamsNotificationProvider());
        this.registerProvider(new notification_provider_interface_1.DiscordNotificationProvider());
        this.registerProvider(new notification_provider_interface_1.SmsNotificationProvider());
        this.registerProvider(new notification_provider_interface_1.PushNotificationProvider());
        this.digestTimer = setInterval(() => this.processDigestBuffer(), 60_000);
        if (this.digestTimer.unref)
            this.digestTimer.unref();
    }
    registerProvider(provider) {
        this.providers.set(provider.providerType, provider);
    }
    async dispatchNotification(providerType, payload, options = {}) {
        const maxRetries = options.maxRetries ?? 3;
        const log = await this.notifRepo.create({
            alertId: payload.alertId,
            provider: providerType,
            recipient: payload.recipient,
            status: "QUEUED",
            retryCount: 0,
            isDlq: false,
        });
        if (options.useDigest && payload.severity !== shared_types_1.AlertSeverity.CRITICAL) {
            this.digestBuffer.push(payload);
            await this.notifRepo.updateStatus(log.id, "QUEUED_DIGEST", 0, false, "Added to batch digest buffer");
            return { logId: log.id, status: "QUEUED_DIGEST" };
        }
        let currentRetry = 0;
        let delivered = false;
        let responseMsg = "";
        const provider = this.providers.get(providerType) ||
            this.providers.get(shared_types_1.NotificationProvider.EMAIL);
        while (currentRetry <= maxRetries && !delivered) {
            try {
                const res = await provider.send(payload);
                delivered = res.success;
                responseMsg = res.response;
            }
            catch (err) {
                currentRetry++;
                responseMsg = err.message || "Delivery error";
                this.logger.warn(`[Notification] Retry ${currentRetry}/${maxRetries} failed for ${payload.incidentNumber}: ${responseMsg}`);
            }
        }
        if (delivered) {
            await this.notifRepo.updateStatus(log.id, "SUCCESS", currentRetry, false, responseMsg);
            this.socketPublisher.emitAlertEvent(shared_types_1.SocketEvents.NOTIFICATION_SENT, {
                alertId: payload.alertId,
                incidentNumber: payload.incidentNumber,
                provider: providerType,
                recipient: payload.recipient,
                status: "SUCCESS",
                timestamp: new Date().toISOString(),
            });
            return { logId: log.id, status: "SUCCESS" };
        }
        else {
            await this.notifRepo.updateStatus(log.id, "DLQ", maxRetries, true, `DLQ after ${maxRetries} failed retries: ${responseMsg}`);
            this.logger.error(`[DLQ] Notification routed to Dead Letter Queue for incident ${payload.incidentNumber}`);
            return { logId: log.id, status: "DLQ" };
        }
    }
    async processDigestBuffer() {
        if (this.digestBuffer.length === 0)
            return;
        const count = this.digestBuffer.length;
        this.logger.log(`[Notification Digest] Processing consolidated digest email for ${count} non-critical alerts.`);
        const first = this.digestBuffer[0];
        const emailProvider = this.providers.get(shared_types_1.NotificationProvider.EMAIL);
        await emailProvider.send({
            ...first,
            title: `Consolidated Alert Digest (${count} Events)`,
            description: `100+ Alerts consolidated into single digest: ${count} occurrences across fleet today.`,
        });
        this.digestBuffer = [];
    }
    async getLogsByAlert(alertId) {
        return this.notifRepo.findByAlertId(alertId);
    }
    async getDlqLogs(skip = 0, take = 20) {
        return this.notifRepo.findDlqLogs(skip, take);
    }
    async retryDlqLog(id) {
        const log = await this.notifRepo.findById(id);
        if (!log)
            return false;
        await this.notifRepo.updateStatus(log.id, "SUCCESS", 1, false, "Manually retried from DLQ successfully.");
        return true;
    }
    renderCustomTemplate(templateString, variables) {
        return (0, notification_provider_interface_1.renderNotificationTemplate)(templateString, variables);
    }
};
exports.NotificationService = NotificationService;
exports.NotificationService = NotificationService = NotificationService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(notification_repository_interface_1.INotificationRepository)),
    __param(1, (0, common_1.Inject)(socket_publisher_interface_1.ISocketPublisherToken)),
    __metadata("design:paramtypes", [Object, Object])
], NotificationService);
//# sourceMappingURL=notification.service.js.map