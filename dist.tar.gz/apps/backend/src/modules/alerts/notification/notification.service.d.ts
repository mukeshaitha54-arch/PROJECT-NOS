import { INotificationRepository } from "../../../common/repositories/notification.repository.interface";
import { ISocketPublisher } from "../../../common/services/socket-publisher.interface";
import { NotificationProvider } from "@nos/shared-types";
import { NotificationPayload } from "./notification-provider.interface";
export declare class NotificationService {
    private readonly notifRepo;
    private readonly socketPublisher;
    private readonly logger;
    private readonly providers;
    private digestBuffer;
    private digestTimer?;
    constructor(notifRepo: INotificationRepository, socketPublisher: ISocketPublisher);
    private registerProvider;
    dispatchNotification(providerType: NotificationProvider, payload: NotificationPayload, options?: {
        maxRetries?: number;
        useDigest?: boolean;
    }): Promise<{
        logId: string;
        status: string;
    }>;
    private processDigestBuffer;
    getLogsByAlert(alertId: string): Promise<{
        id: string;
        status: string;
        alertId: string;
        provider: import("@prisma/client").$Enums.NotificationProvider;
        recipient: string;
        response: string | null;
        retryCount: number;
        isDlq: boolean;
        sentAt: Date;
    }[]>;
    getDlqLogs(skip?: number, take?: number): Promise<[{
        id: string;
        status: string;
        alertId: string;
        provider: import("@prisma/client").$Enums.NotificationProvider;
        recipient: string;
        response: string | null;
        retryCount: number;
        isDlq: boolean;
        sentAt: Date;
    }[], number]>;
    retryDlqLog(id: string): Promise<boolean>;
    renderCustomTemplate(templateString: string, variables: Record<string, string | number>): string;
}
