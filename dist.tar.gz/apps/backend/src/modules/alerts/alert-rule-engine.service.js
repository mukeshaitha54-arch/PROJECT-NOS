"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var AlertRuleEngineService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AlertRuleEngineService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../database/prisma.service");
const realtime_gateway_1 = require("../realtime/realtime.gateway");
const audit_logs_service_1 = require("../audit/audit-logs.service");
const client_1 = require("@prisma/client");
const crypto = require("crypto");
let AlertRuleEngineService = AlertRuleEngineService_1 = class AlertRuleEngineService {
    prisma;
    socketGateway;
    auditService;
    logger = new common_1.Logger(AlertRuleEngineService_1.name);
    constructor(prisma, socketGateway, auditService) {
        this.prisma = prisma;
        this.socketGateway = socketGateway;
        this.auditService = auditService;
    }
    async evaluateTelemetry(deviceId, tenantId, telemetry) {
        try {
            const targetTenantId = tenantId || "default-org";
            const device = await this.prisma.device.findUnique({
                where: { id: deviceId },
            });
            if (!device) {
                this.logger.warn(`Cannot evaluate telemetry for non-existent device ID [${deviceId}].`);
                return;
            }
            const deviceName = device.name ||
                device.deviceName ||
                device.hostname ||
                device.id;
            const isUnderMaintenance = device.status === client_1.DeviceStatus.MAINTENANCE ||
                device.status === "MAINTENANCE";
            const rules = await this.prisma.alertRule.findMany({
                where: {
                    enabled: true,
                    OR: [
                        { tenantId: targetTenantId },
                        { tenantId: "default-org" },
                        { tenantId: null },
                    ],
                },
            });
            const now = new Date();
            const activeAlertStatuses = [
                client_1.AlertStatus.NEW,
                client_1.AlertStatus.OPEN,
                client_1.AlertStatus.ACKNOWLEDGED,
            ];
            for (const rule of rules) {
                if (rule.deviceIds &&
                    rule.deviceIds.length > 0 &&
                    !rule.deviceIds.includes(deviceId)) {
                    continue;
                }
                const value = this.extractMetricValue(rule.metric, telemetry);
                if (value === null || value === undefined || isNaN(value)) {
                    continue;
                }
                const isBreaching = this.compareThreshold(value, rule.operator, rule.threshold);
                const existingBreach = await this.prisma.alertBreachState.findUnique({
                    where: {
                        deviceId_ruleId: {
                            deviceId,
                            ruleId: rule.id,
                        },
                    },
                });
                if (isBreaching) {
                    if (!existingBreach) {
                        await this.prisma.alertBreachState.create({
                            data: {
                                deviceId,
                                ruleId: rule.id,
                                firstBreachAt: now,
                                lastBreachAt: now,
                                consecutiveCount: 1,
                            },
                        });
                        this.logger.debug(`[${deviceName}] Initiated new breach state for rule [${rule.name}] (${value} vs threshold ${rule.threshold})`);
                    }
                    else {
                        await this.prisma.alertBreachState.update({
                            where: { id: existingBreach.id },
                            data: {
                                consecutiveCount: { increment: 1 },
                                lastBreachAt: now,
                            },
                        });
                        const requiredDurationSeconds = rule.duration && rule.duration > 0
                            ? rule.duration * 60
                            : rule.durationSeconds || 60;
                        const elapsedSeconds = (now.getTime() - existingBreach.firstBreachAt.getTime()) / 1000;
                        if (elapsedSeconds >= requiredDurationSeconds) {
                            const existingAlert = await this.prisma.alert.findFirst({
                                where: {
                                    deviceId,
                                    ruleId: rule.id,
                                    status: { in: activeAlertStatuses },
                                },
                            });
                            if (!existingAlert) {
                                await this.createAlert({
                                    rule,
                                    device,
                                    deviceName,
                                    deviceId,
                                    tenantId: targetTenantId,
                                    value,
                                    isUnderMaintenance,
                                    now,
                                });
                            }
                        }
                    }
                }
                else {
                    if (existingBreach) {
                        await this.prisma.$transaction(async (tx) => {
                            await tx.alertBreachState.deleteMany({
                                where: {
                                    deviceId,
                                    ruleId: rule.id,
                                },
                            });
                            const activeAlert = await tx.alert.findFirst({
                                where: {
                                    deviceId,
                                    ruleId: rule.id,
                                    status: { in: activeAlertStatuses },
                                },
                            });
                            if (activeAlert) {
                                const updatedAlert = await tx.alert.update({
                                    where: { id: activeAlert.id },
                                    data: {
                                        status: client_1.AlertStatus.RESOLVED,
                                        resolvedAt: now,
                                    },
                                });
                                if (this.socketGateway?.server) {
                                    this.socketGateway.server
                                        .to(`tenant-${targetTenantId}`)
                                        .emit("alert:resolved", {
                                        alertId: updatedAlert.id,
                                        deviceId,
                                        ruleId: rule.id,
                                        resolvedAt: now.toISOString(),
                                    });
                                }
                            }
                        });
                        this.logger.debug(`[${deviceName}] Resolved breach state for rule [${rule.name}] as value dropped below threshold.`);
                    }
                }
            }
        }
        catch (error) {
            this.logger.error(`Error evaluating telemetry for device [${deviceId}]: ${error instanceof Error ? error.stack : error}`);
        }
    }
    async createAlert(params) {
        const { rule, deviceName, deviceId, tenantId, value, isUnderMaintenance, now, } = params;
        const title = `${deviceName}: ${rule.name}`;
        const durationMin = rule.duration || Math.round((rule.durationSeconds || 60) / 60) || 1;
        const message = `${rule.metric} is ${value}% (threshold: ${rule.threshold}%) for ${durationMin} minutes`;
        const fingerprint = crypto
            .createHash("sha256")
            .update(`${deviceId}:${rule.metric}:${rule.id}`)
            .digest("hex");
        const incidentNumber = `INC-${Date.now().toString(36).toUpperCase()}-${Math.floor(Math.random() * 900 + 100)}`;
        const targetStatus = isUnderMaintenance
            ? client_1.AlertStatus.SUPPRESS
            : client_1.AlertStatus.NEW;
        const alert = await this.prisma.alert.create({
            data: {
                incidentNumber,
                tenantId,
                deviceId,
                ruleId: rule.id,
                title,
                description: message,
                message,
                metric: rule.metric,
                value,
                threshold: rule.threshold,
                severity: rule.severity || client_1.AlertSeverity.MEDIUM,
                status: targetStatus,
                fingerprint,
                source: "RuleEngine",
                createdAt: now,
            },
        });
        this.logger.log(`Triggered Alert [${alert.incidentNumber}] (${alert.status}) on [${deviceName}]: ${message}`);
        if (!isUnderMaintenance) {
            if (this.socketGateway?.server) {
                this.socketGateway.server
                    .to(`tenant-${tenantId}`)
                    .emit("alert:triggered", alert);
            }
        }
        if (this.auditService) {
            await this.auditService.log({
                action: "ALERT_TRIGGERED",
                actor: "SYSTEM",
                target: deviceId,
                tenantId,
                details: {
                    alertId: alert.id,
                    ruleId: rule.id,
                    metric: rule.metric,
                    value,
                    threshold: rule.threshold,
                    suppressedByMaintenance: isUnderMaintenance,
                },
            });
        }
    }
    extractMetricValue(metric, telemetry) {
        const key = metric.toLowerCase().trim();
        if (key === "cpu" || key === "cpuusage") {
            return telemetry.cpu ?? telemetry.cpuUsage ?? null;
        }
        if (key === "ram" || key === "memory" || key === "memoryusagepercent") {
            return (telemetry.ram ??
                telemetry.memoryUsagePercent ??
                telemetry.ramUsage ??
                null);
        }
        if (key === "disk" || key === "diskusagepercent") {
            return telemetry.disk ?? telemetry.diskUsagePercent ?? null;
        }
        if (key === "network" || key === "networkspeed") {
            return (telemetry.network ??
                telemetry.networkUploadSpeed ??
                telemetry.bytesReceived ??
                null);
        }
        if (telemetry[key] !== undefined && telemetry[key] !== null) {
            return Number(telemetry[key]);
        }
        return null;
    }
    compareThreshold(value, operator, threshold) {
        const op = operator.toLowerCase().trim();
        switch (op) {
            case "gt":
            case ">":
                return value > threshold;
            case "lt":
            case "<":
                return value < threshold;
            case "eq":
            case "==":
            case "===":
            case "=":
                return value === threshold;
            case "gte":
            case ">=":
                return value >= threshold;
            case "lte":
            case "<=":
                return value <= threshold;
            case "neq":
            case "!=":
            case "!==":
                return value !== threshold;
            default:
                return value > threshold;
        }
    }
    async testRule(ruleId, deviceId, simulatedValue) {
        const rule = await this.prisma.alertRule.findUnique({
            where: { id: ruleId },
        });
        if (!rule) {
            return {
                wouldTrigger: false,
                reason: `Rule ${ruleId} not found.`,
                durationRequired: 0,
                currentDuration: 0,
            };
        }
        const wouldTrigger = this.compareThreshold(simulatedValue, rule.operator, rule.threshold);
        const durationRequired = rule.duration || Math.round((rule.durationSeconds || 60) / 60) || 1;
        const reason = wouldTrigger
            ? `Simulated value (${simulatedValue}) breaches threshold (${rule.operator} ${rule.threshold}). Alert would trigger after ${durationRequired} minute(s) of continuous breach.`
            : `Simulated value (${simulatedValue}) does not breach threshold (${rule.operator} ${rule.threshold}).`;
        return {
            success: true,
            wouldTrigger,
            reason,
            durationRequired,
            currentDuration: 0,
        };
    }
};
exports.AlertRuleEngineService = AlertRuleEngineService;
exports.AlertRuleEngineService = AlertRuleEngineService = AlertRuleEngineService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        realtime_gateway_1.RealtimeGateway,
        audit_logs_service_1.AuditLogsService])
], AlertRuleEngineService);
//# sourceMappingURL=alert-rule-engine.service.js.map