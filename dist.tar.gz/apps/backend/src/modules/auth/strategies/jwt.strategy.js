"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.JwtStrategy = void 0;
const common_1 = require("@nestjs/common");
const passport_1 = require("@nestjs/passport");
const passport_jwt_1 = require("passport-jwt");
const config_1 = require("@nestjs/config");
const user_repository_interface_1 = require("../../../common/repositories/user.repository.interface");
const prisma_service_1 = require("../../../database/prisma.service");
let JwtStrategy = class JwtStrategy extends (0, passport_1.PassportStrategy)(passport_jwt_1.Strategy, "jwt") {
    userRepo;
    prisma;
    constructor(configService, userRepo, prisma) {
        super({
            jwtFromRequest: passport_jwt_1.ExtractJwt.fromAuthHeaderAsBearerToken(),
            ignoreExpiration: false,
            secretOrKey: configService.get("JWT_SECRET", "nos_super_secret_jwt_key_32_chars_min_length_value!"),
        });
        this.userRepo = userRepo;
        this.prisma = prisma;
    }
    async validate(payload) {
        const user = await this.userRepo.findById(payload.sub);
        if (!user) {
            throw new common_1.UnauthorizedException("Token credentials invalidated.");
        }
        const { passwordHash, ...userWithoutPass } = user;
        const membership = await this.prisma.organizationMember.findFirst({
            where: { userId: user.id },
            orderBy: { joinedAt: "asc" },
            select: { organizationId: true },
        });
        return {
            ...userWithoutPass,
            organizationId: membership?.organizationId ?? "default-org",
        };
    }
};
exports.JwtStrategy = JwtStrategy;
exports.JwtStrategy = JwtStrategy = __decorate([
    (0, common_1.Injectable)(),
    __param(1, (0, common_1.Inject)(user_repository_interface_1.IUserRepositoryToken)),
    __metadata("design:paramtypes", [config_1.ConfigService, Object, prisma_service_1.PrismaService])
], JwtStrategy);
//# sourceMappingURL=jwt.strategy.js.map