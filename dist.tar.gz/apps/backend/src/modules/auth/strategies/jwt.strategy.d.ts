import { Strategy } from "passport-jwt";
import { ConfigService } from "@nestjs/config";
import { IUserRepository } from "../../../common/repositories/user.repository.interface";
import { User } from "@nos/shared-types";
import { PrismaService } from "../../../database/prisma.service";
export interface JwtPayload {
    sub: string;
    email: string;
    role: string;
}
declare const JwtStrategy_base: new (...args: any[]) => Strategy;
export declare class JwtStrategy extends JwtStrategy_base {
    private readonly userRepo;
    private readonly prisma;
    constructor(configService: ConfigService, userRepo: IUserRepository, prisma: PrismaService);
    validate(payload: JwtPayload): Promise<User & {
        organizationId?: string;
    }>;
}
export {};
