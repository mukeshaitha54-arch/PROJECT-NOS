"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthModule = void 0;
const common_1 = require("@nestjs/common");
const jwt_1 = require("@nestjs/jwt");
const config_1 = require("@nestjs/config");
const passport_1 = require("@nestjs/passport");
const auth_controller_1 = require("./auth.controller");
const auth_service_1 = require("./auth.service");
const jwt_strategy_1 = require("./strategies/jwt.strategy");
const prisma_user_repository_1 = require("../../database/repositories/prisma-user.repository");
const prisma_token_repository_1 = require("../../database/repositories/prisma-token.repository");
const argon2_password_hasher_service_1 = require("../../common/services/argon2-password-hasher.service");
const smtp_mail_service_1 = require("../../common/services/smtp-mail.service");
const user_repository_interface_1 = require("../../common/repositories/user.repository.interface");
const token_repository_interface_1 = require("../../common/repositories/token.repository.interface");
const password_hasher_interface_1 = require("../../common/services/password-hasher.interface");
const mail_service_interface_1 = require("../../common/services/mail-service.interface");
let AuthModule = class AuthModule {
};
exports.AuthModule = AuthModule;
exports.AuthModule = AuthModule = __decorate([
    (0, common_1.Module)({
        imports: [
            passport_1.PassportModule.register({ defaultStrategy: "jwt" }),
            jwt_1.JwtModule.registerAsync({
                imports: [config_1.ConfigModule],
                inject: [config_1.ConfigService],
                useFactory: (config) => ({
                    secret: config.get("JWT_SECRET", "nos_super_secret_jwt_key_32_chars_min_length_value!"),
                    signOptions: { expiresIn: config.get("JWT_EXPIRATION", "15m") },
                }),
            }),
        ],
        controllers: [auth_controller_1.AuthController],
        providers: [
            auth_service_1.AuthService,
            jwt_strategy_1.JwtStrategy,
            { provide: user_repository_interface_1.IUserRepositoryToken, useClass: prisma_user_repository_1.PrismaUserRepository },
            { provide: token_repository_interface_1.ITokenRepositoryToken, useClass: prisma_token_repository_1.PrismaTokenRepository },
            { provide: password_hasher_interface_1.IPasswordHasherToken, useClass: argon2_password_hasher_service_1.Argon2PasswordHasherService },
            { provide: mail_service_interface_1.IMailServiceToken, useClass: smtp_mail_service_1.SmtpMailService },
        ],
        exports: [
            auth_service_1.AuthService,
            jwt_1.JwtModule,
            user_repository_interface_1.IUserRepositoryToken,
            token_repository_interface_1.ITokenRepositoryToken,
            password_hasher_interface_1.IPasswordHasherToken,
            mail_service_interface_1.IMailServiceToken,
        ],
    })
], AuthModule);
//# sourceMappingURL=auth.module.js.map