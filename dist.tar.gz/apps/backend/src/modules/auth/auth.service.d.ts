import { JwtService } from "@nestjs/jwt";
import { ConfigService } from "@nestjs/config";
import { User, TokenResponsePayload } from "@nos/shared-types";
import { IUserRepository } from "../../common/repositories/user.repository.interface";
import { ITokenRepository } from "../../common/repositories/token.repository.interface";
import { IPasswordHasher } from "../../common/services/password-hasher.interface";
import { IMailService } from "../../common/services/mail-service.interface";
import { RegisterDto, LoginDto, VerifyEmailDto, ForgotPasswordDto, ResetPasswordDto, ChangePasswordDto, RefreshDto } from "./dto/auth.dto";
import { PrismaService } from "../../database/prisma.service";
export declare class AuthService {
    private readonly userRepo;
    private readonly tokenRepo;
    private readonly hasher;
    private readonly mailService;
    private readonly jwtService;
    private readonly configService;
    private readonly prisma;
    private readonly logger;
    constructor(userRepo: IUserRepository, tokenRepo: ITokenRepository, hasher: IPasswordHasher, mailService: IMailService, jwtService: JwtService, configService: ConfigService, prisma: PrismaService);
    private generateTokens;
    register(dto: RegisterDto): Promise<{
        message: string;
        user: User;
        devOtp?: string;
    }>;
    resendVerificationOtp(email: string): Promise<{
        message: string;
        devOtp?: string;
    }>;
    login(dto: LoginDto): Promise<TokenResponsePayload>;
    verifyEmail(dto: VerifyEmailDto): Promise<{
        message: string;
        accessToken?: string;
        refreshToken?: string;
        user?: any;
    }>;
    refresh(dto: RefreshDto): Promise<TokenResponsePayload>;
    logout(user: User): Promise<{
        message: string;
    }>;
    forgotPassword(dto: ForgotPasswordDto): Promise<{
        message: string;
        devOtp?: string;
    }>;
    resetPassword(dto: ResetPasswordDto): Promise<{
        message: string;
    }>;
    changePassword(user: User, dto: ChangePasswordDto): Promise<{
        message: string;
    }>;
}
