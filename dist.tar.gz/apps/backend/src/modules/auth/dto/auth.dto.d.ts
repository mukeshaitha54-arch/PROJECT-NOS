import { RegisterPayload, LoginPayload, VerifyEmailPayload, ForgotPasswordPayload, ResetPasswordPayload, ChangePasswordPayload, RefreshTokenPayload } from "@nos/shared-types";
export declare class RegisterDto implements RegisterPayload {
    email: string;
    password: string;
    firstName: string;
    lastName: string;
}
export declare class LoginDto implements LoginPayload {
    email: string;
    password: string;
}
export declare class VerifyEmailDto implements VerifyEmailPayload {
    email: string;
    otp: string;
}
export declare class ForgotPasswordDto implements ForgotPasswordPayload {
    email: string;
}
export declare class ResetPasswordDto implements ResetPasswordPayload {
    email: string;
    otp: string;
    newPassword: string;
}
export declare class ChangePasswordDto implements ChangePasswordPayload {
    currentPassword: string;
    newPassword: string;
}
export declare class RefreshDto implements RefreshTokenPayload {
    refreshToken: string;
}
