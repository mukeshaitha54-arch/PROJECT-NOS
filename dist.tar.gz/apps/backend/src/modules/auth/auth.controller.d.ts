import { AuthService } from "./auth.service";
import { RegisterDto, LoginDto, VerifyEmailDto, ForgotPasswordDto, ResetPasswordDto, ChangePasswordDto, RefreshDto } from "./dto/auth.dto";
import { User, ApiResponse } from "@nos/shared-types";
export declare class AuthController {
    private readonly authService;
    constructor(authService: AuthService);
    register(dto: RegisterDto): Promise<ApiResponse>;
    login(dto: LoginDto): Promise<ApiResponse>;
    getMe(user: User): Promise<ApiResponse<User>>;
    resendOtp(email: string): Promise<ApiResponse>;
    verifyEmail(dto: VerifyEmailDto): Promise<ApiResponse>;
    refresh(dto: RefreshDto): Promise<ApiResponse>;
    forgotPassword(dto: ForgotPasswordDto): Promise<ApiResponse>;
    resetPassword(dto: ResetPasswordDto): Promise<ApiResponse>;
    changePassword(user: User, dto: ChangePasswordDto): Promise<ApiResponse>;
    logout(user: User): Promise<ApiResponse>;
}
