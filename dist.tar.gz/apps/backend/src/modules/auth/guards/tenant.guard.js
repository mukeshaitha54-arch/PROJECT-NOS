"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TenantContextGuard = exports.TenantGuard = void 0;
var tenant_context_guard_1 = require("../../../common/guards/tenant-context.guard");
Object.defineProperty(exports, "TenantGuard", { enumerable: true, get: function () { return tenant_context_guard_1.TenantContextGuard; } });
Object.defineProperty(exports, "TenantContextGuard", { enumerable: true, get: function () { return tenant_context_guard_1.TenantContextGuard; } });
//# sourceMappingURL=tenant.guard.js.map