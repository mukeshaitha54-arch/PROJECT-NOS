"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CurrentUser = exports.GetUser = void 0;
var current_user_decorator_1 = require("../../../common/decorators/current-user.decorator");
Object.defineProperty(exports, "GetUser", { enumerable: true, get: function () { return current_user_decorator_1.CurrentUser; } });
Object.defineProperty(exports, "CurrentUser", { enumerable: true, get: function () { return current_user_decorator_1.CurrentUser; } });
//# sourceMappingURL=get-user.decorator.js.map