"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var AuthService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthService = void 0;
const common_1 = require("@nestjs/common");
const jwt_1 = require("@nestjs/jwt");
const config_1 = require("@nestjs/config");
const shared_types_1 = require("@nos/shared-types");
const user_repository_interface_1 = require("../../common/repositories/user.repository.interface");
const token_repository_interface_1 = require("../../common/repositories/token.repository.interface");
const password_hasher_interface_1 = require("../../common/services/password-hasher.interface");
const mail_service_interface_1 = require("../../common/services/mail-service.interface");
const crypto = require("crypto");
const prisma_service_1 = require("../../database/prisma.service");
let AuthService = AuthService_1 = class AuthService {
    userRepo;
    tokenRepo;
    hasher;
    mailService;
    jwtService;
    configService;
    prisma;
    logger = new common_1.Logger(AuthService_1.name);
    constructor(userRepo, tokenRepo, hasher, mailService, jwtService, configService, prisma) {
        this.userRepo = userRepo;
        this.tokenRepo = tokenRepo;
        this.hasher = hasher;
        this.mailService = mailService;
        this.jwtService = jwtService;
        this.configService = configService;
        this.prisma = prisma;
    }
    async generateTokens(user) {
        const payload = { sub: user.id, email: user.email, role: user.role };
        const accessToken = await this.jwtService.signAsync(payload, {
            expiresIn: this.configService.get("JWT_ACCESS_EXPIRED_IN", "15m"),
        });
        const randomSecret = crypto.randomUUID() + crypto.randomUUID();
        const refreshToken = `${user.id}.${randomSecret}`;
        const tokenHash = crypto
            .createHash("sha256")
            .update(refreshToken)
            .digest("hex");
        const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
        await this.tokenRepo.createRefreshToken(user.id, tokenHash, expiresAt);
        return { accessToken, refreshToken, user };
    }
    async register(dto) {
        const normalizedEmail = dto.email.trim().toLowerCase();
        const existing = await this.userRepo.findByEmail(normalizedEmail);
        if (existing) {
            throw new common_1.ConflictException({
                code: shared_types_1.ErrorCode.USER_ALREADY_EXISTS,
                message: "Account with this email already exists.",
            });
        }
        const passwordHash = await this.hasher.hash(dto.password);
        const user = await this.userRepo.create({
            email: normalizedEmail,
            passwordHash,
            firstName: dto.firstName,
            lastName: dto.lastName,
            role: shared_types_1.UserRole.USER,
            isEmailVerified: false,
        });
        const orgId = crypto.randomUUID();
        const orgSlug = `personal-${user.id}`;
        await this.prisma.organization.create({
            data: {
                id: orgId,
                name: `${dto.firstName}'s Workspace`,
                slug: orgSlug,
                status: "ACTIVE",
            },
        });
        await this.prisma.organizationMember.create({
            data: {
                organizationId: orgId,
                userId: user.id,
                role: "OWNER",
            },
        });
        const otp = Math.floor(100000 + Math.random() * 900000).toString();
        const otpHash = await this.hasher.hash(otp);
        const expiresAt = new Date(Date.now() + 15 * 60 * 1000);
        await this.tokenRepo.createOtp(user.id, user.email, otpHash, "EMAIL_VERIFY", expiresAt);
        let smtpConfigured = false;
        try {
            await this.mailService.sendVerificationOtp(user.email, otp);
            smtpConfigured = true;
        }
        catch (mailErr) {
            this.logger.warn(`Verification email delivery skipped: ${mailErr?.message || mailErr}`);
        }
        this.logger.log(`📧 [OTP ISSUED] For [${user.email}]: Verification OTP is [${otp}] (expires in 15m)`);
        const { passwordHash: _, ...cleanUser } = user;
        this.logger.log(`👤 New user registered: [${cleanUser.email}] (ID: ${cleanUser.id})`);
        return {
            message: "Registration successful. Please enter the 6-digit verification code sent to your email.",
            user: cleanUser,
            devOtp: smtpConfigured ? undefined : otp,
        };
    }
    async resendVerificationOtp(email) {
        const normalizedEmail = email.trim().toLowerCase();
        const user = await this.userRepo.findByEmail(normalizedEmail);
        if (!user) {
            return {
                message: "If this email is registered, a new OTP has been sent.",
            };
        }
        const otp = Math.floor(100000 + Math.random() * 900000).toString();
        const otpHash = await this.hasher.hash(otp);
        const expiresAt = new Date(Date.now() + 15 * 60 * 1000);
        await this.tokenRepo.createOtp(user.id, user.email, otpHash, "EMAIL_VERIFY", expiresAt);
        let smtpDelivered = false;
        try {
            await this.mailService.sendVerificationOtp(user.email, otp);
            smtpDelivered = true;
        }
        catch (mailErr) {
            this.logger.warn(`Verification email delivery skipped: ${mailErr?.message || mailErr}`);
        }
        this.logger.log(`📧 [OTP RESENT] For [${email}]: New OTP is [${otp}]`);
        return {
            message: smtpDelivered
                ? "A new verification code has been dispatched to your email."
                : "OTP generated. SMTP not configured — check the code displayed on screen.",
            devOtp: smtpDelivered ? undefined : otp,
        };
    }
    async login(dto) {
        const user = await this.userRepo.findByEmail(dto.email);
        if (!user || !(await this.hasher.verify(user.passwordHash, dto.password))) {
            throw new common_1.UnauthorizedException({
                code: shared_types_1.ErrorCode.INVALID_CREDENTIALS,
                message: "Invalid email or password.",
            });
        }
        if (!user.isEmailVerified &&
            this.configService.get("REQUIRE_EMAIL_VERIFICATION", "true") !==
                "false") {
            throw new common_1.UnauthorizedException({
                code: shared_types_1.ErrorCode.EMAIL_NOT_VERIFIED,
                message: "Email address has not been verified. Please enter the OTP sent to your email.",
            });
        }
        const { passwordHash: _, ...cleanUser } = user;
        this.logger.log(`🔑 User login successful: [${cleanUser.email}]`);
        return this.generateTokens(cleanUser);
    }
    async verifyEmail(dto) {
        const normalizedEmail = dto.email.trim().toLowerCase();
        const latestOtp = await this.tokenRepo.findLatestOtp(normalizedEmail, "EMAIL_VERIFY");
        if (!latestOtp) {
            throw new common_1.BadRequestException({
                code: shared_types_1.ErrorCode.INVALID_OTP,
                message: "No valid verification request found for this email.",
            });
        }
        if (new Date() > latestOtp.expiresAt) {
            throw new common_1.BadRequestException({
                code: shared_types_1.ErrorCode.OTP_EXPIRED,
                message: "Verification OTP has expired. Please request a new one.",
            });
        }
        if (!(await this.hasher.verify(latestOtp.otpHash, dto.otp))) {
            throw new common_1.BadRequestException({
                code: shared_types_1.ErrorCode.INVALID_OTP,
                message: "Incorrect OTP code.",
            });
        }
        await this.tokenRepo.markOtpAsUsed(latestOtp.id);
        const user = await this.userRepo.findByEmail(normalizedEmail);
        if (!user) {
            throw new common_1.NotFoundException("User account not found.");
        }
        await this.userRepo.update(user.id, { isEmailVerified: true });
        try {
            await this.mailService.sendWelcomeEmail(user.email, user.firstName || "User");
        }
        catch { }
        const { passwordHash: _, ...cleanUser } = user;
        cleanUser.isEmailVerified = true;
        const tokens = await this.generateTokens(cleanUser);
        this.logger.log(`✅ Email verified successfully for: [${normalizedEmail}]`);
        return {
            message: "Email verified successfully! Welcome to NOS Platform.",
            accessToken: tokens.accessToken,
            refreshToken: tokens.refreshToken,
            user: cleanUser,
        };
    }
    async refresh(dto) {
        const parts = dto.refreshToken.split(".");
        if (parts.length < 2) {
            throw new common_1.UnauthorizedException({
                code: shared_types_1.ErrorCode.UNAUTHORIZED,
                message: "Malformed refresh token format.",
            });
        }
        const tokenHash = crypto
            .createHash("sha256")
            .update(dto.refreshToken)
            .digest("hex");
        const storedToken = await this.tokenRepo.findRefreshToken(tokenHash);
        if (!storedToken ||
            storedToken.isRevoked ||
            new Date() > storedToken.expiresAt) {
            throw new common_1.UnauthorizedException({
                code: shared_types_1.ErrorCode.UNAUTHORIZED,
                message: "Refresh token is invalid, revoked, or expired.",
            });
        }
        const user = await this.userRepo.findById(storedToken.userId);
        if (!user) {
            throw new common_1.UnauthorizedException({
                code: shared_types_1.ErrorCode.USER_NOT_FOUND,
                message: "Associated user no longer exists.",
            });
        }
        await this.tokenRepo.revokeAllUserRefreshTokens(user.id);
        const { passwordHash: _, ...cleanUser } = user;
        this.logger.log(`🔄 Rotated session refresh tokens for user: [${cleanUser.email}]`);
        return this.generateTokens(cleanUser);
    }
    async logout(user) {
        await this.tokenRepo.revokeAllUserRefreshTokens(user.id);
        this.logger.log(`🚪 User logged out and session tokens revoked: [${user.email}]`);
        return { message: "Logged out successfully." };
    }
    async forgotPassword(dto) {
        const normalizedEmail = dto.email.trim().toLowerCase();
        const user = await this.userRepo.findByEmail(normalizedEmail);
        let devOtp = undefined;
        if (user) {
            const otp = Math.floor(100000 + Math.random() * 900000).toString();
            const otpHash = await this.hasher.hash(otp);
            const expiresAt = new Date(Date.now() + 15 * 60 * 1000);
            await this.tokenRepo.createOtp(user.id, user.email, otpHash, "PASSWORD_RESET", expiresAt);
            try {
                await this.mailService.sendPasswordResetOtp(user.email, otp);
                this.logger.log(`📩 Password reset OTP sent via SMTP to: [${user.email}]`);
            }
            catch (mailErr) {
                this.logger.warn(`Password reset email delivery skipped: ${mailErr?.message || mailErr}`);
                devOtp = otp;
            }
        }
        return {
            message: "If an account matching this email exists, a password reset OTP has been sent.",
            devOtp,
        };
    }
    async resetPassword(dto) {
        const normalizedEmail = dto.email.trim().toLowerCase();
        const latestOtp = await this.tokenRepo.findLatestOtp(normalizedEmail, "PASSWORD_RESET");
        if (!latestOtp) {
            throw new common_1.BadRequestException({
                code: shared_types_1.ErrorCode.INVALID_OTP,
                message: "No active password reset request found.",
            });
        }
        if (new Date() > latestOtp.expiresAt) {
            throw new common_1.BadRequestException({
                code: shared_types_1.ErrorCode.OTP_EXPIRED,
                message: "Password reset OTP has expired.",
            });
        }
        if (!(await this.hasher.verify(latestOtp.otpHash, dto.otp))) {
            throw new common_1.BadRequestException({
                code: shared_types_1.ErrorCode.INVALID_OTP,
                message: "Incorrect OTP code.",
            });
        }
        await this.tokenRepo.markOtpAsUsed(latestOtp.id);
        const user = await this.userRepo.findByEmail(normalizedEmail);
        if (!user) {
            throw new common_1.NotFoundException({
                code: shared_types_1.ErrorCode.USER_NOT_FOUND,
                message: "Account not found.",
            });
        }
        const newPasswordHash = await this.hasher.hash(dto.newPassword);
        await this.userRepo.update(user.id, {
            passwordHash: newPasswordHash,
            isEmailVerified: true,
        });
        await this.tokenRepo.revokeAllUserRefreshTokens(user.id);
        this.logger.log(`🛡️ Password reset successful for user: [${user.email}]`);
        return {
            message: "Password reset successful. Please login with your new credentials.",
        };
    }
    async changePassword(user, dto) {
        const fullUser = await this.userRepo.findById(user.id);
        if (!fullUser ||
            !(await this.hasher.verify(fullUser.passwordHash, dto.currentPassword))) {
            throw new common_1.UnauthorizedException({
                code: shared_types_1.ErrorCode.INVALID_CREDENTIALS,
                message: "Current password is incorrect.",
            });
        }
        const newPasswordHash = await this.hasher.hash(dto.newPassword);
        await this.userRepo.update(user.id, { passwordHash: newPasswordHash });
        await this.tokenRepo.revokeAllUserRefreshTokens(user.id);
        this.logger.log(`🔒 Password changed and existing sessions revoked for: [${user.email}]`);
        return { message: "Password changed successfully." };
    }
};
exports.AuthService = AuthService;
exports.AuthService = AuthService = AuthService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(user_repository_interface_1.IUserRepositoryToken)),
    __param(1, (0, common_1.Inject)(token_repository_interface_1.ITokenRepositoryToken)),
    __param(2, (0, common_1.Inject)(password_hasher_interface_1.IPasswordHasherToken)),
    __param(3, (0, common_1.Inject)(mail_service_interface_1.IMailServiceToken)),
    __metadata("design:paramtypes", [Object, Object, Object, Object, jwt_1.JwtService,
        config_1.ConfigService,
        prisma_service_1.PrismaService])
], AuthService);
//# sourceMappingURL=auth.service.js.map