"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FleetModule = void 0;
const common_1 = require("@nestjs/common");
const installer_controller_1 = require("./controllers/installer.controller");
const onboarding_controller_1 = require("./controllers/onboarding.controller");
const registration_key_controller_1 = require("./controllers/registration-key.controller");
const search_controller_1 = require("./controllers/search.controller");
const fleet_dashboard_controller_1 = require("./controllers/fleet-dashboard.controller");
const smart_group_controller_1 = require("./controllers/smart-group.controller");
const bulk_operations_controller_1 = require("./controllers/bulk-operations.controller");
const hierarchy_controller_1 = require("./controllers/hierarchy.controller");
const registration_key_service_1 = require("./services/registration-key.service");
const search_service_1 = require("./services/search.service");
const fleet_dashboard_service_1 = require("./services/fleet-dashboard.service");
const smart_group_service_1 = require("./services/smart-group.service");
const bulk_operations_service_1 = require("./services/bulk-operations.service");
const hierarchy_service_1 = require("./services/hierarchy.service");
const device_module_1 = require("../device/device.module");
const auth_module_1 = require("../auth/auth.module");
const alerts_module_1 = require("../alerts/alerts.module");
const inventory_module_1 = require("../inventory/inventory.module");
const prisma_service_1 = require("../../database/prisma.service");
let FleetModule = class FleetModule {
};
exports.FleetModule = FleetModule;
exports.FleetModule = FleetModule = __decorate([
    (0, common_1.Module)({
        imports: [
            (0, common_1.forwardRef)(() => device_module_1.DeviceModule),
            auth_module_1.AuthModule,
            alerts_module_1.AlertsModule,
            (0, common_1.forwardRef)(() => inventory_module_1.InventoryModule),
        ],
        controllers: [
            installer_controller_1.InstallerController,
            onboarding_controller_1.OnboardingController,
            registration_key_controller_1.RegistrationKeyController,
            search_controller_1.SearchController,
            fleet_dashboard_controller_1.FleetDashboardController,
            smart_group_controller_1.SmartGroupController,
            bulk_operations_controller_1.BulkOperationsController,
            hierarchy_controller_1.HierarchyController,
        ],
        providers: [
            registration_key_service_1.RegistrationKeyService,
            search_service_1.SearchService,
            fleet_dashboard_service_1.FleetDashboardService,
            smart_group_service_1.SmartGroupService,
            bulk_operations_service_1.BulkOperationsService,
            hierarchy_service_1.HierarchyService,
            prisma_service_1.PrismaService,
        ],
        exports: [
            registration_key_service_1.RegistrationKeyService,
            search_service_1.SearchService,
            fleet_dashboard_service_1.FleetDashboardService,
            smart_group_service_1.SmartGroupService,
            bulk_operations_service_1.BulkOperationsService,
            hierarchy_service_1.HierarchyService,
        ],
    })
], FleetModule);
//# sourceMappingURL=fleet.module.js.map