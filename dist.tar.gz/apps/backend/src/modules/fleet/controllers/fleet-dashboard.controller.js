"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FleetDashboardController = void 0;
const openapi = require("@nestjs/swagger");
const common_1 = require("@nestjs/common");
const fleet_dashboard_service_1 = require("../services/fleet-dashboard.service");
const jwt_auth_guard_1 = require("../../../common/guards/jwt-auth.guard");
const current_tenant_decorator_1 = require("../../../common/decorators/current-tenant.decorator");
let FleetDashboardController = class FleetDashboardController {
    dashboardService;
    constructor(dashboardService) {
        this.dashboardService = dashboardService;
    }
    async getOrganizationTree(tenant, orgId) {
        if (orgId !== tenant.organizationId) {
            throw new Error("Unauthorized cross-tenant access attempt");
        }
        const data = await this.dashboardService.getOrganizationTree(tenant.organizationId);
        return {
            success: true,
            data,
        };
    }
};
exports.FleetDashboardController = FleetDashboardController;
__decorate([
    (0, common_1.Get)(":orgId/tree"),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, current_tenant_decorator_1.CurrentTenant)()),
    __param(1, (0, common_1.Param)("orgId")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], FleetDashboardController.prototype, "getOrganizationTree", null);
exports.FleetDashboardController = FleetDashboardController = __decorate([
    (0, common_1.Controller)("fleet/dashboard"),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    __metadata("design:paramtypes", [fleet_dashboard_service_1.FleetDashboardService])
], FleetDashboardController);
//# sourceMappingURL=fleet-dashboard.controller.js.map