"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OnboardingController = void 0;
const openapi = require("@nestjs/swagger");
const common_1 = require("@nestjs/common");
const registration_key_service_1 = require("../services/registration-key.service");
const tenant_repository_interface_1 = require("../../../common/repositories/tenant.repository.interface");
const prisma_service_1 = require("../../../database/prisma.service");
const password_hasher_interface_1 = require("../../../common/services/password-hasher.interface");
const crypto = require("crypto");
let OnboardingController = class OnboardingController {
    registrationKeyService;
    orgRepo;
    hasher;
    prisma;
    constructor(registrationKeyService, orgRepo, hasher, prisma) {
        this.registrationKeyService = registrationKeyService;
        this.orgRepo = orgRepo;
        this.hasher = hasher;
        this.prisma = prisma;
    }
    async completeOnboarding(dto) {
        const existingOrg = await this.prisma.organization.findUnique({
            where: { slug: dto.slug },
        });
        if (existingOrg) {
            throw new common_1.BadRequestException("Organization slug already exists");
        }
        let user = await this.prisma.user.findUnique({
            where: { email: dto.ownerEmail },
        });
        const transactionResult = await this.prisma.$transaction(async (tx) => {
            if (!user) {
                const generatedPassword = crypto.randomUUID();
                const hash = dto.passwordHash || (await this.hasher.hash(generatedPassword));
                user = await tx.user.create({
                    data: {
                        email: dto.ownerEmail,
                        firstName: dto.ownerFirstName,
                        lastName: dto.ownerLastName,
                        passwordHash: hash,
                        role: "OWNER",
                        isEmailVerified: true,
                    },
                });
            }
            const org = await tx.organization.create({
                data: {
                    name: dto.companyName,
                    slug: dto.slug,
                    timezone: dto.timezone || "UTC",
                    companyName: dto.companyName,
                    brandingEnabled: false,
                    members: {
                        create: {
                            userId: user.id,
                            role: "OWNER",
                        },
                    },
                    quota: {
                        create: {},
                    },
                },
            });
            return { org, user };
        });
        const keyResult = await this.registrationKeyService.generateKey({
            organizationId: transactionResult.org.id,
            displayName: "Default Deployment Key",
            createdBy: transactionResult.user.id,
            maxUses: 0,
        });
        return {
            success: true,
            data: {
                organization: transactionResult.org,
                user: transactionResult.user,
                registrationKey: keyResult,
            },
            message: "Onboarding complete. Please save the Registration Key safely.",
        };
    }
};
exports.OnboardingController = OnboardingController;
__decorate([
    (0, common_1.Post)("wizard"),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], OnboardingController.prototype, "completeOnboarding", null);
exports.OnboardingController = OnboardingController = __decorate([
    (0, common_1.Controller)("fleet/onboarding"),
    __param(1, (0, common_1.Inject)(tenant_repository_interface_1.IOrganizationRepositoryToken)),
    __param(2, (0, common_1.Inject)(password_hasher_interface_1.IPasswordHasherToken)),
    __metadata("design:paramtypes", [registration_key_service_1.RegistrationKeyService, Object, Object, prisma_service_1.PrismaService])
], OnboardingController);
//# sourceMappingURL=onboarding.controller.js.map