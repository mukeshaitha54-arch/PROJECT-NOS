import { RegistrationKeyService } from "../services/registration-key.service";
import { IOrganizationRepository } from "../../../common/repositories/tenant.repository.interface";
import { PrismaService } from "../../../database/prisma.service";
import { IPasswordHasher } from "../../../common/services/password-hasher.interface";
export interface OnboardingWizardDto {
    companyName: string;
    slug: string;
    ownerEmail: string;
    ownerFirstName: string;
    ownerLastName: string;
    passwordHash?: string;
    timezone?: string;
}
export declare class OnboardingController {
    private readonly registrationKeyService;
    private readonly orgRepo;
    private readonly hasher;
    private readonly prisma;
    constructor(registrationKeyService: RegistrationKeyService, orgRepo: IOrganizationRepository, hasher: IPasswordHasher, prisma: PrismaService);
    completeOnboarding(dto: OnboardingWizardDto): Promise<{
        success: boolean;
        data: {
            organization: {
                id: string;
                name: string;
                slug: string;
                status: string;
                timezone: string;
                locale: string;
                logoUrl: string | null;
                companyName: string | null;
                accentColour: string | null;
                supportEmail: string | null;
                brandingEnabled: boolean;
                customDomain: string | null;
                retentionDays: number;
                createdAt: Date;
                updatedAt: Date;
                deletedAt: Date | null;
            };
            user: {
                role: import("@prisma/client").$Enums.Role;
                id: string;
                createdAt: Date;
                updatedAt: Date;
                email: string;
                passwordHash: string;
                firstName: string;
                lastName: string;
                isEmailVerified: boolean;
            };
            registrationKey: {
                key: string;
                registrationKey: import("@prisma/client").RegistrationKey;
            };
        };
        message: string;
    }>;
}
