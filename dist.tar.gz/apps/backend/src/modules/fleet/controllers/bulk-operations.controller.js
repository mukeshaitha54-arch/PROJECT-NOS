"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BulkOperationsController = void 0;
const openapi = require("@nestjs/swagger");
const common_1 = require("@nestjs/common");
const bulk_operations_service_1 = require("../services/bulk-operations.service");
const jwt_auth_guard_1 = require("../../../common/guards/jwt-auth.guard");
const current_user_decorator_1 = require("../../../common/decorators/current-user.decorator");
let BulkOperationsController = class BulkOperationsController {
    bulkService;
    constructor(bulkService) {
        this.bulkService = bulkService;
    }
    async executeAction(dto, user) {
        const result = await this.bulkService.executeBulkAction({
            ...dto,
            performedByUserId: user.id,
        });
        return {
            success: true,
            message: `Bulk operation ${dto.action} completed successfully.`,
            data: result,
        };
    }
};
exports.BulkOperationsController = BulkOperationsController;
__decorate([
    (0, common_1.Post)("action"),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], BulkOperationsController.prototype, "executeAction", null);
exports.BulkOperationsController = BulkOperationsController = __decorate([
    (0, common_1.Controller)("fleet/bulk"),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    __metadata("design:paramtypes", [bulk_operations_service_1.BulkOperationsService])
], BulkOperationsController);
//# sourceMappingURL=bulk-operations.controller.js.map