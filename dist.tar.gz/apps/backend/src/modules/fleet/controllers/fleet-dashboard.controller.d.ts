import { FleetDashboardService } from "../services/fleet-dashboard.service";
import { TenantContext } from "@nos/shared-types";
export declare class FleetDashboardController {
    private readonly dashboardService;
    constructor(dashboardService: FleetDashboardService);
    getOrganizationTree(tenant: TenantContext, orgId: string): Promise<{
        success: boolean;
        data: import("../services/fleet-dashboard.service").FleetTreeNode;
    }>;
}
