import { SmartGroupService, CreateSmartGroupDto } from "../services/smart-group.service";
export declare class SmartGroupController {
    private readonly smartGroupService;
    constructor(smartGroupService: SmartGroupService);
    createGroup(dto: CreateSmartGroupDto): Promise<{
        success: boolean;
        data: {
            description: string | null;
            organizationId: string;
            id: string;
            name: string;
            createdAt: Date;
            updatedAt: Date;
            rules: import("@prisma/client/runtime/library").JsonValue;
        };
    }>;
    getGroups(orgId: string): Promise<{
        success: boolean;
        data: {
            description: string | null;
            organizationId: string;
            id: string;
            name: string;
            createdAt: Date;
            updatedAt: Date;
            rules: import("@prisma/client/runtime/library").JsonValue;
        }[];
    }>;
    evaluateGroup(id: string): Promise<{
        success: boolean;
        data: {
            count: number;
            devices: {
                tenantId: string | null;
                organizationId: string | null;
                id: string;
                name: string | null;
                status: import("@prisma/client").$Enums.DeviceStatus;
                createdAt: Date;
                updatedAt: Date;
                tokenHash: string;
                os: string;
                uuid: string;
                hostname: string;
                deviceName: string;
                osVersion: string;
                architecture: string;
                agentVersion: string;
                claimStatus: import("@prisma/client").$Enums.DeviceClaimStatus;
                lastSeen: Date | null;
                registeredAt: Date;
            }[];
        };
    }>;
}
