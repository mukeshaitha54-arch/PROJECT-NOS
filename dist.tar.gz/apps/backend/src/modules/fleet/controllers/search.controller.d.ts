import { SearchService } from "../services/search.service";
export declare class SearchController {
    private readonly searchService;
    constructor(searchService: SearchService);
    search(orgId: string, query: string): Promise<{
        success: boolean;
        data: import("../services/search.service").SearchResult[];
    }>;
}
