import { HierarchyService } from "../services/hierarchy.service";
export declare class HierarchyController {
    private readonly hierarchyService;
    constructor(hierarchyService: HierarchyService);
    getHierarchy(orgId: string): Promise<{
        success: boolean;
        data: import("../services/hierarchy.service").HierarchyNode;
    }>;
}
