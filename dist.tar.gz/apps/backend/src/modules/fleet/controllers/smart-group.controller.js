"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SmartGroupController = void 0;
const openapi = require("@nestjs/swagger");
const common_1 = require("@nestjs/common");
const smart_group_service_1 = require("../services/smart-group.service");
const jwt_auth_guard_1 = require("../../../common/guards/jwt-auth.guard");
let SmartGroupController = class SmartGroupController {
    smartGroupService;
    constructor(smartGroupService) {
        this.smartGroupService = smartGroupService;
    }
    async createGroup(dto) {
        const data = await this.smartGroupService.createGroup(dto);
        return {
            success: true,
            data,
        };
    }
    async getGroups(orgId) {
        const data = await this.smartGroupService.getGroups(orgId);
        return {
            success: true,
            data,
        };
    }
    async evaluateGroup(id) {
        const devices = await this.smartGroupService.evaluateGroup(id);
        return {
            success: true,
            data: {
                count: devices.length,
                devices,
            },
        };
    }
};
exports.SmartGroupController = SmartGroupController;
__decorate([
    (0, common_1.Post)(),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], SmartGroupController.prototype, "createGroup", null);
__decorate([
    (0, common_1.Get)("organization/:orgId"),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)("orgId")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], SmartGroupController.prototype, "getGroups", null);
__decorate([
    (0, common_1.Get)(":id/evaluate"),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)("id")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], SmartGroupController.prototype, "evaluateGroup", null);
exports.SmartGroupController = SmartGroupController = __decorate([
    (0, common_1.Controller)("fleet/smart-groups"),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    __metadata("design:paramtypes", [smart_group_service_1.SmartGroupService])
], SmartGroupController);
//# sourceMappingURL=smart-group.controller.js.map