"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.InstallerController = void 0;
const openapi = require("@nestjs/swagger");
const common_1 = require("@nestjs/common");
const path = require("path");
const fs = require("fs");
let InstallerController = class InstallerController {
    async getWindowsInstaller(registrationKey, serverUrl, req, res) {
        const safeKey = (registrationKey || "").replace(/[^A-Za-z0-9\-]/g, "");
        const host = req?.headers?.host ? `http://${req.headers.host}` : "";
        const fallbackServer = process.env.API_BASE_URL ||
            process.env.NEXT_PUBLIC_API_BASE_URL ||
            host ||
            "http://localhost:3001";
        const rawServer = (serverUrl || fallbackServer)
            .replace(/[`$'"\\]/g, "")
            .replace(/\s/g, "");
        const baseServer = rawServer.replace(/\/api\/v1\/?$/, "");
        const safeServer = `${baseServer}/api/v1`;
        const agentApiUrl = `${safeServer}/fleet/installer/agent`;
        const lines = [
            "# ===========================================================================",
            "# NOS Agent - Windows Installer",
            `# Generated: ${new Date().toISOString()}`,
            `# Server:    ${safeServer}`,
            "# ===========================================================================",
            "",
            "#Requires -RunAsAdministrator",
            "",
            "# ---------- Configuration ---------------------------------------------------",
            `$ServerUrl      = '${safeServer}'`,
            `$AgentApiUrl    = '${agentApiUrl}'`,
            `$RegKey         = '${safeKey}'`,
            "$ServiceName    = 'NOS-Agent'",
            "$ServiceDisplay = 'Neural Operating System (NOS) Agent'",
            "$ServiceDesc    = 'Endpoint telemetry and health monitoring daemon for NOS.'",
            "$InstallDir     = Join-Path $env:ProgramFiles 'NOSAgent'",
            "$ExePath        = Join-Path $InstallDir 'NOS-Agent.exe'",
            "$ConfigDir      = Join-Path $env:LOCALAPPDATA 'NOS'",
            "",
            "# ---------- Banner ----------------------------------------------------------",
            "Clear-Host",
            "Write-Host ''",
            "Write-Host '  +--------------------------------------------------+' -ForegroundColor Cyan",
            "Write-Host '  |       NOS AGENT - WINDOWS INSTALLER              |' -ForegroundColor Cyan",
            "Write-Host '  +--------------------------------------------------+' -ForegroundColor Cyan",
            "Write-Host ''",
            "",
            "# ---------- Registration Key ------------------------------------------------",
            "if ([string]::IsNullOrWhiteSpace($RegKey)) {",
            "    Write-Host '  Enter your Registration Key from the NOS Dashboard:' -ForegroundColor Yellow",
            "    $RegKey = Read-Host '  Registration Key'",
            "}",
            "",
            "if ([string]::IsNullOrWhiteSpace($RegKey)) {",
            "    Write-Host '  [!] No registration key provided. Aborting.' -ForegroundColor Red",
            "    exit 1",
            "}",
            "",
            "Write-Host ''",
            "Write-Host '  [*] Installing NOS Agent...' -ForegroundColor Cyan",
            "Write-Host ''",
            "",
            "      # ---------- Stop & Release Existing Service & Process -----------------------",
            "      $existingSvc = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue",
            "      if ($null -ne $existingSvc) {",
            "          Write-Host '  [*] Stopping existing service to release file locks...' -ForegroundColor Cyan",
            "          Stop-Service -Name $ServiceName -Force -ErrorAction SilentlyContinue",
            "          Start-Sleep -Seconds 2",
            "          sc.exe delete $ServiceName | Out-Null",
            "          Start-Sleep -Seconds 1",
            "      }",
            "      Get-Process -Name 'NOS-Agent' -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue",
            "      Start-Sleep -Seconds 1",
            "      Write-Host '  [+] Existing service and processes released.' -ForegroundColor Green",
            "",
            "      # ---------- Create Directories ----------------------------------------------",
            "      if (-not (Test-Path $InstallDir)) {",
            "    New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null",
            '    Write-Host "  [+] Created: $InstallDir" -ForegroundColor Green',
            "}",
            "if (-not (Test-Path $ConfigDir)) {",
            "    New-Item -ItemType Directory -Path $ConfigDir -Force | Out-Null",
            "}",
            "",
            "# ---------- Save Configuration ----------------------------------------------",
            "$BaseServerUrl = $ServerUrl.TrimEnd('/') -replace '/api/v1$', ''",
            "$cfg = [ordered]@{",
            "    AgentConfiguration = [ordered]@{",
            "        ServerUrl       = $BaseServerUrl",
            "        RegistrationKey = $RegKey",
            "        DeviceId        = ''",
            "        TenantId        = ''",
            "    }",
            "}",
            "$cfgJson = $cfg | ConvertTo-Json -Depth 5",
            "Set-Content -Path (Join-Path $ConfigDir 'appsettings.json') -Value $cfgJson -Encoding UTF8",
            "try { Set-Content -Path (Join-Path $InstallDir 'appsettings.json') -Value $cfgJson -Encoding UTF8 } catch { }",
            "Write-Host '  [+] Configuration saved.' -ForegroundColor Green",
            "",
            "# ---------- Download Agent EXE ----------------------------------------------",
            "Write-Host '  [*] Downloading NOS Agent...' -ForegroundColor Cyan",
            "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12",
            "",
            "$downloaded = $false",
            "try {",
            "    Invoke-WebRequest -Uri $AgentApiUrl -OutFile $ExePath -TimeoutSec 180 -UseBasicParsing",
            "    $downloaded = $true",
            '    Write-Host "  [+] Downloaded to: $ExePath" -ForegroundColor Green',
            "}",
            "catch {",
            '    Write-Host "  [!] Download failed: $($_.Exception.Message)" -ForegroundColor Yellow',
            "}",
            "",
            "if (-not $downloaded) {",
            "    $searchPaths = @(",
            "        (Join-Path $env:USERPROFILE 'Desktop\\NOS-Agent.exe'),",
            "        (Join-Path $env:USERPROFILE 'Downloads\\NOS-Agent.exe'),",
            "        (Join-Path $PSScriptRoot 'NOS-Agent.exe')",
            "    )",
            "    foreach ($p in $searchPaths) {",
            "        if (Test-Path $p) {",
            "            Copy-Item -Path $p -Destination $ExePath -Force",
            "            $downloaded = $true",
            '            Write-Host "  [+] Found local copy: $p" -ForegroundColor Green',
            "            break",
            "        }",
            "    }",
            "}",
            "",
            "if (-not $downloaded) {",
            "    Write-Host '  [!] Cannot obtain NOS-Agent.exe.' -ForegroundColor Red",
            "    Write-Host '      Download from dashboard and place it next to this script, then re-run.' -ForegroundColor Red",
            "    exit 1",
            "}",
            "",
            "# ---------- Verify Key & Onboard Device -------------------------------------",
            "Write-Host '  [*] Verifying Registration Key and onboarding device...' -ForegroundColor Cyan",
            '$RegEndpoint = "$ServerUrl/device/register"',
            "$MachineUuid = (Get-CimInstance -Class Win32_ComputerSystemProduct -ErrorAction SilentlyContinue).UUID",
            "if ([string]::IsNullOrWhiteSpace($MachineUuid)) { $MachineUuid = [guid]::NewGuid().ToString() }",
            "$RegPayload = @{",
            "    uuid            = $MachineUuid",
            "    hostname        = $env:COMPUTERNAME",
            "    deviceName      = $env:COMPUTERNAME",
            "    os              = (Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue).Caption",
            "    osVersion       = (Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue).Version",
            "    architecture    = if ([Environment]::Is64BitOperatingSystem) { 'X64' } else { 'X86' }",
            "    agentVersion    = '1.0.0'",
            "    registrationKey = $RegKey",
            "} | ConvertTo-Json",
            "",
            "try {",
            "    $RegResp = Invoke-RestMethod -Uri $RegEndpoint -Method Post -Body $RegPayload -ContentType 'application/json' -TimeoutSec 15",
            "    if ($RegResp.success -and $RegResp.data.deviceId) {",
            "        $AssignedId = $RegResp.data.deviceId",
            "        $AssignedToken = if ($RegResp.data.token) { $RegResp.data.token } else { $RegResp.data.registrationToken }",
            '        Write-Host "  [+] Key verified! Device registered with ID: $AssignedId" -ForegroundColor Green',
            "        $cfg.AgentConfiguration.DeviceId = $AssignedId",
            "        $cfgJson = $cfg | ConvertTo-Json -Depth 5",
            "        Set-Content -Path (Join-Path $ConfigDir 'appsettings.json') -Value $cfgJson -Encoding UTF8",
            "        try { Set-Content -Path (Join-Path $InstallDir 'appsettings.json') -Value $cfgJson -Encoding UTF8 } catch { }",
            "        $devObj = @{ DeviceId = $AssignedId; ServerUrl = $BaseServerUrl } | ConvertTo-Json",
            "        Set-Content -Path (Join-Path $ConfigDir 'device.json') -Value $devObj -Encoding UTF8",
            "        try { Set-Content -Path (Join-Path $InstallDir 'device.json') -Value $devObj -Encoding UTF8 } catch { }",
            "        try { cmdkey /generic:'NOS_DeviceToken' /user:$AssignedId /pass:$AssignedToken | Out-Null } catch { }",
            "    }",
            "}",
            "catch {",
            '    Write-Host "  [*] Registration note: $($_.Exception.Message)" -ForegroundColor Yellow',
            "}",
            "",
            "# ---------- Install Windows Service -----------------------------------------",
            "Write-Host '  [*] Installing Windows Service...' -ForegroundColor Cyan",
            "$binPath = ([char]34 + $ExePath + [char]34)",
            "sc.exe create $ServiceName binPath= $binPath start= auto DisplayName= $ServiceDisplay | Out-Null",
            "sc.exe description $ServiceName $ServiceDesc | Out-Null",
            "sc.exe failure $ServiceName reset= 86400 actions= restart/5000/restart/10000/restart/30000 | Out-Null",
            "Write-Host '  [+] Service registered.' -ForegroundColor Green",
            "",
            "# ---------- Start Service ---------------------------------------------------",
            "Write-Host '  [*] Starting NOS Agent service...' -ForegroundColor Cyan",
            "Start-Service -Name $ServiceName -ErrorAction SilentlyContinue",
            "Start-Sleep -Seconds 3",
            "",
            "$svc = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue",
            "if ($null -ne $svc -and $svc.Status -eq 'Running') {",
            "    Write-Host '  [+] NOS Agent service is RUNNING.' -ForegroundColor Green",
            "}",
            "else {",
            "    Write-Host '  [!] Service did not start - check Event Viewer.' -ForegroundColor Yellow",
            "}",
            "",
            "# ---------- Done ------------------------------------------------------------",
            "Write-Host ''",
            "Write-Host '  +--------------------------------------------------+' -ForegroundColor Green",
            "Write-Host '  |         INSTALLATION COMPLETE                    |' -ForegroundColor Green",
            "Write-Host '  +--------------------------------------------------+' -ForegroundColor Green",
            "Write-Host ''",
            'Write-Host "  Server:   $BaseServerUrl" -ForegroundColor Gray',
            'Write-Host "  Install:  $InstallDir" -ForegroundColor Gray',
            'Write-Host "  Service:  $ServiceName" -ForegroundColor Gray',
            'Write-Host "  Device:   $env:COMPUTERNAME" -ForegroundColor Gray',
            "Write-Host '  Telemetry streaming: ACTIVE' -ForegroundColor Green",
            "Write-Host ''",
        ];
        const script = lines.join("\r\n");
        const setHeader = (name, value) => {
            if (typeof res.header === "function") {
                res.header(name, value);
            }
            else if (typeof res.setHeader === "function") {
                res.setHeader(name, value);
            }
        };
        setHeader("Content-Type", "text/plain; charset=utf-8");
        setHeader("Content-Disposition", 'attachment; filename="install-nos-agent.ps1"');
        return res.status(200).send(script);
    }
    async downloadAgentExe(res) {
        const tryPaths = [
            path.join(__dirname, "..", "..", "..", "..", "assets", "NOS-Agent.exe"),
            path.join(__dirname, "..", "..", "..", "assets", "NOS-Agent.exe"),
            path.join(process.cwd(), "apps", "backend", "assets", "NOS-Agent.exe"),
            path.join(process.cwd(), "assets", "NOS-Agent.exe"),
        ];
        const exePath = tryPaths.find((p) => fs.existsSync(p));
        if (!exePath) {
            throw new common_1.NotFoundException("NOS Agent executable not found. Build via apps/NOS.Agent/publish.ps1 to generate apps/backend/assets/NOS-Agent.exe");
        }
        const stat = fs.statSync(exePath);
        if (typeof res.header === "function") {
            res.header("Content-Type", "application/octet-stream");
            res.header("Content-Disposition", 'attachment; filename="NOS-Agent.exe"');
            res.header("Content-Length", stat.size);
        }
        else if (typeof res.setHeader === "function") {
            res.setHeader("Content-Type", "application/octet-stream");
            res.setHeader("Content-Disposition", 'attachment; filename="NOS-Agent.exe"');
            res.setHeader("Content-Length", stat.size);
        }
        const stream = fs.createReadStream(exePath);
        const { StreamableFile } = await Promise.resolve().then(() => require("@nestjs/common"));
        return new StreamableFile(stream);
    }
};
exports.InstallerController = InstallerController;
__decorate([
    (0, common_1.Get)("windows"),
    openapi.ApiResponse({ status: 200, type: Object }),
    __param(0, (0, common_1.Query)("registrationKey")),
    __param(1, (0, common_1.Query)("serverUrl")),
    __param(2, (0, common_1.Req)()),
    __param(3, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object, Object]),
    __metadata("design:returntype", Promise)
], InstallerController.prototype, "getWindowsInstaller", null);
__decorate([
    (0, common_1.Get)("agent"),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], InstallerController.prototype, "downloadAgentExe", null);
exports.InstallerController = InstallerController = __decorate([
    (0, common_1.Controller)("fleet/installer")
], InstallerController);
//# sourceMappingURL=installer.controller.js.map