"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RegistrationKeyController = void 0;
const openapi = require("@nestjs/swagger");
const common_1 = require("@nestjs/common");
const registration_key_service_1 = require("../services/registration-key.service");
const jwt_auth_guard_1 = require("../../../common/guards/jwt-auth.guard");
const current_user_decorator_1 = require("../../../common/decorators/current-user.decorator");
const tenant_repository_interface_1 = require("../../../common/repositories/tenant.repository.interface");
const mail_service_interface_1 = require("../../../common/services/mail-service.interface");
let RegistrationKeyController = class RegistrationKeyController {
    registrationKeyService;
    auditLogRepo;
    orgRepo;
    mailService;
    constructor(registrationKeyService, auditLogRepo, orgRepo, mailService) {
        this.registrationKeyService = registrationKeyService;
        this.auditLogRepo = auditLogRepo;
        this.orgRepo = orgRepo;
        this.mailService = mailService;
    }
    async generateKey(dto, user) {
        const result = await this.registrationKeyService.generateKey({
            ...dto,
            createdBy: user.id,
        });
        try {
            await this.auditLogRepo.record({
                organizationId: result.registrationKey.organizationId,
                correlationId: "N/A",
                userId: user?.id || "system",
                userEmail: user?.email || "unknown",
                action: "REGISTRATION_KEY_GENERATED",
                resourceType: "RegistrationKey",
                resourceId: result.registrationKey.id,
                reason: "Generated new agent registration key",
                ipAddress: user?.ipAddress || "unknown",
                browser: user?.browser || "unknown",
                details: {
                    displayName: dto.displayName,
                    keyPrefix: result.registrationKey.keyPrefix,
                },
            });
        }
        catch { }
        try {
            const org = await this.orgRepo.findById(result.registrationKey.organizationId);
            if (org && user?.email) {
                await this.mailService.sendRegistrationKeyNotification(user.email, dto.displayName, org.name);
            }
        }
        catch { }
        return {
            plainKey: result.key,
            success: true,
            data: result,
            message: "IMPORTANT: The plain key will only be shown this one time.",
        };
    }
    async getKeys(orgId) {
        const keys = await this.registrationKeyService.getKeysByOrganization(orgId);
        return keys;
    }
    async revokeKey(id, user) {
        const revoked = await this.registrationKeyService.revokeKey(id, user.id, "Revoked via UI");
        await this.auditLogRepo.record({
            organizationId: revoked.organizationId,
            correlationId: "N/A",
            userId: user.id,
            userEmail: user.email,
            action: "REGISTRATION_KEY_REVOKED",
            resourceType: "RegistrationKey",
            resourceId: id,
            reason: "Revoked via UI",
            ipAddress: user.ipAddress || "unknown",
            browser: user.browser || "unknown",
            details: {
                keyPrefix: revoked.keyPrefix,
            },
        });
        return {
            success: true,
            data: revoked,
        };
    }
};
exports.RegistrationKeyController = RegistrationKeyController;
__decorate([
    (0, common_1.Post)(),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], RegistrationKeyController.prototype, "generateKey", null);
__decorate([
    (0, common_1.Get)("organization/:orgId"),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)("orgId")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], RegistrationKeyController.prototype, "getKeys", null);
__decorate([
    (0, common_1.Post)(":id/revoke"),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, common_1.Param)("id")),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], RegistrationKeyController.prototype, "revokeKey", null);
exports.RegistrationKeyController = RegistrationKeyController = __decorate([
    (0, common_1.Controller)("fleet/registration-keys"),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    __param(1, (0, common_1.Inject)(tenant_repository_interface_1.IAuditLogRepositoryToken)),
    __param(2, (0, common_1.Inject)(tenant_repository_interface_1.IOrganizationRepositoryToken)),
    __param(3, (0, common_1.Inject)(mail_service_interface_1.IMailServiceToken)),
    __metadata("design:paramtypes", [registration_key_service_1.RegistrationKeyService, Object, Object, Object])
], RegistrationKeyController);
//# sourceMappingURL=registration-key.controller.js.map