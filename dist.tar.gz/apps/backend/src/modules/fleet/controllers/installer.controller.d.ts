import { Request, Response } from "express";
export declare class InstallerController {
    getWindowsInstaller(registrationKey: string, serverUrl: string, req: Request, res: Response): Promise<any>;
    downloadAgentExe(res: Response): Promise<import("@nestjs/common").StreamableFile>;
}
