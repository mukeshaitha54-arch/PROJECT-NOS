import { BulkOperationsService, BulkActionDto } from "../services/bulk-operations.service";
export declare class BulkOperationsController {
    private readonly bulkService;
    constructor(bulkService: BulkOperationsService);
    executeAction(dto: Omit<BulkActionDto, "performedByUserId">, user: any): Promise<{
        success: boolean;
        message: string;
        data: {
            updatedCount: number;
        };
    }>;
}
