import { RegistrationKeyService, CreateRegistrationKeyDto } from "../services/registration-key.service";
import { IAuditLogRepository, IOrganizationRepository } from "../../../common/repositories/tenant.repository.interface";
import { IMailService } from "../../../common/services/mail-service.interface";
export declare class RegistrationKeyController {
    private readonly registrationKeyService;
    private readonly auditLogRepo;
    private readonly orgRepo;
    private readonly mailService;
    constructor(registrationKeyService: RegistrationKeyService, auditLogRepo: IAuditLogRepository, orgRepo: IOrganizationRepository, mailService: IMailService);
    generateKey(dto: Omit<CreateRegistrationKeyDto, "createdBy">, user: any): Promise<{
        plainKey: string;
        success: boolean;
        data: {
            key: string;
            registrationKey: import("@prisma/client").RegistrationKey;
        };
        message: string;
    }>;
    getKeys(orgId: string): Promise<{
        organizationId: string;
        id: string;
        status: string;
        createdAt: Date;
        expiresAt: Date | null;
        keyPrefix: string;
        displayName: string;
        keyHash: string;
        maxUses: number;
        currentUses: number;
        allowedDepartments: string[];
        allowedTeams: string[];
        allowedGroups: string[];
        allowedTags: string[];
        createdBy: string;
        lastUsed: Date | null;
        lastUsedBy: string | null;
        lastUsedIp: string | null;
        revokedBy: string | null;
        revokedReason: string | null;
        notes: string | null;
        totalGenerated: number;
        failedAttempts: number;
        devicesCreated: number;
    }[]>;
    revokeKey(id: string, user: any): Promise<{
        success: boolean;
        data: {
            organizationId: string;
            id: string;
            status: string;
            createdAt: Date;
            expiresAt: Date | null;
            keyPrefix: string;
            displayName: string;
            keyHash: string;
            maxUses: number;
            currentUses: number;
            allowedDepartments: string[];
            allowedTeams: string[];
            allowedGroups: string[];
            allowedTags: string[];
            createdBy: string;
            lastUsed: Date | null;
            lastUsedBy: string | null;
            lastUsedIp: string | null;
            revokedBy: string | null;
            revokedReason: string | null;
            notes: string | null;
            totalGenerated: number;
            failedAttempts: number;
            devicesCreated: number;
        };
    }>;
}
