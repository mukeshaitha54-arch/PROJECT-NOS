"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SmartGroupService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../../database/prisma.service");
const device_repository_interface_1 = require("../../../common/repositories/device.repository.interface");
let SmartGroupService = class SmartGroupService {
    prisma;
    deviceRepo;
    constructor(prisma, deviceRepo) {
        this.prisma = prisma;
        this.deviceRepo = deviceRepo;
    }
    async createGroup(dto) {
        return this.prisma.smartGroup.create({
            data: {
                organizationId: dto.organizationId,
                name: dto.name,
                description: dto.description,
                rules: dto.rules,
            },
        });
    }
    async getGroups(organizationId) {
        return this.prisma.smartGroup.findMany({
            where: { organizationId },
            orderBy: { name: "asc" },
        });
    }
    async evaluateGroup(groupId) {
        const group = await this.prisma.smartGroup.findUnique({
            where: { id: groupId },
        });
        if (!group)
            throw new common_1.NotFoundException("SmartGroup not found");
        const rules = group.rules;
        const devices = await this.deviceRepo.findAll(group.organizationId);
        return devices.filter((device) => this.evaluateRules(device, rules));
    }
    evaluateRules(device, rules) {
        for (const rule of rules) {
            const fieldValue = String(device[rule.field] || "");
            switch (rule.operator) {
                case "equals":
                    if (fieldValue !== rule.value)
                        return false;
                    break;
                case "notEquals":
                    if (fieldValue === rule.value)
                        return false;
                    break;
                case "contains":
                    if (!fieldValue.includes(rule.value))
                        return false;
                    break;
                case "startsWith":
                    if (!fieldValue.startsWith(rule.value))
                        return false;
                    break;
                case "endsWith":
                    if (!fieldValue.endsWith(rule.value))
                        return false;
                    break;
            }
        }
        return true;
    }
};
exports.SmartGroupService = SmartGroupService;
exports.SmartGroupService = SmartGroupService = __decorate([
    (0, common_1.Injectable)(),
    __param(1, (0, common_1.Inject)(device_repository_interface_1.IDeviceRepositoryToken)),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService, Object])
], SmartGroupService);
//# sourceMappingURL=smart-group.service.js.map