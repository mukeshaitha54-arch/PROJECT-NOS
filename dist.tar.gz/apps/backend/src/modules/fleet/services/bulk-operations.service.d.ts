import { PrismaService } from "../../../database/prisma.service";
import { IAuditLogRepository } from "../../../common/repositories/tenant.repository.interface";
import { IDeviceRepository } from "../../../common/repositories/device.repository.interface";
import { DeviceTimelineService } from "../../device/services/device-timeline.service";
export interface BulkActionDto {
    organizationId: string;
    deviceIds: string[];
    action: "ASSIGN" | "TRANSFER" | "RETIRE" | "MAINTENANCE" | "UPDATE_TAGS" | "MOVE";
    payload?: any;
    performedByUserId: string;
}
export declare class BulkOperationsService {
    private readonly prisma;
    private readonly auditLogRepo;
    private readonly deviceRepo;
    private readonly timelineService;
    constructor(prisma: PrismaService, auditLogRepo: IAuditLogRepository, deviceRepo: IDeviceRepository, timelineService: DeviceTimelineService);
    executeBulkAction(dto: BulkActionDto): Promise<{
        updatedCount: number;
    }>;
}
