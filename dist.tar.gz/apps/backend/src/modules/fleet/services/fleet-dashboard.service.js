"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FleetDashboardService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../../database/prisma.service");
const client_1 = require("@prisma/client");
let FleetDashboardService = class FleetDashboardService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async getOrganizationTree(organizationId) {
        const devices = await this.prisma.device.findMany({
            where: { organizationId },
        });
        const ownerships = await this.prisma.deviceOwnership.findMany({
            where: { organizationId },
        });
        const ownershipMap = new Map(ownerships.map((o) => [o.deviceId, o]));
        const root = {
            id: "root",
            name: "Organization Root",
            onlineCount: 0,
            offlineCount: 0,
            totalCount: 0,
            children: [],
        };
        const branchMap = new Map();
        for (const device of devices) {
            const isOnline = device.status === client_1.DeviceStatus.ONLINE;
            root.totalCount++;
            if (isOnline)
                root.onlineCount++;
            else
                root.offlineCount++;
            const ownership = ownershipMap.get(device.id);
            const branchName = ownership?.branch || "Unassigned Branch";
            const deptName = ownership?.assignedDepartmentId || "Unassigned Department";
            const teamName = ownership?.assignedTeamId || "Unassigned Team";
            if (!branchMap.has(branchName)) {
                branchMap.set(branchName, {
                    id: `branch_${branchName}`,
                    name: branchName,
                    onlineCount: 0,
                    offlineCount: 0,
                    totalCount: 0,
                    children: [],
                });
                root.children.push(branchMap.get(branchName));
            }
            const branch = branchMap.get(branchName);
            branch.totalCount++;
            if (isOnline)
                branch.onlineCount++;
            else
                branch.offlineCount++;
            let dept = branch.children.find((c) => c.name === deptName);
            if (!dept) {
                dept = {
                    id: `dept_${branchName}_${deptName}`,
                    name: deptName,
                    onlineCount: 0,
                    offlineCount: 0,
                    totalCount: 0,
                    children: [],
                };
                branch.children.push(dept);
            }
            dept.totalCount++;
            if (isOnline)
                dept.onlineCount++;
            else
                dept.offlineCount++;
            let team = dept.children.find((c) => c.name === teamName);
            if (!team) {
                team = {
                    id: `team_${branchName}_${deptName}_${teamName}`,
                    name: teamName,
                    onlineCount: 0,
                    offlineCount: 0,
                    totalCount: 0,
                    children: [],
                };
                dept.children.push(team);
            }
            team.totalCount++;
            if (isOnline)
                team.onlineCount++;
            else
                team.offlineCount++;
        }
        return root;
    }
};
exports.FleetDashboardService = FleetDashboardService;
exports.FleetDashboardService = FleetDashboardService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], FleetDashboardService);
//# sourceMappingURL=fleet-dashboard.service.js.map