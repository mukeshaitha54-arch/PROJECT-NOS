import { IRegistrationKeyRepository } from "../../../common/repositories/registration-key.repository.interface";
import { IOrganizationRepository } from "../../../common/repositories/tenant.repository.interface";
import { RegistrationKey } from "@prisma/client";
export interface CreateRegistrationKeyDto {
    organizationId: string;
    displayName: string;
    maxUses?: number;
    expiresAt?: Date;
    allowedDepartments?: string[];
    allowedTeams?: string[];
    allowedGroups?: string[];
    allowedTags?: string[];
    createdBy: string;
}
export declare class RegistrationKeyService {
    private readonly registrationKeyRepo;
    private readonly orgRepo;
    constructor(registrationKeyRepo: IRegistrationKeyRepository, orgRepo: IOrganizationRepository);
    generateKey(dto: CreateRegistrationKeyDto): Promise<{
        key: string;
        registrationKey: RegistrationKey;
    }>;
    validateKey(plainKey: string, ipAddress?: string): Promise<RegistrationKey>;
    revokeKey(id: string, revokedBy: string, reason: string): Promise<RegistrationKey>;
    getKeysByOrganization(organizationId: string): Promise<RegistrationKey[]>;
    incrementKeyUsage(keyId: string, ipAddress?: string): Promise<void>;
}
