"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RegistrationKeyService = void 0;
const common_1 = require("@nestjs/common");
const registration_key_repository_interface_1 = require("../../../common/repositories/registration-key.repository.interface");
const tenant_repository_interface_1 = require("../../../common/repositories/tenant.repository.interface");
const crypto = require("crypto");
let RegistrationKeyService = class RegistrationKeyService {
    registrationKeyRepo;
    orgRepo;
    constructor(registrationKeyRepo, orgRepo) {
        this.registrationKeyRepo = registrationKeyRepo;
        this.orgRepo = orgRepo;
    }
    async generateKey(dto) {
        let org = dto.organizationId
            ? await this.orgRepo.findById(dto.organizationId)
            : null;
        if (!org) {
            org = await this.orgRepo.findBySlug("default-org");
            if (org) {
                dto.organizationId = org.id;
            }
            else {
                org = await this.orgRepo.create({
                    name: "Default Organization",
                    slug: "default-org",
                });
                dto.organizationId = org.id;
            }
        }
        const prefix = "NOS";
        const randomPart = crypto.randomBytes(8).toString("hex").toUpperCase();
        const plainKey = `${prefix}-${randomPart.slice(0, 4)}-${randomPart.slice(4, 8)}-${randomPart.slice(8, 12)}-${randomPart.slice(12, 16)}`;
        const keyHash = crypto.createHash("sha256").update(plainKey).digest("hex");
        const newKey = await this.registrationKeyRepo.create({
            organizationId: dto.organizationId,
            displayName: dto.displayName,
            keyHash,
            keyPrefix: plainKey.substring(0, 13) + "********",
            status: "ACTIVE",
            maxUses: dto.maxUses || 0,
            currentUses: 0,
            expiresAt: dto.expiresAt || null,
            allowedDepartments: dto.allowedDepartments || [],
            allowedTeams: dto.allowedTeams || [],
            allowedGroups: dto.allowedGroups || [],
            allowedTags: dto.allowedTags || [],
            createdBy: dto.createdBy,
            lastUsed: null,
            lastUsedBy: null,
            lastUsedIp: null,
            revokedBy: null,
            revokedReason: null,
            notes: null,
            totalGenerated: 1,
            failedAttempts: 0,
            devicesCreated: 0,
        });
        return { key: plainKey, registrationKey: newKey };
    }
    async validateKey(plainKey, ipAddress) {
        const keyHash = crypto.createHash("sha256").update(plainKey).digest("hex");
        const registrationKey = await this.registrationKeyRepo.findByHash(keyHash);
        if (!registrationKey) {
            throw new common_1.BadRequestException("Invalid registration key");
        }
        if (registrationKey.status !== "ACTIVE") {
            await this.registrationKeyRepo.recordFailedAttempt(registrationKey.id);
            throw new common_1.BadRequestException("Registration key is not active");
        }
        if (registrationKey.expiresAt && new Date() > registrationKey.expiresAt) {
            await this.registrationKeyRepo.recordFailedAttempt(registrationKey.id);
            throw new common_1.BadRequestException("Registration key has expired");
        }
        if (registrationKey.maxUses > 0 &&
            registrationKey.currentUses >= registrationKey.maxUses) {
            await this.registrationKeyRepo.recordFailedAttempt(registrationKey.id);
            throw new common_1.BadRequestException("Registration key usage limit reached");
        }
        return registrationKey;
    }
    async revokeKey(id, revokedBy, reason) {
        return this.registrationKeyRepo.update(id, {
            status: "REVOKED",
            revokedBy,
            revokedReason: reason,
        });
    }
    async getKeysByOrganization(organizationId) {
        return this.registrationKeyRepo.findByOrganizationId(organizationId);
    }
    async incrementKeyUsage(keyId, ipAddress) {
        const key = await this.registrationKeyRepo.findById(keyId);
        if (!key)
            return;
        await this.registrationKeyRepo.update(keyId, {
            currentUses: key.currentUses + 1,
            lastUsed: new Date(),
            lastUsedIp: ipAddress,
        });
    }
};
exports.RegistrationKeyService = RegistrationKeyService;
exports.RegistrationKeyService = RegistrationKeyService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(registration_key_repository_interface_1.IRegistrationKeyRepository)),
    __param(1, (0, common_1.Inject)(tenant_repository_interface_1.IOrganizationRepositoryToken)),
    __metadata("design:paramtypes", [Object, Object])
], RegistrationKeyService);
//# sourceMappingURL=registration-key.service.js.map