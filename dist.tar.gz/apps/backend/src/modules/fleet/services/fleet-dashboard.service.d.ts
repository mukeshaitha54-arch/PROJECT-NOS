import { PrismaService } from "../../../database/prisma.service";
export interface FleetTreeNode {
    id: string;
    name: string;
    onlineCount: number;
    offlineCount: number;
    totalCount: number;
    children: FleetTreeNode[];
}
export declare class FleetDashboardService {
    private readonly prisma;
    constructor(prisma: PrismaService);
    getOrganizationTree(organizationId: string): Promise<FleetTreeNode>;
}
