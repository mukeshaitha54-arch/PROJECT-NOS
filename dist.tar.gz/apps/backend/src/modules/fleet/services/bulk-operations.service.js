"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BulkOperationsService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../../database/prisma.service");
const tenant_repository_interface_1 = require("../../../common/repositories/tenant.repository.interface");
const device_repository_interface_1 = require("../../../common/repositories/device.repository.interface");
const device_timeline_service_1 = require("../../device/services/device-timeline.service");
let BulkOperationsService = class BulkOperationsService {
    prisma;
    auditLogRepo;
    deviceRepo;
    timelineService;
    constructor(prisma, auditLogRepo, deviceRepo, timelineService) {
        this.prisma = prisma;
        this.auditLogRepo = auditLogRepo;
        this.deviceRepo = deviceRepo;
        this.timelineService = timelineService;
    }
    async executeBulkAction(dto) {
        let updatedCount = 0;
        await this.prisma.$transaction(async (tx) => {
            const devices = await tx.device.findMany({
                where: {
                    id: { in: dto.deviceIds },
                    organizationId: dto.organizationId,
                },
            });
            if (devices.length === 0)
                return;
            const validDeviceIds = devices.map((d) => d.id);
            switch (dto.action) {
                case "RETIRE":
                    await tx.device.updateMany({
                        where: { id: { in: validDeviceIds } },
                        data: { status: "OFFLINE", claimStatus: "UNASSIGNED" },
                    });
                    break;
                case "MAINTENANCE":
                    const isMaintenance = dto.payload?.enabled ?? true;
                    await tx.device.updateMany({
                        where: { id: { in: validDeviceIds } },
                        data: { status: isMaintenance ? "MAINTENANCE" : "ONLINE" },
                    });
                    break;
                case "ASSIGN":
                case "MOVE":
                case "TRANSFER":
                    for (const deviceId of validDeviceIds) {
                        await tx.deviceOwnership.upsert({
                            where: { deviceId },
                            update: {
                                assignedTeamId: dto.payload?.team,
                                assignedDepartmentId: dto.payload?.department,
                                branch: dto.payload?.branch,
                            },
                            create: {
                                deviceId,
                                organizationId: dto.organizationId,
                                assignedTeamId: dto.payload?.team,
                                assignedDepartmentId: dto.payload?.department,
                                branch: dto.payload?.branch,
                                criticality: "MEDIUM",
                                environment: "PRODUCTION",
                                purpose: "GENERAL",
                            },
                        });
                    }
                    break;
                case "UPDATE_TAGS":
                    for (const deviceId of validDeviceIds) {
                        await tx.deviceOwnership.updateMany({
                            where: { deviceId },
                            data: {
                                purpose: dto.payload?.tags?.[0] || "GENERAL",
                            },
                        });
                    }
                    break;
            }
            updatedCount = validDeviceIds.length;
            await this.auditLogRepo.record({
                organizationId: dto.organizationId,
                correlationId: "N/A",
                userId: dto.performedByUserId,
                userEmail: "bulk-action@system.local",
                action: `BULK_DEVICE_${dto.action}`,
                resourceType: "DeviceBulk",
                resourceId: "multiple",
                reason: dto.payload?.reason || "Bulk operation via dashboard",
                ipAddress: "unknown",
                browser: "api",
                details: {
                    deviceCount: updatedCount,
                    deviceIds: validDeviceIds,
                    payload: dto.payload,
                },
            });
            for (const deviceId of validDeviceIds) {
                await tx.deviceTimelineEvent.create({
                    data: {
                        deviceId,
                        eventType: "SYSTEM_EVENT",
                        severity: "INFO",
                        title: `Bulk Action: ${dto.action}`,
                        detail: `Device modified via bulk ${dto.action} operation by operator.`,
                        actorId: dto.performedByUserId,
                        metadata: dto.payload || {},
                    },
                });
            }
        });
        return { updatedCount };
    }
};
exports.BulkOperationsService = BulkOperationsService;
exports.BulkOperationsService = BulkOperationsService = __decorate([
    (0, common_1.Injectable)(),
    __param(1, (0, common_1.Inject)(tenant_repository_interface_1.IAuditLogRepositoryToken)),
    __param(2, (0, common_1.Inject)(device_repository_interface_1.IDeviceRepositoryToken)),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService, Object, Object, device_timeline_service_1.DeviceTimelineService])
], BulkOperationsService);
//# sourceMappingURL=bulk-operations.service.js.map