import { PrismaService } from "../../../database/prisma.service";
export interface HealthPills {
    healthy: number;
    warning: number;
    offline: number;
}
export interface HierarchyNode {
    name: string;
    type: string;
    totalDevices: number;
    health: HealthPills;
    children: HierarchyNode[];
}
export declare class HierarchyService {
    private readonly prisma;
    constructor(prisma: PrismaService);
    getHierarchy(organizationId: string): Promise<HierarchyNode>;
    private calculateHealth;
}
