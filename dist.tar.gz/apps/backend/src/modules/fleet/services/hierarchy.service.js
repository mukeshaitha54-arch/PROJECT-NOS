"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.HierarchyService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../../database/prisma.service");
const client_1 = require("@prisma/client");
let HierarchyService = class HierarchyService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async getHierarchy(organizationId) {
        const org = await this.prisma.organization.findUnique({
            where: { id: organizationId },
        });
        if (!org)
            throw new Error("Organization not found");
        const devicesRaw = await this.prisma.device.findMany({
            where: { organizationId },
        });
        const ownerships = await this.prisma.deviceOwnership.findMany({
            where: { deviceId: { in: devicesRaw.map((d) => d.id) } },
        });
        const devices = devicesRaw.map((d) => ({
            ...d,
            ownership: ownerships.find((o) => o.deviceId === d.id),
        }));
        const departments = await this.prisma.department.findMany({
            where: { organizationId },
        });
        const teams = await this.prisma.team.findMany({
            where: { organizationId },
        });
        const orgNode = {
            name: org.name,
            type: "Organization",
            totalDevices: devices.length,
            health: this.calculateHealth(devices),
            children: [],
        };
        const branchNames = Array.from(new Set(devices
            .map((d) => d.ownership?.branch)
            .filter((b) => !!b && b.trim().length > 0)));
        if (branchNames.length === 0) {
            branchNames.push("Main Office");
        }
        for (const branch of branchNames) {
            const branchDevices = devices.filter((d) => d.ownership?.branch === branch ||
                (branch === "Main Office" && !d.ownership?.branch));
            const branchNode = {
                name: branch,
                type: "Branch",
                totalDevices: branchDevices.length,
                health: this.calculateHealth(branchDevices),
                children: [],
            };
            for (const dept of departments) {
                const deptDevices = branchDevices.filter((d) => d.ownership?.assignedDepartmentId === dept.id);
                const deptTeams = teams.filter((t) => t.departmentId === dept.id);
                const deptNode = {
                    name: dept.name,
                    type: "Department",
                    totalDevices: deptDevices.length,
                    health: { healthy: 0, warning: 0, offline: 0 },
                    children: [],
                };
                let deptDevicesAggregated = [...deptDevices];
                for (const team of deptTeams) {
                    const teamDevices = branchDevices.filter((d) => d.ownership?.assignedTeamId === team.id);
                    if (teamDevices.length > 0) {
                        teamDevices.forEach((td) => {
                            if (!deptDevicesAggregated.find((d) => d.id === td.id)) {
                                deptDevicesAggregated.push(td);
                            }
                        });
                    }
                    deptNode.children.push({
                        name: team.name,
                        type: "Team",
                        totalDevices: teamDevices.length,
                        health: this.calculateHealth(teamDevices),
                        children: [],
                    });
                }
                if (deptDevicesAggregated.length > 0 || deptNode.children.length > 0) {
                    deptNode.totalDevices = deptDevicesAggregated.length;
                    deptNode.health = this.calculateHealth(deptDevicesAggregated);
                    branchNode.children.push(deptNode);
                }
            }
            const unassignedDevices = branchDevices.filter((d) => !d.ownership?.assignedDepartmentId && !d.ownership?.assignedTeamId);
            if (unassignedDevices.length > 0) {
                branchNode.children.push({
                    name: "Unassigned",
                    type: "Department",
                    totalDevices: unassignedDevices.length,
                    health: this.calculateHealth(unassignedDevices),
                    children: [],
                });
            }
            if (branchNode.totalDevices > 0 || branchNode.children.length > 0) {
                orgNode.children.push(branchNode);
            }
        }
        if (orgNode.children.length === 0 && devices.length > 0) {
            orgNode.children.push({
                name: "Main Office",
                type: "Branch",
                totalDevices: devices.length,
                health: this.calculateHealth(devices),
                children: [
                    {
                        name: "Unassigned",
                        type: "Department",
                        totalDevices: devices.length,
                        health: this.calculateHealth(devices),
                        children: [],
                    },
                ],
            });
        }
        return orgNode;
    }
    calculateHealth(devices) {
        return devices.reduce((acc, dev) => {
            if (dev.status === client_1.DeviceStatus.ONLINE)
                acc.healthy++;
            else if (dev.status === client_1.DeviceStatus.OFFLINE)
                acc.offline++;
            else
                acc.warning++;
            return acc;
        }, { healthy: 0, warning: 0, offline: 0 });
    }
};
exports.HierarchyService = HierarchyService;
exports.HierarchyService = HierarchyService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], HierarchyService);
//# sourceMappingURL=hierarchy.service.js.map