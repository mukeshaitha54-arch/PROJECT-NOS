import { IUserRepository } from "../../../common/repositories/user.repository.interface";
import { IDeviceRepository } from "../../../common/repositories/device.repository.interface";
import { IAlertRepository } from "../../../common/repositories/alert.repository.interface";
import { IInventoryRepository } from "../../../common/repositories/inventory.repository.interface";
export interface SearchResult {
    type: string;
    id: string;
    title: string;
    subtitle?: string;
    metadata?: any;
}
export declare class SearchService {
    private readonly userRepo;
    private readonly deviceRepo;
    private readonly alertRepo;
    private readonly inventoryRepo;
    constructor(userRepo: IUserRepository, deviceRepo: IDeviceRepository, alertRepo: IAlertRepository, inventoryRepo: IInventoryRepository);
    globalSearch(query: string, organizationId: string): Promise<SearchResult[]>;
}
