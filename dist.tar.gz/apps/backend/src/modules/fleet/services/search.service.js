"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SearchService = void 0;
const common_1 = require("@nestjs/common");
const user_repository_interface_1 = require("../../../common/repositories/user.repository.interface");
const device_repository_interface_1 = require("../../../common/repositories/device.repository.interface");
const alert_repository_interface_1 = require("../../../common/repositories/alert.repository.interface");
const inventory_repository_interface_1 = require("../../../common/repositories/inventory.repository.interface");
let SearchService = class SearchService {
    userRepo;
    deviceRepo;
    alertRepo;
    inventoryRepo;
    constructor(userRepo, deviceRepo, alertRepo, inventoryRepo) {
        this.userRepo = userRepo;
        this.deviceRepo = deviceRepo;
        this.alertRepo = alertRepo;
        this.inventoryRepo = inventoryRepo;
    }
    async globalSearch(query, organizationId) {
        if (!query || query.length < 2) {
            return [];
        }
        const [users, devices, alerts, inventories] = await Promise.all([
            this.userRepo.search(query, organizationId).catch(() => []),
            this.deviceRepo.search(query, organizationId).catch(() => []),
            this.alertRepo.search(query, organizationId).catch(() => []),
            this.inventoryRepo.search(query, organizationId).catch(() => []),
        ]);
        const results = [];
        for (const user of users) {
            results.push({
                type: "USER",
                id: user.id,
                title: `${user.firstName} ${user.lastName}`,
                subtitle: user.email,
                metadata: { role: user.role },
            });
        }
        for (const device of devices) {
            results.push({
                type: "DEVICE",
                id: device.id,
                title: device.hostname,
                subtitle: device.os,
                metadata: { status: device.status },
            });
        }
        for (const alert of alerts) {
            results.push({
                type: "ALERT",
                id: alert.id,
                title: alert.title,
                subtitle: alert.incidentNumber,
                metadata: { severity: alert.severity, status: alert.status },
            });
        }
        for (const inv of inventories) {
            results.push({
                type: "INVENTORY",
                id: inv.id,
                title: `${inv.manufacturer} ${inv.model}`,
                subtitle: inv.serialNumber,
                metadata: { deviceId: inv.deviceId },
            });
        }
        return results.sort((a, b) => a.title.localeCompare(b.title));
    }
};
exports.SearchService = SearchService;
exports.SearchService = SearchService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(user_repository_interface_1.IUserRepositoryToken)),
    __param(1, (0, common_1.Inject)(device_repository_interface_1.IDeviceRepositoryToken)),
    __param(2, (0, common_1.Inject)(alert_repository_interface_1.IAlertRepository)),
    __param(3, (0, common_1.Inject)(inventory_repository_interface_1.IInventoryRepository)),
    __metadata("design:paramtypes", [Object, Object, Object, Object])
], SearchService);
//# sourceMappingURL=search.service.js.map