import { PrismaService } from "../../../database/prisma.service";
import { IDeviceRepository } from "../../../common/repositories/device.repository.interface";
import { Device } from "@prisma/client";
export interface SmartGroupRule {
    field: string;
    operator: "equals" | "contains" | "startsWith" | "endsWith" | "notEquals";
    value: string;
}
export interface CreateSmartGroupDto {
    organizationId: string;
    name: string;
    description?: string;
    rules: SmartGroupRule[];
}
export declare class SmartGroupService {
    private readonly prisma;
    private readonly deviceRepo;
    constructor(prisma: PrismaService, deviceRepo: IDeviceRepository);
    createGroup(dto: CreateSmartGroupDto): Promise<{
        description: string | null;
        organizationId: string;
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date;
        rules: import("@prisma/client/runtime/library").JsonValue;
    }>;
    getGroups(organizationId: string): Promise<{
        description: string | null;
        organizationId: string;
        id: string;
        name: string;
        createdAt: Date;
        updatedAt: Date;
        rules: import("@prisma/client/runtime/library").JsonValue;
    }[]>;
    evaluateGroup(groupId: string): Promise<Device[]>;
    private evaluateRules;
}
