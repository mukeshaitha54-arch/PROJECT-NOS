export declare class FleetModule {
}
