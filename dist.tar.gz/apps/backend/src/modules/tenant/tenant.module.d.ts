export declare class TenantModule {
}
