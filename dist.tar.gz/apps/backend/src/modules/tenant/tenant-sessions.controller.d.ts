import { TenantSessionsService } from "./tenant-sessions.service";
export declare class TenantSessionsController {
    private readonly sessionsService;
    constructor(sessionsService: TenantSessionsService);
    getActiveSessions(): Promise<{
        success: boolean;
        data: {
            sessions: {
                userId: string;
                name: any;
                email: any;
                role: any;
                lastActive: any;
                ipAddress: any;
                userAgent: any;
            }[];
        };
    }>;
}
