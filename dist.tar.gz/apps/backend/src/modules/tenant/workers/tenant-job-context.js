"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TenantJobContext = void 0;
const common_1 = require("@nestjs/common");
class TenantJobContext {
    static logger = new common_1.Logger("TenantJobContext");
    static wrapPayload(payload, context) {
        return {
            tenantContext: {
                organizationId: context?.organizationId || "default-org",
                correlationId: context?.correlationId || `worker-${Date.now()}`,
                requestId: context?.requestId || `req-${Date.now()}`,
                userId: context?.userId,
            },
            data: payload,
        };
    }
    static extractContext(jobData) {
        if (jobData?.tenantContext && jobData.tenantContext.organizationId) {
            return jobData.tenantContext;
        }
        this.logger.debug("Job payload lacking explicit tenantContext; using default backward-compatible context.");
        return {
            organizationId: jobData?.organizationId || "default-org",
            correlationId: jobData?.correlationId || "job-no-corr-id",
            requestId: jobData?.requestId || "job-no-req-id",
        };
    }
}
exports.TenantJobContext = TenantJobContext;
//# sourceMappingURL=tenant-job-context.js.map