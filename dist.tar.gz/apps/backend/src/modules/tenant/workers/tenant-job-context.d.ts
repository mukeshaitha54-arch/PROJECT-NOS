import { TenantContext } from "@nos/shared-types";
export interface TenantAwareJobPayload<T = any> {
    tenantContext: TenantContext;
    data: T;
}
export declare class TenantJobContext {
    private static readonly logger;
    static wrapPayload<T>(payload: T, context?: Partial<TenantContext>): TenantAwareJobPayload<T>;
    static extractContext<T>(jobData: TenantAwareJobPayload<T> | any): TenantContext;
}
