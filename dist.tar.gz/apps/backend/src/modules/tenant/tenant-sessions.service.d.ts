import { PrismaService } from "../prisma/prisma.service";
export declare class TenantSessionsService {
    private readonly prisma;
    private readonly logger;
    constructor(prisma: PrismaService);
    getActiveSessions(): Promise<{
        success: boolean;
        data: {
            sessions: {
                userId: string;
                name: any;
                email: any;
                role: any;
                lastActive: any;
                ipAddress: any;
                userAgent: any;
            }[];
        };
    }>;
}
