"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrganizationInvitationController = void 0;
const openapi = require("@nestjs/swagger");
const common_1 = require("@nestjs/common");
const organization_invitation_service_1 = require("../services/organization-invitation.service");
const jwt_auth_guard_1 = require("../../../common/guards/jwt-auth.guard");
const current_user_decorator_1 = require("../../../common/decorators/current-user.decorator");
let OrganizationInvitationController = class OrganizationInvitationController {
    invitationService;
    constructor(invitationService) {
        this.invitationService = invitationService;
    }
    async invite(organizationId, email, role, teamIds, departmentIds, user) {
        const result = await this.invitationService.inviteMember({
            organizationId,
            email,
            role,
            teamIds,
            departmentIds,
            invitedByUserId: user.id,
        });
        return {
            success: true,
            message: "Invitation sent successfully.",
            data: result,
        };
    }
    async accept(token, user) {
        const member = await this.invitationService.acceptInvitation(token, user.id);
        return {
            success: true,
            message: "Invitation accepted successfully. You are now a member of the organization.",
            data: member,
        };
    }
};
exports.OrganizationInvitationController = OrganizationInvitationController;
__decorate([
    (0, common_1.Post)("invite"),
    (0, common_1.HttpCode)(common_1.HttpStatus.CREATED),
    openapi.ApiResponse({ status: common_1.HttpStatus.CREATED }),
    __param(0, (0, common_1.Body)("organizationId")),
    __param(1, (0, common_1.Body)("email")),
    __param(2, (0, common_1.Body)("role")),
    __param(3, (0, common_1.Body)("teamIds")),
    __param(4, (0, common_1.Body)("departmentIds")),
    __param(5, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, Array, Array, Object]),
    __metadata("design:returntype", Promise)
], OrganizationInvitationController.prototype, "invite", null);
__decorate([
    (0, common_1.Post)("accept"),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    openapi.ApiResponse({ status: common_1.HttpStatus.OK }),
    __param(0, (0, common_1.Body)("token")),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], OrganizationInvitationController.prototype, "accept", null);
exports.OrganizationInvitationController = OrganizationInvitationController = __decorate([
    (0, common_1.Controller)("tenant/invitations"),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    __metadata("design:paramtypes", [organization_invitation_service_1.OrganizationInvitationService])
], OrganizationInvitationController);
//# sourceMappingURL=organization-invitation.controller.js.map