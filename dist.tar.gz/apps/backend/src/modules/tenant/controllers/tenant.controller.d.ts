import { UserRole, ApiResponse, OrganizationDto, OrganizationStatus, OrganizationSettingsDto, DepartmentDto, TeamDto, OrganizationMemberDto, OrganizationInvitationDto, ApiKeyDto, ApiKeyCreateRequestDto, AuditSearchRequestDto, AuditSearchResultDto, PermissionMatrixDto, PermissionProfileDto, DeviceGroupDto, DeviceTransferRequestDto, DeviceTransferStatus, TenantContext, UserSessionDto } from "@nos/shared-types";
import { OrganizationService } from "../services/organization.service";
import { UserGovernanceService } from "../services/user-governance.service";
import { ApiKeyService } from "../services/api-key.service";
import { AuditEngineService } from "../services/audit-engine.service";
import { DeviceGovernanceService } from "../services/device-governance.service";
import { RbacEvaluationService } from "../services/rbac-evaluation.service";
import { TenantScoresService, TenantHealthReport } from "../services/tenant-scores.service";
export declare class TenantController {
    private readonly orgService;
    private readonly userService;
    private readonly apiKeyService;
    private readonly auditService;
    private readonly deviceGovernanceService;
    private readonly rbacService;
    private readonly scoresService;
    constructor(orgService: OrganizationService, userService: UserGovernanceService, apiKeyService: ApiKeyService, auditService: AuditEngineService, deviceGovernanceService: DeviceGovernanceService, rbacService: RbacEvaluationService, scoresService: TenantScoresService);
    getOrganization(id: string): Promise<ApiResponse<OrganizationDto>>;
    createOrganization(body: any, tenant: TenantContext): Promise<ApiResponse<OrganizationDto>>;
    updateStatus(id: string, body: {
        status: OrganizationStatus;
        reason?: string;
    }, tenant: TenantContext): Promise<ApiResponse<OrganizationDto>>;
    updateSettings(id: string, body: OrganizationSettingsDto, tenant: TenantContext): Promise<ApiResponse<OrganizationDto>>;
    softDelete(id: string, body: {
        reason?: string;
    }, tenant: TenantContext): Promise<ApiResponse<void>>;
    restoreOrganization(id: string, body: {
        reason?: string;
    }, tenant: TenantContext): Promise<ApiResponse<OrganizationDto>>;
    getHealthScore(id: string): Promise<ApiResponse<TenantHealthReport>>;
    createDepartment(body: {
        name: string;
        description?: string;
        headUserId?: string;
    }, tenant: TenantContext): Promise<ApiResponse<DepartmentDto>>;
    listDepartments(tenant: TenantContext): Promise<ApiResponse<DepartmentDto[]>>;
    createTeam(body: {
        name: string;
        departmentId?: string;
        description?: string;
        leadUserId?: string;
    }, tenant: TenantContext): Promise<ApiResponse<TeamDto>>;
    listTeams(tenant: TenantContext): Promise<ApiResponse<TeamDto[]>>;
    listMembers(query: any, tenant: TenantContext): Promise<ApiResponse<{
        items: OrganizationMemberDto[];
        total: number;
    }>>;
    inviteMember(body: {
        email: string;
        role: UserRole;
        teamIds?: string[];
        departmentIds?: string[];
    }, tenant: TenantContext): Promise<ApiResponse<{
        invitation: OrganizationInvitationDto;
        inviteLink: string;
    }>>;
    importCsv(body: {
        csvContent: string;
    }, tenant: TenantContext): Promise<ApiResponse<{
        total: number;
        success: number;
        errors: any[];
    }>>;
    removeMember(userId: string, body: {
        reason?: string;
    }, tenant: TenantContext): Promise<ApiResponse<void>>;
    impersonate(body: {
        targetUserId: string;
        reason: string;
    }, tenant: TenantContext): Promise<ApiResponse<{
        impersonationToken: string;
        targetUserId: string;
        expiresAt: string;
    }>>;
    listApiKeys(query: any, tenant: TenantContext): Promise<ApiResponse<{
        items: ApiKeyDto[];
        total: number;
    }>>;
    createApiKey(body: ApiKeyCreateRequestDto, tenant: TenantContext): Promise<ApiResponse<{
        apiKey: ApiKeyDto;
        plainKey: string;
    }>>;
    revokeApiKey(id: string, body: {
        reason?: string;
    }, tenant: TenantContext): Promise<ApiResponse<void>>;
    searchAudit(body: AuditSearchRequestDto, tenant: TenantContext): Promise<ApiResponse<AuditSearchResultDto>>;
    listSessions(tenant: TenantContext): Promise<ApiResponse<UserSessionDto[]>>;
    revokeSession(id: string, tenant: TenantContext): Promise<ApiResponse<void>>;
    getRbacMatrix(tenant: TenantContext): Promise<ApiResponse<PermissionMatrixDto>>;
    createPermissionProfile(body: {
        name: string;
        permissions: string[];
        description?: string;
        abacConditions?: any;
    }, tenant: TenantContext): Promise<ApiResponse<PermissionProfileDto>>;
    listPermissionProfiles(tenant: TenantContext): Promise<ApiResponse<PermissionProfileDto[]>>;
    createDeviceGroup(body: {
        name: string;
        groupType: string;
        description?: string;
        filterCriteria?: any;
        deviceIds?: string[];
    }, tenant: TenantContext): Promise<ApiResponse<DeviceGroupDto>>;
    listDeviceGroups(tenant: TenantContext): Promise<ApiResponse<DeviceGroupDto[]>>;
    createTransferRequest(body: {
        deviceId: string;
        toOrganizationId: string;
        reason: string;
    }, tenant: TenantContext): Promise<ApiResponse<DeviceTransferRequestDto>>;
    resolveTransferRequest(id: string, body: {
        status: DeviceTransferStatus;
    }, tenant: TenantContext): Promise<ApiResponse<DeviceTransferRequestDto>>;
}
