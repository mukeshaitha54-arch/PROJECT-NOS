import { OrganizationInvitationService } from "../services/organization-invitation.service";
export declare class OrganizationInvitationController {
    private readonly invitationService;
    constructor(invitationService: OrganizationInvitationService);
    invite(organizationId: string, email: string, role?: string, teamIds?: string[], departmentIds?: string[], user?: any): Promise<{
        success: boolean;
        message: string;
        data: {
            invitationId: string;
            token: string;
        };
    }>;
    accept(token: string, user?: any): Promise<{
        success: boolean;
        message: string;
        data: {
            userId: string;
            role: string;
            organizationId: string;
            id: string;
            updatedAt: Date;
            customRoleId: string | null;
            teamIds: string[];
            departmentIds: string[];
            isSuspended: boolean;
            joinedAt: Date;
        };
    }>;
}
