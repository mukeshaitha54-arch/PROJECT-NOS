"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TenantController = void 0;
const openapi = require("@nestjs/swagger");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const jwt_auth_guard_1 = require("../../../common/guards/jwt-auth.guard");
const roles_guard_1 = require("../../../common/guards/roles.guard");
const tenant_context_guard_1 = require("../../../common/guards/tenant-context.guard");
const rbac_permission_guard_1 = require("../../../common/guards/rbac-permission.guard");
const roles_decorator_1 = require("../../../common/decorators/roles.decorator");
const current_tenant_decorator_1 = require("../../../common/decorators/current-tenant.decorator");
const require_permissions_decorator_1 = require("../../../common/decorators/require-permissions.decorator");
const shared_types_1 = require("@nos/shared-types");
const organization_service_1 = require("../services/organization.service");
const user_governance_service_1 = require("../services/user-governance.service");
const api_key_service_1 = require("../services/api-key.service");
const audit_engine_service_1 = require("../services/audit-engine.service");
const device_governance_service_1 = require("../services/device-governance.service");
const rbac_evaluation_service_1 = require("../services/rbac-evaluation.service");
const tenant_scores_service_1 = require("../services/tenant-scores.service");
let TenantController = class TenantController {
    orgService;
    userService;
    apiKeyService;
    auditService;
    deviceGovernanceService;
    rbacService;
    scoresService;
    constructor(orgService, userService, apiKeyService, auditService, deviceGovernanceService, rbacService, scoresService) {
        this.orgService = orgService;
        this.userService = userService;
        this.apiKeyService = apiKeyService;
        this.auditService = auditService;
        this.deviceGovernanceService = deviceGovernanceService;
        this.rbacService = rbacService;
        this.scoresService = scoresService;
    }
    async getOrganization(id) {
        const data = await this.orgService.getById(id);
        return { success: true, data, timestamp: new Date().toISOString() };
    }
    async createOrganization(body, tenant) {
        const data = await this.orgService.create(body, tenant);
        return { success: true, data, timestamp: new Date().toISOString() };
    }
    async updateStatus(id, body, tenant) {
        const data = await this.orgService.updateStatus(id, body.status, tenant, body.reason);
        return { success: true, data, timestamp: new Date().toISOString() };
    }
    async updateSettings(id, body, tenant) {
        const data = await this.orgService.updateSettings(id, body, tenant);
        return { success: true, data, timestamp: new Date().toISOString() };
    }
    async softDelete(id, body, tenant) {
        await this.orgService.softDelete(id, tenant, body?.reason || "Deleted by admin");
        return { success: true, timestamp: new Date().toISOString() };
    }
    async restoreOrganization(id, body, tenant) {
        const data = await this.orgService.restore(id, tenant, body?.reason || "Restored by admin");
        return { success: true, data, timestamp: new Date().toISOString() };
    }
    async getHealthScore(id) {
        const data = await this.scoresService.evaluateHealth(id);
        return { success: true, data, timestamp: new Date().toISOString() };
    }
    async createDepartment(body, tenant) {
        const data = await this.userService.createDepartment(tenant.organizationId, body.name, body.description, body.headUserId);
        return { success: true, data, timestamp: new Date().toISOString() };
    }
    async listDepartments(tenant) {
        const data = await this.userService.listDepartments(tenant.organizationId);
        return { success: true, data, timestamp: new Date().toISOString() };
    }
    async createTeam(body, tenant) {
        const data = await this.userService.createTeam(tenant.organizationId, body.name, body.departmentId, body.description, body.leadUserId);
        return { success: true, data, timestamp: new Date().toISOString() };
    }
    async listTeams(tenant) {
        const data = await this.userService.listTeams(tenant.organizationId);
        return { success: true, data, timestamp: new Date().toISOString() };
    }
    async listMembers(query, tenant) {
        const data = await this.userService.listMembers(tenant.organizationId, query);
        return { success: true, data, timestamp: new Date().toISOString() };
    }
    async inviteMember(body, tenant) {
        const data = await this.userService.inviteUser(tenant.organizationId, body.email, body.role, tenant, body.teamIds, body.departmentIds);
        return { success: true, data, timestamp: new Date().toISOString() };
    }
    async importCsv(body, tenant) {
        const data = await this.userService.importUsersFromCsv(tenant.organizationId, body.csvContent, tenant);
        return { success: true, data, timestamp: new Date().toISOString() };
    }
    async removeMember(userId, body, tenant) {
        await this.userService.removeMember(tenant.organizationId, userId, tenant, body?.reason);
        return { success: true, timestamp: new Date().toISOString() };
    }
    async impersonate(body, tenant) {
        const data = await this.userService.impersonateUser(tenant.organizationId, body.targetUserId, body.reason, tenant);
        return { success: true, data, timestamp: new Date().toISOString() };
    }
    async listApiKeys(query, tenant) {
        const data = await this.apiKeyService.list(tenant.organizationId, query);
        return { success: true, data, timestamp: new Date().toISOString() };
    }
    async createApiKey(body, tenant) {
        const data = await this.apiKeyService.generate(tenant.organizationId, tenant.userId || "system", body, tenant);
        return { success: true, data, timestamp: new Date().toISOString() };
    }
    async revokeApiKey(id, body, tenant) {
        await this.apiKeyService.revoke(tenant.organizationId, id, tenant, body?.reason);
        return { success: true, timestamp: new Date().toISOString() };
    }
    async searchAudit(body, tenant) {
        const data = await this.auditService.search({
            ...body,
            organizationId: tenant.organizationId,
        });
        return { success: true, data, timestamp: new Date().toISOString() };
    }
    async listSessions(tenant) {
        const data = await this.userService.listActiveSessions(tenant.organizationId);
        return { success: true, data, timestamp: new Date().toISOString() };
    }
    async revokeSession(id, tenant) {
        await this.userService.revokeSession(tenant.organizationId, id, tenant, "Admin revoked session via dashboard");
        return { success: true, timestamp: new Date().toISOString() };
    }
    async getRbacMatrix(tenant) {
        const data = await this.rbacService.getPermissionMatrix(tenant.organizationId);
        return { success: true, data, timestamp: new Date().toISOString() };
    }
    async createPermissionProfile(body, tenant) {
        const data = await this.deviceGovernanceService.createPermissionProfile(tenant.organizationId, body.name, body.permissions, body.description, body.abacConditions);
        return { success: true, data, timestamp: new Date().toISOString() };
    }
    async listPermissionProfiles(tenant) {
        const data = await this.deviceGovernanceService.listPermissionProfiles(tenant.organizationId);
        return { success: true, data, timestamp: new Date().toISOString() };
    }
    async createDeviceGroup(body, tenant) {
        const data = await this.deviceGovernanceService.createDeviceGroup(tenant.organizationId, body.name, body.groupType, tenant, body.description, body.filterCriteria, body.deviceIds);
        return { success: true, data, timestamp: new Date().toISOString() };
    }
    async listDeviceGroups(tenant) {
        const data = await this.deviceGovernanceService.listDeviceGroups(tenant.organizationId);
        return { success: true, data, timestamp: new Date().toISOString() };
    }
    async createTransferRequest(body, tenant) {
        const data = await this.deviceGovernanceService.createTransferRequest(body.deviceId, tenant.organizationId, body.toOrganizationId, body.reason, tenant);
        return { success: true, data, timestamp: new Date().toISOString() };
    }
    async resolveTransferRequest(id, body, tenant) {
        const data = await this.deviceGovernanceService.resolveTransferRequest(id, body.status, tenant);
        return { success: true, data, timestamp: new Date().toISOString() };
    }
};
exports.TenantController = TenantController;
__decorate([
    (0, common_1.Get)("organization/:id"),
    (0, swagger_1.ApiOperation)({
        summary: "Get organization details and real-time quota usage",
    }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)("id")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], TenantController.prototype, "getOrganization", null);
__decorate([
    (0, common_1.Post)("organization"),
    (0, roles_decorator_1.Roles)(shared_types_1.UserRole.SUPER_ADMIN, shared_types_1.UserRole.OWNER),
    (0, swagger_1.ApiOperation)({ summary: "Create new enterprise organization tenant" }),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_tenant_decorator_1.CurrentTenant)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], TenantController.prototype, "createOrganization", null);
__decorate([
    (0, common_1.Put)("organization/:id/status"),
    (0, roles_decorator_1.Roles)(shared_types_1.UserRole.SUPER_ADMIN, shared_types_1.UserRole.OWNER),
    (0, swagger_1.ApiOperation)({
        summary: "Update organization status (ACTIVE, SUSPENDED, ARCHIVED)",
    }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)("id")),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_tenant_decorator_1.CurrentTenant)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], TenantController.prototype, "updateStatus", null);
__decorate([
    (0, common_1.Put)("organization/:id/settings"),
    (0, require_permissions_decorator_1.RequirePermissions)(shared_types_1.PermissionFlag.SETTINGS_MANAGE),
    (0, swagger_1.ApiOperation)({
        summary: "Update organization security and general settings",
    }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)("id")),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_tenant_decorator_1.CurrentTenant)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], TenantController.prototype, "updateSettings", null);
__decorate([
    (0, common_1.Delete)("organization/:id"),
    (0, roles_decorator_1.Roles)(shared_types_1.UserRole.SUPER_ADMIN, shared_types_1.UserRole.OWNER),
    (0, swagger_1.ApiOperation)({ summary: "Soft delete enterprise organization tenant" }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)("id")),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_tenant_decorator_1.CurrentTenant)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], TenantController.prototype, "softDelete", null);
__decorate([
    (0, common_1.Post)("organization/:id/restore"),
    (0, roles_decorator_1.Roles)(shared_types_1.UserRole.SUPER_ADMIN, shared_types_1.UserRole.OWNER),
    (0, swagger_1.ApiOperation)({ summary: "Restore soft-deleted enterprise organization" }),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, common_1.Param)("id")),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_tenant_decorator_1.CurrentTenant)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], TenantController.prototype, "restoreOrganization", null);
__decorate([
    (0, common_1.Get)("organization/:id/health-score"),
    (0, require_permissions_decorator_1.RequirePermissions)(shared_types_1.PermissionFlag.SETTINGS_MANAGE),
    (0, swagger_1.ApiOperation)({
        summary: "Retrieve comprehensive real-time Organization Health Score report",
    }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)("id")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], TenantController.prototype, "getHealthScore", null);
__decorate([
    (0, common_1.Post)("departments"),
    (0, require_permissions_decorator_1.RequirePermissions)(shared_types_1.PermissionFlag.TEAMS_MANAGE),
    (0, swagger_1.ApiOperation)({ summary: "Create department under current tenant" }),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_tenant_decorator_1.CurrentTenant)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], TenantController.prototype, "createDepartment", null);
__decorate([
    (0, common_1.Get)("departments"),
    (0, require_permissions_decorator_1.RequirePermissions)(shared_types_1.PermissionFlag.TEAMS_MANAGE, shared_types_1.PermissionFlag.USERS_MANAGE),
    (0, swagger_1.ApiOperation)({ summary: "List all departments in current organization" }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, current_tenant_decorator_1.CurrentTenant)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], TenantController.prototype, "listDepartments", null);
__decorate([
    (0, common_1.Post)("teams"),
    (0, require_permissions_decorator_1.RequirePermissions)(shared_types_1.PermissionFlag.TEAMS_MANAGE),
    (0, swagger_1.ApiOperation)({ summary: "Create team within department" }),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_tenant_decorator_1.CurrentTenant)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], TenantController.prototype, "createTeam", null);
__decorate([
    (0, common_1.Get)("teams"),
    (0, require_permissions_decorator_1.RequirePermissions)(shared_types_1.PermissionFlag.TEAMS_MANAGE, shared_types_1.PermissionFlag.USERS_MANAGE),
    (0, swagger_1.ApiOperation)({ summary: "List all teams in organization" }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, current_tenant_decorator_1.CurrentTenant)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], TenantController.prototype, "listTeams", null);
__decorate([
    (0, common_1.Get)("members"),
    (0, require_permissions_decorator_1.RequirePermissions)(shared_types_1.PermissionFlag.USERS_MANAGE),
    (0, swagger_1.ApiOperation)({
        summary: "List organization members with role filtering and pagination",
    }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_tenant_decorator_1.CurrentTenant)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], TenantController.prototype, "listMembers", null);
__decorate([
    (0, common_1.Post)("members/invite"),
    (0, require_permissions_decorator_1.RequirePermissions)(shared_types_1.PermissionFlag.USERS_MANAGE),
    (0, swagger_1.ApiOperation)({
        summary: "Invite new member via email with quota validation",
    }),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_tenant_decorator_1.CurrentTenant)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], TenantController.prototype, "inviteMember", null);
__decorate([
    (0, common_1.Post)("members/import-csv"),
    (0, require_permissions_decorator_1.RequirePermissions)(shared_types_1.PermissionFlag.USERS_MANAGE),
    (0, swagger_1.ApiOperation)({ summary: "Bulk invite users from CSV formatted payload" }),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_tenant_decorator_1.CurrentTenant)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], TenantController.prototype, "importCsv", null);
__decorate([
    (0, common_1.Delete)("members/:userId"),
    (0, require_permissions_decorator_1.RequirePermissions)(shared_types_1.PermissionFlag.USERS_MANAGE),
    (0, swagger_1.ApiOperation)({ summary: "Remove user member and revoke active sessions" }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)("userId")),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_tenant_decorator_1.CurrentTenant)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], TenantController.prototype, "removeMember", null);
__decorate([
    (0, common_1.Post)("impersonate"),
    (0, roles_decorator_1.Roles)(shared_types_1.UserRole.SUPER_ADMIN, shared_types_1.UserRole.OWNER),
    (0, swagger_1.ApiOperation)({
        summary: "Impersonate organization user with mandatory justification audit trail",
    }),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_tenant_decorator_1.CurrentTenant)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], TenantController.prototype, "impersonate", null);
__decorate([
    (0, common_1.Get)("api-keys"),
    (0, require_permissions_decorator_1.RequirePermissions)(shared_types_1.PermissionFlag.API_KEYS_MANAGE),
    (0, swagger_1.ApiOperation)({ summary: "List active organization API keys" }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_tenant_decorator_1.CurrentTenant)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], TenantController.prototype, "listApiKeys", null);
__decorate([
    (0, common_1.Post)("api-keys"),
    (0, require_permissions_decorator_1.RequirePermissions)(shared_types_1.PermissionFlag.API_KEYS_MANAGE),
    (0, swagger_1.ApiOperation)({
        summary: "Generate secure enterprise API key with scoped authorization",
    }),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_tenant_decorator_1.CurrentTenant)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], TenantController.prototype, "createApiKey", null);
__decorate([
    (0, common_1.Delete)("api-keys/:id"),
    (0, require_permissions_decorator_1.RequirePermissions)(shared_types_1.PermissionFlag.API_KEYS_MANAGE),
    (0, swagger_1.ApiOperation)({ summary: "Revoke enterprise API key" }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)("id")),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_tenant_decorator_1.CurrentTenant)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], TenantController.prototype, "revokeApiKey", null);
__decorate([
    (0, common_1.Post)("audit/search"),
    (0, require_permissions_decorator_1.RequirePermissions)(shared_types_1.PermissionFlag.AUDIT_READ),
    (0, swagger_1.ApiOperation)({
        summary: "Search and export universal structured audit logs",
    }),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_tenant_decorator_1.CurrentTenant)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], TenantController.prototype, "searchAudit", null);
__decorate([
    (0, common_1.Get)("sessions"),
    (0, require_permissions_decorator_1.RequirePermissions)(shared_types_1.PermissionFlag.USERS_MANAGE),
    (0, swagger_1.ApiOperation)({ summary: "List active user sessions for the organization" }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, current_tenant_decorator_1.CurrentTenant)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], TenantController.prototype, "listSessions", null);
__decorate([
    (0, common_1.Delete)("sessions/:id"),
    (0, require_permissions_decorator_1.RequirePermissions)(shared_types_1.PermissionFlag.USERS_MANAGE),
    (0, swagger_1.ApiOperation)({ summary: "Revoke active user session" }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)("id")),
    __param(1, (0, current_tenant_decorator_1.CurrentTenant)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], TenantController.prototype, "revokeSession", null);
__decorate([
    (0, common_1.Get)("rbac/matrix"),
    (0, require_permissions_decorator_1.RequirePermissions)(shared_types_1.PermissionFlag.ROLE_BUILDER_MANAGE, shared_types_1.PermissionFlag.USERS_MANAGE),
    (0, swagger_1.ApiOperation)({
        summary: "Get full interactive RBAC & ABAC permission matrix",
    }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, current_tenant_decorator_1.CurrentTenant)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], TenantController.prototype, "getRbacMatrix", null);
__decorate([
    (0, common_1.Post)("rbac/profiles"),
    (0, require_permissions_decorator_1.RequirePermissions)(shared_types_1.PermissionFlag.ROLE_BUILDER_MANAGE),
    (0, swagger_1.ApiOperation)({
        summary: "Create custom permission profile with ABAC attribute rules",
    }),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_tenant_decorator_1.CurrentTenant)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], TenantController.prototype, "createPermissionProfile", null);
__decorate([
    (0, common_1.Get)("rbac/profiles"),
    (0, require_permissions_decorator_1.RequirePermissions)(shared_types_1.PermissionFlag.ROLE_BUILDER_MANAGE, shared_types_1.PermissionFlag.USERS_MANAGE),
    (0, swagger_1.ApiOperation)({
        summary: "List custom permission profiles and role templates",
    }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, current_tenant_decorator_1.CurrentTenant)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], TenantController.prototype, "listPermissionProfiles", null);
__decorate([
    (0, common_1.Post)("device-groups"),
    (0, require_permissions_decorator_1.RequirePermissions)(shared_types_1.PermissionFlag.DEVICE_MANAGEMENT),
    (0, swagger_1.ApiOperation)({
        summary: "Create Static or Dynamic Smart Device Group with automated filters",
    }),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_tenant_decorator_1.CurrentTenant)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], TenantController.prototype, "createDeviceGroup", null);
__decorate([
    (0, common_1.Get)("device-groups"),
    (0, require_permissions_decorator_1.RequirePermissions)(shared_types_1.PermissionFlag.DEVICE_MANAGEMENT, shared_types_1.PermissionFlag.TELEMETRY_READ),
    (0, swagger_1.ApiOperation)({ summary: "List device groups under current tenant" }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, current_tenant_decorator_1.CurrentTenant)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], TenantController.prototype, "listDeviceGroups", null);
__decorate([
    (0, common_1.Post)("device-transfers"),
    (0, require_permissions_decorator_1.RequirePermissions)(shared_types_1.PermissionFlag.DEVICE_MANAGEMENT),
    (0, swagger_1.ApiOperation)({
        summary: "Initiate approval-based device transfer request between organizations",
    }),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_tenant_decorator_1.CurrentTenant)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], TenantController.prototype, "createTransferRequest", null);
__decorate([
    (0, common_1.Put)("device-transfers/:id/resolve"),
    (0, roles_decorator_1.Roles)(shared_types_1.UserRole.SUPER_ADMIN, shared_types_1.UserRole.OWNER, shared_types_1.UserRole.ADMIN),
    (0, swagger_1.ApiOperation)({
        summary: "Approve or reject incoming device transfer request",
    }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)("id")),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_tenant_decorator_1.CurrentTenant)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], TenantController.prototype, "resolveTransferRequest", null);
exports.TenantController = TenantController = __decorate([
    (0, swagger_1.ApiTags)("Tenant & SaaS Enterprise Governance"),
    (0, common_1.Controller)("tenant"),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, tenant_context_guard_1.TenantContextGuard, roles_guard_1.RolesGuard, rbac_permission_guard_1.RbacPermissionGuard),
    (0, swagger_1.ApiBearerAuth)(),
    __metadata("design:paramtypes", [organization_service_1.OrganizationService,
        user_governance_service_1.UserGovernanceService,
        api_key_service_1.ApiKeyService,
        audit_engine_service_1.AuditEngineService,
        device_governance_service_1.DeviceGovernanceService,
        rbac_evaluation_service_1.RbacEvaluationService,
        tenant_scores_service_1.TenantScoresService])
], TenantController);
//# sourceMappingURL=tenant.controller.js.map