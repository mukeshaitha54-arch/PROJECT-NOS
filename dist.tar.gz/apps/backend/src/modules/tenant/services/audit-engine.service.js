"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuditEngineService = void 0;
const common_1 = require("@nestjs/common");
const tenant_repository_interface_1 = require("../../../common/repositories/tenant.repository.interface");
let AuditEngineService = class AuditEngineService {
    auditRepository;
    constructor(auditRepository) {
        this.auditRepository = auditRepository;
    }
    async logEvent(context, action, resourceType, resourceId, reason, details) {
        return this.auditRepository.record({
            organizationId: context.organizationId || "default-org",
            userId: context.userId,
            action,
            resourceType,
            resourceId,
            reason,
            ipAddress: context.ipAddress || "127.0.0.1",
            browser: context.browser || "System/Worker",
            correlationId: context.correlationId || "no-correlation",
            details,
        });
    }
    async search(request) {
        return this.auditRepository.search(request);
    }
};
exports.AuditEngineService = AuditEngineService;
exports.AuditEngineService = AuditEngineService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(tenant_repository_interface_1.IAuditLogRepositoryToken)),
    __metadata("design:paramtypes", [Object])
], AuditEngineService);
//# sourceMappingURL=audit-engine.service.js.map