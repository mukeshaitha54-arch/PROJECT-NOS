"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApiKeyService = void 0;
const common_1 = require("@nestjs/common");
const crypto = require("crypto");
const shared_types_1 = require("@nos/shared-types");
const tenant_repository_interface_1 = require("../../../common/repositories/tenant.repository.interface");
const quota_engine_service_1 = require("./quota-engine.service");
const audit_engine_service_1 = require("./audit-engine.service");
let ApiKeyService = class ApiKeyService {
    apiKeyRepository;
    quotaService;
    auditService;
    constructor(apiKeyRepository, quotaService, auditService) {
        this.apiKeyRepository = apiKeyRepository;
        this.quotaService = quotaService;
        this.auditService = auditService;
    }
    hashKey(plainKey) {
        return crypto.createHash("sha256").update(plainKey).digest("hex");
    }
    async generate(organizationId, createdByUserId, data, context) {
        await this.quotaService.checkQuotaConsumption(organizationId, "API_KEYS");
        const randomSecret = crypto.randomBytes(24).toString("hex");
        const keyPrefix = `nos_live_${randomSecret.substring(0, 8)}`;
        const plainKey = `nos_live_${randomSecret}`;
        const tokenHash = this.hashKey(plainKey);
        const apiKey = await this.apiKeyRepository.create(organizationId, createdByUserId, data, keyPrefix, tokenHash);
        await this.auditService.logEvent(context, shared_types_1.AuditActionType.API_KEY_CREATE, "ApiKey", apiKey.id, `Generated new API key '${data.name}' with scopes [${data.scopes.join(", ")}]`, { scopes: data.scopes, allowedIps: data.allowedIps });
        return { apiKey, plainKey };
    }
    async validateAndRecordUsage(plainKey) {
        const tokenHash = this.hashKey(plainKey);
        const key = await this.apiKeyRepository.findByTokenHash(tokenHash);
        if (!key) {
            throw new common_1.UnauthorizedException({
                code: shared_types_1.ErrorCode.UNAUTHORIZED,
                message: "Invalid or revoked API key.",
            });
        }
        if (new Date(key.expiresAt) < new Date()) {
            throw new common_1.UnauthorizedException({
                code: shared_types_1.ErrorCode.UNAUTHORIZED,
                message: "API key has expired.",
            });
        }
        await this.apiKeyRepository.recordUsage(key.id);
        return key;
    }
    async list(organizationId, params) {
        return this.apiKeyRepository.listByOrganization(organizationId, params);
    }
    async revoke(organizationId, id, context, reason) {
        await this.apiKeyRepository.revoke(organizationId, id);
        await this.auditService.logEvent(context, shared_types_1.AuditActionType.API_KEY_REVOKE, "ApiKey", id, reason ||
            "Revoked enterprise API key due to governance policy or security rotation");
    }
};
exports.ApiKeyService = ApiKeyService;
exports.ApiKeyService = ApiKeyService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(tenant_repository_interface_1.IApiKeyRepositoryToken)),
    __metadata("design:paramtypes", [Object, quota_engine_service_1.QuotaEngineService,
        audit_engine_service_1.AuditEngineService])
], ApiKeyService);
//# sourceMappingURL=api-key.service.js.map