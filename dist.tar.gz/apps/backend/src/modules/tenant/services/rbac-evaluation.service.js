"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RbacEvaluationService = void 0;
const common_1 = require("@nestjs/common");
const shared_types_1 = require("@nos/shared-types");
const tenant_repository_interface_1 = require("../../../common/repositories/tenant.repository.interface");
let RbacEvaluationService = class RbacEvaluationService {
    governanceRepository;
    constructor(governanceRepository) {
        this.governanceRepository = governanceRepository;
    }
    getDefaultRolePermissions(role) {
        const all = Object.values(shared_types_1.PermissionFlag);
        switch (role) {
            case shared_types_1.UserRole.OWNER:
            case shared_types_1.UserRole.SUPER_ADMIN:
                return all;
            case shared_types_1.UserRole.ADMIN:
            case shared_types_1.UserRole.MANAGER:
                return all.filter((f) => f !== shared_types_1.PermissionFlag.ROLE_BUILDER_MANAGE);
            case shared_types_1.UserRole.OPERATOR:
                return [
                    shared_types_1.PermissionFlag.DEVICE_MANAGEMENT,
                    shared_types_1.PermissionFlag.INVENTORY_READ_WRITE,
                    shared_types_1.PermissionFlag.TELEMETRY_READ,
                    shared_types_1.PermissionFlag.ALERTS_MANAGE,
                    shared_types_1.PermissionFlag.RULES_MANAGE,
                    shared_types_1.PermissionFlag.MAINTENANCE_MANAGE,
                ];
            case shared_types_1.UserRole.ANALYST:
                return [
                    shared_types_1.PermissionFlag.INVENTORY_READ_WRITE,
                    shared_types_1.PermissionFlag.TELEMETRY_READ,
                    shared_types_1.PermissionFlag.ALERTS_MANAGE,
                    shared_types_1.PermissionFlag.RULES_MANAGE,
                ];
            case shared_types_1.UserRole.AUDITOR:
                return [shared_types_1.PermissionFlag.TELEMETRY_READ, shared_types_1.PermissionFlag.AUDIT_READ];
            case shared_types_1.UserRole.VIEWER:
            case shared_types_1.UserRole.USER:
            default:
                return [shared_types_1.PermissionFlag.TELEMETRY_READ];
        }
    }
    async hasPermission(organizationId, role, requiredPermission, customRoleId, abacContext) {
        if (role === shared_types_1.UserRole.OWNER || role === shared_types_1.UserRole.SUPER_ADMIN) {
            return true;
        }
        let permissions = this.getDefaultRolePermissions(role);
        if (role === shared_types_1.UserRole.CUSTOM_ROLE && customRoleId) {
            const profiles = await this.governanceRepository.listPermissionProfiles(organizationId);
            const profile = profiles.find((p) => p.id === customRoleId);
            if (profile) {
                permissions = profile.permissions;
                if (profile.abacConditions && abacContext) {
                    if (profile.abacConditions.requiredDepartmentId &&
                        abacContext.departmentId !==
                            profile.abacConditions.requiredDepartmentId) {
                        return false;
                    }
                }
            }
        }
        return permissions.includes(requiredPermission);
    }
    async getPermissionMatrix(organizationId) {
        const defaultRoles = [
            shared_types_1.UserRole.OWNER,
            shared_types_1.UserRole.SUPER_ADMIN,
            shared_types_1.UserRole.ADMIN,
            shared_types_1.UserRole.MANAGER,
            shared_types_1.UserRole.OPERATOR,
            shared_types_1.UserRole.ANALYST,
            shared_types_1.UserRole.VIEWER,
            shared_types_1.UserRole.AUDITOR,
            shared_types_1.UserRole.CUSTOM_ROLE,
        ];
        const roles = defaultRoles.map((r) => ({
            role: r,
            permissions: this.getDefaultRolePermissions(r),
        }));
        const allPermissions = [
            {
                flag: shared_types_1.PermissionFlag.DEVICE_MANAGEMENT,
                category: "Devices",
                label: "Manage Devices",
                description: "Register, edit, and command nodes",
            },
            {
                flag: shared_types_1.PermissionFlag.INVENTORY_READ_WRITE,
                category: "Inventory",
                label: "Inventory Access",
                description: "Read and update hardware/OS inventory",
            },
            {
                flag: shared_types_1.PermissionFlag.TELEMETRY_READ,
                category: "Telemetry",
                label: "Read Telemetry",
                description: "View raw metric streams and heartbeats",
            },
            {
                flag: shared_types_1.PermissionFlag.ALERTS_MANAGE,
                category: "Alerting",
                label: "Manage Alerts",
                description: "Acknowledge, escalate, and resolve alerts",
            },
            {
                flag: shared_types_1.PermissionFlag.RULES_MANAGE,
                category: "Alerting",
                label: "Rule Studio Admin",
                description: "Author and simulate rule thresholds",
            },
            {
                flag: shared_types_1.PermissionFlag.MAINTENANCE_MANAGE,
                category: "Operations",
                label: "Maintenance Windows",
                description: "Schedule and enforce outage windows",
            },
            {
                flag: shared_types_1.PermissionFlag.USERS_MANAGE,
                category: "Governance",
                label: "User Governance",
                description: "Invite, suspend, and assign users",
            },
            {
                flag: shared_types_1.PermissionFlag.TEAMS_MANAGE,
                category: "Governance",
                label: "Teams & Departments",
                description: "Organize teams and lead hierarchies",
            },
            {
                flag: shared_types_1.PermissionFlag.SETTINGS_MANAGE,
                category: "Tenant",
                label: "Organization Settings",
                description: "Configure retention, timezone, and policies",
            },
            {
                flag: shared_types_1.PermissionFlag.API_KEYS_MANAGE,
                category: "Tenant",
                label: "API Keys",
                description: "Generate and rotate enterprise API keys",
            },
            {
                flag: shared_types_1.PermissionFlag.AUDIT_READ,
                category: "Audit & Compliance",
                label: "Read Audit Logs",
                description: "Search universal audit logs and export reports",
            },
            {
                flag: shared_types_1.PermissionFlag.ROLE_BUILDER_MANAGE,
                category: "RBAC",
                label: "Custom Role Builder",
                description: "Design custom roles with granular ABAC flags",
            },
        ];
        return { roles, allPermissions };
    }
};
exports.RbacEvaluationService = RbacEvaluationService;
exports.RbacEvaluationService = RbacEvaluationService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(tenant_repository_interface_1.IDeviceGovernanceRepositoryToken)),
    __metadata("design:paramtypes", [Object])
], RbacEvaluationService);
//# sourceMappingURL=rbac-evaluation.service.js.map