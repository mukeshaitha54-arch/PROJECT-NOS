"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TenantScoresService = void 0;
const common_1 = require("@nestjs/common");
const quota_engine_service_1 = require("./quota-engine.service");
const user_governance_service_1 = require("./user-governance.service");
const audit_engine_service_1 = require("./audit-engine.service");
let TenantScoresService = class TenantScoresService {
    quotaService;
    userService;
    auditService;
    constructor(quotaService, userService, auditService) {
        this.quotaService = quotaService;
        this.userService = userService;
        this.auditService = auditService;
    }
    async evaluateHealth(organizationId) {
        const usage = await this.quotaService.getQuotaUsage(organizationId);
        const sessions = await this.userService.listActiveSessions(organizationId);
        const auditRes = await this.auditService.search({
            organizationId,
            limit: 10,
        });
        const recommendations = [];
        let quotaScore = 100 - usage.percentUsed;
        if (usage.isLimitExceeded) {
            quotaScore = 0;
            recommendations.push({
                category: "Quota",
                priority: "HIGH",
                message: "Device quota limit exceeded or reached. Upgrade organization tier immediately to prevent ingest blocking.",
            });
        }
        else if (usage.isApproachingLimit) {
            recommendations.push({
                category: "Quota",
                priority: "MEDIUM",
                message: "Device quota usage is above 80%. Plan for expansion.",
            });
        }
        let securityScore = 100;
        const riskySessions = sessions.filter((s) => (s.riskScore && s.riskScore > 50) || !s.os || s.os === "Unknown");
        if (riskySessions.length > 0) {
            securityScore = Math.max(20, 100 - riskySessions.length * 15);
            recommendations.push({
                category: "Security",
                priority: "MEDIUM",
                message: `Found ${riskySessions.length} active session(s) with elevated risk scores or unidentified OS architecture. Consider forcing session revocation.`,
            });
        }
        let complianceScore = 100;
        if (auditRes.total < 5) {
            complianceScore = 75;
            recommendations.push({
                category: "Compliance",
                priority: "LOW",
                message: "Low recent audit log volume detected. Ensure tenant context propagation is enabled across all operators and custom scripts.",
            });
        }
        const overallHealthScore = Math.round((quotaScore + securityScore + complianceScore) / 3);
        return {
            organizationId,
            overallHealthScore,
            securityPostureScore: securityScore,
            complianceReadinessScore: complianceScore,
            quotaCapacityScore: quotaScore,
            recommendations,
            timestamp: new Date().toISOString(),
        };
    }
};
exports.TenantScoresService = TenantScoresService;
exports.TenantScoresService = TenantScoresService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [quota_engine_service_1.QuotaEngineService,
        user_governance_service_1.UserGovernanceService,
        audit_engine_service_1.AuditEngineService])
], TenantScoresService);
//# sourceMappingURL=tenant-scores.service.js.map