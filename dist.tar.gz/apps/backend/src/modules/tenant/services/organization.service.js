"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrganizationService = void 0;
const common_1 = require("@nestjs/common");
const shared_types_1 = require("@nos/shared-types");
const tenant_repository_interface_1 = require("../../../common/repositories/tenant.repository.interface");
const quota_engine_service_1 = require("./quota-engine.service");
let OrganizationService = class OrganizationService {
    orgRepository;
    auditRepository;
    quotaService;
    constructor(orgRepository, auditRepository, quotaService) {
        this.orgRepository = orgRepository;
        this.auditRepository = auditRepository;
        this.quotaService = quotaService;
    }
    async getById(id) {
        const org = await this.orgRepository.findById(id);
        if (!org) {
            throw new common_1.NotFoundException({
                code: "RESOURCE_NOT_FOUND",
                message: `Organization [${id}] not found.`,
            });
        }
        const usage = await this.quotaService.getQuotaUsage(id);
        return { ...org, quotaUsage: usage };
    }
    async create(data, context) {
        const existing = await this.orgRepository.findBySlug(data.slug);
        if (existing) {
            throw new common_1.BadRequestException({
                code: shared_types_1.ErrorCode.VALIDATION_ERROR,
                message: `Organization slug [${data.slug}] is already taken.`,
            });
        }
        const created = await this.orgRepository.create({
            name: data.name,
            slug: data.slug,
            status: shared_types_1.OrganizationStatus.ACTIVE,
            settings: data.settings,
            quota: data.quota,
        });
        await this.auditRepository.record({
            organizationId: created.id,
            userId: context.userId,
            action: shared_types_1.AuditActionType.ORG_LIFECYCLE_CHANGE,
            resourceType: "ORGANIZATION",
            resourceId: created.id,
            reason: "Created new enterprise organization tenant",
            ipAddress: context.ipAddress || "127.0.0.1",
            browser: context.browser || "System",
            correlationId: context.correlationId,
            details: { name: data.name, slug: data.slug },
        });
        return created;
    }
    async updateStatus(id, status, context, reason) {
        await this.getById(id);
        const updated = await this.orgRepository.updateStatus(id, status);
        await this.auditRepository.record({
            organizationId: id,
            userId: context.userId,
            action: shared_types_1.AuditActionType.ORG_LIFECYCLE_CHANGE,
            resourceType: "ORGANIZATION",
            resourceId: id,
            reason: reason || `Updated organization status to ${status}`,
            ipAddress: context.ipAddress || "127.0.0.1",
            browser: context.browser || "System",
            correlationId: context.correlationId,
            details: { previousStatus: updated.status, newStatus: status },
        });
        return updated;
    }
    async updateSettings(id, settings, context) {
        await this.getById(id);
        const updated = await this.orgRepository.updateSettings(id, settings);
        await this.auditRepository.record({
            organizationId: id,
            userId: context.userId,
            action: shared_types_1.AuditActionType.ORG_SETTINGS_UPDATE,
            resourceType: "ORGANIZATION",
            resourceId: id,
            reason: "Modified organization security and alert configuration policies",
            ipAddress: context.ipAddress || "127.0.0.1",
            browser: context.browser || "System",
            correlationId: context.correlationId,
        });
        return updated;
    }
    async archive(id, context, reason) {
        await this.updateStatus(id, shared_types_1.OrganizationStatus.ARCHIVED, context, reason);
    }
    async softDelete(id, context, reason) {
        await this.getById(id);
        await this.orgRepository.softDelete(id);
        await this.auditRepository.record({
            organizationId: id,
            userId: context.userId,
            action: shared_types_1.AuditActionType.ORG_LIFECYCLE_CHANGE,
            resourceType: "ORGANIZATION",
            resourceId: id,
            reason: reason || "Soft-deleted enterprise organization tenant",
            ipAddress: context.ipAddress || "127.0.0.1",
            browser: context.browser || "System",
            correlationId: context.correlationId,
        });
    }
    async restore(id, context, reason) {
        const restored = await this.orgRepository.restore(id);
        await this.auditRepository.record({
            organizationId: id,
            userId: context.userId,
            action: shared_types_1.AuditActionType.ORG_LIFECYCLE_CHANGE,
            resourceType: "ORGANIZATION",
            resourceId: id,
            reason: reason || "Restored soft-deleted enterprise organization tenant",
            ipAddress: context.ipAddress || "127.0.0.1",
            browser: context.browser || "System",
            correlationId: context.correlationId,
        });
        return restored;
    }
    async listAll(params) {
        return this.orgRepository.listAll(params);
    }
};
exports.OrganizationService = OrganizationService;
exports.OrganizationService = OrganizationService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(tenant_repository_interface_1.IOrganizationRepositoryToken)),
    __param(1, (0, common_1.Inject)(tenant_repository_interface_1.IAuditLogRepositoryToken)),
    __metadata("design:paramtypes", [Object, Object, quota_engine_service_1.QuotaEngineService])
], OrganizationService);
//# sourceMappingURL=organization.service.js.map