import { DeviceOwnershipDto, DeviceGroupDto, DeviceTransferRequestDto, DeviceTransferStatus, PermissionProfileDto, RoleTemplateDto, TenantContext } from "@nos/shared-types";
import { IDeviceGovernanceRepository } from "../../../common/repositories/tenant.repository.interface";
import { IDeviceRepository } from "../../../common/repositories/device.repository.interface";
import { AuditEngineService } from "./audit-engine.service";
export declare class DeviceGovernanceService {
    private readonly governanceRepository;
    private readonly deviceRepository;
    private readonly auditService;
    constructor(governanceRepository: IDeviceGovernanceRepository, deviceRepository: IDeviceRepository, auditService: AuditEngineService);
    assignOwnership(deviceId: string, organizationId: string, data: Partial<DeviceOwnershipDto>, context: TenantContext): Promise<DeviceOwnershipDto>;
    getOwnership(deviceId: string, organizationId: string): Promise<DeviceOwnershipDto | null>;
    createDeviceGroup(organizationId: string, name: string, groupType: string, context: TenantContext, description?: string, filterCriteria?: Record<string, any>, deviceIds?: string[]): Promise<DeviceGroupDto>;
    listDeviceGroups(organizationId: string): Promise<DeviceGroupDto[]>;
    createTransferRequest(deviceId: string, fromOrgId: string, toOrgId: string, reason: string, context: TenantContext): Promise<DeviceTransferRequestDto>;
    resolveTransferRequest(id: string, status: DeviceTransferStatus, context: TenantContext): Promise<DeviceTransferRequestDto>;
    listTransferRequests(organizationId: string, type: "INCOMING" | "OUTGOING"): Promise<DeviceTransferRequestDto[]>;
    listPermissionProfiles(organizationId: string): Promise<PermissionProfileDto[]>;
    createPermissionProfile(organizationId: string, name: string, permissions: string[], description?: string, abacConditions?: Record<string, any>): Promise<PermissionProfileDto>;
    listRoleTemplates(): Promise<RoleTemplateDto[]>;
}
