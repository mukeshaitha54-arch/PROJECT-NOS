import { PrismaService } from "../../../database/prisma.service";
import { IMailService } from "../../../common/services/mail-service.interface";
export interface CreateInvitationDto {
    organizationId: string;
    email: string;
    role?: string;
    teamIds?: string[];
    departmentIds?: string[];
    invitedByUserId: string;
}
export declare class OrganizationInvitationService {
    private readonly prisma;
    private readonly mailService;
    constructor(prisma: PrismaService, mailService: IMailService);
    inviteMember(dto: CreateInvitationDto): Promise<{
        invitationId: string;
        token: string;
    }>;
    acceptInvitation(token: string, userId: string): Promise<{
        userId: string;
        role: string;
        organizationId: string;
        id: string;
        updatedAt: Date;
        customRoleId: string | null;
        teamIds: string[];
        departmentIds: string[];
        isSuspended: boolean;
        joinedAt: Date;
    }>;
}
