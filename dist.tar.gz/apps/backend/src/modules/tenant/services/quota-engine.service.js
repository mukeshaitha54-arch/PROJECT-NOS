"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.QuotaEngineService = void 0;
const common_1 = require("@nestjs/common");
const shared_types_1 = require("@nos/shared-types");
const tenant_repository_interface_1 = require("../../../common/repositories/tenant.repository.interface");
const device_repository_interface_1 = require("../../../common/repositories/device.repository.interface");
let QuotaEngineService = class QuotaEngineService {
    orgRepository;
    teamRepository;
    apiKeyRepository;
    deviceRepository;
    constructor(orgRepository, teamRepository, apiKeyRepository, deviceRepository) {
        this.orgRepository = orgRepository;
        this.teamRepository = teamRepository;
        this.apiKeyRepository = apiKeyRepository;
        this.deviceRepository = deviceRepository;
    }
    async getQuotaUsage(organizationId) {
        const quota = await this.orgRepository.getQuota(organizationId);
        const defaults = quota || {
            maxDevices: 50,
            maxUsers: 10,
            maxApiKeys: 10,
            maxStorageMb: 1024,
            maxDailyTelemetry: 100000,
            maxDailyAlerts: 5000,
        };
        const [devicesCount, membersRes, apiKeysRes] = await Promise.all([
            this.deviceRepository.countByOrganization
                ? this.deviceRepository
                    .countByOrganization(organizationId)
                    .catch(() => 0)
                : this.deviceRepository
                    .findAll(organizationId)
                    .then((list) => list.length)
                    .catch(() => 0),
            this.teamRepository
                .listMembers(organizationId)
                .catch(() => ({ total: 1 })),
            this.apiKeyRepository
                .listByOrganization(organizationId)
                .catch(() => ({ total: 0 })),
        ]);
        const currentDevices = devicesCount || 0;
        const currentUsers = membersRes.total || 1;
        const currentApiKeys = apiKeysRes.total || 0;
        const currentStorageMb = Math.round(currentDevices * 4.5);
        const currentDailyTelemetry = currentDevices * 240;
        const currentDailyAlerts = Math.round(currentDevices * 2);
        const ratio = currentDevices / Math.max(1, defaults.maxDevices);
        const isApproachingLimit = ratio >= 0.8 && ratio < 1.0;
        const isLimitExceeded = ratio >= 1.0 || currentUsers > defaults.maxUsers;
        const percentUsed = Math.min(100, Math.round(ratio * 100));
        return {
            ...defaults,
            currentDevices,
            currentUsers,
            currentApiKeys,
            currentStorageMb,
            currentDailyTelemetry,
            currentDailyAlerts,
            isApproachingLimit,
            isLimitExceeded,
            percentUsed,
        };
    }
    async checkQuotaConsumption(organizationId, resource) {
        const usage = await this.getQuotaUsage(organizationId);
        if (resource === "DEVICES" && usage.currentDevices >= usage.maxDevices) {
            throw new common_1.BadRequestException({
                code: shared_types_1.ErrorCode.VALIDATION_ERROR,
                message: `Organization [${organizationId}] device quota exceeded (${usage.currentDevices}/${usage.maxDevices}). Please upgrade quota.`,
            });
        }
        if (resource === "USERS" && usage.currentUsers >= usage.maxUsers) {
            throw new common_1.BadRequestException({
                code: shared_types_1.ErrorCode.VALIDATION_ERROR,
                message: `Organization [${organizationId}] user quota exceeded (${usage.currentUsers}/${usage.maxUsers}). Please upgrade quota.`,
            });
        }
        if (resource === "API_KEYS" && usage.currentApiKeys >= usage.maxApiKeys) {
            throw new common_1.BadRequestException({
                code: shared_types_1.ErrorCode.VALIDATION_ERROR,
                message: `Organization [${organizationId}] API key quota exceeded (${usage.currentApiKeys}/${usage.maxApiKeys}). Please upgrade quota.`,
            });
        }
    }
    async updateQuota(organizationId, updates) {
        await this.orgRepository.updateQuota(organizationId, updates);
        return this.getQuotaUsage(organizationId);
    }
};
exports.QuotaEngineService = QuotaEngineService;
exports.QuotaEngineService = QuotaEngineService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(tenant_repository_interface_1.IOrganizationRepositoryToken)),
    __param(1, (0, common_1.Inject)(tenant_repository_interface_1.ITeamRepositoryToken)),
    __param(2, (0, common_1.Inject)(tenant_repository_interface_1.IApiKeyRepositoryToken)),
    __param(3, (0, common_1.Inject)(device_repository_interface_1.IDeviceRepositoryToken)),
    __metadata("design:paramtypes", [Object, Object, Object, Object])
], QuotaEngineService);
//# sourceMappingURL=quota-engine.service.js.map