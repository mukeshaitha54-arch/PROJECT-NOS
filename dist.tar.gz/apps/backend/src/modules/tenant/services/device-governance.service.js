"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeviceGovernanceService = void 0;
const common_1 = require("@nestjs/common");
const shared_types_1 = require("@nos/shared-types");
const tenant_repository_interface_1 = require("../../../common/repositories/tenant.repository.interface");
const device_repository_interface_1 = require("../../../common/repositories/device.repository.interface");
const audit_engine_service_1 = require("./audit-engine.service");
let DeviceGovernanceService = class DeviceGovernanceService {
    governanceRepository;
    deviceRepository;
    auditService;
    constructor(governanceRepository, deviceRepository, auditService) {
        this.governanceRepository = governanceRepository;
        this.deviceRepository = deviceRepository;
        this.auditService = auditService;
    }
    async assignOwnership(deviceId, organizationId, data, context) {
        const device = await this.deviceRepository.findById(deviceId);
        if (!device) {
            throw new common_1.NotFoundException({
                code: "RESOURCE_NOT_FOUND",
                message: `Device [${deviceId}] not found.`,
            });
        }
        const ownership = await this.governanceRepository.assignOwnership(deviceId, organizationId, data);
        await this.auditService.logEvent(context, shared_types_1.AuditActionType.INVENTORY_UPDATE, "DEVICE", deviceId, `Assigned device to owner user [${data.ownerUserId || "none"}], team [${data.assignedTeamId || "none"}] in org [${organizationId}]`, data);
        return ownership;
    }
    async getOwnership(deviceId, organizationId) {
        return this.governanceRepository.getOwnership(deviceId, organizationId);
    }
    async createDeviceGroup(organizationId, name, groupType, context, description, filterCriteria, deviceIds) {
        let matchedDeviceIds = deviceIds || [];
        if (groupType === "DYNAMIC" && filterCriteria) {
            const allDevices = await this.deviceRepository.findAll(organizationId);
            matchedDeviceIds = allDevices
                .filter((d) => {
                if (filterCriteria.os && d.os !== filterCriteria.os)
                    return false;
                if (filterCriteria.status && d.status !== filterCriteria.status)
                    return false;
                if (filterCriteria.architecture &&
                    d.architecture !== filterCriteria.architecture)
                    return false;
                if (filterCriteria.hostnameContains &&
                    !d.hostname
                        ?.toLowerCase()
                        .includes(String(filterCriteria.hostnameContains).toLowerCase()))
                    return false;
                return true;
            })
                .map((d) => d.id);
        }
        const group = await this.governanceRepository.createDeviceGroup(organizationId, name, groupType, description, filterCriteria, matchedDeviceIds);
        await this.auditService.logEvent(context, shared_types_1.AuditActionType.ORG_SETTINGS_UPDATE, "DEVICE_GROUP", group.id, `Created ${groupType} device group [${name}] matching ${matchedDeviceIds.length} devices`, { filterCriteria, matchedCount: matchedDeviceIds.length });
        return group;
    }
    async listDeviceGroups(organizationId) {
        return this.governanceRepository.listDeviceGroups(organizationId);
    }
    async createTransferRequest(deviceId, fromOrgId, toOrgId, reason, context) {
        const request = await this.governanceRepository.createTransferRequest(deviceId, fromOrgId, toOrgId, context.userId || "system", reason);
        await this.auditService.logEvent(context, shared_types_1.AuditActionType.DEVICE_TRANSFER, "DEVICE_TRANSFER", request.id, `Requested device transfer from [${fromOrgId}] to [${toOrgId}]: ${reason}`, { deviceId, fromOrgId, toOrgId });
        return request;
    }
    async resolveTransferRequest(id, status, context) {
        if (status !== shared_types_1.DeviceTransferStatus.APPROVED &&
            status !== shared_types_1.DeviceTransferStatus.REJECTED) {
            throw new common_1.BadRequestException({
                code: shared_types_1.ErrorCode.VALIDATION_ERROR,
                message: "Status must be APPROVED or REJECTED.",
            });
        }
        const resolved = await this.governanceRepository.resolveTransferRequest(id, status, context.userId);
        const auditType = shared_types_1.AuditActionType.DEVICE_TRANSFER;
        await this.auditService.logEvent(context, auditType, "DEVICE_TRANSFER", resolved.id, `Resolved device transfer request with status: ${status}`, { approvedByUserId: context.userId });
        return resolved;
    }
    async listTransferRequests(organizationId, type) {
        return this.governanceRepository.listTransferRequests(organizationId, type);
    }
    async listPermissionProfiles(organizationId) {
        return this.governanceRepository.listPermissionProfiles(organizationId);
    }
    async createPermissionProfile(organizationId, name, permissions, description, abacConditions) {
        return this.governanceRepository.createPermissionProfile(organizationId, name, permissions, description, abacConditions);
    }
    async listRoleTemplates() {
        return this.governanceRepository.listRoleTemplates();
    }
};
exports.DeviceGovernanceService = DeviceGovernanceService;
exports.DeviceGovernanceService = DeviceGovernanceService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(tenant_repository_interface_1.IDeviceGovernanceRepositoryToken)),
    __param(1, (0, common_1.Inject)(device_repository_interface_1.IDeviceRepositoryToken)),
    __metadata("design:paramtypes", [Object, Object, audit_engine_service_1.AuditEngineService])
], DeviceGovernanceService);
//# sourceMappingURL=device-governance.service.js.map