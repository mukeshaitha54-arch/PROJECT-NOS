import { DepartmentDto, TeamDto, OrganizationMemberDto, OrganizationInvitationDto, UserSessionDto, UserActivityDto, UserRole, TenantContext } from "@nos/shared-types";
import { ITeamRepository, IUserSessionRepository } from "../../../common/repositories/tenant.repository.interface";
import { QuotaEngineService } from "./quota-engine.service";
import { AuditEngineService } from "./audit-engine.service";
export declare class UserGovernanceService {
    private readonly teamRepository;
    private readonly sessionRepository;
    private readonly quotaService;
    private readonly auditService;
    constructor(teamRepository: ITeamRepository, sessionRepository: IUserSessionRepository, quotaService: QuotaEngineService, auditService: AuditEngineService);
    createDepartment(organizationId: string, name: string, description?: string, headUserId?: string): Promise<DepartmentDto>;
    listDepartments(organizationId: string): Promise<DepartmentDto[]>;
    createTeam(organizationId: string, name: string, departmentId?: string, description?: string, leadUserId?: string): Promise<TeamDto>;
    listTeams(organizationId: string): Promise<TeamDto[]>;
    addMember(organizationId: string, userId: string, role: UserRole, context: TenantContext, teamIds?: string[], departmentIds?: string[], customRoleId?: string): Promise<OrganizationMemberDto>;
    updateMemberRole(organizationId: string, userId: string, role: UserRole, context: TenantContext, customRoleId?: string): Promise<OrganizationMemberDto>;
    removeMember(organizationId: string, userId: string, context: TenantContext, reason?: string): Promise<void>;
    listMembers(organizationId: string, params?: {
        search?: string;
        role?: string;
        page?: number;
        limit?: number;
    }): Promise<{
        items: OrganizationMemberDto[];
        total: number;
    }>;
    inviteUser(organizationId: string, email: string, role: UserRole, context: TenantContext, teamIds?: string[], departmentIds?: string[]): Promise<{
        invitation: OrganizationInvitationDto;
        inviteLink: string;
    }>;
    listInvitations(organizationId: string): Promise<OrganizationInvitationDto[]>;
    revokeInvitation(organizationId: string, id: string, context: TenantContext): Promise<void>;
    importUsersFromCsv(organizationId: string, csvContent: string, context: TenantContext): Promise<{
        total: number;
        success: number;
        errors: Array<{
            row: number;
            email: string;
            error: string;
        }>;
    }>;
    listActiveSessions(organizationId: string, userId?: string): Promise<UserSessionDto[]>;
    revokeSession(organizationId: string, sessionId: string, context: TenantContext, reason?: string): Promise<void>;
    revokeAllUserSessions(organizationId: string, targetUserId: string, context: TenantContext, reason?: string): Promise<void>;
    recordActivity(organizationId: string, userId: string, action: string, ipAddress: string, browser: string, resourceType?: string, resourceId?: string): Promise<void>;
    listUserActivities(organizationId: string, userId?: string, limit?: number): Promise<UserActivityDto[]>;
    impersonateUser(organizationId: string, targetUserId: string, reason: string, context: TenantContext): Promise<{
        impersonationToken: string;
        targetUserId: string;
        expiresAt: string;
    }>;
}
