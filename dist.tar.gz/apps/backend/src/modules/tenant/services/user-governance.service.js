"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserGovernanceService = void 0;
const common_1 = require("@nestjs/common");
const crypto = require("crypto");
const shared_types_1 = require("@nos/shared-types");
const tenant_repository_interface_1 = require("../../../common/repositories/tenant.repository.interface");
const quota_engine_service_1 = require("./quota-engine.service");
const audit_engine_service_1 = require("./audit-engine.service");
let UserGovernanceService = class UserGovernanceService {
    teamRepository;
    sessionRepository;
    quotaService;
    auditService;
    constructor(teamRepository, sessionRepository, quotaService, auditService) {
        this.teamRepository = teamRepository;
        this.sessionRepository = sessionRepository;
        this.quotaService = quotaService;
        this.auditService = auditService;
    }
    async createDepartment(organizationId, name, description, headUserId) {
        return this.teamRepository.createDepartment(organizationId, name, description, headUserId);
    }
    async listDepartments(organizationId) {
        return this.teamRepository.listDepartments(organizationId);
    }
    async createTeam(organizationId, name, departmentId, description, leadUserId) {
        return this.teamRepository.createTeam(organizationId, name, departmentId, description, leadUserId);
    }
    async listTeams(organizationId) {
        return this.teamRepository.listTeams(organizationId);
    }
    async addMember(organizationId, userId, role, context, teamIds, departmentIds, customRoleId) {
        await this.quotaService.checkQuotaConsumption(organizationId, "USERS");
        const member = await this.teamRepository.addMember(organizationId, userId, role, teamIds, departmentIds, customRoleId);
        await this.auditService.logEvent(context, shared_types_1.AuditActionType.PERMISSION_CHANGE, "MEMBER", member.id, `Assigned user [${userId}] to role [${role}] in organization [${organizationId}]`, { role, teamIds, departmentIds, customRoleId });
        return member;
    }
    async updateMemberRole(organizationId, userId, role, context, customRoleId) {
        const member = await this.teamRepository.updateMemberRole(organizationId, userId, role, customRoleId);
        await this.auditService.logEvent(context, shared_types_1.AuditActionType.PERMISSION_CHANGE, "MEMBER", member.id, `Updated member [${userId}] role to [${role}] in org [${organizationId}]`, { role, customRoleId });
        return member;
    }
    async removeMember(organizationId, userId, context, reason) {
        await this.teamRepository.removeMember(organizationId, userId);
        await this.sessionRepository.revokeAllUserSessions(userId, organizationId);
        await this.auditService.logEvent(context, shared_types_1.AuditActionType.USER_REMOVED, "MEMBER", userId, reason ||
            `Removed user [${userId}] from organization [${organizationId}] and revoked sessions`);
    }
    async listMembers(organizationId, params) {
        return this.teamRepository.listMembers(organizationId, params);
    }
    async inviteUser(organizationId, email, role, context, teamIds, departmentIds) {
        await this.quotaService.checkQuotaConsumption(organizationId, "USERS");
        const token = crypto.randomBytes(32).toString("hex");
        const tokenHash = crypto.createHash("sha256").update(token).digest("hex");
        const expiresAt = new Date();
        expiresAt.setDate(expiresAt.getDate() + 7);
        const invitation = await this.teamRepository.createInvitation(organizationId, email, role, context.userId || "system", tokenHash, expiresAt, teamIds, departmentIds);
        const inviteLink = `https://app.nos.enterprises/accept-invite?token=${token}`;
        await this.auditService.logEvent(context, shared_types_1.AuditActionType.USER_INVITED, "INVITE", invitation.id, `Invited user [${email}] with role [${role}]`, { email, role });
        return { invitation, inviteLink };
    }
    async listInvitations(organizationId) {
        return this.teamRepository.listInvitations(organizationId);
    }
    async revokeInvitation(organizationId, id, context) {
        await this.teamRepository.revokeInvitation(organizationId, id);
        await this.auditService.logEvent(context, shared_types_1.AuditActionType.USER_REMOVED, "INVITE", id, "Revoked user invitation");
    }
    async importUsersFromCsv(organizationId, csvContent, context) {
        const lines = csvContent
            .split(/\r?\n/)
            .map((l) => l.trim())
            .filter((l) => l.length > 0 && !l.startsWith("#"));
        const errors = [];
        let success = 0;
        for (let i = 0; i < lines.length; i++) {
            const parts = lines[i].split(",").map((p) => p.trim());
            const email = parts[0];
            const roleStr = (parts[1] || "OPERATOR").toUpperCase();
            if (!email || !email.includes("@")) {
                errors.push({
                    row: i + 1,
                    email,
                    error: "Invalid email address syntax",
                });
                continue;
            }
            try {
                await this.inviteUser(organizationId, email, roleStr, context);
                success++;
            }
            catch (err) {
                errors.push({
                    row: i + 1,
                    email,
                    error: err?.message || "Quota exceeded or import error",
                });
            }
        }
        return { total: lines.length, success, errors };
    }
    async listActiveSessions(organizationId, userId) {
        return this.sessionRepository.listActiveSessions(organizationId, userId);
    }
    async revokeSession(organizationId, sessionId, context, reason) {
        await this.sessionRepository.revokeSession(sessionId, organizationId);
        await this.auditService.logEvent(context, shared_types_1.AuditActionType.SESSION_REVOKE, "SESSION", sessionId, reason || "Revoked active session");
    }
    async revokeAllUserSessions(organizationId, targetUserId, context, reason) {
        await this.sessionRepository.revokeAllUserSessions(targetUserId, organizationId);
        await this.auditService.logEvent(context, shared_types_1.AuditActionType.SESSION_REVOKE, "USER_SESSIONS", targetUserId, reason || "Force logout from all devices");
    }
    async recordActivity(organizationId, userId, action, ipAddress, browser, resourceType, resourceId) {
        await this.sessionRepository.recordActivity({
            organizationId,
            userId,
            action,
            ipAddress,
            browser,
            resourceType,
            resourceId,
        });
    }
    async listUserActivities(organizationId, userId, limit = 50) {
        return this.sessionRepository.listUserActivities(organizationId, userId, limit);
    }
    async impersonateUser(organizationId, targetUserId, reason, context) {
        if (!reason || reason.trim().length < 5) {
            throw new common_1.BadRequestException({
                code: shared_types_1.ErrorCode.VALIDATION_ERROR,
                message: "Mandatory justification reason required for impersonation.",
            });
        }
        await this.auditService.logEvent(context, shared_types_1.AuditActionType.USER_IMPERSONATION, "IMPERSONATION", targetUserId, `IMPERSONATION TRACE: User [${context.userId}] initiated impersonation of [${targetUserId}]. Justification: ${reason}`, { targetUserId, reason });
        const token = `imp_${crypto.randomBytes(32).toString("hex")}`;
        const expiresAt = new Date(Date.now() + 30 * 60 * 1000).toISOString();
        return { impersonationToken: token, targetUserId, expiresAt };
    }
};
exports.UserGovernanceService = UserGovernanceService;
exports.UserGovernanceService = UserGovernanceService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(tenant_repository_interface_1.ITeamRepositoryToken)),
    __param(1, (0, common_1.Inject)(tenant_repository_interface_1.IUserSessionRepositoryToken)),
    __metadata("design:paramtypes", [Object, Object, quota_engine_service_1.QuotaEngineService,
        audit_engine_service_1.AuditEngineService])
], UserGovernanceService);
//# sourceMappingURL=user-governance.service.js.map