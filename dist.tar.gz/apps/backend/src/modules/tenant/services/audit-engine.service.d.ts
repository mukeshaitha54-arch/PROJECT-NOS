import { AuditLogDto, AuditSearchRequestDto, AuditSearchResultDto, AuditActionType, TenantContext } from "@nos/shared-types";
import { IAuditLogRepository } from "../../../common/repositories/tenant.repository.interface";
export declare class AuditEngineService {
    private readonly auditRepository;
    constructor(auditRepository: IAuditLogRepository);
    logEvent(context: TenantContext, action: AuditActionType, resourceType?: string, resourceId?: string, reason?: string, details?: Record<string, any>): Promise<AuditLogDto>;
    search(request: AuditSearchRequestDto): Promise<AuditSearchResultDto>;
}
