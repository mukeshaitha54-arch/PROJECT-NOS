import { OrganizationDto, OrganizationStatus, OrganizationSettingsDto, OrganizationQuotaDto, TenantContext } from "@nos/shared-types";
import { IOrganizationRepository, IAuditLogRepository } from "../../../common/repositories/tenant.repository.interface";
import { QuotaEngineService } from "./quota-engine.service";
export declare class OrganizationService {
    private readonly orgRepository;
    private readonly auditRepository;
    private readonly quotaService;
    constructor(orgRepository: IOrganizationRepository, auditRepository: IAuditLogRepository, quotaService: QuotaEngineService);
    getById(id: string): Promise<OrganizationDto>;
    create(data: {
        name: string;
        slug: string;
        settings?: Partial<OrganizationSettingsDto>;
        quota?: Partial<OrganizationQuotaDto>;
    }, context: TenantContext): Promise<OrganizationDto>;
    updateStatus(id: string, status: OrganizationStatus, context: TenantContext, reason?: string): Promise<OrganizationDto>;
    updateSettings(id: string, settings: OrganizationSettingsDto, context: TenantContext): Promise<OrganizationDto>;
    archive(id: string, context: TenantContext, reason: string): Promise<void>;
    softDelete(id: string, context: TenantContext, reason: string): Promise<void>;
    restore(id: string, context: TenantContext, reason: string): Promise<OrganizationDto>;
    listAll(params?: {
        search?: string;
        status?: string;
        page?: number;
        limit?: number;
    }): Promise<{
        items: OrganizationDto[];
        total: number;
        page: number;
        totalPages: number;
    }>;
}
