import { QuotaEngineService } from "./quota-engine.service";
import { UserGovernanceService } from "./user-governance.service";
import { AuditEngineService } from "./audit-engine.service";
export interface TenantHealthReport {
    organizationId: string;
    overallHealthScore: number;
    securityPostureScore: number;
    complianceReadinessScore: number;
    quotaCapacityScore: number;
    recommendations: Array<{
        category: string;
        priority: "HIGH" | "MEDIUM" | "LOW";
        message: string;
    }>;
    timestamp: string;
}
export declare class TenantScoresService {
    private readonly quotaService;
    private readonly userService;
    private readonly auditService;
    constructor(quotaService: QuotaEngineService, userService: UserGovernanceService, auditService: AuditEngineService);
    evaluateHealth(organizationId: string): Promise<TenantHealthReport>;
}
