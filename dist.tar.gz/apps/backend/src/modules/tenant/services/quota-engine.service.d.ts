import { OrganizationQuotaDto, OrganizationQuotaUsageDto } from "@nos/shared-types";
import { IOrganizationRepository, ITeamRepository, IApiKeyRepository } from "../../../common/repositories/tenant.repository.interface";
import { IDeviceRepository } from "../../../common/repositories/device.repository.interface";
export declare class QuotaEngineService {
    private readonly orgRepository;
    private readonly teamRepository;
    private readonly apiKeyRepository;
    private readonly deviceRepository;
    constructor(orgRepository: IOrganizationRepository, teamRepository: ITeamRepository, apiKeyRepository: IApiKeyRepository, deviceRepository: IDeviceRepository);
    getQuotaUsage(organizationId: string): Promise<OrganizationQuotaUsageDto>;
    checkQuotaConsumption(organizationId: string, resource: "DEVICES" | "USERS" | "API_KEYS"): Promise<void>;
    updateQuota(organizationId: string, updates: Partial<OrganizationQuotaDto>): Promise<OrganizationQuotaUsageDto>;
}
