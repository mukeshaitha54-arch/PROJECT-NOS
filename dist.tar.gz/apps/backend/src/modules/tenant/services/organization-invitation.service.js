"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrganizationInvitationService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../../database/prisma.service");
const crypto = require("crypto");
const mail_service_interface_1 = require("../../../common/services/mail-service.interface");
let OrganizationInvitationService = class OrganizationInvitationService {
    prisma;
    mailService;
    constructor(prisma, mailService) {
        this.prisma = prisma;
        this.mailService = mailService;
    }
    async inviteMember(dto) {
        const org = await this.prisma.organization.findUnique({
            where: { id: dto.organizationId },
        });
        if (!org) {
            throw new common_1.NotFoundException("Organization not found");
        }
        const token = crypto.randomBytes(32).toString("hex");
        const tokenHash = crypto.createHash("sha256").update(token).digest("hex");
        const expiresAt = new Date();
        expiresAt.setDate(expiresAt.getDate() + 7);
        const invitation = await this.prisma.organizationInvitation.create({
            data: {
                organizationId: dto.organizationId,
                email: dto.email,
                role: dto.role || "OPERATOR",
                teamIds: dto.teamIds || [],
                departmentIds: dto.departmentIds || [],
                invitedByUserId: dto.invitedByUserId,
                status: "PENDING",
                tokenHash,
                expiresAt,
            },
        });
        const inviteUrl = `http://localhost:3000/onboarding/invite?token=${token}`;
        await this.mailService.sendInvitationEmail(dto.email, org.name, inviteUrl);
        return {
            invitationId: invitation.id,
            token,
        };
    }
    async acceptInvitation(token, userId) {
        const tokenHash = crypto.createHash("sha256").update(token).digest("hex");
        const invitation = await this.prisma.organizationInvitation.findUnique({
            where: { tokenHash },
        });
        if (!invitation) {
            throw new common_1.BadRequestException("Invalid or expired invitation token");
        }
        if (invitation.status !== "PENDING") {
            throw new common_1.BadRequestException(`Invitation is already ${invitation.status.toLowerCase()}`);
        }
        if (new Date() > invitation.expiresAt) {
            await this.prisma.organizationInvitation.update({
                where: { id: invitation.id },
                data: { status: "EXPIRED" },
            });
            throw new common_1.BadRequestException("Invitation has expired");
        }
        const existingMember = await this.prisma.organizationMember.findUnique({
            where: {
                organizationId_userId: {
                    organizationId: invitation.organizationId,
                    userId,
                },
            },
        });
        if (existingMember) {
            throw new common_1.BadRequestException("User is already a member of this organization");
        }
        const member = await this.prisma.$transaction(async (tx) => {
            const newMember = await tx.organizationMember.create({
                data: {
                    organizationId: invitation.organizationId,
                    userId,
                    role: invitation.role,
                    teamIds: invitation.teamIds,
                    departmentIds: invitation.departmentIds,
                },
            });
            await tx.organizationInvitation.update({
                where: { id: invitation.id },
                data: {
                    status: "ACCEPTED",
                    acceptedAt: new Date(),
                },
            });
            return newMember;
        });
        return member;
    }
};
exports.OrganizationInvitationService = OrganizationInvitationService;
exports.OrganizationInvitationService = OrganizationInvitationService = __decorate([
    (0, common_1.Injectable)(),
    __param(1, (0, common_1.Inject)(mail_service_interface_1.IMailServiceToken)),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService, Object])
], OrganizationInvitationService);
//# sourceMappingURL=organization-invitation.service.js.map