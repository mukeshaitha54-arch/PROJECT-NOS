import { UserRole, PermissionFlag, PermissionMatrixDto } from "@nos/shared-types";
import { IDeviceGovernanceRepository } from "../../../common/repositories/tenant.repository.interface";
export declare class RbacEvaluationService {
    private readonly governanceRepository;
    constructor(governanceRepository: IDeviceGovernanceRepository);
    private getDefaultRolePermissions;
    hasPermission(organizationId: string, role: UserRole | string, requiredPermission: PermissionFlag, customRoleId?: string, abacContext?: Record<string, any>): Promise<boolean>;
    getPermissionMatrix(organizationId: string): Promise<PermissionMatrixDto>;
}
