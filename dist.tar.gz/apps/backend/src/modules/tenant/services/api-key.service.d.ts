import { ApiKeyDto, ApiKeyCreateRequestDto, TenantContext } from "@nos/shared-types";
import { IApiKeyRepository } from "../../../common/repositories/tenant.repository.interface";
import { QuotaEngineService } from "./quota-engine.service";
import { AuditEngineService } from "./audit-engine.service";
export declare class ApiKeyService {
    private readonly apiKeyRepository;
    private readonly quotaService;
    private readonly auditService;
    constructor(apiKeyRepository: IApiKeyRepository, quotaService: QuotaEngineService, auditService: AuditEngineService);
    private hashKey;
    generate(organizationId: string, createdByUserId: string, data: ApiKeyCreateRequestDto, context: TenantContext): Promise<{
        apiKey: ApiKeyDto;
        plainKey: string;
    }>;
    validateAndRecordUsage(plainKey: string): Promise<ApiKeyDto>;
    list(organizationId: string, params?: {
        page?: number;
        limit?: number;
        search?: string;
    }): Promise<{
        items: ApiKeyDto[];
        total: number;
    }>;
    revoke(organizationId: string, id: string, context: TenantContext, reason?: string): Promise<void>;
}
