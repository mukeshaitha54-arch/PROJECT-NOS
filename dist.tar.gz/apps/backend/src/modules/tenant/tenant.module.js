"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TenantModule = void 0;
const common_1 = require("@nestjs/common");
const tenant_controller_1 = require("./controllers/tenant.controller");
const organization_invitation_controller_1 = require("./controllers/organization-invitation.controller");
const tenant_sessions_controller_1 = require("./tenant-sessions.controller");
const organization_service_1 = require("./services/organization.service");
const user_governance_service_1 = require("./services/user-governance.service");
const api_key_service_1 = require("./services/api-key.service");
const audit_engine_service_1 = require("./services/audit-engine.service");
const device_governance_service_1 = require("./services/device-governance.service");
const rbac_evaluation_service_1 = require("./services/rbac-evaluation.service");
const quota_engine_service_1 = require("./services/quota-engine.service");
const tenant_scores_service_1 = require("./services/tenant-scores.service");
const organization_invitation_service_1 = require("./services/organization-invitation.service");
const tenant_sessions_service_1 = require("./tenant-sessions.service");
const device_module_1 = require("../device/device.module");
const auth_module_1 = require("../auth/auth.module");
let TenantModule = class TenantModule {
};
exports.TenantModule = TenantModule;
exports.TenantModule = TenantModule = __decorate([
    (0, common_1.Global)(),
    (0, common_1.Module)({
        imports: [device_module_1.DeviceModule, auth_module_1.AuthModule],
        controllers: [
            tenant_controller_1.TenantController,
            organization_invitation_controller_1.OrganizationInvitationController,
            tenant_sessions_controller_1.TenantSessionsController,
        ],
        providers: [
            organization_service_1.OrganizationService,
            user_governance_service_1.UserGovernanceService,
            api_key_service_1.ApiKeyService,
            audit_engine_service_1.AuditEngineService,
            device_governance_service_1.DeviceGovernanceService,
            rbac_evaluation_service_1.RbacEvaluationService,
            quota_engine_service_1.QuotaEngineService,
            tenant_scores_service_1.TenantScoresService,
            organization_invitation_service_1.OrganizationInvitationService,
            tenant_sessions_service_1.TenantSessionsService,
        ],
        exports: [
            organization_service_1.OrganizationService,
            user_governance_service_1.UserGovernanceService,
            api_key_service_1.ApiKeyService,
            audit_engine_service_1.AuditEngineService,
            device_governance_service_1.DeviceGovernanceService,
            rbac_evaluation_service_1.RbacEvaluationService,
            quota_engine_service_1.QuotaEngineService,
            tenant_scores_service_1.TenantScoresService,
            organization_invitation_service_1.OrganizationInvitationService,
            tenant_sessions_service_1.TenantSessionsService,
        ],
    })
], TenantModule);
//# sourceMappingURL=tenant.module.js.map