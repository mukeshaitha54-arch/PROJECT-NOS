"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var TenantSessionsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.TenantSessionsService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma/prisma.service");
let TenantSessionsService = TenantSessionsService_1 = class TenantSessionsService {
    prisma;
    logger = new common_1.Logger(TenantSessionsService_1.name);
    constructor(prisma) {
        this.prisma = prisma;
    }
    async getActiveSessions() {
        const [refreshTokens, userSessions] = await Promise.all([
            this.prisma.refreshToken.findMany({
                where: { isRevoked: false },
                include: { user: true },
                orderBy: { createdAt: "desc" },
            }),
            this.prisma.userSession.findMany({
                where: { isRevoked: false, isActive: true },
            }),
        ]);
        const sessionMap = new Map();
        for (const session of userSessions) {
            if (!sessionMap.has(session.userId) ||
                session.lastUsedAt > sessionMap.get(session.userId).lastUsedAt) {
                sessionMap.set(session.userId, session);
            }
        }
        const sessions = refreshTokens.map((token) => {
            const user = token.user || {};
            const activeSession = sessionMap.get(token.userId);
            const name = [user.firstName, user.lastName].filter(Boolean).join(" ") ||
                user.email ||
                "Unknown User";
            const lastActive = activeSession?.lastUsedAt
                ? activeSession.lastUsedAt.toISOString()
                : token.createdAt.toISOString();
            const ipAddress = activeSession?.ipAddress || "127.0.0.1";
            const userAgent = activeSession?.browser || "NOS-Web-Console/7.0";
            return {
                userId: token.userId,
                name,
                email: user.email || "unknown@nos.io",
                role: user.role || "VIEWER",
                lastActive,
                ipAddress,
                userAgent,
            };
        });
        return {
            success: true,
            data: {
                sessions,
            },
        };
    }
};
exports.TenantSessionsService = TenantSessionsService;
exports.TenantSessionsService = TenantSessionsService = TenantSessionsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], TenantSessionsService);
//# sourceMappingURL=tenant-sessions.service.js.map