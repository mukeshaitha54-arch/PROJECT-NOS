"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UsersController = void 0;
const openapi = require("@nestjs/swagger");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const jwt_auth_guard_1 = require("../../common/guards/jwt-auth.guard");
const roles_guard_1 = require("../../common/guards/roles.guard");
const roles_decorator_1 = require("../../common/decorators/roles.decorator");
const current_user_decorator_1 = require("../../common/decorators/current-user.decorator");
const shared_types_1 = require("@nos/shared-types");
let UsersController = class UsersController {
    async getProfile(user) {
        return {
            success: true,
            data: user,
            timestamp: new Date().toISOString(),
        };
    }
    async adminPing(user) {
        return {
            success: true,
            data: {
                message: "RBAC verified: Administrative access granted.",
                userId: user.id,
                role: user.role,
            },
            timestamp: new Date().toISOString(),
        };
    }
};
exports.UsersController = UsersController;
__decorate([
    (0, common_1.Get)("me"),
    (0, roles_decorator_1.Roles)(shared_types_1.UserRole.SUPER_ADMIN, shared_types_1.UserRole.ADMIN, shared_types_1.UserRole.OPERATOR, shared_types_1.UserRole.ANALYST, shared_types_1.UserRole.VIEWER, shared_types_1.UserRole.USER),
    (0, swagger_1.ApiOperation)({
        summary: "Retrieve profile information for currently authenticated user",
    }),
    (0, swagger_1.ApiResponse)({
        status: common_1.HttpStatus.OK,
        description: "Current authenticated user profile data.",
    }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "getProfile", null);
__decorate([
    (0, common_1.Get)("admin/ping"),
    (0, roles_decorator_1.Roles)(shared_types_1.UserRole.SUPER_ADMIN, shared_types_1.UserRole.ADMIN),
    (0, swagger_1.ApiOperation)({
        summary: "Test endpoint verifying RBAC Administrative privilege access",
    }),
    (0, swagger_1.ApiResponse)({
        status: common_1.HttpStatus.OK,
        description: "Confirmed Administrative RBAC permissions.",
    }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "adminPing", null);
exports.UsersController = UsersController = __decorate([
    (0, swagger_1.ApiTags)("Users & Identity Management"),
    (0, common_1.Controller)("users"),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    (0, swagger_1.ApiBearerAuth)()
], UsersController);
//# sourceMappingURL=users.controller.js.map