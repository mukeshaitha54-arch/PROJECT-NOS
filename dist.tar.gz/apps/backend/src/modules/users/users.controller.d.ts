import { User, ApiResponse } from "@nos/shared-types";
export declare class UsersController {
    getProfile(user: User): Promise<ApiResponse<User>>;
    adminPing(user: User): Promise<ApiResponse>;
}
