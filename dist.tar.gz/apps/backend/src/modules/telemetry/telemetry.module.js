"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TelemetryModule = void 0;
const common_1 = require("@nestjs/common");
const telemetry_controller_1 = require("./telemetry.controller");
const telemetry_service_1 = require("./telemetry.service");
const telemetry_aggregation_service_1 = require("./telemetry-aggregation.service");
const telemetry_cron_service_1 = require("./telemetry-cron.service");
const telemetry_retention_service_1 = require("./telemetry-retention.service");
const prisma_telemetry_repository_1 = require("../../database/repositories/prisma-telemetry.repository");
const noop_telemetry_publisher_service_1 = require("../../common/services/noop-telemetry-publisher.service");
const telemetry_repository_interface_1 = require("../../common/repositories/telemetry.repository.interface");
const telemetry_publisher_interface_1 = require("../../common/services/telemetry-publisher.interface");
const device_module_1 = require("../device/device.module");
const database_module_1 = require("../../database/database.module");
let TelemetryModule = class TelemetryModule {
};
exports.TelemetryModule = TelemetryModule;
exports.TelemetryModule = TelemetryModule = __decorate([
    (0, common_1.Module)({
        imports: [device_module_1.DeviceModule, database_module_1.DatabaseModule],
        controllers: [telemetry_controller_1.TelemetryController],
        providers: [
            telemetry_service_1.TelemetryService,
            telemetry_aggregation_service_1.TelemetryAggregationService,
            telemetry_cron_service_1.TelemetryCronService,
            telemetry_retention_service_1.TelemetryRetentionService,
            { provide: telemetry_repository_interface_1.ITelemetryRepositoryToken, useClass: prisma_telemetry_repository_1.PrismaTelemetryRepository },
            {
                provide: telemetry_publisher_interface_1.ITelemetryPublisherToken,
                useClass: noop_telemetry_publisher_service_1.NoOpTelemetryPublisherService,
            },
        ],
        exports: [
            telemetry_service_1.TelemetryService,
            telemetry_aggregation_service_1.TelemetryAggregationService,
            telemetry_retention_service_1.TelemetryRetentionService,
            telemetry_repository_interface_1.ITelemetryRepositoryToken,
            telemetry_publisher_interface_1.ITelemetryPublisherToken,
        ],
    })
], TelemetryModule);
//# sourceMappingURL=telemetry.module.js.map