import { Device } from "@prisma/client";
import { TelemetryService } from "./telemetry.service";
import { SubmitTelemetryDto, TelemetryHistoryQueryDto } from "./dto/telemetry.dto";
import { AlertRuleEngineService } from "../alerts/alert-rule-engine.service";
export declare class TelemetryController {
    private readonly telemetryService;
    private readonly alertRuleEngine;
    constructor(telemetryService: TelemetryService, alertRuleEngine: AlertRuleEngineService);
    submitTelemetry(device: Device, dto: SubmitTelemetryDto): Promise<{
        success: boolean;
        snapshotId: string;
        timestamp: string;
        message: string;
        data: import("@nos/shared-types").TelemetrySnapshot;
    }>;
    getLatest(deviceId: string): Promise<{
        success: boolean;
        data: import("@nos/shared-types").TelemetrySnapshot;
    }>;
    getHistory(deviceId: string, query: TelemetryHistoryQueryDto): Promise<{
        snapshots: import("@nos/shared-types").TelemetrySnapshot[];
        total: number;
        page: number;
        limit: number;
        totalPages: number;
        success: boolean;
    }>;
}
