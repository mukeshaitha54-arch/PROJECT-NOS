import { EventEmitter2 } from "@nestjs/event-emitter";
import { Device as PrismaDevice, TelemetryAggregation } from "@prisma/client";
import { ITelemetryRepository } from "../../common/repositories/telemetry.repository.interface";
import { ITelemetryPublisher } from "../../common/services/telemetry-publisher.interface";
import { SubmitTelemetryDto, TelemetryHistoryQueryDto } from "./dto/telemetry.dto";
import { TelemetrySnapshot as TelemetrySnapshotContract, PaginatedTelemetryResponse } from "@nos/shared-types";
import { PrismaService } from "../../database/prisma.service";
export declare class TelemetryService {
    private readonly telemetryRepo;
    private readonly publisher;
    private readonly eventEmitter;
    private readonly prisma;
    private readonly logger;
    constructor(telemetryRepo: ITelemetryRepository, publisher: ITelemetryPublisher, eventEmitter: EventEmitter2, prisma: PrismaService);
    recordTelemetry(authenticatedDevice: PrismaDevice, dto: SubmitTelemetryDto): Promise<TelemetrySnapshotContract>;
    getLatestTelemetry(deviceId: string): Promise<TelemetrySnapshotContract>;
    getLatestAggregated(deviceId: string, granularity: "1m" | "15m" | "1h" | "1d"): Promise<TelemetryAggregation>;
    getHistory(deviceId: string, startDate?: Date | string, endDate?: Date | string, page?: number, limit?: number): Promise<PaginatedTelemetryResponse>;
    getTelemetryHistory(deviceId: string, query: TelemetryHistoryQueryDto): Promise<PaginatedTelemetryResponse>;
}
