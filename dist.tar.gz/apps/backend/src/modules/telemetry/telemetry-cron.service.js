"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var TelemetryCronService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.TelemetryCronService = void 0;
const common_1 = require("@nestjs/common");
const schedule_1 = require("@nestjs/schedule");
const prisma_service_1 = require("../../database/prisma.service");
const telemetry_aggregation_service_1 = require("./telemetry-aggregation.service");
const telemetry_retention_service_1 = require("./telemetry-retention.service");
let TelemetryCronService = TelemetryCronService_1 = class TelemetryCronService {
    prisma;
    aggregationService;
    retentionService;
    logger = new common_1.Logger(TelemetryCronService_1.name);
    constructor(prisma, aggregationService, retentionService) {
        this.prisma = prisma;
        this.aggregationService = aggregationService;
        this.retentionService = retentionService;
    }
    async handle1MinuteAggregation() {
        const lockKey = "aggregation_lock_1m";
        if (!(await this.acquireLock(lockKey))) {
            this.logger.warn("[1m] Telemetry aggregation already RUNNING. Skipping scheduled run.");
            return;
        }
        try {
            const startTime = new Date();
            this.logger.log(`Starting [1m] aggregation schedule at ${startTime.toISOString()}`);
            const result = await this.aggregationService.aggregateSnapshots("1m", 5);
            const duration = Date.now() - startTime.getTime();
            this.logger.log(`Completed [1m] schedule run in ${duration}ms — Devices processed: ${result.devicesProcessed}, Rows inserted: ${result.rowsInserted}.`);
        }
        catch (error) {
            this.logger.error(`Failed [1m] scheduled aggregation: ${error instanceof Error ? error.stack : error}`);
        }
        finally {
            await this.releaseLock(lockKey);
        }
    }
    async handle15MinuteAggregation() {
        const lockKey = "aggregation_lock_15m";
        if (!(await this.acquireLock(lockKey))) {
            this.logger.warn("[15m] Telemetry aggregation already RUNNING. Skipping scheduled run.");
            return;
        }
        try {
            const startTime = new Date();
            this.logger.log(`Starting [15m] aggregation schedule at ${startTime.toISOString()}`);
            const result = await this.aggregationService.aggregateSnapshots("15m", 30);
            const duration = Date.now() - startTime.getTime();
            this.logger.log(`Completed [15m] schedule run in ${duration}ms — Devices processed: ${result.devicesProcessed}, Rows inserted: ${result.rowsInserted}.`);
        }
        catch (error) {
            this.logger.error(`Failed [15m] scheduled aggregation: ${error instanceof Error ? error.stack : error}`);
        }
        finally {
            await this.releaseLock(lockKey);
        }
    }
    async handle1HourAggregation() {
        const lockKey = "aggregation_lock_1h";
        if (!(await this.acquireLock(lockKey))) {
            this.logger.warn("[1h] Telemetry aggregation already RUNNING. Skipping scheduled run.");
            return;
        }
        try {
            const startTime = new Date();
            this.logger.log(`Starting [1h] aggregation schedule at ${startTime.toISOString()}`);
            const result = await this.aggregationService.aggregateSnapshots("1h", 360);
            const duration = Date.now() - startTime.getTime();
            this.logger.log(`Completed [1h] schedule run in ${duration}ms — Devices processed: ${result.devicesProcessed}, Rows inserted: ${result.rowsInserted}.`);
        }
        catch (error) {
            this.logger.error(`Failed [1h] scheduled aggregation: ${error instanceof Error ? error.stack : error}`);
        }
        finally {
            await this.releaseLock(lockKey);
        }
    }
    async handleDailyAggregation() {
        const lockKey = "aggregation_lock_1d";
        if (!(await this.acquireLock(lockKey))) {
            this.logger.warn("[1d] Telemetry aggregation already RUNNING. Skipping scheduled run.");
            return;
        }
        try {
            const startTime = new Date();
            this.logger.log(`Starting [1d] daily aggregation schedule at ${startTime.toISOString()}`);
            const result = await this.aggregationService.aggregateSnapshots("1d", 1440);
            const duration = Date.now() - startTime.getTime();
            this.logger.log(`Completed [1d] schedule run in ${duration}ms — Devices processed: ${result.devicesProcessed}, Rows inserted: ${result.rowsInserted}.`);
        }
        catch (error) {
            this.logger.error(`Failed [1d] scheduled aggregation: ${error instanceof Error ? error.stack : error}`);
        }
        finally {
            await this.releaseLock(lockKey);
        }
    }
    async handleDailyRetentionPurge() {
        const lockKey = "retention_purge_lock";
        if (!(await this.acquireLock(lockKey))) {
            this.logger.warn("Telemetry data retention purge already RUNNING. Skipping scheduled run.");
            return;
        }
        try {
            this.logger.log(`Triggering daily data retention purge schedule at ${new Date().toISOString()}...`);
            await this.retentionService.purgeOldData();
        }
        catch (error) {
            this.logger.error(`Failed daily retention purge: ${error instanceof Error ? error.stack : error}`);
        }
        finally {
            await this.releaseLock(lockKey);
        }
    }
    async acquireLock(key) {
        try {
            const current = await this.prisma.keyValue.findUnique({ where: { key } });
            if (current && current.value === "RUNNING") {
                return false;
            }
            await this.prisma.keyValue.upsert({
                where: { key },
                update: { value: "RUNNING" },
                create: { key, value: "RUNNING" },
            });
            return true;
        }
        catch (error) {
            this.logger.error(`Error acquiring KeyValue lock [${key}]: ${error instanceof Error ? error.message : error}`);
            return false;
        }
    }
    async releaseLock(key) {
        try {
            await this.prisma.keyValue.upsert({
                where: { key },
                update: { value: "IDLE" },
                create: { key, value: "IDLE" },
            });
        }
        catch (error) {
            this.logger.error(`Error releasing KeyValue lock [${key}]: ${error instanceof Error ? error.message : error}`);
        }
    }
};
exports.TelemetryCronService = TelemetryCronService;
__decorate([
    (0, schedule_1.Cron)(schedule_1.CronExpression.EVERY_MINUTE),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], TelemetryCronService.prototype, "handle1MinuteAggregation", null);
__decorate([
    (0, schedule_1.Cron)("0 */15 * * * *"),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], TelemetryCronService.prototype, "handle15MinuteAggregation", null);
__decorate([
    (0, schedule_1.Cron)(schedule_1.CronExpression.EVERY_HOUR),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], TelemetryCronService.prototype, "handle1HourAggregation", null);
__decorate([
    (0, schedule_1.Cron)("0 0 2 * * *"),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], TelemetryCronService.prototype, "handleDailyAggregation", null);
__decorate([
    (0, schedule_1.Cron)("0 5 2 * * *"),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], TelemetryCronService.prototype, "handleDailyRetentionPurge", null);
exports.TelemetryCronService = TelemetryCronService = TelemetryCronService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        telemetry_aggregation_service_1.TelemetryAggregationService,
        telemetry_retention_service_1.TelemetryRetentionService])
], TelemetryCronService);
//# sourceMappingURL=telemetry-cron.service.js.map