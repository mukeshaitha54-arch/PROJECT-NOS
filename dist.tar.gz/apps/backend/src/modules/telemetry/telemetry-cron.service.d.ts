import { PrismaService } from "../../database/prisma.service";
import { TelemetryAggregationService } from "./telemetry-aggregation.service";
import { TelemetryRetentionService } from "./telemetry-retention.service";
export declare class TelemetryCronService {
    private readonly prisma;
    private readonly aggregationService;
    private readonly retentionService;
    private readonly logger;
    constructor(prisma: PrismaService, aggregationService: TelemetryAggregationService, retentionService: TelemetryRetentionService);
    handle1MinuteAggregation(): Promise<void>;
    handle15MinuteAggregation(): Promise<void>;
    handle1HourAggregation(): Promise<void>;
    handleDailyAggregation(): Promise<void>;
    handleDailyRetentionPurge(): Promise<void>;
    private acquireLock;
    private releaseLock;
}
