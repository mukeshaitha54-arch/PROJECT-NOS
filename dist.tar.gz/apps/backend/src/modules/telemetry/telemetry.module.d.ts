export declare class TelemetryModule {
}
