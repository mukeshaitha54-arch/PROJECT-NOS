"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var TelemetryAggregationService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.TelemetryAggregationService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../database/prisma.service");
let TelemetryAggregationService = TelemetryAggregationService_1 = class TelemetryAggregationService {
    prisma;
    logger = new common_1.Logger(TelemetryAggregationService_1.name);
    constructor(prisma) {
        this.prisma = prisma;
    }
    async aggregateSnapshots(granularity, defaultWindowMinutes) {
        const startTime = Date.now();
        this.logger.log(`Starting telemetry aggregation cycle for granularity [${granularity}]...`);
        const keyName = `aggregation_last_run_${granularity}`;
        const lastRunRecord = await this.prisma.keyValue.findUnique({
            where: { key: keyName },
        });
        const now = new Date();
        let lastRun;
        if (lastRunRecord && lastRunRecord.value) {
            lastRun = new Date(lastRunRecord.value);
            if (isNaN(lastRun.getTime())) {
                lastRun = this.getDefaultLastRun(granularity, defaultWindowMinutes, now);
            }
        }
        else {
            lastRun = this.getDefaultLastRun(granularity, defaultWindowMinutes, now);
        }
        const snapshots = await this.prisma.telemetrySnapshot.findMany({
            where: {
                timestamp: {
                    gt: lastRun,
                    lte: now,
                },
            },
            orderBy: { timestamp: "asc" },
            include: {
                device: {
                    select: { id: true, organizationId: true },
                },
            },
        });
        if (snapshots.length === 0) {
            this.logger.log(`No new telemetry snapshots found since [${lastRun.toISOString()}] for granularity [${granularity}]. Returning early.`);
            await this.prisma.keyValue.upsert({
                where: { key: keyName },
                update: { value: now.toISOString() },
                create: { key: keyName, value: now.toISOString() },
            });
            return { devicesProcessed: 0, rowsInserted: 0 };
        }
        const distinctDeviceIds = new Set();
        const bucketMap = new Map();
        const bucketDurationMs = this.getBucketDurationMs(granularity);
        for (const snap of snapshots) {
            distinctDeviceIds.add(snap.deviceId);
            const tenantId = snap.device?.organizationId || "default-org";
            const bucketStart = this.calculateBucketStart(snap.timestamp, granularity, bucketDurationMs);
            const groupKey = `${snap.deviceId}__${bucketStart.getTime()}`;
            let group = bucketMap.get(groupKey);
            if (!group) {
                group = [];
                bucketMap.set(groupKey, group);
            }
            group.push({ ...snap, tenantId });
        }
        const aggregatedBuckets = [];
        for (const [_, group] of bucketMap) {
            if (group.length === 0)
                continue;
            const sample = group[0];
            const periodStart = this.calculateBucketStart(sample.timestamp, granularity, bucketDurationMs);
            const periodEnd = new Date(periodStart.getTime() + bucketDurationMs);
            const cpuValues = group
                .map((g) => g.cpuUsage)
                .filter((val) => val != null && !isNaN(val));
            const ramValues = group
                .map((g) => g.memoryUsagePercent)
                .filter((val) => val != null && !isNaN(val));
            const diskValues = group
                .map((g) => g.diskUsagePercent)
                .filter((val) => val != null && !isNaN(val));
            const netValues = group
                .map((g) => (g.networkUploadSpeed ?? 0) + (g.networkDownloadSpeed ?? 0))
                .filter((val) => val != null && !isNaN(val));
            const avgCpu = cpuValues.length
                ? cpuValues.reduce((a, b) => a + b, 0) / cpuValues.length
                : 0;
            const maxCpu = cpuValues.length ? Math.max(...cpuValues) : 0;
            const minCpu = cpuValues.length ? Math.min(...cpuValues) : 0;
            const avgRam = ramValues.length
                ? ramValues.reduce((a, b) => a + b, 0) / ramValues.length
                : 0;
            const maxRam = ramValues.length ? Math.max(...ramValues) : 0;
            const avgDisk = diskValues.length
                ? diskValues.reduce((a, b) => a + b, 0) / diskValues.length
                : 0;
            const avgNetwork = netValues.length
                ? netValues.reduce((a, b) => a + b, 0) / netValues.length
                : 0;
            aggregatedBuckets.push({
                deviceId: sample.deviceId,
                tenantId: sample.tenantId,
                periodStart,
                periodEnd,
                avgCpu: Math.round(avgCpu * 100) / 100,
                maxCpu: Math.round(maxCpu * 100) / 100,
                minCpu: Math.round(minCpu * 100) / 100,
                avgRam: Math.round(avgRam * 100) / 100,
                maxRam: Math.round(maxRam * 100) / 100,
                avgDisk: Math.round(avgDisk * 100) / 100,
                avgNetwork: Math.round(avgNetwork * 100) / 100,
                sampleCount: group.length,
            });
        }
        const transactions = [];
        for (const bucket of aggregatedBuckets) {
            transactions.push(this.prisma.telemetryAggregation.create({
                data: {
                    deviceId: bucket.deviceId,
                    tenantId: bucket.tenantId,
                    tier: granularity,
                    granularity: granularity,
                    avgCpu: bucket.avgCpu,
                    maxCpu: bucket.maxCpu,
                    minCpu: bucket.minCpu,
                    avgRam: bucket.avgRam,
                    maxRam: bucket.maxRam,
                    avgDisk: bucket.avgDisk,
                    avgNetwork: bucket.avgNetwork,
                    sampleCount: bucket.sampleCount,
                    periodStart: bucket.periodStart,
                    periodEnd: bucket.periodEnd,
                },
            }));
        }
        transactions.push(this.prisma.keyValue.upsert({
            where: { key: keyName },
            update: { value: now.toISOString() },
            create: { key: keyName, value: now.toISOString() },
        }));
        await this.prisma.$transaction(transactions);
        const duration = Date.now() - startTime;
        this.logger.log(`Completed aggregation for [${granularity}] in ${duration}ms. Processed ${distinctDeviceIds.size} device(s), inserted ${aggregatedBuckets.length} aggregation row(s).`);
        return {
            devicesProcessed: distinctDeviceIds.size,
            rowsInserted: aggregatedBuckets.length,
        };
    }
    getDefaultLastRun(granularity, customMinutes, now) {
        const minutes = customMinutes ??
            (granularity === "1m"
                ? 5
                : granularity === "15m"
                    ? 30
                    : granularity === "1h"
                        ? 360
                        : 1440);
        return new Date(now.getTime() - minutes * 60 * 1000);
    }
    getBucketDurationMs(granularity) {
        switch (granularity) {
            case "1m":
                return 60 * 1000;
            case "15m":
                return 15 * 60 * 1000;
            case "1h":
                return 60 * 60 * 1000;
            case "1d":
                return 24 * 60 * 60 * 1000;
        }
    }
    calculateBucketStart(timestamp, granularity, bucketMs) {
        if (granularity === "1d") {
            const day = new Date(timestamp);
            day.setUTCHours(0, 0, 0, 0);
            return day;
        }
        const ms = timestamp.getTime();
        return new Date(Math.floor(ms / bucketMs) * bucketMs);
    }
};
exports.TelemetryAggregationService = TelemetryAggregationService;
exports.TelemetryAggregationService = TelemetryAggregationService = TelemetryAggregationService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], TelemetryAggregationService);
//# sourceMappingURL=telemetry-aggregation.service.js.map