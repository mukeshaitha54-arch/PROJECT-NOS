import { PrismaService } from "../../database/prisma.service";
export type Granularity = "1m" | "15m" | "1h" | "1d";
export declare class TelemetryAggregationService {
    private readonly prisma;
    private readonly logger;
    constructor(prisma: PrismaService);
    aggregateSnapshots(granularity: Granularity, defaultWindowMinutes?: number): Promise<{
        devicesProcessed: number;
        rowsInserted: number;
    }>;
    private getDefaultLastRun;
    private getBucketDurationMs;
    private calculateBucketStart;
}
