import { PrismaService } from "../../database/prisma.service";
export declare class TelemetryRetentionService {
    private readonly prisma;
    private readonly logger;
    constructor(prisma: PrismaService);
    purgeOldData(): Promise<void>;
}
