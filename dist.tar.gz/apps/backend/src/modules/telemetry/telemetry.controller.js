"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TelemetryController = void 0;
const openapi = require("@nestjs/swagger");
const common_1 = require("@nestjs/common");
const throttler_1 = require("@nestjs/throttler");
const swagger_1 = require("@nestjs/swagger");
const telemetry_service_1 = require("./telemetry.service");
const telemetry_dto_1 = require("./dto/telemetry.dto");
const device_auth_guard_1 = require("../device/guards/device-auth.guard");
const current_device_decorator_1 = require("../device/decorators/current-device.decorator");
const alert_rule_engine_service_1 = require("../alerts/alert-rule-engine.service");
let TelemetryController = class TelemetryController {
    telemetryService;
    alertRuleEngine;
    constructor(telemetryService, alertRuleEngine) {
        this.telemetryService = telemetryService;
        this.alertRuleEngine = alertRuleEngine;
    }
    async submitTelemetry(device, dto) {
        const data = await this.telemetryService.recordTelemetry(device, dto);
        const orgId = device.tenantId ||
            device.organizationId ||
            "default-org";
        this.alertRuleEngine
            .evaluateTelemetry(device.id, orgId, dto)
            .catch((err) => {
        });
        return {
            success: true,
            snapshotId: data.id,
            timestamp: data.timestamp,
            message: "Telemetry snapshot successfully stored in UTC.",
            data,
        };
    }
    async getLatest(deviceId) {
        const data = await this.telemetryService.getLatestTelemetry(deviceId);
        return {
            success: true,
            data,
        };
    }
    async getHistory(deviceId, query) {
        const result = await this.telemetryService.getTelemetryHistory(deviceId, query);
        return {
            success: true,
            ...result,
        };
    }
};
exports.TelemetryController = TelemetryController;
__decorate([
    (0, common_1.Post)(),
    (0, common_1.HttpCode)(common_1.HttpStatus.CREATED),
    (0, common_1.UseGuards)(device_auth_guard_1.DeviceAuthGuard),
    (0, swagger_1.ApiOperation)({
        summary: "Submit real-time hardware telemetry snapshot (30s interval)",
        description: "Protected via X-Device-Token. Ingests raw hardware system performance metrics and executes validation bounds checking.",
    }),
    (0, swagger_1.ApiHeader)({
        name: "X-Device-Token",
        required: true,
        description: "Cryptographic device authentication credentials",
    }),
    (0, swagger_1.ApiResponse)({
        status: 201,
        description: "Telemetry snapshot validated and persisted successfully.",
    }),
    (0, swagger_1.ApiResponse)({
        status: 400,
        description: "Malformed payload parameters or invalid percentage boundaries.",
    }),
    (0, swagger_1.ApiResponse)({
        status: 401,
        description: "Unknown device, invalid token, or expired session.",
    }),
    openapi.ApiResponse({ status: common_1.HttpStatus.CREATED }),
    __param(0, (0, current_device_decorator_1.CurrentDevice)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, telemetry_dto_1.SubmitTelemetryDto]),
    __metadata("design:returntype", Promise)
], TelemetryController.prototype, "submitTelemetry", null);
__decorate([
    (0, common_1.Get)("latest/:deviceId"),
    (0, swagger_1.ApiOperation)({
        summary: "Retrieve latest telemetry snapshot by Device UUID",
        description: "Returns most recent hardware diagnostic snapshot recorded for the specified device.",
    }),
    (0, swagger_1.ApiParam)({
        name: "deviceId",
        required: true,
        description: "Target Device Primary Key UUID",
    }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: "Latest telemetry snapshot retrieved successfully.",
    }),
    (0, swagger_1.ApiResponse)({
        status: 404,
        description: "No telemetry historical records exist for target device.",
    }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)("deviceId")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], TelemetryController.prototype, "getLatest", null);
__decorate([
    (0, common_1.Get)("history/:deviceId"),
    (0, swagger_1.ApiOperation)({
        summary: "Retrieve historical telemetry snapshots with time-series pagination",
        description: "Supports UTC from/to range filters and limit/page pagination parameters.",
    }),
    (0, swagger_1.ApiParam)({
        name: "deviceId",
        required: true,
        description: "Target Device Primary Key UUID",
    }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: "Paginated telemetry dataset retrieved successfully.",
    }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)("deviceId")),
    __param(1, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, telemetry_dto_1.TelemetryHistoryQueryDto]),
    __metadata("design:returntype", Promise)
], TelemetryController.prototype, "getHistory", null);
exports.TelemetryController = TelemetryController = __decorate([
    (0, throttler_1.SkipThrottle)({ auth: true }),
    (0, swagger_1.ApiTags)("Telemetry Ingestion & Queries (Phase 2B)"),
    (0, common_1.Controller)("telemetry"),
    __metadata("design:paramtypes", [telemetry_service_1.TelemetryService,
        alert_rule_engine_service_1.AlertRuleEngineService])
], TelemetryController);
//# sourceMappingURL=telemetry.controller.js.map