"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var TelemetryRetentionService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.TelemetryRetentionService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../database/prisma.service");
let TelemetryRetentionService = TelemetryRetentionService_1 = class TelemetryRetentionService {
    prisma;
    logger = new common_1.Logger(TelemetryRetentionService_1.name);
    constructor(prisma) {
        this.prisma = prisma;
    }
    async purgeOldData() {
        const startTime = Date.now();
        this.logger.log("Starting daily telemetry retention and data purge job...");
        const now = new Date();
        const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
        const ninetyDaysAgo = new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000);
        const oneYearAgo = new Date(now.getTime() - 365 * 24 * 60 * 60 * 1000);
        try {
            const delSnapshots = await this.prisma.telemetrySnapshot.deleteMany({
                where: {
                    timestamp: { lt: sevenDaysAgo },
                },
            });
            this.logger.log(`Purged ${delSnapshots.count} raw telemetry snapshot(s) older than 7 days.`);
            const del1m = await this.prisma.telemetryAggregation.deleteMany({
                where: {
                    OR: [{ granularity: "1m" }, { tier: "1m" }],
                    periodStart: { lt: thirtyDaysAgo },
                },
            });
            this.logger.log(`Purged ${del1m.count} [1m] aggregated records older than 30 days.`);
            const del15m = await this.prisma.telemetryAggregation.deleteMany({
                where: {
                    OR: [{ granularity: "15m" }, { tier: "15m" }],
                    periodStart: { lt: ninetyDaysAgo },
                },
            });
            this.logger.log(`Purged ${del15m.count} [15m] aggregated records older than 90 days.`);
            const del1h = await this.prisma.telemetryAggregation.deleteMany({
                where: {
                    OR: [{ granularity: "1h" }, { tier: "1h" }],
                    periodStart: { lt: oneYearAgo },
                },
            });
            this.logger.log(`Purged ${del1h.count} [1h] aggregated records older than 1 year.`);
            try {
                await this.prisma.$queryRawUnsafe("VACUUM telemetry_snapshots;");
                await this.prisma.$queryRawUnsafe("VACUUM telemetry_aggregations;");
                this.logger.log("Successfully executed VACUUM on telemetry tables.");
            }
            catch (vacuumErr) {
                this.logger.debug(`VACUUM operation skipped (not supported by current engine or restricted): ${vacuumErr instanceof Error ? vacuumErr.message : vacuumErr}`);
            }
            const duration = Date.now() - startTime;
            this.logger.log(`Telemetry data retention purge completed successfully in ${duration}ms.`);
        }
        catch (error) {
            this.logger.error(`Error executing telemetry data retention purge: ${error instanceof Error ? error.stack : error}`);
        }
    }
};
exports.TelemetryRetentionService = TelemetryRetentionService;
exports.TelemetryRetentionService = TelemetryRetentionService = TelemetryRetentionService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], TelemetryRetentionService);
//# sourceMappingURL=telemetry-retention.service.js.map