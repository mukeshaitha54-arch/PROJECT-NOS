"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TelemetryHistoryQueryDto = exports.SubmitTelemetryDto = void 0;
exports.toTelemetrySnapshotDto = toTelemetrySnapshotDto;
const openapi = require("@nestjs/swagger");
const class_validator_1 = require("class-validator");
const swagger_1 = require("@nestjs/swagger");
const class_transformer_1 = require("class-transformer");
class RunningServiceDto {
    name;
    status;
    startType;
    static _OPENAPI_METADATA_FACTORY() {
        return { name: { required: true, type: () => String }, status: { required: true, type: () => String }, startType: { required: true, type: () => String } };
    }
}
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], RunningServiceDto.prototype, "name", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], RunningServiceDto.prototype, "status", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], RunningServiceDto.prototype, "startType", void 0);
class GatewayDto {
    ipv4;
    ipv6;
    mac;
    static _OPENAPI_METADATA_FACTORY() {
        return { ipv4: { required: false, type: () => String }, ipv6: { required: false, type: () => String }, mac: { required: false, type: () => String } };
    }
}
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], GatewayDto.prototype, "ipv4", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], GatewayDto.prototype, "ipv6", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], GatewayDto.prototype, "mac", void 0);
class DnsDto {
    primary;
    secondary;
    servers;
    static _OPENAPI_METADATA_FACTORY() {
        return { primary: { required: false, type: () => String }, secondary: { required: false, type: () => String }, servers: { required: false, type: () => [String] } };
    }
}
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], DnsDto.prototype, "primary", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], DnsDto.prototype, "secondary", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.IsString)({ each: true }),
    __metadata("design:type", Array)
], DnsDto.prototype, "servers", void 0);
class SubmitTelemetryDto {
    deviceId;
    cpuUsage;
    cpuTemperature;
    cpuFrequency;
    logicalProcessors;
    physicalProcessors;
    memoryUsed;
    memoryFree;
    memoryTotal;
    memoryUsagePercent;
    diskReadSpeed;
    diskWriteSpeed;
    diskUsagePercent;
    diskFree;
    diskTotal;
    networkUploadSpeed;
    networkDownloadSpeed;
    bytesSent;
    bytesReceived;
    activeConnections;
    runningProcesses;
    systemUptime;
    bootTime;
    ipAddress;
    macAddress;
    timestamp;
    runningServices;
    gateway;
    dns;
    static _OPENAPI_METADATA_FACTORY() {
        return { deviceId: { required: false, type: () => String }, cpuUsage: { required: true, type: () => Number, minimum: 0, maximum: 100 }, cpuTemperature: { required: true, type: () => Number }, cpuFrequency: { required: true, type: () => Number, minimum: 0 }, logicalProcessors: { required: true, type: () => Number, minimum: 1 }, physicalProcessors: { required: true, type: () => Number, minimum: 1 }, memoryUsed: { required: true, type: () => Number, minimum: 0 }, memoryFree: { required: true, type: () => Number, minimum: 0 }, memoryTotal: { required: true, type: () => Number, minimum: 0 }, memoryUsagePercent: { required: true, type: () => Number, minimum: 0, maximum: 100 }, diskReadSpeed: { required: true, type: () => Number, minimum: 0 }, diskWriteSpeed: { required: true, type: () => Number, minimum: 0 }, diskUsagePercent: { required: true, type: () => Number, minimum: 0, maximum: 100 }, diskFree: { required: true, type: () => Number, minimum: 0 }, diskTotal: { required: true, type: () => Number, minimum: 0 }, networkUploadSpeed: { required: true, type: () => Number, minimum: 0 }, networkDownloadSpeed: { required: true, type: () => Number, minimum: 0 }, bytesSent: { required: true, type: () => Number, minimum: 0 }, bytesReceived: { required: true, type: () => Number, minimum: 0 }, activeConnections: { required: true, type: () => Number, minimum: 0 }, runningProcesses: { required: true, type: () => Number, minimum: 0 }, systemUptime: { required: true, type: () => Number, minimum: 0 }, bootTime: { required: true, type: () => String }, ipAddress: { required: true, type: () => String }, macAddress: { required: true, type: () => String }, timestamp: { required: false, type: () => String }, runningServices: { required: false, type: () => Number }, gateway: { required: false, type: () => String }, dns: { required: false, type: () => String } };
    }
}
exports.SubmitTelemetryDto = SubmitTelemetryDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        description: "Explicit device UUID if differing from authorization token state",
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], SubmitTelemetryDto.prototype, "deviceId", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: "CPU processing load percentage (0 - 100%)",
        minimum: 0,
        maximum: 100,
    }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    (0, class_validator_1.Max)(100),
    __metadata("design:type", Number)
], SubmitTelemetryDto.prototype, "cpuUsage", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: "CPU temperature in degrees Celsius" }),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], SubmitTelemetryDto.prototype, "cpuTemperature", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: "CPU core clock frequency in MHz / GHz" }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], SubmitTelemetryDto.prototype, "cpuFrequency", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: "Total logical processing core threads" }),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], SubmitTelemetryDto.prototype, "logicalProcessors", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: "Total physical CPU core units" }),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], SubmitTelemetryDto.prototype, "physicalProcessors", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: "Active memory consumption in bytes or MB" }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], SubmitTelemetryDto.prototype, "memoryUsed", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: "Available free memory in bytes or MB" }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], SubmitTelemetryDto.prototype, "memoryFree", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: "Total memory capacity in bytes or MB" }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], SubmitTelemetryDto.prototype, "memoryTotal", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: "Memory usage percentage gauge (0 - 100%)",
        minimum: 0,
        maximum: 100,
    }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    (0, class_validator_1.Max)(100),
    __metadata("design:type", Number)
], SubmitTelemetryDto.prototype, "memoryUsagePercent", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: "Storage drive read throughput speed in bytes/sec",
    }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], SubmitTelemetryDto.prototype, "diskReadSpeed", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: "Storage drive write throughput speed in bytes/sec",
    }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], SubmitTelemetryDto.prototype, "diskWriteSpeed", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: "Primary disk usage percentage gauge (0 - 100%)",
        minimum: 0,
        maximum: 100,
    }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    (0, class_validator_1.Max)(100),
    __metadata("design:type", Number)
], SubmitTelemetryDto.prototype, "diskUsagePercent", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: "Available primary storage capacity in bytes or MB/GB",
    }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], SubmitTelemetryDto.prototype, "diskFree", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: "Total primary storage capacity in bytes or MB/GB",
    }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], SubmitTelemetryDto.prototype, "diskTotal", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: "Network interface transmission rate in bytes/sec",
        minimum: 0,
    }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], SubmitTelemetryDto.prototype, "networkUploadSpeed", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: "Network interface reception rate in bytes/sec",
        minimum: 0,
    }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], SubmitTelemetryDto.prototype, "networkDownloadSpeed", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: "Cumulative bytes transmitted since boot" }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], SubmitTelemetryDto.prototype, "bytesSent", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: "Cumulative bytes received since boot" }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], SubmitTelemetryDto.prototype, "bytesReceived", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: "Count of active network TCP sockets and connections",
    }),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], SubmitTelemetryDto.prototype, "activeConnections", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: "Total running operational kernel processes" }),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], SubmitTelemetryDto.prototype, "runningProcesses", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: "Host OS continuous uptime in elapsed seconds" }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], SubmitTelemetryDto.prototype, "systemUptime", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: "Host OS initial boot timestamp (ISO 8601 UTC string)",
    }),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], SubmitTelemetryDto.prototype, "bootTime", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: "Primary network interface IPv4 routing address",
    }),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], SubmitTelemetryDto.prototype, "ipAddress", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: "Primary network adapter physical hardware MAC address",
    }),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], SubmitTelemetryDto.prototype, "macAddress", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        description: "Client snapshot timestamp in ISO 8601 UTC format",
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], SubmitTelemetryDto.prototype, "timestamp", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        description: "List of running Windows services or count",
    }),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], SubmitTelemetryDto.prototype, "runningServices", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        description: "Default gateway IPv4",
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], SubmitTelemetryDto.prototype, "gateway", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: "DNS configuration IPv4" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], SubmitTelemetryDto.prototype, "dns", void 0);
class TelemetryHistoryQueryDto {
    from;
    to;
    limit;
    page;
    static _OPENAPI_METADATA_FACTORY() {
        return { from: { required: false, type: () => String }, to: { required: false, type: () => String }, limit: { required: false, type: () => Number, minimum: 1 }, page: { required: false, type: () => Number, minimum: 1 } };
    }
}
exports.TelemetryHistoryQueryDto = TelemetryHistoryQueryDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: "ISO 8601 UTC start filter timestamp" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], TelemetryHistoryQueryDto.prototype, "from", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: "ISO 8601 UTC end filter timestamp" }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], TelemetryHistoryQueryDto.prototype, "to", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        description: "Number of records per page (default 50)",
        minimum: 1,
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], TelemetryHistoryQueryDto.prototype, "limit", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        description: "1-indexed pagination page number (default 1)",
        minimum: 1,
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], TelemetryHistoryQueryDto.prototype, "page", void 0);
function toTelemetrySnapshotDto(entity) {
    return {
        id: entity.id,
        deviceId: entity.deviceId,
        cpuUsage: entity.cpuUsage,
        cpuTemperature: entity.cpuTemperature,
        cpuFrequency: entity.cpuFrequency,
        logicalProcessors: entity.logicalProcessors,
        physicalProcessors: entity.physicalProcessors,
        memoryUsed: entity.memoryUsed,
        memoryFree: entity.memoryFree,
        memoryTotal: entity.memoryTotal,
        memoryUsagePercent: entity.memoryUsagePercent,
        diskReadSpeed: entity.diskReadSpeed,
        diskWriteSpeed: entity.diskWriteSpeed,
        diskUsagePercent: entity.diskUsagePercent,
        diskFree: entity.diskFree,
        diskTotal: entity.diskTotal,
        networkUploadSpeed: entity.networkUploadSpeed,
        networkDownloadSpeed: entity.networkDownloadSpeed,
        bytesSent: entity.bytesSent ? Number(entity.bytesSent) : 0,
        bytesReceived: entity.bytesReceived ? Number(entity.bytesReceived) : 0,
        activeConnections: entity.activeConnections,
        runningProcesses: entity.runningProcesses,
        runningServices: entity.runningServices,
        systemUptime: entity.systemUptime,
        bootTime: entity.bootTime.toISOString(),
        ipAddress: entity.ipAddress,
        gateway: entity.gateway,
        dns: entity.dns,
        macAddress: entity.macAddress,
        timestamp: entity.timestamp.toISOString(),
    };
}
//# sourceMappingURL=telemetry.dto.js.map