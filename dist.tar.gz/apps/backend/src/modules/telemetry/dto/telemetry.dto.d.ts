import { TelemetrySnapshot as PrismaTelemetrySnapshot } from "@prisma/client";
import { TelemetrySnapshot as TelemetrySnapshotContract } from "@nos/shared-types";
export declare class SubmitTelemetryDto {
    deviceId?: string;
    cpuUsage: number;
    cpuTemperature: number;
    cpuFrequency: number;
    logicalProcessors: number;
    physicalProcessors: number;
    memoryUsed: number;
    memoryFree: number;
    memoryTotal: number;
    memoryUsagePercent: number;
    diskReadSpeed: number;
    diskWriteSpeed: number;
    diskUsagePercent: number;
    diskFree: number;
    diskTotal: number;
    networkUploadSpeed: number;
    networkDownloadSpeed: number;
    bytesSent: number;
    bytesReceived: number;
    activeConnections: number;
    runningProcesses: number;
    systemUptime: number;
    bootTime: string;
    ipAddress: string;
    macAddress: string;
    timestamp?: string;
    runningServices?: number;
    gateway?: string;
    dns?: string;
}
export declare class TelemetryHistoryQueryDto {
    from?: string;
    to?: string;
    limit?: number;
    page?: number;
}
export declare function toTelemetrySnapshotDto(entity: PrismaTelemetrySnapshot): TelemetrySnapshotContract;
