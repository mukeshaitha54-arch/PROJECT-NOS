"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var TelemetryService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.TelemetryService = void 0;
const common_1 = require("@nestjs/common");
const event_emitter_1 = require("@nestjs/event-emitter");
const telemetry_repository_interface_1 = require("../../common/repositories/telemetry.repository.interface");
const telemetry_publisher_interface_1 = require("../../common/services/telemetry-publisher.interface");
const telemetry_dto_1 = require("./dto/telemetry.dto");
const domain_events_1 = require("../../common/events/domain-events");
const prisma_service_1 = require("../../database/prisma.service");
const device_telemetry_paused_store_1 = require("../../common/stores/device-telemetry-paused.store");
let TelemetryService = TelemetryService_1 = class TelemetryService {
    telemetryRepo;
    publisher;
    eventEmitter;
    prisma;
    logger = new common_1.Logger(TelemetryService_1.name);
    constructor(telemetryRepo, publisher, eventEmitter, prisma) {
        this.telemetryRepo = telemetryRepo;
        this.publisher = publisher;
        this.eventEmitter = eventEmitter;
        this.prisma = prisma;
    }
    async recordTelemetry(authenticatedDevice, dto) {
        const targetDeviceId = dto.deviceId || authenticatedDevice.id;
        if (targetDeviceId !== authenticatedDevice.id) {
            throw new common_1.BadRequestException("Security violation: Cannot submit telemetry metrics on behalf of a differing device UUID.");
        }
        const isPaused = device_telemetry_paused_store_1.deviceTelemetryPausedStore.get(authenticatedDevice.id) ??
            device_telemetry_paused_store_1.deviceTelemetryPausedStore.get(authenticatedDevice.uuid) ??
            false;
        if (isPaused) {
            this.logger.debug(`Telemetry ingestion skipped for Device [${authenticatedDevice.hostname}] (${authenticatedDevice.id}): Telemetry is PAUSED.`);
            return {
                id: "paused",
                deviceId: targetDeviceId,
                cpuUsage: dto.cpuUsage,
                cpuTemperature: dto.cpuTemperature ?? 0,
                cpuFrequency: dto.cpuFrequency ?? 0,
                logicalProcessors: dto.logicalProcessors ?? 0,
                physicalProcessors: dto.physicalProcessors ?? 0,
                memoryUsed: dto.memoryUsed,
                memoryFree: dto.memoryFree,
                memoryTotal: dto.memoryTotal,
                memoryUsagePercent: dto.memoryUsagePercent,
                diskReadSpeed: dto.diskReadSpeed ?? 0,
                diskWriteSpeed: dto.diskWriteSpeed ?? 0,
                diskUsagePercent: dto.diskUsagePercent,
                diskFree: dto.diskFree,
                diskTotal: dto.diskTotal,
                networkUploadSpeed: dto.networkUploadSpeed ?? 0,
                networkDownloadSpeed: dto.networkDownloadSpeed ?? 0,
                bytesSent: dto.bytesSent ?? 0,
                bytesReceived: dto.bytesReceived ?? 0,
                activeConnections: dto.activeConnections ?? 0,
                runningProcesses: dto.runningProcesses ?? 0,
                runningServices: dto.runningServices ?? 0,
                systemUptime: dto.systemUptime,
                bootTime: new Date().toISOString(),
                ipAddress: dto.ipAddress,
                macAddress: dto.macAddress,
                gateway: dto.gateway ?? "",
                dns: dto.dns ?? "",
                timestamp: new Date().toISOString(),
            };
        }
        let bootTimeDate;
        try {
            bootTimeDate = new Date(dto.bootTime);
            if (isNaN(bootTimeDate.getTime()))
                bootTimeDate = new Date();
        }
        catch {
            bootTimeDate = new Date();
        }
        let timestampDate;
        if (dto.timestamp) {
            const parsed = new Date(dto.timestamp);
            if (!isNaN(parsed.getTime()))
                timestampDate = parsed;
        }
        const entity = await this.telemetryRepo.create({
            deviceId: targetDeviceId,
            cpuUsage: dto.cpuUsage,
            cpuTemperature: dto.cpuTemperature,
            cpuFrequency: dto.cpuFrequency,
            logicalProcessors: dto.logicalProcessors,
            physicalProcessors: dto.physicalProcessors,
            memoryUsed: dto.memoryUsed,
            memoryFree: dto.memoryFree,
            memoryTotal: dto.memoryTotal,
            memoryUsagePercent: dto.memoryUsagePercent,
            diskReadSpeed: dto.diskReadSpeed,
            diskWriteSpeed: dto.diskWriteSpeed,
            diskUsagePercent: dto.diskUsagePercent,
            diskFree: dto.diskFree,
            diskTotal: dto.diskTotal,
            networkUploadSpeed: dto.networkUploadSpeed,
            networkDownloadSpeed: dto.networkDownloadSpeed,
            bytesSent: dto.bytesSent,
            bytesReceived: dto.bytesReceived,
            activeConnections: dto.activeConnections,
            runningProcesses: dto.runningProcesses,
            runningServices: dto.runningServices ?? 0,
            systemUptime: dto.systemUptime,
            bootTime: bootTimeDate,
            ipAddress: dto.ipAddress,
            macAddress: dto.macAddress,
            gateway: dto.gateway ?? "",
            dns: dto.dns ?? "",
            timestamp: timestampDate || new Date(),
        });
        const dtoResult = (0, telemetry_dto_1.toTelemetrySnapshotDto)(entity);
        await this.publisher.publish(dtoResult);
        this.eventEmitter.emit("telemetry.received", new domain_events_1.TelemetryReceivedEvent(authenticatedDevice.organizationId || "default-org", targetDeviceId, dtoResult));
        return dtoResult;
    }
    async getLatestTelemetry(deviceId) {
        const entity = await this.telemetryRepo.findLatest(deviceId);
        if (!entity) {
            throw new common_1.NotFoundException(`No telemetry snapshots recorded yet for device ID [${deviceId}].`);
        }
        return (0, telemetry_dto_1.toTelemetrySnapshotDto)(entity);
    }
    async getLatestAggregated(deviceId, granularity) {
        const entity = await this.prisma.telemetryAggregation.findFirst({
            where: {
                deviceId,
                OR: [{ granularity }, { tier: granularity }],
            },
            orderBy: { periodStart: "desc" },
        });
        if (!entity) {
            throw new common_1.NotFoundException(`No telemetry aggregations recorded for device [${deviceId}] at granularity [${granularity}].`);
        }
        return entity;
    }
    async getHistory(deviceId, startDate, endDate, page = 1, limit = 50) {
        const pageNum = page > 0 ? page : 1;
        const limitNum = limit > 0 ? limit : 50;
        const skip = (pageNum - 1) * limitNum;
        const end = endDate ? new Date(endDate) : new Date();
        const start = startDate
            ? new Date(startDate)
            : new Date(end.getTime() - 24 * 60 * 60 * 1000);
        const durationMs = Math.abs(end.getTime() - start.getTime());
        const oneHourMs = 60 * 60 * 1000;
        const oneDayMs = 24 * 60 * 60 * 1000;
        const sevenDaysMs = 7 * 24 * 60 * 60 * 1000;
        if (durationMs <= oneHourMs) {
            this.logger.debug(`Range <= 1h (${Math.round(durationMs / 60000)}m). Querying raw TelemetrySnapshot table.`);
            const { items, total } = await this.telemetryRepo.findRange({
                deviceId,
                from: start,
                to: end,
                skip,
                take: limitNum,
            });
            const snapshots = items.map(telemetry_dto_1.toTelemetrySnapshotDto);
            const totalPages = Math.ceil(total / limitNum) || 1;
            return { snapshots, total, page: pageNum, limit: limitNum, totalPages };
        }
        let targetGranularities;
        if (durationMs <= oneDayMs) {
            targetGranularities = ["1m", "15m"];
        }
        else if (durationMs <= sevenDaysMs) {
            targetGranularities = ["15m", "1h"];
        }
        else {
            targetGranularities = ["1d"];
        }
        this.logger.debug(`Range > 1h. Querying TelemetryAggregation table for tiers [${targetGranularities.join(", ")}].`);
        const where = {
            deviceId,
            OR: [
                { granularity: { in: targetGranularities } },
                { tier: { in: targetGranularities } },
            ],
            periodStart: {
                gte: start,
                lte: end,
            },
        };
        const [aggItems, total] = await Promise.all([
            this.prisma.telemetryAggregation.findMany({
                where,
                orderBy: { periodStart: "desc" },
                skip,
                take: limitNum,
            }),
            this.prisma.telemetryAggregation.count({ where }),
        ]);
        const snapshots = aggItems.map((agg) => mapAggregationToSnapshotContract(agg));
        const totalPages = Math.ceil(total / limitNum) || 1;
        return {
            snapshots,
            total,
            page: pageNum,
            limit: limitNum,
            totalPages,
        };
    }
    async getTelemetryHistory(deviceId, query) {
        return this.getHistory(deviceId, query.from, query.to, query.page, query.limit);
    }
};
exports.TelemetryService = TelemetryService;
exports.TelemetryService = TelemetryService = TelemetryService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(telemetry_repository_interface_1.ITelemetryRepositoryToken)),
    __param(1, (0, common_1.Inject)(telemetry_publisher_interface_1.ITelemetryPublisherToken)),
    __metadata("design:paramtypes", [Object, Object, event_emitter_1.EventEmitter2,
        prisma_service_1.PrismaService])
], TelemetryService);
function mapAggregationToSnapshotContract(agg) {
    return {
        id: agg.id,
        deviceId: agg.deviceId,
        cpuUsage: agg.avgCpu,
        cpuTemperature: 0,
        cpuFrequency: 0,
        logicalProcessors: 1,
        physicalProcessors: 1,
        memoryUsed: 0,
        memoryFree: 0,
        memoryTotal: 16 * 1024 * 1024 * 1024,
        memoryUsagePercent: agg.avgRam,
        diskReadSpeed: 0,
        diskWriteSpeed: 0,
        diskUsagePercent: agg.avgDisk,
        diskFree: 0,
        diskTotal: 0,
        networkUploadSpeed: agg.avgNetwork / 2,
        networkDownloadSpeed: agg.avgNetwork / 2,
        bytesSent: 0,
        bytesReceived: 0,
        activeConnections: agg.sampleCount,
        runningProcesses: 0,
        runningServices: 0,
        systemUptime: 0,
        bootTime: agg.periodStart.toISOString(),
        ipAddress: "aggregated",
        gateway: "0.0.0.0",
        dns: "8.8.8.8",
        macAddress: "aggregated",
        timestamp: agg.periodStart.toISOString(),
    };
}
//# sourceMappingURL=telemetry.service.js.map