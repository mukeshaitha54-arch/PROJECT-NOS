"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var RealtimeService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.RealtimeService = void 0;
const common_1 = require("@nestjs/common");
const socket_metrics_service_1 = require("./services/socket-metrics.service");
const connection_registry_service_1 = require("./services/connection-registry.service");
const presence_service_1 = require("./services/presence.service");
let RealtimeService = RealtimeService_1 = class RealtimeService {
    metricsService;
    registryService;
    presenceService;
    logger = new common_1.Logger(RealtimeService_1.name);
    constructor(metricsService, registryService, presenceService) {
        this.metricsService = metricsService;
        this.registryService = registryService;
        this.presenceService = presenceService;
    }
    async getSocketHealth(correlationId) {
        this.logger.debug(`Evaluating enterprise realtime Socket.IO health telemetry. CorId: [${correlationId || "none"}]`);
        const totalRooms = this.registryService.getTotalActiveRooms();
        const healthData = this.metricsService.buildHealthResponse(totalRooms, 1);
        return {
            success: true,
            data: healthData,
            requestId: correlationId,
            timestamp: new Date().toISOString(),
        };
    }
    async getPresenceOverview() {
        return {
            onlineUsers: this.presenceService.getOnlineUsersList(),
            onlineDevices: this.presenceService.getOnlineDevicesList(),
            totalActiveSockets: this.registryService.getActiveSessionsCount(),
        };
    }
};
exports.RealtimeService = RealtimeService;
exports.RealtimeService = RealtimeService = RealtimeService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [socket_metrics_service_1.SocketMetricsService,
        connection_registry_service_1.ConnectionRegistryService,
        presence_service_1.PresenceService])
], RealtimeService);
//# sourceMappingURL=realtime.service.js.map