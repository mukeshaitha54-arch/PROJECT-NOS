import { RealtimeService } from "./realtime.service";
import { FastifyRequest } from "fastify";
import { ApiResponse, SocketHealthResponse } from "@nos/shared-types";
export declare class RealtimeController {
    private readonly realtimeService;
    constructor(realtimeService: RealtimeService);
    getHealth(req: FastifyRequest, headerId?: string): Promise<ApiResponse<SocketHealthResponse>>;
}
