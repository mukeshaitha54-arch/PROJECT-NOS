import { ApiResponse, SocketHealthResponse } from "@nos/shared-types";
import { SocketMetricsService } from "./services/socket-metrics.service";
import { ConnectionRegistryService } from "./services/connection-registry.service";
import { PresenceService } from "./services/presence.service";
export declare class RealtimeService {
    private readonly metricsService;
    private readonly registryService;
    private readonly presenceService;
    private readonly logger;
    constructor(metricsService: SocketMetricsService, registryService: ConnectionRegistryService, presenceService: PresenceService);
    getSocketHealth(correlationId?: string): Promise<ApiResponse<SocketHealthResponse>>;
    getPresenceOverview(): Promise<any>;
}
