"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var ConnectionRegistryService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConnectionRegistryService = void 0;
const common_1 = require("@nestjs/common");
let ConnectionRegistryService = ConnectionRegistryService_1 = class ConnectionRegistryService {
    logger = new common_1.Logger(ConnectionRegistryService_1.name);
    sessions = new Map();
    userToSockets = new Map();
    deviceToSockets = new Map();
    registerSession(metadata) {
        const session = {
            ...metadata,
            connectedAt: Date.now(),
            rooms: new Set(),
        };
        this.sessions.set(session.socketId, session);
        if (session.userId) {
            if (!this.userToSockets.has(session.userId)) {
                this.userToSockets.set(session.userId, new Set());
            }
            this.userToSockets.get(session.userId).add(session.socketId);
        }
        if (session.deviceId) {
            if (!this.deviceToSockets.has(session.deviceId)) {
                this.deviceToSockets.set(session.deviceId, new Set());
            }
            this.deviceToSockets.get(session.deviceId).add(session.socketId);
        }
        this.logger.debug(`Registered session [${session.socketId}] User: [${session.userId || "N/A"}] Role: [${session.role || "N/A"}]`);
        return session;
    }
    removeSession(socketId) {
        const session = this.sessions.get(socketId);
        if (!session)
            return undefined;
        this.sessions.delete(socketId);
        if (session.userId) {
            const userSockets = this.userToSockets.get(session.userId);
            if (userSockets) {
                userSockets.delete(socketId);
                if (userSockets.size === 0) {
                    this.userToSockets.delete(session.userId);
                }
            }
        }
        if (session.deviceId) {
            const deviceSockets = this.deviceToSockets.get(session.deviceId);
            if (deviceSockets) {
                deviceSockets.delete(socketId);
                if (deviceSockets.size === 0) {
                    this.deviceToSockets.delete(session.deviceId);
                }
            }
        }
        session.rooms.clear();
        this.logger.debug(`Removed session [${socketId}]`);
        return session;
    }
    getSession(socketId) {
        return this.sessions.get(socketId);
    }
    addRoom(socketId, room) {
        const session = this.sessions.get(socketId);
        if (session) {
            session.rooms.add(room);
        }
    }
    removeRoom(socketId, room) {
        const session = this.sessions.get(socketId);
        if (session) {
            session.rooms.delete(room);
        }
    }
    getActiveSessionsCount() {
        return this.sessions.size;
    }
    getAllSessions() {
        return Array.from(this.sessions.values());
    }
    getTotalActiveRooms() {
        const uniqueRooms = new Set();
        for (const session of this.sessions.values()) {
            for (const r of session.rooms) {
                uniqueRooms.add(r);
            }
        }
        return uniqueRooms.size;
    }
};
exports.ConnectionRegistryService = ConnectionRegistryService;
exports.ConnectionRegistryService = ConnectionRegistryService = ConnectionRegistryService_1 = __decorate([
    (0, common_1.Injectable)()
], ConnectionRegistryService);
//# sourceMappingURL=connection-registry.service.js.map