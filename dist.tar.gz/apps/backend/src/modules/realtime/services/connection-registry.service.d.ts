export interface SocketSessionMetadata {
    socketId: string;
    userId?: string;
    deviceId?: string;
    role?: string;
    ipAddress?: string;
    connectedAt: number;
    rooms: Set<string>;
}
export declare class ConnectionRegistryService {
    private readonly logger;
    private readonly sessions;
    private readonly userToSockets;
    private readonly deviceToSockets;
    registerSession(metadata: Omit<SocketSessionMetadata, "rooms" | "connectedAt">): SocketSessionMetadata;
    removeSession(socketId: string): SocketSessionMetadata | undefined;
    getSession(socketId: string): SocketSessionMetadata | undefined;
    addRoom(socketId: string, room: string): void;
    removeRoom(socketId: string, room: string): void;
    getActiveSessionsCount(): number;
    getAllSessions(): SocketSessionMetadata[];
    getTotalActiveRooms(): number;
}
