export declare class SocketRateLimiterService {
    private readonly logger;
    private readonly limits;
    private readonly CLEANUP_INTERVAL_MS;
    constructor();
    checkLimit(clientId: string, action: "join" | "heartbeat" | "reconnect" | "auth" | "message", maxRequests?: number, windowSeconds?: number): boolean;
    clearClient(clientId: string): void;
    private cleanup;
}
