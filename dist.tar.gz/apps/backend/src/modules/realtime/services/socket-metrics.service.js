"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SocketMetricsService = void 0;
const common_1 = require("@nestjs/common");
let SocketMetricsService = class SocketMetricsService {
    startTime = Date.now();
    connectedClientsCount = 0;
    reconnectCount = 0;
    disconnectCount = 0;
    totalSessionDurationMs = 0;
    droppedEventsCount = 0;
    authFailuresCount = 0;
    latestLatencyMs = 2;
    recordClientConnection(isReconnect = false) {
        this.connectedClientsCount++;
        if (isReconnect) {
            this.reconnectCount++;
        }
    }
    recordClientDisconnection(sessionDurationMs) {
        this.connectedClientsCount = Math.max(0, this.connectedClientsCount - 1);
        this.disconnectCount++;
        if (sessionDurationMs > 0) {
            this.totalSessionDurationMs += sessionDurationMs;
        }
    }
    recordAuthFailure() {
        this.authFailuresCount++;
    }
    recordDroppedEvent() {
        this.droppedEventsCount++;
    }
    updateLatency(latencyMs) {
        if (latencyMs >= 0) {
            this.latestLatencyMs = Math.round(this.latestLatencyMs * 0.7 + latencyMs * 0.3);
        }
    }
    getConnectionMetrics() {
        const averageSessionTimeMs = this.disconnectCount > 0
            ? Math.round(this.totalSessionDurationMs / this.disconnectCount)
            : 0;
        return {
            connectedClients: this.connectedClientsCount,
            reconnectCount: this.reconnectCount,
            disconnectCount: this.disconnectCount,
            averageSessionTimeMs,
            totalAuthFailures: this.authFailuresCount,
            droppedEvents: this.droppedEventsCount,
        };
    }
    buildHealthResponse(totalRooms = 0, namespacesCount = 1) {
        const metrics = this.getConnectionMetrics();
        const memoryUsage = process.memoryUsage().heapUsed;
        const uptimeSeconds = Math.floor((Date.now() - this.startTime) / 1000);
        return {
            connectedClients: metrics.connectedClients,
            rooms: totalRooms,
            namespaces: namespacesCount,
            reconnectCount: metrics.reconnectCount,
            disconnectCount: metrics.disconnectCount,
            averageSessionTime: Math.floor(metrics.averageSessionTimeMs / 1000),
            droppedEvents: metrics.droppedEvents,
            memoryUsage,
            latency: this.latestLatencyMs,
            gatewayUptime: uptimeSeconds,
            authenticationFailures: metrics.totalAuthFailures,
        };
    }
};
exports.SocketMetricsService = SocketMetricsService;
exports.SocketMetricsService = SocketMetricsService = __decorate([
    (0, common_1.Injectable)()
], SocketMetricsService);
//# sourceMappingURL=socket-metrics.service.js.map