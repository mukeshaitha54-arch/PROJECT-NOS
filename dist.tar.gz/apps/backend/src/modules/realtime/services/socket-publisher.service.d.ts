import { Server } from "socket.io";
import { ISocketPublisher } from "../../../common/services/socket-publisher.interface";
import { ISocketEventBus } from "../../../common/services/socket-event-bus.interface";
import { SocketMetricsService } from "./socket-metrics.service";
export declare class SocketPublisherService implements ISocketPublisher {
    private readonly eventBus;
    private readonly metrics;
    private readonly logger;
    private server?;
    private readonly dedupCache;
    private readonly DEDUP_TTL_MS;
    constructor(eventBus: ISocketEventBus, metrics: SocketMetricsService);
    setServer(server: Server): void;
    emitDeviceConnected(deviceId: string, payload: any, correlationId?: string): Promise<void>;
    emitDeviceDisconnected(deviceId: string, payload: any, correlationId?: string): Promise<void>;
    emitDeviceOnline(deviceId: string, payload: any, correlationId?: string): Promise<void>;
    emitDeviceOffline(deviceId: string, payload: any, correlationId?: string): Promise<void>;
    emitHeartbeatReceived(deviceId: string, payload: any, correlationId?: string): Promise<void>;
    emitTelemetryReceived(deviceId: string, payload: any, correlationId?: string): Promise<void>;
    emitInventoryUpdated(deviceId: string, payload: any, correlationId?: string): Promise<void>;
    emitDashboardUpdated(payload: any, correlationId?: string): Promise<void>;
    emitSystemStatusChanged(payload: any, correlationId?: string): Promise<void>;
    emitAlertEvent(event: string, payload: any, correlationId?: string): Promise<void>;
    emitDeviceTelemetryStatus(deviceId: string, organizationId: string, telemetryPaused: boolean, correlationId?: string): Promise<void>;
    emitTenantEvent(organizationId: string, event: string, payload: any, correlationId?: string): Promise<void>;
    private broadcast;
    private minimizePayload;
    private cleanupDedup;
}
