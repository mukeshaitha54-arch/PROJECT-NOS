"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var SocketRateLimiterService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.SocketRateLimiterService = void 0;
const common_1 = require("@nestjs/common");
let SocketRateLimiterService = SocketRateLimiterService_1 = class SocketRateLimiterService {
    logger = new common_1.Logger(SocketRateLimiterService_1.name);
    limits = new Map();
    CLEANUP_INTERVAL_MS = 60000;
    constructor() {
        const timer = setInterval(() => this.cleanup(), this.CLEANUP_INTERVAL_MS);
        if (timer && typeof timer.unref === "function") {
            timer.unref();
        }
    }
    checkLimit(clientId, action, maxRequests = 30, windowSeconds = 60) {
        const key = `${clientId}:${action}`;
        const now = Date.now();
        const windowMs = windowSeconds * 1000;
        let record = this.limits.get(key);
        if (!record) {
            record = { timestamps: [] };
            this.limits.set(key, record);
        }
        record.timestamps = record.timestamps.filter((ts) => now - ts <= windowMs);
        if (record.timestamps.length >= maxRequests) {
            this.logger.warn(`Rate limit exceeded for socket [${clientId}] on action [${action}] (${record.timestamps.length}/${maxRequests} per ${windowSeconds}s)`);
            return false;
        }
        record.timestamps.push(now);
        return true;
    }
    clearClient(clientId) {
        for (const key of this.limits.keys()) {
            if (key.startsWith(`${clientId}:`)) {
                this.limits.delete(key);
            }
        }
    }
    cleanup() {
        const now = Date.now();
        const maxWindowMs = 300000;
        for (const [key, record] of this.limits.entries()) {
            record.timestamps = record.timestamps.filter((ts) => now - ts <= maxWindowMs);
            if (record.timestamps.length === 0) {
                this.limits.delete(key);
            }
        }
    }
};
exports.SocketRateLimiterService = SocketRateLimiterService;
exports.SocketRateLimiterService = SocketRateLimiterService = SocketRateLimiterService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [])
], SocketRateLimiterService);
//# sourceMappingURL=socket-rate-limiter.service.js.map