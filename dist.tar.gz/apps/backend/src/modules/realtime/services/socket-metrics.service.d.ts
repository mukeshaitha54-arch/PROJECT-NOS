import { SocketConnectionMetrics, SocketHealthResponse } from "@nos/shared-types";
export declare class SocketMetricsService {
    private readonly startTime;
    private connectedClientsCount;
    private reconnectCount;
    private disconnectCount;
    private totalSessionDurationMs;
    private droppedEventsCount;
    private authFailuresCount;
    private latestLatencyMs;
    recordClientConnection(isReconnect?: boolean): void;
    recordClientDisconnection(sessionDurationMs: number): void;
    recordAuthFailure(): void;
    recordDroppedEvent(): void;
    updateLatency(latencyMs: number): void;
    getConnectionMetrics(): SocketConnectionMetrics;
    buildHealthResponse(totalRooms?: number, namespacesCount?: number): SocketHealthResponse;
}
