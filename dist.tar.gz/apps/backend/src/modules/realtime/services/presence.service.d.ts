import { SocketPresenceDto } from "@nos/shared-types";
export declare class PresenceService {
    private readonly logger;
    private readonly onlineUsers;
    private readonly onlineDevices;
    updateUserActivity(userId: string, socketId: string, role?: string, ipAddress?: string): void;
    removeUser(userId: string): void;
    updateDeviceOnline(deviceId: string, ipAddress?: string, timestamp?: Date): void;
    updateDeviceOffline(deviceId: string): void;
    isDeviceOnline(deviceId: string): boolean;
    isUserOnline(userId: string): boolean;
    getOnlineUsersList(): SocketPresenceDto[];
    getOnlineDevicesList(): SocketPresenceDto[];
    getOnlineDevicesCount(): number;
}
