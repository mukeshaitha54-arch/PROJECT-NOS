"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var SocketPublisherService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.SocketPublisherService = void 0;
const common_1 = require("@nestjs/common");
const shared_types_1 = require("@nos/shared-types");
const socket_event_bus_interface_1 = require("../../../common/services/socket-event-bus.interface");
const socket_metrics_service_1 = require("./socket-metrics.service");
let SocketPublisherService = SocketPublisherService_1 = class SocketPublisherService {
    eventBus;
    metrics;
    logger = new common_1.Logger(SocketPublisherService_1.name);
    server;
    dedupCache = new Map();
    DEDUP_TTL_MS = 1500;
    constructor(eventBus, metrics) {
        this.eventBus = eventBus;
        this.metrics = metrics;
        const timer = setInterval(() => this.cleanupDedup(), 30000);
        if (timer && typeof timer.unref === "function") {
            timer.unref();
        }
    }
    setServer(server) {
        this.server = server;
        this.logger.log("Socket.IO Server instance registered in SocketPublisherService.");
    }
    async emitDeviceConnected(deviceId, payload, correlationId) {
        const rooms = [shared_types_1.SocketRooms.DASHBOARD, (0, shared_types_1.getDeviceRoom)(deviceId)];
        await this.broadcast(shared_types_1.SocketEvents.DEVICE_CONNECTED, rooms, payload, correlationId, `conn-${deviceId}`);
    }
    async emitDeviceDisconnected(deviceId, payload, correlationId) {
        const rooms = [shared_types_1.SocketRooms.DASHBOARD, (0, shared_types_1.getDeviceRoom)(deviceId)];
        await this.broadcast(shared_types_1.SocketEvents.DEVICE_DISCONNECTED, rooms, payload, correlationId, `disc-${deviceId}`);
    }
    async emitDeviceOnline(deviceId, payload, correlationId) {
        const rooms = [shared_types_1.SocketRooms.DASHBOARD, (0, shared_types_1.getDeviceRoom)(deviceId)];
        await this.broadcast(shared_types_1.SocketEvents.DEVICE_ONLINE, rooms, payload, correlationId, `online-${deviceId}`);
    }
    async emitDeviceOffline(deviceId, payload, correlationId) {
        const rooms = [shared_types_1.SocketRooms.DASHBOARD, (0, shared_types_1.getDeviceRoom)(deviceId)];
        await this.broadcast(shared_types_1.SocketEvents.DEVICE_OFFLINE, rooms, payload, correlationId, `offline-${deviceId}`);
    }
    async emitHeartbeatReceived(deviceId, payload, correlationId) {
        const rooms = [shared_types_1.SocketRooms.DASHBOARD, (0, shared_types_1.getDeviceRoom)(deviceId)];
        const dedupKey = `hb-${deviceId}-${payload.timestamp || payload.uptime}`;
        await this.broadcast(shared_types_1.SocketEvents.HEARTBEAT_RECEIVED, rooms, payload, correlationId, dedupKey);
    }
    async emitTelemetryReceived(deviceId, payload, correlationId) {
        const rooms = [shared_types_1.SocketRooms.DASHBOARD, (0, shared_types_1.getDeviceRoom)(deviceId)];
        const dedupKey = `tele-${deviceId}-${payload.timestamp || payload.id}`;
        await this.broadcast(shared_types_1.SocketEvents.TELEMETRY_RECEIVED, rooms, payload, correlationId, dedupKey);
    }
    async emitInventoryUpdated(deviceId, payload, correlationId) {
        const rooms = [shared_types_1.SocketRooms.DASHBOARD, (0, shared_types_1.getDeviceRoom)(deviceId)];
        const dedupKey = `inv-${deviceId}-${payload.inventoryVersion || payload.timestamp}`;
        await this.broadcast(shared_types_1.SocketEvents.INVENTORY_UPDATED, rooms, payload, correlationId, dedupKey);
    }
    async emitDashboardUpdated(payload, correlationId) {
        const rooms = [shared_types_1.SocketRooms.DASHBOARD];
        await this.broadcast(shared_types_1.SocketEvents.DASHBOARD_UPDATED, rooms, payload, correlationId);
    }
    async emitSystemStatusChanged(payload, correlationId) {
        const rooms = [
            shared_types_1.SocketRooms.DASHBOARD,
            shared_types_1.SocketRooms.ADMINS,
            shared_types_1.SocketRooms.OPERATORS,
        ];
        await this.broadcast(shared_types_1.SocketEvents.SYSTEM_STATUS_CHANGED, rooms, payload, correlationId);
    }
    async emitAlertEvent(event, payload, correlationId) {
        const rooms = [
            shared_types_1.SocketRooms.DASHBOARD,
            shared_types_1.SocketRooms.ADMINS,
            shared_types_1.SocketRooms.OPERATORS,
        ];
        await this.broadcast(event, rooms, payload, correlationId);
    }
    async emitDeviceTelemetryStatus(deviceId, organizationId, telemetryPaused, correlationId) {
        const rooms = [
            shared_types_1.SocketRooms.DASHBOARD,
            (0, shared_types_1.getDeviceRoom)(deviceId),
            `org_${organizationId}`,
        ];
        await this.broadcast(shared_types_1.SocketEvents.TELEMETRY_STATUS, rooms, { deviceId, telemetryPaused }, correlationId);
    }
    async emitTenantEvent(organizationId, event, payload, correlationId) {
        const rooms = [`org_${organizationId}`];
        await this.broadcast(event, rooms, payload, correlationId);
    }
    async broadcast(event, rooms, payload, correlationId, dedupKey) {
        const now = Date.now();
        if (dedupKey) {
            const existing = this.dedupCache.get(dedupKey);
            if (existing && now - existing < this.DEDUP_TTL_MS) {
                this.logger.debug(`Dropped duplicate socket broadcast event [${event}] Key: [${dedupKey}]`);
                this.metrics.recordDroppedEvent();
                return;
            }
            this.dedupCache.set(dedupKey, now);
        }
        const cleanPayload = this.minimizePayload(payload);
        const eventId = `evt-${now}-${Math.random().toString(36).substring(2, 8)}`;
        const deviceId = cleanPayload?.deviceId ||
            cleanPayload?.snapshot?.deviceId ||
            (dedupKey ? dedupKey.split("-")[1] : undefined);
        const envelope = {
            eventId,
            eventType: event,
            version: 1,
            event,
            timestamp: new Date().toISOString(),
            organizationId: cleanPayload?.organizationId || "default-org",
            deviceId,
            correlationId: correlationId ||
                `nos-pub-${now}-${Math.random().toString(36).substring(2, 6)}`,
            payload: cleanPayload,
        };
        for (const room of rooms) {
            await this.eventBus.publish(room, event, envelope);
        }
        if (this.server) {
            try {
                this.server.to(rooms).compress(true).emit(event, envelope);
                this.logger.verbose(`Broadcasted [${event}] to rooms [${rooms.join(", ")}] CorId: [${envelope.correlationId}]`);
            }
            catch (err) {
                this.logger.error(`Failed to broadcast event [${event}] to rooms [${rooms.join(", ")}]: ${err.message}`, err.stack);
            }
        }
        else {
            this.logger.debug(`Socket server instance not ready yet. Event [${event}] queued to local event bus only.`);
        }
    }
    minimizePayload(data) {
        if (!data || typeof data !== "object")
            return data;
        if (Array.isArray(data))
            return data.map((item) => this.minimizePayload(item));
        const clean = {};
        for (const [key, val] of Object.entries(data)) {
            if (val !== undefined &&
                val !== null &&
                typeof val !== "function" &&
                !key.startsWith("_") &&
                !key.startsWith("$")) {
                clean[key] =
                    typeof val === "object" && !(val instanceof Date)
                        ? this.minimizePayload(val)
                        : val;
            }
        }
        return clean;
    }
    cleanupDedup() {
        const now = Date.now();
        for (const [key, ts] of this.dedupCache.entries()) {
            if (now - ts > 30000) {
                this.dedupCache.delete(key);
            }
        }
    }
};
exports.SocketPublisherService = SocketPublisherService;
exports.SocketPublisherService = SocketPublisherService = SocketPublisherService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(socket_event_bus_interface_1.ISocketEventBusToken)),
    __metadata("design:paramtypes", [Object, socket_metrics_service_1.SocketMetricsService])
], SocketPublisherService);
//# sourceMappingURL=socket-publisher.service.js.map