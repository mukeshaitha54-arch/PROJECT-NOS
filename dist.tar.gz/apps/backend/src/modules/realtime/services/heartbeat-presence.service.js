"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var HeartbeatPresenceService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.HeartbeatPresenceService = void 0;
const common_1 = require("@nestjs/common");
const presence_service_1 = require("./presence.service");
const socket_publisher_interface_1 = require("../../../common/services/socket-publisher.interface");
let HeartbeatPresenceService = HeartbeatPresenceService_1 = class HeartbeatPresenceService {
    presenceService;
    socketPublisher;
    logger = new common_1.Logger(HeartbeatPresenceService_1.name);
    lastHeartbeatTimes = new Map();
    STALE_THRESHOLD_MS = 90 * 1000;
    sweepTimer;
    constructor(presenceService, socketPublisher) {
        this.presenceService = presenceService;
        this.socketPublisher = socketPublisher;
        this.sweepTimer = setInterval(() => this.sweepOfflineDevices(), 15000);
        if (this.sweepTimer && typeof this.sweepTimer.unref === "function") {
            this.sweepTimer.unref();
        }
    }
    onModuleDestroy() {
        if (this.sweepTimer) {
            clearInterval(this.sweepTimer);
        }
        this.lastHeartbeatTimes.clear();
    }
    async processHeartbeat(deviceId, ipAddress, cpuUsage, ramUsage, uptime, correlationId, runningProcesses, activeConnections, diskReadSpeed, diskWriteSpeed, networkUploadSpeed, networkDownloadSpeed, processes) {
        const now = Date.now();
        const wasOnline = this.presenceService.isDeviceOnline(deviceId);
        this.lastHeartbeatTimes.set(deviceId, now);
        this.presenceService.updateDeviceOnline(deviceId, ipAddress, new Date(now));
        if (!wasOnline) {
            this.logger.log(`Device [${deviceId}] re-established heartbeat. Transitioning to ONLINE.`);
            await this.socketPublisher.emitDeviceOnline(deviceId, { deviceId, ipAddress, timestamp: new Date(now).toISOString() }, correlationId);
        }
        const heartbeatEvent = {
            deviceId,
            cpuUsage,
            ramUsage,
            uptime,
            ipAddress,
            timestamp: new Date(now).toISOString(),
            status: "ONLINE",
            ...(runningProcesses !== undefined && { runningProcesses }),
            ...(activeConnections !== undefined && { activeConnections }),
            ...(diskReadSpeed !== undefined && { diskReadSpeed }),
            ...(diskWriteSpeed !== undefined && { diskWriteSpeed }),
            ...(networkUploadSpeed !== undefined && { networkUploadSpeed }),
            ...(networkDownloadSpeed !== undefined && { networkDownloadSpeed }),
            ...(processes !== undefined && { processes }),
        };
        await this.socketPublisher.emitHeartbeatReceived(deviceId, heartbeatEvent, correlationId);
    }
    async sweepOfflineDevices() {
        const now = Date.now();
        for (const [deviceId, lastSeen] of this.lastHeartbeatTimes.entries()) {
            if (now - lastSeen > this.STALE_THRESHOLD_MS) {
                this.logger.warn(`Device [${deviceId}] missed heartbeat threshold (${Math.round((now - lastSeen) / 1000)}s). Marking OFFLINE.`);
                this.lastHeartbeatTimes.delete(deviceId);
                this.presenceService.updateDeviceOffline(deviceId);
                try {
                    await this.socketPublisher.emitDeviceOffline(deviceId, {
                        deviceId,
                        reason: "HEARTBEAT_TIMEOUT",
                        timestamp: new Date(now).toISOString(),
                    }, `nos-offline-sweep-${now}`);
                }
                catch (err) {
                    this.logger.error(`Error emitting offline transition for device [${deviceId}]: ${err.message}`);
                }
            }
        }
    }
};
exports.HeartbeatPresenceService = HeartbeatPresenceService;
exports.HeartbeatPresenceService = HeartbeatPresenceService = HeartbeatPresenceService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(1, (0, common_1.Inject)((0, common_1.forwardRef)(() => socket_publisher_interface_1.ISocketPublisherToken))),
    __metadata("design:paramtypes", [presence_service_1.PresenceService, Object])
], HeartbeatPresenceService);
//# sourceMappingURL=heartbeat-presence.service.js.map