"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var PresenceService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.PresenceService = void 0;
const common_1 = require("@nestjs/common");
let PresenceService = PresenceService_1 = class PresenceService {
    logger = new common_1.Logger(PresenceService_1.name);
    onlineUsers = new Map();
    onlineDevices = new Map();
    updateUserActivity(userId, socketId, role = "USER", ipAddress = "0.0.0.0") {
        const now = new Date();
        const existing = this.onlineUsers.get(userId);
        if (existing) {
            existing.lastActivity = now;
            existing.socketId = socketId;
        }
        else {
            this.onlineUsers.set(userId, {
                socketId,
                userId,
                role,
                ipAddress,
                onlineSince: now,
                lastActivity: now,
            });
            this.logger.debug(`User [${userId}] is now ONLINE in PresenceService.`);
        }
    }
    removeUser(userId) {
        if (this.onlineUsers.has(userId)) {
            this.onlineUsers.delete(userId);
            this.logger.debug(`User [${userId}] is now OFFLINE in PresenceService.`);
        }
    }
    updateDeviceOnline(deviceId, ipAddress = "0.0.0.0", timestamp) {
        const now = timestamp || new Date();
        const existing = this.onlineDevices.get(deviceId);
        if (existing) {
            existing.lastActivity = now;
            if (ipAddress && ipAddress !== "0.0.0.0")
                existing.ipAddress = ipAddress;
        }
        else {
            this.onlineDevices.set(deviceId, {
                deviceId,
                ipAddress,
                onlineSince: now,
                lastActivity: now,
            });
            this.logger.debug(`Device [${deviceId}] registered online presence.`);
        }
    }
    updateDeviceOffline(deviceId) {
        if (this.onlineDevices.has(deviceId)) {
            this.onlineDevices.delete(deviceId);
            this.logger.debug(`Device [${deviceId}] removed from online presence.`);
        }
    }
    isDeviceOnline(deviceId) {
        return this.onlineDevices.has(deviceId);
    }
    isUserOnline(userId) {
        return this.onlineUsers.has(userId);
    }
    getOnlineUsersList() {
        return Array.from(this.onlineUsers.values()).map((rec) => ({
            socketId: rec.socketId,
            userId: rec.userId,
            role: rec.role,
            ipAddress: rec.ipAddress,
            onlineSince: rec.onlineSince.toISOString(),
            lastActivity: rec.lastActivity.toISOString(),
        }));
    }
    getOnlineDevicesList() {
        return Array.from(this.onlineDevices.values()).map((rec) => ({
            socketId: `agent-${rec.deviceId}`,
            deviceId: rec.deviceId,
            ipAddress: rec.ipAddress,
            onlineSince: rec.onlineSince.toISOString(),
            lastActivity: rec.lastActivity.toISOString(),
        }));
    }
    getOnlineDevicesCount() {
        return this.onlineDevices.size;
    }
};
exports.PresenceService = PresenceService;
exports.PresenceService = PresenceService = PresenceService_1 = __decorate([
    (0, common_1.Injectable)()
], PresenceService);
//# sourceMappingURL=presence.service.js.map