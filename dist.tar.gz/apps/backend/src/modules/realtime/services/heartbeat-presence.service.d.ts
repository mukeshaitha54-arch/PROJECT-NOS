import { OnModuleDestroy } from "@nestjs/common";
import { PresenceService } from "./presence.service";
import { ISocketPublisher } from "../../../common/services/socket-publisher.interface";
export declare class HeartbeatPresenceService implements OnModuleDestroy {
    private readonly presenceService;
    private readonly socketPublisher;
    private readonly logger;
    private readonly lastHeartbeatTimes;
    private readonly STALE_THRESHOLD_MS;
    private readonly sweepTimer?;
    constructor(presenceService: PresenceService, socketPublisher: ISocketPublisher);
    onModuleDestroy(): void;
    processHeartbeat(deviceId: string, ipAddress: string, cpuUsage: number, ramUsage: number, uptime: number, correlationId?: string, runningProcesses?: number, activeConnections?: number, diskReadSpeed?: number, diskWriteSpeed?: number, networkUploadSpeed?: number, networkDownloadSpeed?: number, processes?: any[]): Promise<void>;
    private sweepOfflineDevices;
}
