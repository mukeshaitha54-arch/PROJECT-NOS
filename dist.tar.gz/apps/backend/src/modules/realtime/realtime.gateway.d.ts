import { OnGatewayConnection, OnGatewayDisconnect, OnGatewayInit } from "@nestjs/websockets";
import { ConfigService } from "@nestjs/config";
import { JwtService } from "@nestjs/jwt";
import { Server, Socket } from "socket.io";
import { IUserRepository } from "../../common/repositories/user.repository.interface";
import { ConnectionRegistryService } from "./services/connection-registry.service";
import { PresenceService } from "./services/presence.service";
import { SocketMetricsService } from "./services/socket-metrics.service";
import { SocketRateLimiterService } from "./services/socket-rate-limiter.service";
import { SocketPublisherService } from "./services/socket-publisher.service";
export declare class RealtimeGateway implements OnGatewayInit, OnGatewayConnection, OnGatewayDisconnect {
    private readonly configService;
    private readonly jwtService;
    private readonly userRepo;
    private readonly registry;
    private readonly presence;
    private readonly metrics;
    private readonly rateLimiter;
    private readonly publisher;
    server: Server;
    private readonly logger;
    constructor(configService: ConfigService, jwtService: JwtService, userRepo: IUserRepository, registry: ConnectionRegistryService, presence: PresenceService, metrics: SocketMetricsService, rateLimiter: SocketRateLimiterService, publisher: SocketPublisherService);
    afterInit(server: Server): void;
    handleConnection(client: Socket): Promise<void>;
    handleDisconnect(client: Socket): void;
    handleJoinRoom(room: string, client: Socket): {
        status: string;
        room: string;
        timestamp: string;
    };
    handleLeaveRoom(room: string, client: Socket): {
        status: string;
        room: string;
        timestamp: string;
    };
    handlePing(clientTimeMs: number, client: Socket): {
        pong: number;
        serverTime: string;
    };
    private extractToken;
    private authorizeRoomAccess;
}
