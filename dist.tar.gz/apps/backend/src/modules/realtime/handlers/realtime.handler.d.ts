import { ISocketPublisher } from "../../../common/services/socket-publisher.interface";
import { DeviceRegisteredEvent, DeviceReconnectedEvent, HeartbeatReceivedEvent, DeviceOfflineEvent, DeviceMaintenanceEvent, DeviceRetiredEvent, DeviceTelemetryStatusEvent, TelemetryReceivedEvent, InventoryUpdatedEvent } from "../../../common/events/domain-events";
export declare class RealtimeHandler {
    private readonly socketPublisher;
    private readonly logger;
    constructor(socketPublisher: ISocketPublisher);
    onDeviceRegistered(event: DeviceRegisteredEvent): Promise<void>;
    onDeviceReconnected(event: DeviceReconnectedEvent): Promise<void>;
    onHeartbeatReceived(event: HeartbeatReceivedEvent): Promise<void>;
    onDeviceOffline(event: DeviceOfflineEvent): Promise<void>;
    onDeviceMaintenance(event: DeviceMaintenanceEvent): Promise<void>;
    onDeviceRetired(event: DeviceRetiredEvent): Promise<void>;
    onTelemetryReceived(event: TelemetryReceivedEvent): Promise<void>;
    onInventoryUpdated(event: InventoryUpdatedEvent): Promise<void>;
    onDeviceTelemetryStatus(event: DeviceTelemetryStatusEvent): Promise<void>;
}
