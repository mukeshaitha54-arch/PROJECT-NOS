"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var RealtimeHandler_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.RealtimeHandler = void 0;
const common_1 = require("@nestjs/common");
const event_emitter_1 = require("@nestjs/event-emitter");
const socket_publisher_interface_1 = require("../../../common/services/socket-publisher.interface");
const domain_events_1 = require("../../../common/events/domain-events");
let RealtimeHandler = RealtimeHandler_1 = class RealtimeHandler {
    socketPublisher;
    logger = new common_1.Logger(RealtimeHandler_1.name);
    constructor(socketPublisher) {
        this.socketPublisher = socketPublisher;
    }
    async onDeviceRegistered(event) {
        try {
            await this.socketPublisher.emitDeviceConnected(event.deviceId, {
                id: event.deviceId,
                hostname: event.hostname,
                status: "ONLINE",
                os: event.os,
                osVersion: event.osVersion,
                architecture: event.architecture,
                agentVersion: event.agentVersion,
                organizationId: event.organizationId,
            }, event.correlationId);
            await this.socketPublisher.emitDeviceOnline(event.deviceId, {
                deviceId: event.deviceId,
                status: "ONLINE",
                timestamp: event.timestamp,
            }, event.correlationId);
        }
        catch (err) {
            this.logger.error(`Realtime broadcast failed for ${event.eventType}: ${err.message}`);
        }
    }
    async onDeviceReconnected(event) {
        try {
            await this.socketPublisher.emitDeviceOnline(event.deviceId, {
                deviceId: event.deviceId,
                status: "ONLINE",
                timestamp: event.timestamp,
            }, event.correlationId);
        }
        catch (err) {
            this.logger.error(`Realtime broadcast failed for ${event.eventType}: ${err.message}`);
        }
    }
    async onHeartbeatReceived(event) {
        try {
            await this.socketPublisher.emitHeartbeatReceived(event.deviceId, {
                deviceId: event.deviceId,
                cpuUsage: event.cpuUsage,
                ramUsage: event.ramUsage,
                uptime: event.uptime,
                ipAddress: event.ipAddress,
                timestamp: event.timestamp,
                status: "ONLINE",
                ...(event.runningProcesses !== undefined && {
                    runningProcesses: event.runningProcesses,
                }),
                ...(event.activeConnections !== undefined && {
                    activeConnections: event.activeConnections,
                }),
                ...(event.diskReadSpeed !== undefined && {
                    diskReadSpeed: event.diskReadSpeed,
                }),
                ...(event.diskWriteSpeed !== undefined && {
                    diskWriteSpeed: event.diskWriteSpeed,
                }),
                ...(event.networkUploadSpeed !== undefined && {
                    networkUploadSpeed: event.networkUploadSpeed,
                }),
                ...(event.networkDownloadSpeed !== undefined && {
                    networkDownloadSpeed: event.networkDownloadSpeed,
                }),
                ...(event.processes !== undefined && { processes: event.processes }),
            }, event.correlationId);
        }
        catch (err) {
            this.logger.error(`Realtime broadcast failed for ${event.eventType}: ${err.message}`);
        }
    }
    async onDeviceOffline(event) {
        try {
            await this.socketPublisher.emitDeviceOffline(event.deviceId, {
                deviceId: event.deviceId,
                reason: event.reason,
                timestamp: event.timestamp,
            }, event.correlationId);
        }
        catch (err) {
            this.logger.error(`Realtime broadcast failed for ${event.eventType}: ${err.message}`);
        }
    }
    async onDeviceMaintenance(event) {
        try {
            await this.socketPublisher.emitSystemStatusChanged({
                deviceId: event.deviceId,
                status: event.enabled ? "MAINTENANCE" : "ONLINE",
                timestamp: event.timestamp,
            }, event.correlationId);
        }
        catch (err) {
            this.logger.error(`Realtime broadcast failed for ${event.eventType}: ${err.message}`);
        }
    }
    async onDeviceRetired(event) {
        try {
            await this.socketPublisher.emitDeviceOffline(event.deviceId, {
                deviceId: event.deviceId,
                reason: "DEVICE_RETIRED",
                timestamp: event.timestamp,
            }, event.correlationId);
        }
        catch (err) {
            this.logger.error(`Realtime broadcast failed for ${event.eventType}: ${err.message}`);
        }
    }
    async onTelemetryReceived(event) {
        try {
            await this.socketPublisher.emitTelemetryReceived(event.deviceId, event.snapshot, event.correlationId);
        }
        catch (err) {
            this.logger.error(`Realtime broadcast failed for ${event.eventType}: ${err.message}`);
        }
    }
    async onInventoryUpdated(event) {
        try {
            await this.socketPublisher.emitInventoryUpdated(event.deviceId, {
                deviceId: event.deviceId,
                inventoryVersion: event.inventoryVersion,
                fingerprint: event.fingerprint,
                diffDetected: event.diffDetected,
                updatedFields: ["hardware", "software", "network", "security"],
                timestamp: event.timestamp,
            }, event.correlationId);
        }
        catch (err) {
            this.logger.error(`Realtime broadcast failed for ${event.eventType}: ${err.message}`);
        }
    }
    async onDeviceTelemetryStatus(event) {
        try {
            await this.socketPublisher.emitDeviceTelemetryStatus(event.deviceId, event.organizationId, event.telemetryPaused, event.correlationId);
        }
        catch (err) {
            this.logger.error(`Realtime broadcast failed for ${event.eventType}: ${err.message}`);
        }
    }
};
exports.RealtimeHandler = RealtimeHandler;
__decorate([
    (0, event_emitter_1.OnEvent)(domain_events_1.DomainEventNames.DEVICE_REGISTERED),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [domain_events_1.DeviceRegisteredEvent]),
    __metadata("design:returntype", Promise)
], RealtimeHandler.prototype, "onDeviceRegistered", null);
__decorate([
    (0, event_emitter_1.OnEvent)(domain_events_1.DomainEventNames.DEVICE_RECONNECTED),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [domain_events_1.DeviceReconnectedEvent]),
    __metadata("design:returntype", Promise)
], RealtimeHandler.prototype, "onDeviceReconnected", null);
__decorate([
    (0, event_emitter_1.OnEvent)(domain_events_1.DomainEventNames.HEARTBEAT_RECEIVED),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [domain_events_1.HeartbeatReceivedEvent]),
    __metadata("design:returntype", Promise)
], RealtimeHandler.prototype, "onHeartbeatReceived", null);
__decorate([
    (0, event_emitter_1.OnEvent)(domain_events_1.DomainEventNames.DEVICE_OFFLINE),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [domain_events_1.DeviceOfflineEvent]),
    __metadata("design:returntype", Promise)
], RealtimeHandler.prototype, "onDeviceOffline", null);
__decorate([
    (0, event_emitter_1.OnEvent)(domain_events_1.DomainEventNames.DEVICE_MAINTENANCE),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [domain_events_1.DeviceMaintenanceEvent]),
    __metadata("design:returntype", Promise)
], RealtimeHandler.prototype, "onDeviceMaintenance", null);
__decorate([
    (0, event_emitter_1.OnEvent)(domain_events_1.DomainEventNames.DEVICE_RETIRED),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [domain_events_1.DeviceRetiredEvent]),
    __metadata("design:returntype", Promise)
], RealtimeHandler.prototype, "onDeviceRetired", null);
__decorate([
    (0, event_emitter_1.OnEvent)(domain_events_1.DomainEventNames.TELEMETRY_RECEIVED),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [domain_events_1.TelemetryReceivedEvent]),
    __metadata("design:returntype", Promise)
], RealtimeHandler.prototype, "onTelemetryReceived", null);
__decorate([
    (0, event_emitter_1.OnEvent)(domain_events_1.DomainEventNames.INVENTORY_UPDATED),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [domain_events_1.InventoryUpdatedEvent]),
    __metadata("design:returntype", Promise)
], RealtimeHandler.prototype, "onInventoryUpdated", null);
__decorate([
    (0, event_emitter_1.OnEvent)(domain_events_1.DomainEventNames.DEVICE_TELEMETRY_STATUS),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [domain_events_1.DeviceTelemetryStatusEvent]),
    __metadata("design:returntype", Promise)
], RealtimeHandler.prototype, "onDeviceTelemetryStatus", null);
exports.RealtimeHandler = RealtimeHandler = RealtimeHandler_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(socket_publisher_interface_1.ISocketPublisherToken)),
    __metadata("design:paramtypes", [Object])
], RealtimeHandler);
//# sourceMappingURL=realtime.handler.js.map