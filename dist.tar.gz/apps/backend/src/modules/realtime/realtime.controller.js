"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RealtimeController = void 0;
const openapi = require("@nestjs/swagger");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const realtime_service_1 = require("./realtime.service");
const jwt_auth_guard_1 = require("../../common/guards/jwt-auth.guard");
const roles_guard_1 = require("../../common/guards/roles.guard");
const roles_decorator_1 = require("../../common/decorators/roles.decorator");
const shared_types_1 = require("@nos/shared-types");
let RealtimeController = class RealtimeController {
    realtimeService;
    constructor(realtimeService) {
        this.realtimeService = realtimeService;
    }
    async getHealth(req, headerId) {
        const requestId = headerId ||
            req.headers["x-request-id"] ||
            req.headers["x-correlation-id"] ||
            "unknown";
        return this.realtimeService.getSocketHealth(requestId);
    }
};
exports.RealtimeController = RealtimeController;
__decorate([
    (0, common_1.Get)("health"),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)(shared_types_1.UserRole.SUPER_ADMIN, shared_types_1.UserRole.ADMIN, shared_types_1.UserRole.OPERATOR, shared_types_1.UserRole.ANALYST, shared_types_1.UserRole.VIEWER, shared_types_1.UserRole.USER),
    (0, swagger_1.ApiBearerAuth)(),
    (0, swagger_1.ApiOperation)({
        summary: "Inspect Realtime Socket.IO Gateway health, connection metrics, memory, and dropped events",
    }),
    (0, swagger_1.ApiResponse)({
        status: common_1.HttpStatus.OK,
        description: "Socket gateway diagnostics returned successfully.",
    }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Headers)("x-request-id")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], RealtimeController.prototype, "getHealth", null);
exports.RealtimeController = RealtimeController = __decorate([
    (0, swagger_1.ApiTags)("Realtime Socket Gateway"),
    (0, common_1.Controller)("socket"),
    __metadata("design:paramtypes", [realtime_service_1.RealtimeService])
], RealtimeController);
//# sourceMappingURL=realtime.controller.js.map