"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RealtimeModule = void 0;
const common_1 = require("@nestjs/common");
const auth_module_1 = require("../auth/auth.module");
const realtime_controller_1 = require("./realtime.controller");
const realtime_gateway_1 = require("./realtime.gateway");
const realtime_service_1 = require("./realtime.service");
const socket_publisher_service_1 = require("./services/socket-publisher.service");
const connection_registry_service_1 = require("./services/connection-registry.service");
const presence_service_1 = require("./services/presence.service");
const heartbeat_presence_service_1 = require("./services/heartbeat-presence.service");
const socket_metrics_service_1 = require("./services/socket-metrics.service");
const socket_rate_limiter_service_1 = require("./services/socket-rate-limiter.service");
const realtime_handler_1 = require("./handlers/realtime.handler");
const socket_publisher_interface_1 = require("../../common/services/socket-publisher.interface");
const socket_event_bus_interface_1 = require("../../common/services/socket-event-bus.interface");
const local_socket_event_bus_service_1 = require("../../common/services/local-socket-event-bus.service");
let RealtimeModule = class RealtimeModule {
};
exports.RealtimeModule = RealtimeModule;
exports.RealtimeModule = RealtimeModule = __decorate([
    (0, common_1.Global)(),
    (0, common_1.Module)({
        imports: [auth_module_1.AuthModule],
        controllers: [realtime_controller_1.RealtimeController],
        providers: [
            realtime_gateway_1.RealtimeGateway,
            realtime_service_1.RealtimeService,
            socket_publisher_service_1.SocketPublisherService,
            {
                provide: socket_publisher_interface_1.ISocketPublisherToken,
                useExisting: socket_publisher_service_1.SocketPublisherService,
            },
            {
                provide: socket_event_bus_interface_1.ISocketEventBusToken,
                useClass: local_socket_event_bus_service_1.LocalSocketEventBusService,
            },
            connection_registry_service_1.ConnectionRegistryService,
            presence_service_1.PresenceService,
            heartbeat_presence_service_1.HeartbeatPresenceService,
            socket_metrics_service_1.SocketMetricsService,
            socket_rate_limiter_service_1.SocketRateLimiterService,
            realtime_handler_1.RealtimeHandler,
        ],
        exports: [
            realtime_gateway_1.RealtimeGateway,
            socket_publisher_interface_1.ISocketPublisherToken,
            socket_event_bus_interface_1.ISocketEventBusToken,
            connection_registry_service_1.ConnectionRegistryService,
            presence_service_1.PresenceService,
            heartbeat_presence_service_1.HeartbeatPresenceService,
            socket_metrics_service_1.SocketMetricsService,
            socket_publisher_service_1.SocketPublisherService,
        ],
    })
], RealtimeModule);
//# sourceMappingURL=realtime.module.js.map