export declare class RealtimeModule {
}
