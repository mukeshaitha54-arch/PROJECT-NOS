"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var RealtimeGateway_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.RealtimeGateway = void 0;
const websockets_1 = require("@nestjs/websockets");
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const jwt_1 = require("@nestjs/jwt");
const socket_io_1 = require("socket.io");
const shared_types_1 = require("@nos/shared-types");
const user_repository_interface_1 = require("../../common/repositories/user.repository.interface");
const connection_registry_service_1 = require("./services/connection-registry.service");
const presence_service_1 = require("./services/presence.service");
const socket_metrics_service_1 = require("./services/socket-metrics.service");
const socket_rate_limiter_service_1 = require("./services/socket-rate-limiter.service");
const socket_publisher_interface_1 = require("../../common/services/socket-publisher.interface");
const socket_publisher_service_1 = require("./services/socket-publisher.service");
let RealtimeGateway = RealtimeGateway_1 = class RealtimeGateway {
    configService;
    jwtService;
    userRepo;
    registry;
    presence;
    metrics;
    rateLimiter;
    publisher;
    server;
    logger = new common_1.Logger(RealtimeGateway_1.name);
    constructor(configService, jwtService, userRepo, registry, presence, metrics, rateLimiter, publisher) {
        this.configService = configService;
        this.jwtService = jwtService;
        this.userRepo = userRepo;
        this.registry = registry;
        this.presence = presence;
        this.metrics = metrics;
        this.rateLimiter = rateLimiter;
        this.publisher = publisher;
    }
    afterInit(server) {
        this.logger.log(`Enterprise Realtime Gateway initialized on namespace [${process.env.SOCKET_NAMESPACE || "/realtime"}] (Proxy Ready, CORS: ${this.configService.get("SOCKET_CORS_ORIGIN", "*")})`);
        this.publisher.setServer(server);
    }
    async handleConnection(client) {
        const startMs = Date.now();
        try {
            const forwardedFor = client.handshake.headers["x-forwarded-for"];
            const ipAddress = (Array.isArray(forwardedFor)
                ? forwardedFor[0]
                : forwardedFor || client.handshake.address) || "0.0.0.0";
            if (!this.rateLimiter.checkLimit(ipAddress, "reconnect", 20, 60)) {
                this.logger.warn(`Connection rejected for [${ipAddress}]: Reconnect spam limit reached.`);
                client.disconnect(true);
                return;
            }
            const token = this.extractToken(client);
            if (!token) {
                this.logger.warn(`Unauthorized socket connection attempt from [${ipAddress}]: Missing token.`);
                this.metrics.recordAuthFailure();
                client.emit("unauthorized", {
                    error: "Authentication token missing or invalid in socket handshake.",
                });
                client.disconnect(true);
                return;
            }
            const secret = this.configService.get("JWT_SECRET", "nos_super_secret_jwt_key_32_chars_min_length_value!");
            let payload;
            try {
                payload = await this.jwtService.verifyAsync(token, { secret });
            }
            catch (err) {
                this.logger.warn(`JWT verification failed for socket [${client.id}]: ${err.message}`);
                this.metrics.recordAuthFailure();
                client.emit("unauthorized", {
                    error: "Invalid JWT signature or token expired.",
                });
                client.disconnect(true);
                return;
            }
            const user = await this.userRepo.findById(payload.sub);
            if (!user) {
                this.logger.warn(`Token identity unknown for socket [${client.id}] sub [${payload.sub}]`);
                this.metrics.recordAuthFailure();
                client.disconnect(true);
                return;
            }
            client.user = user;
            client.connectedAtMs = startMs;
            const session = this.registry.registerSession({
                socketId: client.id,
                userId: user.id,
                role: user.role,
                ipAddress: ipAddress.toString(),
            });
            this.presence.updateUserActivity(user.id, client.id, user.role, ipAddress.toString());
            this.metrics.recordClientConnection(client.handshake.query.reconnect === "true");
            client.join(shared_types_1.SocketRooms.DASHBOARD);
            this.registry.addRoom(client.id, shared_types_1.SocketRooms.DASHBOARD);
            const orgId = client.handshake.query?.organizationId ||
                client.handshake.headers?.["x-organization-id"] ||
                payload.org ||
                "default-org";
            const orgRoom = `org_${orgId}`;
            client.join(orgRoom);
            this.registry.addRoom(client.id, orgRoom);
            const ackEnvelope = {
                version: 1,
                event: shared_types_1.SocketEvents.SYSTEM_STATUS_CHANGED,
                timestamp: new Date().toISOString(),
                correlationId: `conn-${client.id}`,
                payload: {
                    message: "Connected securely to NOS Enterprise Realtime Engine.",
                    clientId: client.id,
                    role: user.role,
                    serverTime: new Date().toISOString(),
                },
            };
            client.emit(shared_types_1.SocketEvents.SYSTEM_STATUS_CHANGED, ackEnvelope);
            this.logger.debug(`Client connected securely: [${client.id}] User [${user.email}] Role [${user.role}]`);
        }
        catch (err) {
            this.logger.error(`Fatal exception during socket connection handshake [${client.id}]: ${err.message}`, err.stack);
            this.metrics.recordAuthFailure();
            client.disconnect(true);
        }
    }
    handleDisconnect(client) {
        const session = this.registry.removeSession(client.id);
        this.rateLimiter.clearClient(client.id);
        const connectedAt = client.connectedAtMs ||
            (session ? session.connectedAt : Date.now());
        const durationMs = Date.now() - connectedAt;
        if (session && session.userId) {
            const userSessions = this.registry
                .getAllSessions()
                .filter((s) => s.userId === session.userId);
            if (userSessions.length === 0) {
                this.presence.removeUser(session.userId);
            }
        }
        this.metrics.recordClientDisconnection(durationMs);
        this.logger.debug(`Client disconnected [${client.id}] Duration: ${Math.round(durationMs / 1000)}s`);
    }
    handleJoinRoom(room, client) {
        const user = client.user;
        if (!user) {
            throw new common_1.UnauthorizedException("Socket unauthenticated.");
        }
        if (!this.rateLimiter.checkLimit(client.id, "join", 15, 60)) {
            this.metrics.recordDroppedEvent();
            return {
                status: "ERROR_RATE_LIMITED",
                room,
                timestamp: new Date().toISOString(),
            };
        }
        this.authorizeRoomAccess(user, room);
        client.join(room);
        this.registry.addRoom(client.id, room);
        this.logger.debug(`Socket [${client.id}] User [${user.email}] joined authorized room [${room}]`);
        return { status: "JOINED", room, timestamp: new Date().toISOString() };
    }
    handleLeaveRoom(room, client) {
        client.leave(room);
        this.registry.removeRoom(client.id, room);
        return { status: "LEFT", room, timestamp: new Date().toISOString() };
    }
    handlePing(clientTimeMs, client) {
        const now = Date.now();
        if (typeof clientTimeMs === "number" &&
            clientTimeMs > 0 &&
            clientTimeMs <= now) {
            const oneWayMs = Math.max(1, Math.round((now - clientTimeMs) / 2));
            this.metrics.updateLatency(oneWayMs);
        }
        const user = client.user;
        if (user) {
            this.presence.updateUserActivity(user.id, client.id, user.role, client.handshake.address);
        }
        return { pong: now, serverTime: new Date().toISOString() };
    }
    extractToken(client) {
        const authToken = client.handshake.auth?.token || client.handshake.query?.token;
        if (authToken && typeof authToken === "string") {
            return authToken.replace(/^Bearer\s+/i, "");
        }
        const authHeader = client.handshake.headers?.authorization;
        if (authHeader && typeof authHeader === "string") {
            return authHeader.replace(/^Bearer\s+/i, "");
        }
        return null;
    }
    authorizeRoomAccess(user, room) {
        if (!room) {
            throw new common_1.ForbiddenException("Invalid room parameter.");
        }
        if (user.role === shared_types_1.UserRole.SUPER_ADMIN) {
            return;
        }
        if (room === shared_types_1.SocketRooms.ADMINS && user.role !== shared_types_1.UserRole.ADMIN) {
            this.logger.warn(`User [${user.email}] (Role: ${user.role}) denied access to room [${room}]`);
            throw new common_1.ForbiddenException("Room requires ADMIN privileges.");
        }
        if (room === shared_types_1.SocketRooms.OPERATORS &&
            user.role !== shared_types_1.UserRole.ADMIN &&
            user.role !== shared_types_1.UserRole.OPERATOR) {
            this.logger.warn(`User [${user.email}] denied access to room [${room}]`);
            throw new common_1.ForbiddenException("Room requires OPERATOR or higher privileges.");
        }
        if (room === shared_types_1.SocketRooms.DASHBOARD || room.startsWith("device:")) {
            return;
        }
    }
};
exports.RealtimeGateway = RealtimeGateway;
__decorate([
    (0, websockets_1.WebSocketServer)(),
    __metadata("design:type", socket_io_1.Server)
], RealtimeGateway.prototype, "server", void 0);
__decorate([
    (0, websockets_1.SubscribeMessage)("joinRoom"),
    __param(0, (0, websockets_1.MessageBody)()),
    __param(1, (0, websockets_1.ConnectedSocket)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, socket_io_1.Socket]),
    __metadata("design:returntype", Object)
], RealtimeGateway.prototype, "handleJoinRoom", null);
__decorate([
    (0, websockets_1.SubscribeMessage)("leaveRoom"),
    __param(0, (0, websockets_1.MessageBody)()),
    __param(1, (0, websockets_1.ConnectedSocket)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, socket_io_1.Socket]),
    __metadata("design:returntype", Object)
], RealtimeGateway.prototype, "handleLeaveRoom", null);
__decorate([
    (0, websockets_1.SubscribeMessage)("ping"),
    __param(0, (0, websockets_1.MessageBody)()),
    __param(1, (0, websockets_1.ConnectedSocket)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, socket_io_1.Socket]),
    __metadata("design:returntype", void 0)
], RealtimeGateway.prototype, "handlePing", null);
exports.RealtimeGateway = RealtimeGateway = RealtimeGateway_1 = __decorate([
    (0, websockets_1.WebSocketGateway)({
        cors: {
            origin: process.env.SOCKET_CORS_ORIGIN || "*",
            credentials: true,
        },
        namespace: process.env.SOCKET_NAMESPACE || "/realtime",
        pingTimeout: Number(process.env.SOCKET_PING_TIMEOUT) || 20000,
        pingInterval: Number(process.env.SOCKET_PING_INTERVAL) || 25000,
        transports: ["websocket", "polling"],
    }),
    __param(2, (0, common_1.Inject)(user_repository_interface_1.IUserRepositoryToken)),
    __param(7, (0, common_1.Inject)((0, common_1.forwardRef)(() => socket_publisher_interface_1.ISocketPublisherToken))),
    __metadata("design:paramtypes", [config_1.ConfigService,
        jwt_1.JwtService, Object, connection_registry_service_1.ConnectionRegistryService,
        presence_service_1.PresenceService,
        socket_metrics_service_1.SocketMetricsService,
        socket_rate_limiter_service_1.SocketRateLimiterService,
        socket_publisher_service_1.SocketPublisherService])
], RealtimeGateway);
//# sourceMappingURL=realtime.gateway.js.map