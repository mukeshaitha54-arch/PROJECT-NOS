"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const core_1 = require("@nestjs/core");
const platform_fastify_1 = require("@nestjs/platform-fastify");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const helmet_1 = require("@fastify/helmet");
const compress_1 = require("@fastify/compress");
const static_1 = require("@fastify/static");
const platform_socket_io_1 = require("@nestjs/platform-socket.io");
const crypto = require("crypto");
const path = require("path");
const app_module_1 = require("./app.module");
const logger_service_1 = require("./common/logger/logger.service");
function validateProductionSecrets() {
    if (process.env.NODE_ENV !== "production")
        return;
    const required = ["JWT_SECRET", "REFRESH_TOKEN_SECRET", "DATABASE_URL"];
    const missing = required.filter((k) => !process.env[k]);
    if (missing.length > 0) {
        throw new Error(`[NOS] FATAL: Missing production secrets: [${missing.join(", ")}]. ` +
            `Set all required environment variables before starting in production mode.`);
    }
}
async function bootstrap() {
    validateProductionSecrets();
    const adapter = new platform_fastify_1.FastifyAdapter({
        logger: false,
        trustProxy: true,
    });
    const appLogger = new logger_service_1.LoggerService();
    appLogger.setContext("Bootstrap");
    adapter.getInstance().addHook("onRequest", (req, res, done) => {
        if (req.raw.url && req.raw.url.includes("/api/v1/api/v1/")) {
            req.raw.url = req.raw.url.replace("/api/v1/api/v1/", "/api/v1/");
            req.url = req.raw.url;
        }
        const headerId = req.headers["x-trace-id"] || req.headers["x-correlation-id"];
        const traceId = Array.isArray(headerId)
            ? headerId[0]
            : headerId || crypto.randomUUID();
        req.headers["x-trace-id"] = traceId;
        res.header("x-trace-id", traceId);
        const method = req.method;
        const path = req.raw.url || req.originalUrl || req.url;
        const ip = req.ip || req.socket?.remoteAddress;
        const userAgent = req.headers["user-agent"] || "";
        appLogger.log(`Incoming Request: ${method} ${path}`, {
            traceId,
            method,
            path,
            ip,
            userAgent,
        });
        done();
    });
    const app = await core_1.NestFactory.create(app_module_1.AppModule, adapter, { bufferLogs: true, logger: appLogger });
    app.enableShutdownHooks();
    app.useWebSocketAdapter(new platform_socket_io_1.IoAdapter(app));
    app.useLogger(appLogger);
    await app.register(helmet_1.default, {
        contentSecurityPolicy: false,
    });
    await app.register(compress_1.default, {
        encodings: ["gzip", "deflate"],
    });
    const possibleAssetsDirs = [
        path.join(process.cwd(), "apps", "backend", "assets"),
        path.join(process.cwd(), "assets"),
    ];
    const assetsDir = possibleAssetsDirs.find((d) => {
        try {
            return require("fs").existsSync(d);
        }
        catch {
            return false;
        }
    }) || possibleAssetsDirs[0];
    try {
        await app.register(static_1.default, {
            root: assetsDir,
            prefix: "/downloads/",
            decorateReply: false,
        });
    }
    catch (_) {
    }
    const configuredOrigins = (process.env.FRONTEND_URL || "")
        .split(",")
        .map((o) => o.trim())
        .filter(Boolean);
    const defaultAllowedOrigins = [
        "http://localhost:3000",
        "http://localhost:3001",
        "http://127.0.0.1:3000",
        "http://127.0.0.1:3001",
        "http://nos.is-local.org",
        "https://nos.is-local.org",
        "http://13.127.187.47",
        "http://13.127.187.47:3000",
    ];
    const allowedOrigins = [
        ...new Set([...defaultAllowedOrigins, ...configuredOrigins]),
    ];
    app.enableCors({
        origin: (origin, callback) => {
            if (!origin)
                return callback(null, true);
            if (allowedOrigins.includes(origin) ||
                process.env.NODE_ENV !== "production") {
                return callback(null, true);
            }
            return callback(null, false);
        },
        credentials: true,
        methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
        allowedHeaders: [
            "Origin",
            "X-Requested-With",
            "Content-Type",
            "Accept",
            "Authorization",
            "X-Device-Token",
            "X-Idempotency-Key",
        ],
    });
    app.useGlobalPipes(new common_1.ValidationPipe({
        whitelist: true,
        forbidNonWhitelisted: false,
        transform: true,
        transformOptions: { enableImplicitConversion: true },
    }));
    const apiPrefix = process.env.API_PREFIX || "api/v1";
    app.setGlobalPrefix(apiPrefix);
    app.enableVersioning({ type: common_1.VersioningType.URI });
    const config = new swagger_1.DocumentBuilder()
        .setTitle("NOS — Network Operations & Monitoring Platform API")
        .setDescription("Developer-grade telemetry, network node management, alerting, inventory, and personal workspace administration API. " +
        "Powering real-time device monitoring for home lab setups and personal computers.")
        .setVersion("1.0.0")
        .addBearerAuth({ type: "http", scheme: "bearer", bearerFormat: "JWT" }, "JWT")
        .addApiKey({ type: "apiKey", in: "header", name: "x-api-key" }, "ApiKey")
        .addTag("Health", "System diagnostic and database liveliness endpoints")
        .addTag("Authentication & Identity", "Login, registration, token refresh, password reset")
        .addTag("Devices", "Device registration, heartbeat, and lifecycle management")
        .addTag("Telemetry", "Real-time CPU, RAM, Disk, and Network telemetry ingest and retrieval")
        .addTag("Alerts", "Alert rules, engine evaluation, incident lifecycle")
        .addTag("Inventory", "Hardware, software, network, and security asset discovery")
        .addTag("Dashboard", "Operational overview and device status aggregations")
        .addTag("Realtime", "Socket.IO gateway and room management")
        .addTag("Users", "User management and profile operations")
        .addTag("Workspace", "Personal workspace settings, roles, API keys, and governance")
        .build();
    const document = swagger_1.SwaggerModule.createDocument(app, config);
    swagger_1.SwaggerModule.setup("docs", app, document);
    const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3001;
    const host = process.env.HOST || "0.0.0.0";
    await app.listen(port, host);
    const url = await app.getUrl();
    appLogger.log(`🚀 NOS Backend Fastify Server operational at: ${url}/${apiPrefix}`);
    appLogger.log(`📚 OpenAPI Swagger docs accessible at: ${url}/docs`);
    appLogger.log(`🔒 Production secrets validation: ${process.env.NODE_ENV === "production" ? "ENFORCED" : "DEVELOPMENT MODE"}`);
}
bootstrap();
//# sourceMappingURL=main.js.map