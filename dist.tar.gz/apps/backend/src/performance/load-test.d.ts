import autocannon from "autocannon";
declare function runPerformanceBenchmark(): Promise<autocannon.Result>;
export { runPerformanceBenchmark };
