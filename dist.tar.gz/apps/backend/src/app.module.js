"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppModule = void 0;
const common_1 = require("@nestjs/common");
const core_1 = require("@nestjs/core");
const throttler_1 = require("@nestjs/throttler");
const event_emitter_1 = require("@nestjs/event-emitter");
const schedule_1 = require("@nestjs/schedule");
const config_module_1 = require("./config/config.module");
const graceful_shutdown_service_1 = require("./common/lifecycle/graceful-shutdown.service");
const database_module_1 = require("./database/database.module");
const health_module_1 = require("./modules/health/health.module");
const auth_module_1 = require("./modules/auth/auth.module");
const users_module_1 = require("./modules/users/users.module");
const device_module_1 = require("./modules/device/device.module");
const telemetry_module_1 = require("./modules/telemetry/telemetry.module");
const dashboard_module_1 = require("./modules/dashboard/dashboard.module");
const inventory_module_1 = require("./modules/inventory/inventory.module");
const realtime_module_1 = require("./modules/realtime/realtime.module");
const alerts_module_1 = require("./modules/alerts/alerts.module");
const tenant_module_1 = require("./modules/tenant/tenant.module");
const fleet_module_1 = require("./modules/fleet/fleet.module");
const audit_module_1 = require("./modules/audit/audit.module");
const global_exception_filter_1 = require("./common/filters/global-exception.filter");
let AppModule = class AppModule {
};
exports.AppModule = AppModule;
exports.AppModule = AppModule = __decorate([
    (0, common_1.Module)({
        imports: [
            config_module_1.ConfigModule,
            event_emitter_1.EventEmitterModule.forRoot({ global: true }),
            schedule_1.ScheduleModule.forRoot(),
            throttler_1.ThrottlerModule.forRoot([
                { name: "default", ttl: 60000, limit: 100 },
                { name: "auth", ttl: 60000, limit: 5 },
                { name: "telemetry", ttl: 60000, limit: 1000 },
            ]),
            database_module_1.DatabaseModule,
            health_module_1.HealthModule,
            auth_module_1.AuthModule,
            users_module_1.UsersModule,
            device_module_1.DeviceModule,
            telemetry_module_1.TelemetryModule,
            dashboard_module_1.DashboardModule,
            inventory_module_1.InventoryModule,
            realtime_module_1.RealtimeModule,
            alerts_module_1.AlertsModule,
            tenant_module_1.TenantModule,
            fleet_module_1.FleetModule,
            audit_module_1.AuditModule,
        ],
        controllers: [],
        providers: [
            {
                provide: core_1.APP_FILTER,
                useClass: global_exception_filter_1.GlobalExceptionFilter,
            },
            {
                provide: core_1.APP_GUARD,
                useClass: throttler_1.ThrottlerGuard,
            },
            graceful_shutdown_service_1.GracefulShutdownService,
        ],
    })
], AppModule);
//# sourceMappingURL=app.module.js.map