declare const _default: () => {
    environment: string;
    port: number;
    database: {
        url: string;
    };
    jwt: {
        secret: string;
        expiration: string;
        refreshSecret: string;
    };
    agent: {
        tokenSecret: string;
    };
    frontendUrl: string;
};
export default _default;
