"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatabaseModule = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("./prisma.service");
const tenant_repository_interface_1 = require("../common/repositories/tenant.repository.interface");
const device_timeline_repository_interface_1 = require("../common/repositories/device-timeline.repository.interface");
const prisma_organization_repository_1 = require("./repositories/prisma-organization.repository");
const prisma_team_repository_1 = require("./repositories/prisma-team.repository");
const prisma_api_key_repository_1 = require("./repositories/prisma-api-key.repository");
const prisma_user_session_repository_1 = require("./repositories/prisma-user-session.repository");
const prisma_audit_log_repository_1 = require("./repositories/prisma-audit-log.repository");
const prisma_device_governance_repository_1 = require("./repositories/prisma-device-governance.repository");
const prisma_device_timeline_repository_1 = require("./repositories/prisma-device-timeline.repository");
const prisma_registration_key_repository_1 = require("./repositories/prisma-registration-key.repository");
const registration_key_repository_interface_1 = require("../common/repositories/registration-key.repository.interface");
let DatabaseModule = class DatabaseModule {
};
exports.DatabaseModule = DatabaseModule;
exports.DatabaseModule = DatabaseModule = __decorate([
    (0, common_1.Global)(),
    (0, common_1.Module)({
        providers: [
            prisma_service_1.PrismaService,
            {
                provide: tenant_repository_interface_1.IOrganizationRepositoryToken,
                useClass: prisma_organization_repository_1.PrismaOrganizationRepository,
            },
            { provide: tenant_repository_interface_1.ITeamRepositoryToken, useClass: prisma_team_repository_1.PrismaTeamRepository },
            { provide: tenant_repository_interface_1.IApiKeyRepositoryToken, useClass: prisma_api_key_repository_1.PrismaApiKeyRepository },
            {
                provide: tenant_repository_interface_1.IUserSessionRepositoryToken,
                useClass: prisma_user_session_repository_1.PrismaUserSessionRepository,
            },
            { provide: tenant_repository_interface_1.IAuditLogRepositoryToken, useClass: prisma_audit_log_repository_1.PrismaAuditLogRepository },
            {
                provide: tenant_repository_interface_1.IDeviceGovernanceRepositoryToken,
                useClass: prisma_device_governance_repository_1.PrismaDeviceGovernanceRepository,
            },
            {
                provide: device_timeline_repository_interface_1.IDeviceTimelineRepository,
                useClass: prisma_device_timeline_repository_1.PrismaDeviceTimelineRepository,
            },
            {
                provide: registration_key_repository_interface_1.IRegistrationKeyRepository,
                useClass: prisma_registration_key_repository_1.PrismaRegistrationKeyRepository,
            },
        ],
        exports: [
            prisma_service_1.PrismaService,
            tenant_repository_interface_1.IOrganizationRepositoryToken,
            tenant_repository_interface_1.ITeamRepositoryToken,
            tenant_repository_interface_1.IApiKeyRepositoryToken,
            tenant_repository_interface_1.IUserSessionRepositoryToken,
            tenant_repository_interface_1.IAuditLogRepositoryToken,
            tenant_repository_interface_1.IDeviceGovernanceRepositoryToken,
            device_timeline_repository_interface_1.IDeviceTimelineRepository,
            registration_key_repository_interface_1.IRegistrationKeyRepository,
        ],
    })
], DatabaseModule);
//# sourceMappingURL=database.module.js.map