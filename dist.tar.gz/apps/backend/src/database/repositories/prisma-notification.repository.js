"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrismaNotificationRepository = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma.service");
let PrismaNotificationRepository = class PrismaNotificationRepository {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async create(data) {
        return this.prisma.notificationLog.create({
            data: {
                alertId: data.alertId,
                provider: data.provider,
                recipient: data.recipient,
                status: data.status,
                response: data.response || null,
                retryCount: data.retryCount || 0,
                isDlq: data.isDlq || false,
            },
        });
    }
    async findById(id) {
        return this.prisma.notificationLog.findUnique({ where: { id } });
    }
    async findByAlertId(alertId) {
        return this.prisma.notificationLog.findMany({
            where: { alertId },
            orderBy: { sentAt: "desc" },
        });
    }
    async updateStatus(id, status, retryCount, isDlq = false, response) {
        const updateData = {
            status,
            retryCount,
            isDlq,
        };
        if (response !== undefined)
            updateData.response = response;
        return this.prisma.notificationLog.update({
            where: { id },
            data: updateData,
        });
    }
    async findDlqLogs(skip = 0, take = 20) {
        const where = { isDlq: true };
        const [logs, total] = await Promise.all([
            this.prisma.notificationLog.findMany({
                where,
                skip,
                take,
                orderBy: { sentAt: "desc" },
            }),
            this.prisma.notificationLog.count({ where }),
        ]);
        return [logs, total];
    }
};
exports.PrismaNotificationRepository = PrismaNotificationRepository;
exports.PrismaNotificationRepository = PrismaNotificationRepository = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], PrismaNotificationRepository);
//# sourceMappingURL=prisma-notification.repository.js.map