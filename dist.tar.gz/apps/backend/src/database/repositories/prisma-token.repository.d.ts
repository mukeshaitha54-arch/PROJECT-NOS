import { PrismaService } from "../prisma.service";
import { ITokenRepository, OtpTypeEnum, RefreshTokenRecord, OtpRecord } from "../../common/repositories/token.repository.interface";
export declare class PrismaTokenRepository implements ITokenRepository {
    private readonly prisma;
    constructor(prisma: PrismaService);
    createRefreshToken(userId: string, tokenHash: string, expiresAt: Date): Promise<RefreshTokenRecord>;
    findRefreshToken(tokenHash: string): Promise<RefreshTokenRecord | null>;
    revokeRefreshToken(tokenHash: string): Promise<void>;
    revokeAllUserRefreshTokens(userId: string): Promise<void>;
    createOtp(userId: string, email: string, otpHash: string, type: OtpTypeEnum, expiresAt: Date): Promise<OtpRecord>;
    findLatestOtp(email: string, type: OtpTypeEnum): Promise<OtpRecord | null>;
    markOtpAsUsed(id: string): Promise<void>;
}
