import { PrismaService } from "../prisma.service";
import { IInventoryRepository, InventoryAuditAction } from "../../common/repositories/inventory.repository.interface";
import { SubmitInventoryPayload, DeviceInventoryDto, HardwareInventoryResponse, SoftwareInventoryResponse, NetworkInventoryResponse, SecurityInventoryResponse, InventoryHealthResponse, InventoryAuditLogDto } from "@nos/shared-types";
export declare class PrismaInventoryRepository implements IInventoryRepository {
    private readonly prisma;
    private readonly logger;
    constructor(prisma: PrismaService);
    private mapToDto;
    private resolveDeviceId;
    upsertInventory(deviceId: string, payload: SubmitInventoryPayload, assetFingerprint: string): Promise<{
        inventory: DeviceInventoryDto;
        previousInventory: DeviceInventoryDto | null;
    }>;
    findCompleteInventory(deviceId: string): Promise<DeviceInventoryDto | null>;
    findHardwareInventory(deviceId: string): Promise<HardwareInventoryResponse | null>;
    findSoftwareInventory(deviceId: string, search?: string, page?: number, limit?: number): Promise<SoftwareInventoryResponse | null>;
    findNetworkInventory(deviceId: string): Promise<NetworkInventoryResponse | null>;
    findSecurityInventory(deviceId: string): Promise<SecurityInventoryResponse | null>;
    getInventoryHealth(deviceId?: string): Promise<InventoryHealthResponse>;
    createAuditLog(deviceId: string, action: InventoryAuditAction, changeDetails: string): Promise<void>;
    getRecentAuditLogs(deviceId: string, limit?: number): Promise<InventoryAuditLogDto[]>;
    search(query: string, organizationId: string): Promise<any[]>;
}
