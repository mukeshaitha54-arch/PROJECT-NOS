import { PrismaService } from "../prisma.service";
import { IDashboardRepository, DashboardOverviewCounts, DeviceRowRaw, DeviceDetailRaw, TelemetryHistoryRaw } from "../../common/repositories/dashboard.repository.interface";
export declare class PrismaDashboardRepository implements IDashboardRepository {
    private readonly prisma;
    private readonly logger;
    constructor(prisma: PrismaService);
    getOverviewCounts(organizationId: string): Promise<DashboardOverviewCounts>;
    getDeviceRows(params: {
        organizationId: string;
        skip: number;
        take: number;
        search?: string;
        status?: string;
        os?: string;
    }): Promise<{
        devices: DeviceRowRaw[];
        total: number;
    }>;
    getDeviceDetail(organizationId: string, deviceId: string): Promise<DeviceDetailRaw | null>;
    getTelemetryHistory(organizationId: string, deviceId: string, params: {
        from?: Date;
        to?: Date;
        skip: number;
        take: number;
    }): Promise<TelemetryHistoryRaw>;
}
