import { PrismaService } from "../prisma.service";
import { IAuditLogRepository } from "../../common/repositories/tenant.repository.interface";
import { AuditLogDto, AuditSearchRequestDto, AuditSearchResultDto } from "@nos/shared-types";
export declare class PrismaAuditLogRepository implements IAuditLogRepository {
    private readonly prisma;
    constructor(prisma: PrismaService);
    private mapLog;
    record(data: Omit<AuditLogDto, "id" | "timestamp">): Promise<AuditLogDto>;
    search(request: AuditSearchRequestDto): Promise<AuditSearchResultDto>;
}
