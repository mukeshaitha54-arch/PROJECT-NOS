import { TelemetrySnapshot as PrismaTelemetrySnapshot } from "@prisma/client";
import { PrismaService } from "../prisma.service";
import { ITelemetryRepository, TelemetryCreateInput, TelemetryRangeQuery, TelemetryAggregationResult } from "../../common/repositories/telemetry.repository.interface";
export declare class PrismaTelemetryRepository implements ITelemetryRepository {
    private readonly prisma;
    constructor(prisma: PrismaService);
    create(data: TelemetryCreateInput): Promise<PrismaTelemetrySnapshot>;
    findLatest(deviceId: string): Promise<PrismaTelemetrySnapshot | null>;
    findRange(query: TelemetryRangeQuery): Promise<{
        items: PrismaTelemetrySnapshot[];
        total: number;
    }>;
    exists(id: string): Promise<boolean>;
    deleteOlderThan(cutoffDate: Date): Promise<number>;
    aggregate(deviceId: string, from?: Date, to?: Date): Promise<TelemetryAggregationResult>;
}
