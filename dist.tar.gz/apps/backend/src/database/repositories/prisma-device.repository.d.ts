import { Device, DeviceStatus } from "@prisma/client";
import { PrismaService } from "../prisma.service";
import { IDeviceRepository, CreateDeviceInput, UpdateDeviceInput } from "../../common/repositories/device.repository.interface";
export declare class PrismaDeviceRepository implements IDeviceRepository {
    private readonly prisma;
    constructor(prisma: PrismaService);
    findById(id: string): Promise<Device | null>;
    findByUuid(uuid: string): Promise<Device | null>;
    findByTokenHash(tokenHash: string): Promise<Device | null>;
    findAll(organizationId?: string): Promise<Device[]>;
    countByOrganization(organizationId?: string): Promise<number>;
    create(data: CreateDeviceInput): Promise<Device>;
    update(id: string, data: UpdateDeviceInput): Promise<Device>;
    delete(id: string): Promise<boolean>;
    countByStatus(): Promise<Record<DeviceStatus, number>>;
    search(query: string, organizationId: string): Promise<Device[]>;
}
