import { PrismaService } from "../prisma.service";
import { IAlertRuleRepository, AlertRuleCreateInput, AlertRuleFindManyQuery } from "../../common/repositories/alert-rule.repository.interface";
import { AlertRule } from "@prisma/client";
export declare class PrismaAlertRuleRepository implements IAlertRuleRepository {
    private readonly prisma;
    constructor(prisma: PrismaService);
    create(data: AlertRuleCreateInput): Promise<AlertRule>;
    findById(id: string): Promise<AlertRule | null>;
    findByName(name: string): Promise<AlertRule | null>;
    findMany(enabledOnly?: boolean, metric?: string): Promise<AlertRule[]>;
    findManyPaginated(query: AlertRuleFindManyQuery): Promise<[AlertRule[], number]>;
    update(id: string, data: Partial<AlertRule>): Promise<AlertRule>;
    delete(id: string): Promise<boolean>;
    archive(id: string, performedBy: string): Promise<AlertRule>;
    clone(id: string, newName: string, performedBy: string): Promise<AlertRule>;
    incrementVersion(id: string, modifier: string): Promise<AlertRule>;
    updatePerformanceMetrics(id: string, metrics: {
        execMs: number;
        triggered: boolean;
        suppressed?: boolean;
        deduplicated?: boolean;
        escalated?: boolean;
    }): Promise<void>;
    findConflicting(): Promise<Array<{
        ruleIds: string[];
        reason: string;
    }>>;
    findDuplicates(): Promise<Array<{
        ruleIds: string[];
        reason: string;
    }>>;
    findByIds(ids: string[]): Promise<AlertRule[]>;
    getCategories(): Promise<string[]>;
    getTags(): Promise<string[]>;
}
