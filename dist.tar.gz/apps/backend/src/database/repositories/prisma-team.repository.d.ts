import { PrismaService } from "../prisma.service";
import { ITeamRepository } from "../../common/repositories/tenant.repository.interface";
import { DepartmentDto, TeamDto, OrganizationMemberDto, OrganizationInvitationDto, UserRole } from "@nos/shared-types";
export declare class PrismaTeamRepository implements ITeamRepository {
    private readonly prisma;
    constructor(prisma: PrismaService);
    createDepartment(organizationId: string, name: string, description?: string, headUserId?: string): Promise<DepartmentDto>;
    listDepartments(organizationId: string): Promise<DepartmentDto[]>;
    createTeam(organizationId: string, name: string, departmentId?: string, description?: string, leadUserId?: string): Promise<TeamDto>;
    listTeams(organizationId: string): Promise<TeamDto[]>;
    addMember(organizationId: string, userId: string, role: UserRole, teamIds?: string[], departmentIds?: string[], customRoleId?: string): Promise<OrganizationMemberDto>;
    updateMemberRole(organizationId: string, userId: string, role: UserRole, customRoleId?: string): Promise<OrganizationMemberDto>;
    removeMember(organizationId: string, userId: string): Promise<void>;
    listMembers(organizationId: string, params?: {
        search?: string;
        role?: string;
        page?: number;
        limit?: number;
    }): Promise<{
        items: OrganizationMemberDto[];
        total: number;
    }>;
    findMember(organizationId: string, userId: string): Promise<OrganizationMemberDto | null>;
    createInvitation(organizationId: string, email: string, role: UserRole, invitedByUserId: string, tokenHash: string, expiresAt: Date, teamIds?: string[], departmentIds?: string[]): Promise<OrganizationInvitationDto>;
    listInvitations(organizationId: string): Promise<OrganizationInvitationDto[]>;
    revokeInvitation(organizationId: string, id: string): Promise<void>;
}
