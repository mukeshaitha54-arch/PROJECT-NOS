import { UserRole } from "@nos/shared-types";
import { PrismaService } from "../prisma.service";
import { IUserRepository, CreateUserData, UpdateUserData } from "../../common/repositories/user.repository.interface";
import { User } from "@prisma/client";
export declare class PrismaUserRepository implements IUserRepository {
    private readonly prisma;
    constructor(prisma: PrismaService);
    private mapRole;
    private mapPrismaRole;
    findById(id: string): Promise<{
        role: UserRole;
        createdAt: string;
        updatedAt: string;
        id: string;
        email: string;
        passwordHash: string;
        firstName: string;
        lastName: string;
        isEmailVerified: boolean;
    }>;
    findByEmail(email: string): Promise<{
        role: UserRole;
        createdAt: string;
        updatedAt: string;
        id: string;
        email: string;
        passwordHash: string;
        firstName: string;
        lastName: string;
        isEmailVerified: boolean;
    }>;
    create(data: CreateUserData): Promise<{
        role: UserRole;
        createdAt: string;
        updatedAt: string;
        id: string;
        email: string;
        passwordHash: string;
        firstName: string;
        lastName: string;
        isEmailVerified: boolean;
    }>;
    update(id: string, data: UpdateUserData): Promise<{
        role: UserRole;
        createdAt: string;
        updatedAt: string;
        id: string;
        email: string;
        passwordHash: string;
        firstName: string;
        lastName: string;
        isEmailVerified: boolean;
    }>;
    delete(id: string): Promise<boolean>;
    search(query: string, organizationId: string): Promise<User[]>;
}
