"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrismaUserRepository = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma.service");
const client_1 = require("@prisma/client");
let PrismaUserRepository = class PrismaUserRepository {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    mapRole(role) {
        return role;
    }
    mapPrismaRole(role) {
        return role;
    }
    async findById(id) {
        const user = await this.prisma.user.findUnique({ where: { id } });
        if (!user)
            return null;
        return {
            ...user,
            role: this.mapRole(user.role),
            createdAt: user.createdAt.toISOString(),
            updatedAt: user.updatedAt.toISOString(),
        };
    }
    async findByEmail(email) {
        const user = await this.prisma.user.findUnique({
            where: { email: email.toLowerCase() },
        });
        if (!user)
            return null;
        return {
            ...user,
            role: this.mapRole(user.role),
            createdAt: user.createdAt.toISOString(),
            updatedAt: user.updatedAt.toISOString(),
        };
    }
    async create(data) {
        const user = await this.prisma.user.create({
            data: {
                email: data.email.toLowerCase(),
                passwordHash: data.passwordHash,
                firstName: data.firstName,
                lastName: data.lastName,
                role: data.role ? this.mapPrismaRole(data.role) : client_1.Role.USER,
                isEmailVerified: data.isEmailVerified ?? false,
            },
        });
        return {
            ...user,
            role: this.mapRole(user.role),
            createdAt: user.createdAt.toISOString(),
            updatedAt: user.updatedAt.toISOString(),
        };
    }
    async update(id, data) {
        const updatePayload = {};
        if (data.firstName !== undefined)
            updatePayload.firstName = data.firstName;
        if (data.lastName !== undefined)
            updatePayload.lastName = data.lastName;
        if (data.passwordHash !== undefined)
            updatePayload.passwordHash = data.passwordHash;
        if (data.role !== undefined)
            updatePayload.role = this.mapPrismaRole(data.role);
        if (data.isEmailVerified !== undefined)
            updatePayload.isEmailVerified = data.isEmailVerified;
        const user = await this.prisma.user.update({
            where: { id },
            data: updatePayload,
        });
        return {
            ...user,
            role: this.mapRole(user.role),
            createdAt: user.createdAt.toISOString(),
            updatedAt: user.updatedAt.toISOString(),
        };
    }
    async delete(id) {
        try {
            await this.prisma.user.delete({ where: { id } });
            return true;
        }
        catch {
            return false;
        }
    }
    async search(query, organizationId) {
        return this.prisma.user.findMany({
            where: {
                OR: [
                    { firstName: { contains: query, mode: "insensitive" } },
                    { lastName: { contains: query, mode: "insensitive" } },
                    { email: { contains: query, mode: "insensitive" } },
                ],
            },
            take: 20,
        });
    }
};
exports.PrismaUserRepository = PrismaUserRepository;
exports.PrismaUserRepository = PrismaUserRepository = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], PrismaUserRepository);
//# sourceMappingURL=prisma-user.repository.js.map