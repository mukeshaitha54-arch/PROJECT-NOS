import { PrismaService } from "../prisma.service";
import { IMaintenanceRepository, MaintenanceWindowCreateInput } from "../../common/repositories/maintenance.repository.interface";
import { MaintenanceWindow } from "@prisma/client";
export declare class PrismaMaintenanceRepository implements IMaintenanceRepository {
    private readonly prisma;
    constructor(prisma: PrismaService);
    create(data: MaintenanceWindowCreateInput): Promise<MaintenanceWindow>;
    findById(id: string): Promise<MaintenanceWindow | null>;
    findActiveByDevice(deviceId: string, atTime?: Date): Promise<MaintenanceWindow[]>;
    findMany(enabledOnly?: boolean): Promise<MaintenanceWindow[]>;
    update(id: string, data: Partial<MaintenanceWindow>): Promise<MaintenanceWindow>;
    delete(id: string): Promise<boolean>;
}
