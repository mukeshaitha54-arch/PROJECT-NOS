"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrismaMaintenanceRepository = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma.service");
let PrismaMaintenanceRepository = class PrismaMaintenanceRepository {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async create(data) {
        return this.prisma.maintenanceWindow.create({
            data: {
                deviceId: data.deviceId || null,
                deviceGroupId: data.deviceGroupId || null,
                title: data.title,
                startTime: data.startTime,
                endTime: data.endTime,
                reason: data.reason,
                type: data.type || "SCHEDULED",
                enabled: data.enabled ?? true,
            },
        });
    }
    async findById(id) {
        return this.prisma.maintenanceWindow.findUnique({ where: { id } });
    }
    async findActiveByDevice(deviceId, atTime = new Date()) {
        return this.prisma.maintenanceWindow.findMany({
            where: {
                enabled: true,
                startTime: { lte: atTime },
                endTime: { gte: atTime },
                OR: [
                    { deviceId: deviceId },
                    { deviceId: null, deviceGroupId: null },
                ],
            },
        });
    }
    async findMany(enabledOnly = false) {
        const where = {};
        if (enabledOnly)
            where.enabled = true;
        return this.prisma.maintenanceWindow.findMany({
            where,
            orderBy: { startTime: "desc" },
        });
    }
    async update(id, data) {
        const updateData = { ...data };
        delete updateData.id;
        delete updateData.createdAt;
        return this.prisma.maintenanceWindow.update({
            where: { id },
            data: updateData,
        });
    }
    async delete(id) {
        try {
            await this.prisma.maintenanceWindow.delete({ where: { id } });
            return true;
        }
        catch {
            return false;
        }
    }
};
exports.PrismaMaintenanceRepository = PrismaMaintenanceRepository;
exports.PrismaMaintenanceRepository = PrismaMaintenanceRepository = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], PrismaMaintenanceRepository);
//# sourceMappingURL=prisma-maintenance.repository.js.map