"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrismaApiKeyRepository = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma.service");
let PrismaApiKeyRepository = class PrismaApiKeyRepository {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    mapEntity(entity) {
        return {
            id: entity.id,
            organizationId: entity.organizationId,
            name: entity.name,
            keyPrefix: entity.keyPrefix,
            tokenHash: entity.tokenHash,
            scopes: entity.scopes || [],
            allowedIps: entity.allowedIps || [],
            expiresAt: entity.expiresAt.toISOString(),
            lastUsedAt: entity.lastUsedAt ? entity.lastUsedAt.toISOString() : null,
            usageCount: entity.usageCount || 0,
            createdByUserId: entity.createdByUserId,
            isRevoked: entity.isRevoked,
            createdAt: entity.createdAt.toISOString(),
            updatedAt: entity.updatedAt.toISOString(),
        };
    }
    async create(organizationId, createdByUserId, data, keyPrefix, tokenHash) {
        const expiresAt = new Date();
        expiresAt.setDate(expiresAt.getDate() + (data.expiryDays || 90));
        const created = await this.prisma.apiKey.create({
            data: {
                organizationId,
                name: data.name,
                keyPrefix,
                tokenHash,
                scopes: data.scopes,
                allowedIps: data.allowedIps || [],
                expiresAt,
                createdByUserId,
                isRevoked: false,
            },
        });
        return this.mapEntity(created);
    }
    async findByTokenHash(tokenHash) {
        const key = await this.prisma.apiKey.findUnique({
            where: { tokenHash },
        });
        if (!key || key.isRevoked)
            return null;
        return this.mapEntity(key);
    }
    async listByOrganization(organizationId, params) {
        const page = params?.page && params.page > 0 ? params.page : 1;
        const limit = params?.limit && params.limit > 0 ? params.limit : 20;
        const skip = (page - 1) * limit;
        const where = { organizationId, isRevoked: false };
        if (params?.search) {
            where.name = { contains: params.search, mode: "insensitive" };
        }
        const [total, rows] = await Promise.all([
            this.prisma.apiKey.count({ where }),
            this.prisma.apiKey.findMany({
                where,
                skip,
                take: limit,
                orderBy: { createdAt: "desc" },
            }),
        ]);
        return {
            items: rows.map((r) => this.mapEntity(r)),
            total,
        };
    }
    async revoke(organizationId, id) {
        await this.prisma.apiKey.updateMany({
            where: { id, organizationId },
            data: { isRevoked: true },
        });
    }
    async recordUsage(id) {
        await this.prisma.apiKey.update({
            where: { id },
            data: {
                lastUsedAt: new Date(),
                usageCount: { increment: 1 },
            },
        });
    }
};
exports.PrismaApiKeyRepository = PrismaApiKeyRepository;
exports.PrismaApiKeyRepository = PrismaApiKeyRepository = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], PrismaApiKeyRepository);
//# sourceMappingURL=prisma-api-key.repository.js.map