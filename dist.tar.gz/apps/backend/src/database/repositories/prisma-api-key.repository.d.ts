import { PrismaService } from "../prisma.service";
import { IApiKeyRepository } from "../../common/repositories/tenant.repository.interface";
import { ApiKeyDto, ApiKeyCreateRequestDto } from "@nos/shared-types";
export declare class PrismaApiKeyRepository implements IApiKeyRepository {
    private readonly prisma;
    constructor(prisma: PrismaService);
    private mapEntity;
    create(organizationId: string, createdByUserId: string, data: ApiKeyCreateRequestDto, keyPrefix: string, tokenHash: string): Promise<ApiKeyDto>;
    findByTokenHash(tokenHash: string): Promise<ApiKeyDto | null>;
    listByOrganization(organizationId: string, params?: {
        page?: number;
        limit?: number;
        search?: string;
    }): Promise<{
        items: ApiKeyDto[];
        total: number;
    }>;
    revoke(organizationId: string, id: string): Promise<void>;
    recordUsage(id: string): Promise<void>;
}
