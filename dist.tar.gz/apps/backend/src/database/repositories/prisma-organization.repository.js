"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrismaOrganizationRepository = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma.service");
const shared_types_1 = require("@nos/shared-types");
let PrismaOrganizationRepository = class PrismaOrganizationRepository {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    getDefaultSettings() {
        return {
            timezone: "UTC",
            language: "en-US",
            retentionDays: 90,
            notificationDefaults: {
                emailEnabled: true,
                webhookEnabled: false,
            },
            maintenanceDefaults: {
                defaultDurationMinutes: 120,
                requireApproval: true,
                autoNotify: true,
            },
            securityPolicies: {
                enforceMfa: true,
                sessionTimeoutMinutes: 60,
                maxFailedLoginAttempts: 5,
                allowedIpRanges: [],
            },
            passwordPolicies: {
                minLength: 12,
                requireUppercase: true,
                requireNumbers: true,
                requireSymbols: true,
                expiryDays: 90,
            },
        };
    }
    getDefaultQuota() {
        return {
            maxDevices: 50,
            maxUsers: 10,
            maxApiKeys: 10,
            maxStorageMb: 1024,
            maxDailyTelemetry: 100000,
            maxDailyAlerts: 5000,
        };
    }
    mapEntity(org) {
        const settings = this.getDefaultSettings();
        const quota = org.quota
            ? {
                maxDevices: org.quota.maxDevices,
                maxUsers: org.quota.maxUsers,
                maxApiKeys: org.quota.maxApiKeys,
                maxStorageMb: org.quota.maxStorageMb,
                maxDailyTelemetry: org.quota.maxDailyTelemetry,
                maxDailyAlerts: org.quota.maxDailyAlerts,
            }
            : this.getDefaultQuota();
        const quotaUsage = org.quota
            ? {
                ...quota,
                currentDevices: org.quota.currentDevices,
                currentUsers: org.quota.currentUsers,
                currentApiKeys: org.quota.currentApiKeys,
                currentStorageMb: org.quota.currentStorageMb,
                currentDailyTelemetry: org.quota.currentDailyTelemetry,
                currentDailyAlerts: org.quota.currentDailyAlerts,
                isApproachingLimit: org.quota.currentDevices / org.quota.maxDevices > 0.8,
                isLimitExceeded: org.quota.currentDevices >= org.quota.maxDevices,
                percentUsed: Math.min(100, Math.round((org.quota.currentDevices / org.quota.maxDevices) * 100)),
            }
            : undefined;
        return {
            id: org.id,
            name: org.name,
            slug: org.slug,
            status: org.status || shared_types_1.OrganizationStatus.ACTIVE,
            createdAt: org.createdAt.toISOString(),
            updatedAt: org.updatedAt.toISOString(),
            deletedAt: org.deletedAt ? org.deletedAt.toISOString() : null,
            settings,
            quota,
            quotaUsage,
        };
    }
    async findById(id) {
        const org = await this.prisma.organization.findUnique({
            where: { id },
            include: { quota: true },
        });
        if (!org)
            return null;
        return this.mapEntity(org);
    }
    async findBySlug(slug) {
        const org = await this.prisma.organization.findUnique({
            where: { slug: slug.toLowerCase() },
            include: { quota: true },
        });
        if (!org)
            return null;
        return this.mapEntity(org);
    }
    async create(data) {
        const settings = { ...this.getDefaultSettings(), ...data.settings };
        const quotaDefaults = { ...this.getDefaultQuota(), ...data.quota };
        const created = await this.prisma.organization.create({
            data: {
                name: data.name,
                slug: data.slug.toLowerCase(),
                status: data.status || shared_types_1.OrganizationStatus.ACTIVE,
                quota: {
                    create: {
                        maxDevices: quotaDefaults.maxDevices,
                        maxUsers: quotaDefaults.maxUsers,
                        maxApiKeys: quotaDefaults.maxApiKeys,
                        maxStorageMb: quotaDefaults.maxStorageMb,
                        maxDailyTelemetry: quotaDefaults.maxDailyTelemetry,
                        maxDailyAlerts: quotaDefaults.maxDailyAlerts,
                    },
                },
            },
            include: { quota: true },
        });
        return this.mapEntity(created);
    }
    async updateStatus(id, status) {
        const updated = await this.prisma.organization.update({
            where: { id },
            data: { status },
            include: { quota: true },
        });
        return this.mapEntity(updated);
    }
    async updateSettings(id, settings) {
        const updated = await this.prisma.organization.update({
            where: { id },
            data: { timezone: settings?.timezone || "UTC" },
            include: { quota: true },
        });
        return this.mapEntity(updated);
    }
    async softDelete(id) {
        await this.prisma.organization.update({
            where: { id },
            data: {
                status: shared_types_1.OrganizationStatus.DELETED,
                deletedAt: new Date(),
            },
        });
    }
    async restore(id) {
        const updated = await this.prisma.organization.update({
            where: { id },
            data: {
                status: shared_types_1.OrganizationStatus.ACTIVE,
                deletedAt: null,
            },
            include: { quota: true },
        });
        return this.mapEntity(updated);
    }
    async listAll(params) {
        const page = params?.page && params.page > 0 ? params.page : 1;
        const limit = params?.limit && params.limit > 0 ? params.limit : 20;
        const skip = (page - 1) * limit;
        const where = {};
        if (params?.status) {
            where.status = params.status;
        }
        else {
            where.status = { not: shared_types_1.OrganizationStatus.DELETED };
        }
        if (params?.search) {
            where.OR = [
                { name: { contains: params.search, mode: "insensitive" } },
                { slug: { contains: params.search, mode: "insensitive" } },
            ];
        }
        const [total, rows] = await Promise.all([
            this.prisma.organization.count({ where }),
            this.prisma.organization.findMany({
                where,
                skip,
                take: limit,
                orderBy: { name: "asc" },
                include: { quota: true },
            }),
        ]);
        const totalPages = Math.max(1, Math.ceil(total / limit));
        return {
            items: rows.map((r) => this.mapEntity(r)),
            total,
            page,
            totalPages,
        };
    }
    async getQuota(organizationId) {
        const q = await this.prisma.organizationQuota.findUnique({
            where: { organizationId },
        });
        if (!q)
            return null;
        return {
            maxDevices: q.maxDevices,
            maxUsers: q.maxUsers,
            maxApiKeys: q.maxApiKeys,
            maxStorageMb: q.maxStorageMb,
            maxDailyTelemetry: q.maxDailyTelemetry,
            maxDailyAlerts: q.maxDailyAlerts,
        };
    }
    async updateQuota(organizationId, quota) {
        const q = await this.prisma.organizationQuota.upsert({
            where: { organizationId },
            update: { ...quota },
            create: {
                organizationId,
                ...this.getDefaultQuota(),
                ...quota,
            },
        });
        return {
            maxDevices: q.maxDevices,
            maxUsers: q.maxUsers,
            maxApiKeys: q.maxApiKeys,
            maxStorageMb: q.maxStorageMb,
            maxDailyTelemetry: q.maxDailyTelemetry,
            maxDailyAlerts: q.maxDailyAlerts,
        };
    }
};
exports.PrismaOrganizationRepository = PrismaOrganizationRepository;
exports.PrismaOrganizationRepository = PrismaOrganizationRepository = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], PrismaOrganizationRepository);
//# sourceMappingURL=prisma-organization.repository.js.map