"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrismaAuditLogRepository = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma.service");
let PrismaAuditLogRepository = class PrismaAuditLogRepository {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    mapLog(log) {
        return {
            id: log.id,
            organizationId: log.organizationId,
            userId: log.userId || null,
            userEmail: log.userEmail || null,
            action: log.action,
            resourceType: log.resourceType || null,
            resourceId: log.resourceId || null,
            reason: log.reason || null,
            ipAddress: log.ipAddress,
            browser: log.browser,
            correlationId: log.correlationId,
            details: log.details
                ? log.details
                : undefined,
            timestamp: log.timestamp.toISOString(),
        };
    }
    async record(data) {
        const created = await this.prisma.auditLog.create({
            data: {
                organizationId: data.organizationId,
                userId: data.userId || null,
                userEmail: data.userEmail || null,
                action: data.action,
                resourceType: data.resourceType || null,
                resourceId: data.resourceId || null,
                reason: data.reason || null,
                ipAddress: data.ipAddress,
                browser: data.browser,
                correlationId: data.correlationId,
                details: data.details
                    ? data.details
                    : null,
            },
        });
        return this.mapLog(created);
    }
    async search(request) {
        const page = request.page && request.page > 0 ? request.page : 1;
        const limit = request.limit && request.limit > 0 ? request.limit : 20;
        const skip = (page - 1) * limit;
        const where = {};
        if (request.organizationId) {
            where.organizationId = request.organizationId;
        }
        if (request.userId) {
            where.userId = request.userId;
        }
        if (request.action) {
            where.action = request.action;
        }
        if (request.resourceType) {
            where.resourceType = request.resourceType;
        }
        if (request.from || request.to) {
            where.timestamp = {};
            if (request.from)
                where.timestamp.gte = new Date(request.from);
            if (request.to)
                where.timestamp.lte = new Date(request.to);
        }
        if (request.search) {
            where.OR = [
                { action: { contains: request.search, mode: "insensitive" } },
                { userEmail: { contains: request.search, mode: "insensitive" } },
                { reason: { contains: request.search, mode: "insensitive" } },
                { correlationId: { contains: request.search, mode: "insensitive" } },
            ];
        }
        const [total, rows] = await Promise.all([
            this.prisma.auditLog.count({ where }),
            this.prisma.auditLog.findMany({
                where,
                skip,
                take: limit,
                orderBy: { timestamp: "desc" },
            }),
        ]);
        const totalPages = Math.max(1, Math.ceil(total / limit));
        return {
            items: rows.map((r) => this.mapLog(r)),
            total,
            page,
            totalPages,
            limit,
        };
    }
};
exports.PrismaAuditLogRepository = PrismaAuditLogRepository;
exports.PrismaAuditLogRepository = PrismaAuditLogRepository = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], PrismaAuditLogRepository);
//# sourceMappingURL=prisma-audit-log.repository.js.map