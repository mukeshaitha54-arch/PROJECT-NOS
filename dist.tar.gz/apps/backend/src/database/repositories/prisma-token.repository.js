"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrismaTokenRepository = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma.service");
let PrismaTokenRepository = class PrismaTokenRepository {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async createRefreshToken(userId, tokenHash, expiresAt) {
        return this.prisma.refreshToken.create({
            data: {
                userId,
                tokenHash,
                expiresAt,
            },
        });
    }
    async findRefreshToken(tokenHash) {
        return this.prisma.refreshToken.findUnique({
            where: { tokenHash },
        });
    }
    async revokeRefreshToken(tokenHash) {
        await this.prisma.refreshToken.updateMany({
            where: { tokenHash },
            data: { isRevoked: true },
        });
    }
    async revokeAllUserRefreshTokens(userId) {
        await this.prisma.refreshToken.updateMany({
            where: { userId, isRevoked: false },
            data: { isRevoked: true },
        });
    }
    async createOtp(userId, email, otpHash, type, expiresAt) {
        const created = await this.prisma.verificationOtp.create({
            data: {
                userId,
                email: email.toLowerCase(),
                otpHash,
                type: type,
                expiresAt,
            },
        });
        return { ...created, type: created.type };
    }
    async findLatestOtp(email, type) {
        const record = await this.prisma.verificationOtp.findFirst({
            where: {
                email: email.toLowerCase(),
                type: type,
                isUsed: false,
            },
            orderBy: { createdAt: "desc" },
        });
        if (!record)
            return null;
        return { ...record, type: record.type };
    }
    async markOtpAsUsed(id) {
        await this.prisma.verificationOtp.update({
            where: { id },
            data: { isUsed: true },
        });
    }
};
exports.PrismaTokenRepository = PrismaTokenRepository;
exports.PrismaTokenRepository = PrismaTokenRepository = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], PrismaTokenRepository);
//# sourceMappingURL=prisma-token.repository.js.map