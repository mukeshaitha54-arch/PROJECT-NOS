"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrismaDeviceGovernanceRepository = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma.service");
const shared_types_1 = require("@nos/shared-types");
let PrismaDeviceGovernanceRepository = class PrismaDeviceGovernanceRepository {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async assignOwnership(deviceId, organizationId, data) {
        const upserted = await this.prisma.deviceOwnership.upsert({
            where: { deviceId },
            update: {
                organizationId,
                ownerUserId: data.ownerUserId ?? null,
                assignedTeamId: data.assignedTeamId ?? null,
                assignedDepartmentId: data.assignedDepartmentId ?? null,
                assignedOperatorId: data.assignedOperatorId ?? null,
                groupIds: data.groupIds ?? [],
            },
            create: {
                deviceId,
                organizationId,
                ownerUserId: data.ownerUserId ?? null,
                assignedTeamId: data.assignedTeamId ?? null,
                assignedDepartmentId: data.assignedDepartmentId ?? null,
                assignedOperatorId: data.assignedOperatorId ?? null,
                groupIds: data.groupIds ?? [],
            },
        });
        await this.prisma.device
            .update({
            where: { id: deviceId },
            data: { organizationId },
        })
            .catch(() => null);
        return {
            id: upserted.id,
            deviceId: upserted.deviceId,
            organizationId: upserted.organizationId,
            ownerUserId: upserted.ownerUserId || null,
            assignedTeamId: upserted.assignedTeamId || null,
            assignedDepartmentId: upserted.assignedDepartmentId || null,
            assignedOperatorId: upserted.assignedOperatorId || null,
            groupIds: upserted.groupIds,
            assignedAt: upserted.assignedAt.toISOString(),
            updatedAt: upserted.updatedAt.toISOString(),
        };
    }
    async getOwnership(deviceId, organizationId) {
        const found = await this.prisma.deviceOwnership.findFirst({
            where: { deviceId, organizationId },
        });
        if (!found)
            return null;
        return {
            id: found.id,
            deviceId: found.deviceId,
            organizationId: found.organizationId,
            ownerUserId: found.ownerUserId || null,
            assignedTeamId: found.assignedTeamId || null,
            assignedDepartmentId: found.assignedDepartmentId || null,
            assignedOperatorId: found.assignedOperatorId || null,
            groupIds: found.groupIds,
            assignedAt: found.assignedAt.toISOString(),
            updatedAt: found.updatedAt.toISOString(),
        };
    }
    async createDeviceGroup(organizationId, name, groupType, description, filterCriteria, deviceIds) {
        const created = await this.prisma.deviceGroup.create({
            data: {
                organizationId,
                name,
                groupType: groupType || "STATIC",
                description: description || null,
                filterCriteria: filterCriteria
                    ? filterCriteria
                    : null,
                deviceIds: deviceIds ?? [],
                deviceCount: deviceIds ? deviceIds.length : 0,
            },
        });
        return {
            id: created.id,
            organizationId: created.organizationId,
            name: created.name,
            description: created.description || undefined,
            groupType: created.groupType,
            filterCriteria: created.filterCriteria
                ? created.filterCriteria
                : undefined,
            deviceIds: created.deviceIds,
            deviceCount: created.deviceCount,
            createdAt: created.createdAt.toISOString(),
            updatedAt: created.updatedAt.toISOString(),
        };
    }
    async listDeviceGroups(organizationId) {
        const rows = await this.prisma.deviceGroup.findMany({
            where: { organizationId },
            orderBy: { name: "asc" },
        });
        return rows.map((g) => ({
            id: g.id,
            organizationId: g.organizationId,
            name: g.name,
            description: g.description || undefined,
            groupType: g.groupType,
            filterCriteria: g.filterCriteria
                ? g.filterCriteria
                : undefined,
            deviceIds: g.deviceIds,
            deviceCount: g.deviceCount,
            createdAt: g.createdAt.toISOString(),
            updatedAt: g.updatedAt.toISOString(),
        }));
    }
    async createTransferRequest(deviceId, fromOrgId, toOrgId, requestedBy, reason) {
        const req = await this.prisma.deviceTransferRequest.create({
            data: {
                deviceId,
                fromOrganizationId: fromOrgId,
                toOrganizationId: toOrgId,
                requestedByUserId: requestedBy,
                status: shared_types_1.DeviceTransferStatus.PENDING_APPROVAL,
                reason,
            },
        });
        return {
            id: req.id,
            deviceId: req.deviceId,
            fromOrganizationId: req.fromOrganizationId,
            toOrganizationId: req.toOrganizationId,
            requestedByUserId: req.requestedByUserId,
            approvedByUserId: req.approvedByUserId || null,
            status: req.status,
            reason: req.reason,
            createdAt: req.createdAt.toISOString(),
            resolvedAt: req.resolvedAt ? req.resolvedAt.toISOString() : null,
        };
    }
    async resolveTransferRequest(id, status, approvedByUserId) {
        const updated = await this.prisma.deviceTransferRequest.update({
            where: { id },
            data: {
                status,
                approvedByUserId: approvedByUserId || null,
                resolvedAt: new Date(),
            },
        });
        if (status === shared_types_1.DeviceTransferStatus.APPROVED) {
            await this.assignOwnership(updated.deviceId, updated.toOrganizationId, {});
        }
        return {
            id: updated.id,
            deviceId: updated.deviceId,
            fromOrganizationId: updated.fromOrganizationId,
            toOrganizationId: updated.toOrganizationId,
            requestedByUserId: updated.requestedByUserId,
            approvedByUserId: updated.approvedByUserId || null,
            status: updated.status,
            reason: updated.reason,
            createdAt: updated.createdAt.toISOString(),
            resolvedAt: updated.resolvedAt ? updated.resolvedAt.toISOString() : null,
        };
    }
    async listTransferRequests(organizationId, type) {
        const where = type === "INCOMING"
            ? { toOrganizationId: organizationId }
            : { fromOrganizationId: organizationId };
        const list = await this.prisma.deviceTransferRequest.findMany({
            where,
            orderBy: { createdAt: "desc" },
        });
        return list.map((r) => ({
            id: r.id,
            deviceId: r.deviceId,
            fromOrganizationId: r.fromOrganizationId,
            toOrganizationId: r.toOrganizationId,
            requestedByUserId: r.requestedByUserId,
            approvedByUserId: r.approvedByUserId || null,
            status: r.status,
            reason: r.reason,
            createdAt: r.createdAt.toISOString(),
            resolvedAt: r.resolvedAt ? r.resolvedAt.toISOString() : null,
        }));
    }
    async listPermissionProfiles(organizationId) {
        const list = await this.prisma.permissionProfile.findMany({
            where: { organizationId },
            orderBy: { name: "asc" },
        });
        return list.map((p) => ({
            id: p.id,
            organizationId: p.organizationId,
            name: p.name,
            description: p.description || undefined,
            permissions: p.permissions,
            abacConditions: p.abacConditions
                ? p.abacConditions
                : undefined,
            isBuiltIn: p.isBuiltIn,
            createdAt: p.createdAt.toISOString(),
            updatedAt: p.updatedAt.toISOString(),
        }));
    }
    async createPermissionProfile(organizationId, name, permissions, description, abacConditions) {
        const created = await this.prisma.permissionProfile.create({
            data: {
                organizationId,
                name,
                permissions,
                description: description || null,
                abacConditions: abacConditions
                    ? abacConditions
                    : null,
                isBuiltIn: false,
            },
        });
        return {
            id: created.id,
            organizationId: created.organizationId,
            name: created.name,
            description: created.description || undefined,
            permissions: created.permissions,
            abacConditions: created.abacConditions
                ? created.abacConditions
                : undefined,
            isBuiltIn: created.isBuiltIn,
            createdAt: created.createdAt.toISOString(),
            updatedAt: created.updatedAt.toISOString(),
        };
    }
    async listRoleTemplates() {
        const list = await this.prisma.roleTemplate.findMany();
        return list.map((r) => ({
            id: r.id,
            name: r.name,
            baseRole: r.baseRole,
            defaultPermissions: r.defaultPermissions,
            description: r.description,
        }));
    }
};
exports.PrismaDeviceGovernanceRepository = PrismaDeviceGovernanceRepository;
exports.PrismaDeviceGovernanceRepository = PrismaDeviceGovernanceRepository = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], PrismaDeviceGovernanceRepository);
//# sourceMappingURL=prisma-device-governance.repository.js.map