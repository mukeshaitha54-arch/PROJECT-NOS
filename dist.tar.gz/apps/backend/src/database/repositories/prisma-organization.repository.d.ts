import { PrismaService } from "../prisma.service";
import { IOrganizationRepository } from "../../common/repositories/tenant.repository.interface";
import { OrganizationDto, OrganizationStatus, OrganizationSettingsDto, OrganizationQuotaDto } from "@nos/shared-types";
export declare class PrismaOrganizationRepository implements IOrganizationRepository {
    private readonly prisma;
    constructor(prisma: PrismaService);
    private getDefaultSettings;
    private getDefaultQuota;
    private mapEntity;
    findById(id: string): Promise<OrganizationDto | null>;
    findBySlug(slug: string): Promise<OrganizationDto | null>;
    create(data: {
        name: string;
        slug: string;
        status?: OrganizationStatus;
        settings?: Partial<OrganizationSettingsDto>;
        quota?: Partial<OrganizationQuotaDto>;
    }): Promise<OrganizationDto>;
    updateStatus(id: string, status: OrganizationStatus): Promise<OrganizationDto>;
    updateSettings(id: string, settings: any): Promise<OrganizationDto>;
    softDelete(id: string): Promise<void>;
    restore(id: string): Promise<OrganizationDto>;
    listAll(params?: {
        search?: string;
        status?: string;
        page?: number;
        limit?: number;
    }): Promise<{
        items: OrganizationDto[];
        total: number;
        page: number;
        totalPages: number;
    }>;
    getQuota(organizationId: string): Promise<OrganizationQuotaDto | null>;
    updateQuota(organizationId: string, quota: Partial<OrganizationQuotaDto>): Promise<OrganizationQuotaDto>;
}
