"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrismaAlertRuleAuditRepository = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma.service");
let PrismaAlertRuleAuditRepository = class PrismaAlertRuleAuditRepository {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async create(data) {
        return this.prisma.alertRuleAuditLog.create({
            data: {
                ruleId: data.ruleId,
                action: data.action,
                field: data.field || null,
                oldValue: data.oldValue || null,
                newValue: data.newValue || null,
                version: data.version,
                performedBy: data.performedBy,
                reason: data.reason || null,
                correlationId: data.correlationId || null,
                ipAddress: data.ipAddress || null,
                browser: data.browser || null,
            },
        });
    }
    async findByRuleId(ruleId, skip = 0, take = 50) {
        const [data, total] = await Promise.all([
            this.prisma.alertRuleAuditLog.findMany({
                where: { ruleId },
                orderBy: { timestamp: "desc" },
                skip,
                take,
            }),
            this.prisma.alertRuleAuditLog.count({ where: { ruleId } }),
        ]);
        return [data, total];
    }
    async findByAction(action, skip = 0, take = 50) {
        const [data, total] = await Promise.all([
            this.prisma.alertRuleAuditLog.findMany({
                where: { action },
                orderBy: { timestamp: "desc" },
                skip,
                take,
            }),
            this.prisma.alertRuleAuditLog.count({ where: { action } }),
        ]);
        return [data, total];
    }
    async findByPerformedBy(performedBy, skip = 0, take = 50) {
        const [data, total] = await Promise.all([
            this.prisma.alertRuleAuditLog.findMany({
                where: { performedBy: { contains: performedBy, mode: "insensitive" } },
                orderBy: { timestamp: "desc" },
                skip,
                take,
            }),
            this.prisma.alertRuleAuditLog.count({
                where: { performedBy: { contains: performedBy, mode: "insensitive" } },
            }),
        ]);
        return [data, total];
    }
};
exports.PrismaAlertRuleAuditRepository = PrismaAlertRuleAuditRepository;
exports.PrismaAlertRuleAuditRepository = PrismaAlertRuleAuditRepository = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], PrismaAlertRuleAuditRepository);
//# sourceMappingURL=prisma-alert-rule-audit.repository.js.map