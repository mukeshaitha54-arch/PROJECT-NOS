"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrismaTeamRepository = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma.service");
const shared_types_1 = require("@nos/shared-types");
let PrismaTeamRepository = class PrismaTeamRepository {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async createDepartment(organizationId, name, description, headUserId) {
        const dept = await this.prisma.department.create({
            data: {
                organizationId,
                name,
                description: description ?? null,
                headUserId: headUserId ?? null,
            },
        });
        return {
            id: dept.id,
            organizationId: dept.organizationId,
            name: dept.name,
            description: dept.description ?? undefined,
            headUserId: dept.headUserId ?? undefined,
            createdAt: dept.createdAt.toISOString(),
            updatedAt: dept.updatedAt.toISOString(),
        };
    }
    async listDepartments(organizationId) {
        const depts = await this.prisma.department.findMany({
            where: { organizationId },
            orderBy: { name: "asc" },
        });
        return depts.map((dept) => ({
            id: dept.id,
            organizationId: dept.organizationId,
            name: dept.name,
            description: dept.description ?? undefined,
            headUserId: dept.headUserId ?? undefined,
            createdAt: dept.createdAt.toISOString(),
            updatedAt: dept.updatedAt.toISOString(),
        }));
    }
    async createTeam(organizationId, name, departmentId, description, leadUserId) {
        const team = await this.prisma.team.create({
            data: {
                organizationId,
                name,
                departmentId: departmentId ?? null,
                description: description ?? null,
                leadUserId: leadUserId ?? null,
            },
        });
        return {
            id: team.id,
            organizationId: team.organizationId,
            departmentId: team.departmentId ?? undefined,
            name: team.name,
            description: team.description ?? undefined,
            leadUserId: team.leadUserId ?? undefined,
            createdAt: team.createdAt.toISOString(),
            updatedAt: team.updatedAt.toISOString(),
        };
    }
    async listTeams(organizationId) {
        const teams = await this.prisma.team.findMany({
            where: { organizationId },
            orderBy: { name: "asc" },
        });
        return teams.map((team) => ({
            id: team.id,
            organizationId: team.organizationId,
            departmentId: team.departmentId ?? undefined,
            name: team.name,
            description: team.description ?? undefined,
            leadUserId: team.leadUserId ?? undefined,
            createdAt: team.createdAt.toISOString(),
            updatedAt: team.updatedAt.toISOString(),
        }));
    }
    async addMember(organizationId, userId, role, teamIds, departmentIds, customRoleId) {
        const member = await this.prisma.organizationMember.upsert({
            where: { organizationId_userId: { organizationId, userId } },
            update: {
                role: role,
                customRoleId: customRoleId ?? null,
                teamIds: teamIds ?? [],
                departmentIds: departmentIds ?? [],
                isSuspended: false,
            },
            create: {
                organizationId,
                userId,
                role: role,
                customRoleId: customRoleId ?? null,
                teamIds: teamIds ?? [],
                departmentIds: departmentIds ?? [],
                isSuspended: false,
            },
        });
        const user = await this.prisma.user.findUnique({ where: { id: userId } });
        return {
            id: member.id,
            organizationId: member.organizationId,
            userId: member.userId,
            role: member.role,
            customRoleId: member.customRoleId ?? undefined,
            teamIds: member.teamIds,
            departmentIds: member.departmentIds,
            joinedAt: member.joinedAt.toISOString(),
            isSuspended: member.isSuspended,
            user: user
                ? {
                    id: user.id,
                    email: user.email,
                    firstName: user.firstName,
                    lastName: user.lastName,
                }
                : undefined,
        };
    }
    async updateMemberRole(organizationId, userId, role, customRoleId) {
        const member = await this.prisma.organizationMember.update({
            where: { organizationId_userId: { organizationId, userId } },
            data: {
                role: role,
                customRoleId: customRoleId ?? null,
            },
        });
        return {
            id: member.id,
            organizationId: member.organizationId,
            userId: member.userId,
            role: member.role,
            customRoleId: member.customRoleId ?? undefined,
            teamIds: member.teamIds,
            departmentIds: member.departmentIds,
            joinedAt: member.joinedAt.toISOString(),
            isSuspended: member.isSuspended,
        };
    }
    async removeMember(organizationId, userId) {
        await this.prisma.organizationMember.deleteMany({
            where: { organizationId, userId },
        });
    }
    async listMembers(organizationId, params) {
        const page = params?.page && params.page > 0 ? params.page : 1;
        const limit = params?.limit && params.limit > 0 ? params.limit : 50;
        const skip = (page - 1) * limit;
        const where = { organizationId };
        if (params?.role) {
            where.role = params.role;
        }
        const [total, rows] = await Promise.all([
            this.prisma.organizationMember.count({ where }),
            this.prisma.organizationMember.findMany({
                where,
                skip,
                take: limit,
                orderBy: { joinedAt: "desc" },
            }),
        ]);
        const userIds = rows.map((r) => r.userId);
        const users = await this.prisma.user.findMany({
            where: { id: { in: userIds } },
        });
        const userMap = new Map(users.map((u) => [u.id, u]));
        const items = rows.map((m) => {
            const u = userMap.get(m.userId);
            return {
                id: m.id,
                organizationId: m.organizationId,
                userId: m.userId,
                role: m.role,
                customRoleId: m.customRoleId ?? undefined,
                teamIds: m.teamIds,
                departmentIds: m.departmentIds,
                joinedAt: m.joinedAt.toISOString(),
                isSuspended: m.isSuspended,
                user: u
                    ? {
                        id: u.id,
                        email: u.email,
                        firstName: u.firstName,
                        lastName: u.lastName,
                    }
                    : undefined,
            };
        });
        return { items, total };
    }
    async findMember(organizationId, userId) {
        const m = await this.prisma.organizationMember.findUnique({
            where: { organizationId_userId: { organizationId, userId } },
        });
        if (!m)
            return null;
        const u = await this.prisma.user.findUnique({ where: { id: m.userId } });
        return {
            id: m.id,
            organizationId: m.organizationId,
            userId: m.userId,
            role: m.role,
            customRoleId: m.customRoleId ?? undefined,
            teamIds: m.teamIds,
            departmentIds: m.departmentIds,
            joinedAt: m.joinedAt.toISOString(),
            isSuspended: m.isSuspended,
            user: u
                ? {
                    id: u.id,
                    email: u.email,
                    firstName: u.firstName,
                    lastName: u.lastName,
                }
                : undefined,
        };
    }
    async createInvitation(organizationId, email, role, invitedByUserId, tokenHash, expiresAt, teamIds, departmentIds) {
        const inv = await this.prisma.organizationInvitation.create({
            data: {
                organizationId,
                email: email.toLowerCase(),
                role: role,
                invitedByUserId,
                tokenHash,
                expiresAt,
                teamIds: teamIds ?? [],
                departmentIds: departmentIds ?? [],
                status: shared_types_1.InvitationStatus.PENDING,
            },
        });
        return {
            id: inv.id,
            organizationId: inv.organizationId,
            email: inv.email,
            role: inv.role,
            teamIds: inv.teamIds,
            departmentIds: inv.departmentIds,
            invitedByUserId: inv.invitedByUserId,
            status: inv.status,
            tokenHash: inv.tokenHash,
            expiresAt: inv.expiresAt.toISOString(),
            createdAt: inv.createdAt.toISOString(),
            acceptedAt: inv.acceptedAt ? inv.acceptedAt.toISOString() : null,
        };
    }
    async listInvitations(organizationId) {
        const invs = await this.prisma.organizationInvitation.findMany({
            where: { organizationId, status: shared_types_1.InvitationStatus.PENDING },
            orderBy: { createdAt: "desc" },
        });
        return invs.map((inv) => ({
            id: inv.id,
            organizationId: inv.organizationId,
            email: inv.email,
            role: inv.role,
            teamIds: inv.teamIds,
            departmentIds: inv.departmentIds,
            invitedByUserId: inv.invitedByUserId,
            status: inv.status,
            tokenHash: inv.tokenHash,
            expiresAt: inv.expiresAt.toISOString(),
            createdAt: inv.createdAt.toISOString(),
            acceptedAt: inv.acceptedAt ? inv.acceptedAt.toISOString() : null,
        }));
    }
    async revokeInvitation(organizationId, id) {
        await this.prisma.organizationInvitation.updateMany({
            where: { id, organizationId },
            data: { status: shared_types_1.InvitationStatus.REVOKED },
        });
    }
};
exports.PrismaTeamRepository = PrismaTeamRepository;
exports.PrismaTeamRepository = PrismaTeamRepository = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], PrismaTeamRepository);
//# sourceMappingURL=prisma-team.repository.js.map