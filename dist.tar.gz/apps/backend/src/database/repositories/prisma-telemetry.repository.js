"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrismaTelemetryRepository = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../prisma.service");
let PrismaTelemetryRepository = class PrismaTelemetryRepository {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async create(data) {
        return this.prisma.telemetrySnapshot.create({
            data: {
                deviceId: data.deviceId,
                cpuUsage: data.cpuUsage,
                cpuTemperature: data.cpuTemperature,
                cpuFrequency: data.cpuFrequency,
                logicalProcessors: data.logicalProcessors,
                physicalProcessors: data.physicalProcessors,
                memoryUsed: data.memoryUsed,
                memoryFree: data.memoryFree,
                memoryTotal: data.memoryTotal,
                memoryUsagePercent: data.memoryUsagePercent,
                diskReadSpeed: data.diskReadSpeed,
                diskWriteSpeed: data.diskWriteSpeed,
                diskUsagePercent: data.diskUsagePercent,
                diskFree: data.diskFree,
                diskTotal: data.diskTotal,
                networkUploadSpeed: data.networkUploadSpeed,
                networkDownloadSpeed: data.networkDownloadSpeed,
                bytesSent: data.bytesSent,
                bytesReceived: data.bytesReceived,
                activeConnections: data.activeConnections,
                runningProcesses: data.runningProcesses,
                runningServices: data.runningServices
                    ? data.runningServices
                    : client_1.Prisma.JsonNull,
                systemUptime: data.systemUptime,
                bootTime: data.bootTime,
                ipAddress: data.ipAddress,
                macAddress: data.macAddress,
                gateway: data.gateway,
                dns: data.dns ? data.dns : client_1.Prisma.JsonNull,
                timestamp: data.timestamp || new Date(),
            },
        });
    }
    async findLatest(deviceId) {
        return this.prisma.telemetrySnapshot.findFirst({
            where: { deviceId },
            orderBy: { timestamp: "desc" },
        });
    }
    async findRange(query) {
        const where = {
            deviceId: query.deviceId,
        };
        if (query.from || query.to) {
            where.timestamp = {};
            if (query.from)
                where.timestamp.gte = query.from;
            if (query.to)
                where.timestamp.lte = query.to;
        }
        const [items, total] = await Promise.all([
            this.prisma.telemetrySnapshot.findMany({
                where,
                orderBy: { timestamp: "desc" },
                skip: query.skip || 0,
                take: query.take || 50,
            }),
            this.prisma.telemetrySnapshot.count({ where }),
        ]);
        return { items, total };
    }
    async exists(id) {
        const count = await this.prisma.telemetrySnapshot.count({ where: { id } });
        return count > 0;
    }
    async deleteOlderThan(cutoffDate) {
        const result = await this.prisma.telemetrySnapshot.deleteMany({
            where: { timestamp: { lt: cutoffDate } },
        });
        return result.count;
    }
    async aggregate(deviceId, from, to) {
        const where = { deviceId };
        if (from || to) {
            where.timestamp = {};
            if (from)
                where.timestamp.gte = from;
            if (to)
                where.timestamp.lte = to;
        }
        const agg = await this.prisma.telemetrySnapshot.aggregate({
            where,
            _avg: {
                cpuUsage: true,
                memoryUsagePercent: true,
                diskUsagePercent: true,
            },
            _count: { id: true },
        });
        return {
            deviceId,
            avgCpuUsage: agg._avg.cpuUsage || 0,
            avgMemoryUsage: agg._avg.memoryUsagePercent || 0,
            avgDiskUsage: agg._avg.diskUsagePercent || 0,
            sampleCount: agg._count.id,
        };
    }
};
exports.PrismaTelemetryRepository = PrismaTelemetryRepository;
exports.PrismaTelemetryRepository = PrismaTelemetryRepository = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], PrismaTelemetryRepository);
//# sourceMappingURL=prisma-telemetry.repository.js.map