"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrismaHeartbeatRepository = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma.service");
let PrismaHeartbeatRepository = class PrismaHeartbeatRepository {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async create(data) {
        return this.prisma.heartbeat.create({
            data: {
                deviceId: data.deviceId,
                cpuUsage: data.cpuUsage,
                ramUsage: data.ramUsage,
                uptime: data.uptime,
                ipAddress: data.ipAddress,
                timestamp: data.timestamp || new Date(),
            },
        });
    }
    async findLatestByDeviceId(deviceId) {
        return this.prisma.heartbeat.findFirst({
            where: { deviceId },
            orderBy: { timestamp: "desc" },
        });
    }
    async findLatestForDevices(deviceIds) {
        if (!deviceIds.length)
            return new Map();
        const heartbeats = await this.prisma.heartbeat.findMany({
            where: { deviceId: { in: deviceIds } },
            orderBy: { timestamp: "desc" },
            distinct: ["deviceId"],
        });
        return new Map(heartbeats.map((h) => [h.deviceId, h]));
    }
    async findRecentByDeviceId(deviceId, limit = 10) {
        return this.prisma.heartbeat.findMany({
            where: { deviceId },
            orderBy: { timestamp: "desc" },
            take: limit,
        });
    }
    async deleteOldHeartbeats(olderThan) {
        const res = await this.prisma.heartbeat.deleteMany({
            where: {
                timestamp: { lt: olderThan },
            },
        });
        return res.count;
    }
};
exports.PrismaHeartbeatRepository = PrismaHeartbeatRepository;
exports.PrismaHeartbeatRepository = PrismaHeartbeatRepository = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], PrismaHeartbeatRepository);
//# sourceMappingURL=prisma-heartbeat.repository.js.map