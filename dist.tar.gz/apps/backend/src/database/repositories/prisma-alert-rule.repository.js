"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrismaAlertRuleRepository = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma.service");
const client_1 = require("@prisma/client");
let PrismaAlertRuleRepository = class PrismaAlertRuleRepository {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async create(data) {
        return this.prisma.alertRule.create({
            data: {
                version: data.version || 1,
                name: data.name,
                description: data.description || null,
                metric: data.metric,
                operator: data.operator,
                threshold: data.threshold,
                durationSeconds: data.durationSeconds ?? 0,
                severity: (data.severity || "MEDIUM"),
                priority: (data.priority || "NORMAL"),
                category: (data.category || "SYSTEM"),
                ruleStatus: (data.ruleStatus || "ACTIVE"),
                enabled: data.enabled ?? true,
                cooldownSeconds: data.cooldownSeconds ?? 300,
                timeoutMs: data.timeoutMs ?? 500,
                scheduleMode: (data.scheduleMode ||
                    "ALWAYS"),
                cronExpression: data.cronExpression || null,
                tags: data.tags || [],
                templateName: data.templateName || null,
                silentMode: data.silentMode ?? false,
                businessHoursOnly: data.businessHoursOnly ?? false,
                dependsOnIds: data.dependsOnIds || [],
                complexityScore: data.complexityScore || "SIMPLE",
                noiseScore: data.noiseScore ?? 0,
                createdBy: data.createdBy || null,
                modifiedBy: data.modifiedBy || null,
                owner: data.owner || null,
                publishedAt: new Date(),
            },
        });
    }
    async findById(id) {
        return this.prisma.alertRule.findUnique({ where: { id } });
    }
    async findByName(name) {
        return this.prisma.alertRule.findFirst({ where: { name } });
    }
    async findMany(enabledOnly = false, metric) {
        const where = {
            ruleStatus: { not: client_1.AlertRuleStatus.ARCHIVED },
        };
        if (enabledOnly)
            where.enabled = true;
        if (metric)
            where.metric = metric;
        return this.prisma.alertRule.findMany({
            where,
            orderBy: [{ priority: "desc" }, { name: "asc" }],
        });
    }
    async findManyPaginated(query) {
        const where = {};
        if (query.enabledOnly)
            where.enabled = true;
        if (query.enabled !== undefined)
            where.enabled = query.enabled;
        if (query.metric)
            where.metric = { contains: query.metric, mode: "insensitive" };
        if (query.severity)
            where.severity = query.severity;
        if (query.category)
            where.category = query.category;
        if (query.ruleStatus)
            where.ruleStatus = query.ruleStatus;
        if (query.priority)
            where.priority = query.priority;
        if (query.owner)
            where.owner = { contains: query.owner, mode: "insensitive" };
        if (query.version !== undefined)
            where.version = query.version;
        if (query.tags && query.tags.length > 0) {
            where.tags = { hasSome: query.tags };
        }
        if (query.name) {
            where.name = { contains: query.name, mode: "insensitive" };
        }
        const [data, total] = await Promise.all([
            this.prisma.alertRule.findMany({
                where,
                skip: query.skip ?? 0,
                take: query.take ?? 50,
                orderBy: [{ priority: "desc" }, { name: "asc" }],
            }),
            this.prisma.alertRule.count({ where }),
        ]);
        return [data, total];
    }
    async update(id, data) {
        const updateData = { ...data };
        delete updateData.id;
        delete updateData.createdAt;
        return this.prisma.alertRule.update({
            where: { id },
            data: updateData,
        });
    }
    async delete(id) {
        try {
            await this.prisma.alertRule.delete({ where: { id } });
            return true;
        }
        catch {
            return false;
        }
    }
    async archive(id, performedBy) {
        return this.prisma.alertRule.update({
            where: { id },
            data: {
                ruleStatus: client_1.AlertRuleStatus.ARCHIVED,
                enabled: false,
                archivedAt: new Date(),
                modifiedBy: performedBy,
            },
        });
    }
    async clone(id, newName, performedBy) {
        const source = await this.prisma.alertRule.findUniqueOrThrow({
            where: { id },
        });
        return this.prisma.alertRule.create({
            data: {
                version: 1,
                name: newName,
                description: source.description
                    ? `Clone of: ${source.description}`
                    : `Cloned from "${source.name}"`,
                metric: source.metric,
                operator: source.operator,
                threshold: source.threshold,
                durationSeconds: source.durationSeconds,
                severity: source.severity,
                priority: source.priority,
                category: source.category,
                ruleStatus: client_1.AlertRuleStatus.ACTIVE,
                enabled: false,
                cooldownSeconds: source.cooldownSeconds,
                timeoutMs: source.timeoutMs,
                scheduleMode: source.scheduleMode,
                cronExpression: source.cronExpression,
                tags: source.tags,
                templateName: source.templateName,
                silentMode: source.silentMode,
                businessHoursOnly: source.businessHoursOnly,
                dependsOnIds: source.dependsOnIds,
                complexityScore: source.complexityScore,
                noiseScore: source.noiseScore,
                createdBy: performedBy,
                modifiedBy: performedBy,
                owner: performedBy,
                publishedAt: new Date(),
            },
        });
    }
    async incrementVersion(id, modifier) {
        return this.prisma.alertRule.update({
            where: { id },
            data: {
                version: { increment: 1 },
                modifiedBy: modifier,
                publishedAt: new Date(),
            },
        });
    }
    async updatePerformanceMetrics(id, metrics) {
        const current = await this.prisma.alertRule.findUnique({
            where: { id },
            select: {
                evaluationCount: true,
                avgExecMs: true,
                maxExecMs: true,
                minExecMs: true,
            },
        });
        if (!current)
            return;
        const evalCount = Number(current.evaluationCount);
        const currentAvg = current.avgExecMs;
        const newAvg = evalCount === 0
            ? metrics.execMs
            : (currentAvg * evalCount + metrics.execMs) / (evalCount + 1);
        await this.prisma.alertRule.update({
            where: { id },
            data: {
                evaluationCount: { increment: 1 },
                triggerCount: metrics.triggered ? { increment: 1 } : undefined,
                suppressionCount: metrics.suppressed ? { increment: 1 } : undefined,
                deduplicationCount: metrics.deduplicated ? { increment: 1 } : undefined,
                escalationCount: metrics.escalated ? { increment: 1 } : undefined,
                avgExecMs: newAvg,
                maxExecMs: metrics.execMs > (current.maxExecMs || 0)
                    ? metrics.execMs
                    : undefined,
                minExecMs: current.minExecMs === 0 || metrics.execMs < current.minExecMs
                    ? metrics.execMs
                    : undefined,
                lastEvaluatedAt: new Date(),
            },
        });
    }
    async findConflicting() {
        const rules = await this.prisma.alertRule.findMany({
            where: { ruleStatus: { not: client_1.AlertRuleStatus.ARCHIVED }, enabled: true },
            select: {
                id: true,
                name: true,
                metric: true,
                operator: true,
                threshold: true,
                severity: true,
            },
        });
        const conflicts = [];
        for (let i = 0; i < rules.length; i++) {
            for (let j = i + 1; j < rules.length; j++) {
                const a = rules[i];
                const b = rules[j];
                if (a.metric === b.metric &&
                    a.operator === b.operator &&
                    a.threshold === b.threshold &&
                    a.severity !== b.severity) {
                    conflicts.push({
                        ruleIds: [a.id, b.id],
                        reason: `Rules "${a.name}" and "${b.name}" have identical conditions (${a.metric} ${a.operator} ${a.threshold}) but different severities`,
                    });
                }
            }
        }
        return conflicts;
    }
    async findDuplicates() {
        const rules = await this.prisma.alertRule.findMany({
            where: { ruleStatus: { not: client_1.AlertRuleStatus.ARCHIVED } },
            select: {
                id: true,
                name: true,
                metric: true,
                operator: true,
                threshold: true,
                durationSeconds: true,
                severity: true,
            },
        });
        const duplicates = [];
        const seen = new Map();
        for (const rule of rules) {
            const key = `${rule.metric}:${rule.operator}:${rule.threshold}:${rule.durationSeconds}:${rule.severity}`;
            if (seen.has(key)) {
                const existingId = seen.get(key);
                const existing = rules.find((r) => r.id === existingId);
                duplicates.push({
                    ruleIds: [existingId, rule.id],
                    reason: `Rule "${rule.name}" is a duplicate of "${existing?.name}" (same metric, operator, threshold, duration, severity)`,
                });
            }
            else {
                seen.set(key, rule.id);
            }
        }
        return duplicates;
    }
    async findByIds(ids) {
        return this.prisma.alertRule.findMany({ where: { id: { in: ids } } });
    }
    async getCategories() {
        const results = await this.prisma.alertRule.findMany({
            select: { category: true },
            distinct: ["category"],
        });
        return results.map((r) => r.category);
    }
    async getTags() {
        const results = await this.prisma.alertRule.findMany({
            select: { tags: true },
        });
        const tagSet = new Set();
        for (const r of results) {
            for (const t of r.tags)
                tagSet.add(t);
        }
        return Array.from(tagSet).sort();
    }
};
exports.PrismaAlertRuleRepository = PrismaAlertRuleRepository;
exports.PrismaAlertRuleRepository = PrismaAlertRuleRepository = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], PrismaAlertRuleRepository);
//# sourceMappingURL=prisma-alert-rule.repository.js.map