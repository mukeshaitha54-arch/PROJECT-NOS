import { PrismaService } from "../prisma.service";
import { IDeviceGovernanceRepository } from "../../common/repositories/tenant.repository.interface";
import { DeviceOwnershipDto, DeviceGroupDto, DeviceTransferRequestDto, PermissionProfileDto, RoleTemplateDto } from "@nos/shared-types";
export declare class PrismaDeviceGovernanceRepository implements IDeviceGovernanceRepository {
    private readonly prisma;
    constructor(prisma: PrismaService);
    assignOwnership(deviceId: string, organizationId: string, data: Partial<DeviceOwnershipDto>): Promise<DeviceOwnershipDto>;
    getOwnership(deviceId: string, organizationId: string): Promise<DeviceOwnershipDto | null>;
    createDeviceGroup(organizationId: string, name: string, groupType: string, description?: string, filterCriteria?: Record<string, unknown>, deviceIds?: string[]): Promise<DeviceGroupDto>;
    listDeviceGroups(organizationId: string): Promise<DeviceGroupDto[]>;
    createTransferRequest(deviceId: string, fromOrgId: string, toOrgId: string, requestedBy: string, reason: string): Promise<DeviceTransferRequestDto>;
    resolveTransferRequest(id: string, status: string, approvedByUserId?: string): Promise<DeviceTransferRequestDto>;
    listTransferRequests(organizationId: string, type: "INCOMING" | "OUTGOING"): Promise<DeviceTransferRequestDto[]>;
    listPermissionProfiles(organizationId: string): Promise<PermissionProfileDto[]>;
    createPermissionProfile(organizationId: string, name: string, permissions: string[], description?: string, abacConditions?: Record<string, unknown>): Promise<PermissionProfileDto>;
    listRoleTemplates(): Promise<RoleTemplateDto[]>;
}
