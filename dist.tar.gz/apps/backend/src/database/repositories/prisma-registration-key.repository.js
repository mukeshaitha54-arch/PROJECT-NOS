"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrismaRegistrationKeyRepository = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma.service");
let PrismaRegistrationKeyRepository = class PrismaRegistrationKeyRepository {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async create(data) {
        return this.prisma.registrationKey.create({
            data,
        });
    }
    async findById(id) {
        return this.prisma.registrationKey.findUnique({
            where: { id },
        });
    }
    async findByHash(keyHash) {
        return this.prisma.registrationKey.findUnique({
            where: { keyHash },
        });
    }
    async findByOrganizationId(organizationId) {
        return this.prisma.registrationKey.findMany({
            where: { organizationId },
            orderBy: { createdAt: "desc" },
        });
    }
    async update(id, data) {
        return this.prisma.registrationKey.update({
            where: { id },
            data,
        });
    }
    async incrementUsage(id, deviceId, ipAddress) {
        await this.prisma.registrationKey.update({
            where: { id },
            data: {
                currentUses: { increment: 1 },
                devicesCreated: { increment: 1 },
                lastUsed: new Date(),
                lastUsedBy: deviceId,
                lastUsedIp: ipAddress,
            },
        });
    }
    async recordFailedAttempt(id) {
        await this.prisma.registrationKey.update({
            where: { id },
            data: {
                failedAttempts: { increment: 1 },
            },
        });
    }
};
exports.PrismaRegistrationKeyRepository = PrismaRegistrationKeyRepository;
exports.PrismaRegistrationKeyRepository = PrismaRegistrationKeyRepository = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], PrismaRegistrationKeyRepository);
//# sourceMappingURL=prisma-registration-key.repository.js.map