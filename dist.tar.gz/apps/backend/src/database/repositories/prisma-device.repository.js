"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrismaDeviceRepository = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../prisma.service");
let PrismaDeviceRepository = class PrismaDeviceRepository {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async findById(id) {
        return this.prisma.device.findUnique({ where: { id } });
    }
    async findByUuid(uuid) {
        return this.prisma.device.findUnique({ where: { uuid } });
    }
    async findByTokenHash(tokenHash) {
        return this.prisma.device.findUnique({ where: { tokenHash } });
    }
    async findAll(organizationId) {
        const where = organizationId && organizationId !== "default-org"
            ? { organizationId }
            : {};
        return this.prisma.device.findMany({
            where,
            orderBy: { lastSeen: "desc" },
        });
    }
    async countByOrganization(organizationId) {
        const where = organizationId && organizationId !== "default-org"
            ? { organizationId }
            : {};
        return this.prisma.device.count({ where });
    }
    async create(data) {
        let resolvedOrgId = undefined;
        if (data.organizationId) {
            const orgExists = await this.prisma.organization.findUnique({
                where: { id: data.organizationId },
            });
            if (orgExists) {
                resolvedOrgId = orgExists.id;
            }
            else {
                const firstOrg = await this.prisma.organization.findFirst();
                if (firstOrg) {
                    resolvedOrgId = firstOrg.id;
                }
                else {
                    try {
                        const defaultOrg = await this.prisma.organization.create({
                            data: {
                                id: data.organizationId === "default-org"
                                    ? "default-org"
                                    : undefined,
                                name: "Personal Workspace",
                                slug: "personal",
                                status: "ACTIVE",
                            },
                        });
                        resolvedOrgId = defaultOrg.id;
                    }
                    catch {
                        const fallback = await this.prisma.organization.findFirst();
                        resolvedOrgId = fallback?.id;
                    }
                }
            }
        }
        return this.prisma.device.create({
            data: {
                uuid: data.uuid,
                hostname: data.hostname,
                deviceName: data.deviceName,
                os: data.os,
                osVersion: data.osVersion,
                architecture: data.architecture,
                agentVersion: data.agentVersion,
                status: data.status || client_1.DeviceStatus.ONLINE,
                organizationId: resolvedOrgId,
                tenantId: resolvedOrgId,
                tokenHash: data.tokenHash,
                lastSeen: data.lastSeen || new Date(),
            },
        });
    }
    async update(id, data) {
        let updateData = { ...data };
        if (updateData.organizationId) {
            const orgExists = await this.prisma.organization.findUnique({
                where: { id: updateData.organizationId },
            });
            if (!orgExists) {
                delete updateData.organizationId;
            }
            else {
                updateData.tenantId = updateData.organizationId;
            }
        }
        return this.prisma.device.update({
            where: { id },
            data: updateData,
        });
    }
    async delete(id) {
        try {
            await this.prisma.device.delete({ where: { id } });
            return true;
        }
        catch {
            return false;
        }
    }
    async countByStatus() {
        const counts = await this.prisma.device.groupBy({
            by: ["status"],
            _count: { status: true },
        });
        const result = {
            [client_1.DeviceStatus.ONLINE]: 0,
            [client_1.DeviceStatus.OFFLINE]: 0,
            [client_1.DeviceStatus.DEGRADED]: 0,
            [client_1.DeviceStatus.CRITICAL]: 0,
            [client_1.DeviceStatus.MAINTENANCE]: 0,
        };
        for (const item of counts) {
            result[item.status] = item._count.status;
        }
        return result;
    }
    async search(query, organizationId) {
        return this.prisma.device.findMany({
            where: {
                organizationId,
                OR: [
                    { hostname: { contains: query, mode: "insensitive" } },
                    { deviceName: { contains: query, mode: "insensitive" } },
                    { uuid: { contains: query, mode: "insensitive" } },
                ],
            },
            take: 20,
        });
    }
};
exports.PrismaDeviceRepository = PrismaDeviceRepository;
exports.PrismaDeviceRepository = PrismaDeviceRepository = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], PrismaDeviceRepository);
//# sourceMappingURL=prisma-device.repository.js.map