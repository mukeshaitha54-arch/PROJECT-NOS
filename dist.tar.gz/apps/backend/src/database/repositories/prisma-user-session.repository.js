"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrismaUserSessionRepository = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma.service");
let PrismaUserSessionRepository = class PrismaUserSessionRepository {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    mapSession(s) {
        return {
            id: s.id,
            userId: s.userId,
            organizationId: s.organizationId,
            tokenHash: s.tokenHash,
            ipAddress: s.ipAddress,
            browser: s.browser,
            os: s.os || "Unknown",
            isActive: s.isActive,
            isRevoked: s.isRevoked,
            lastUsedAt: s.lastUsedAt.toISOString(),
            expiresAt: s.expiresAt.toISOString(),
            createdAt: s.createdAt.toISOString(),
            riskScore: s.riskScore || 0,
        };
    }
    async create(data) {
        const s = await this.prisma.userSession.create({
            data: {
                userId: data.userId,
                organizationId: data.organizationId,
                tokenHash: data.tokenHash,
                ipAddress: data.ipAddress,
                browser: data.browser,
                os: data.os,
                expiresAt: data.expiresAt,
                riskScore: data.riskScore || 0,
                isActive: true,
                isRevoked: false,
            },
        });
        return this.mapSession(s);
    }
    async listActiveSessions(organizationId, userId) {
        const where = {
            organizationId,
            isActive: true,
            isRevoked: false,
        };
        if (userId) {
            where.userId = userId;
        }
        const list = await this.prisma.userSession.findMany({
            where,
            orderBy: { lastUsedAt: "desc" },
        });
        return list.map((s) => this.mapSession(s));
    }
    async revokeSession(id, organizationId) {
        await this.prisma.userSession.updateMany({
            where: { id, organizationId },
            data: { isActive: false, isRevoked: true },
        });
    }
    async revokeAllUserSessions(userId, organizationId) {
        const where = { userId };
        if (organizationId)
            where.organizationId = organizationId;
        await this.prisma.userSession.updateMany({
            where,
            data: { isActive: false, isRevoked: true },
        });
    }
    async recordActivity(data) {
        await this.prisma.userActivity.create({
            data: {
                userId: data.userId,
                organizationId: data.organizationId,
                action: data.action,
                resourceType: data.resourceType || null,
                resourceId: data.resourceId || null,
                ipAddress: data.ipAddress,
                browser: data.browser,
            },
        });
    }
    async listUserActivities(organizationId, userId, limit = 50) {
        const where = { organizationId };
        if (userId)
            where.userId = userId;
        const list = await this.prisma.userActivity.findMany({
            where,
            orderBy: { timestamp: "desc" },
            take: limit,
        });
        return list.map((a) => ({
            id: a.id,
            userId: a.userId,
            organizationId: a.organizationId,
            action: a.action,
            resourceType: a.resourceType || undefined,
            resourceId: a.resourceId || undefined,
            ipAddress: a.ipAddress,
            browser: a.browser,
            timestamp: a.timestamp.toISOString(),
        }));
    }
};
exports.PrismaUserSessionRepository = PrismaUserSessionRepository;
exports.PrismaUserSessionRepository = PrismaUserSessionRepository = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], PrismaUserSessionRepository);
//# sourceMappingURL=prisma-user-session.repository.js.map