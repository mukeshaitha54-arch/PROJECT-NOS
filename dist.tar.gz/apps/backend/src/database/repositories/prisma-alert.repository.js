"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrismaAlertRepository = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma.service");
const client_1 = require("@prisma/client");
let PrismaAlertRepository = class PrismaAlertRepository {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async create(data) {
        return this.prisma.alert.create({
            data: {
                incidentNumber: data.incidentNumber,
                deviceId: data.deviceId,
                ruleId: data.ruleId || null,
                parentAlertId: data.parentAlertId || null,
                title: data.title,
                description: data.description,
                severity: data.severity,
                status: (data.status || "NEW"),
                category: (data.category || "SYSTEM"),
                source: data.source || "RuleEngine",
                fingerprint: data.fingerprint,
                riskScore: data.riskScore ?? 0,
                confidenceScore: data.confidenceScore || "HIGH",
                recoveryTimerSeconds: data.recoveryTimerSeconds || null,
                tags: data.tags || [],
                runbookUrl: data.runbookUrl || null,
                assignedUserId: data.assignedUserId || null,
            },
        });
    }
    async findById(id) {
        return this.prisma.alert.findUnique({
            where: { id },
            include: {
                rule: true,
                device: true,
                comments: { orderBy: { createdAt: "asc" }, include: { user: true } },
                history: { orderBy: { timestamp: "desc" } },
                childAlerts: true,
            },
        });
    }
    async findByFingerprint(fingerprint, openOnly = true) {
        const where = { fingerprint };
        if (openOnly) {
            where.status = {
                in: [client_1.AlertStatus.NEW, client_1.AlertStatus.OPEN, client_1.AlertStatus.ACKNOWLEDGED],
            };
        }
        return this.prisma.alert.findFirst({
            where,
            orderBy: { lastOccurred: "desc" },
        });
    }
    async findMany(query) {
        const where = {};
        if (query.status)
            where.status = query.status;
        if (query.severity)
            where.severity = query.severity;
        if (query.category)
            where.category = query.category;
        if (query.deviceId)
            where.deviceId = query.deviceId;
        if (query.assignedUserId)
            where.assignedUserId = query.assignedUserId;
        if (query.tag)
            where.tags = { has: query.tag };
        if (query.search) {
            where.OR = [
                { incidentNumber: { contains: query.search, mode: "insensitive" } },
                { title: { contains: query.search, mode: "insensitive" } },
                { description: { contains: query.search, mode: "insensitive" } },
            ];
        }
        const orderBy = {};
        const sortField = query.sortBy || "createdAt";
        const sortOrder = query.sortOrder || "desc";
        orderBy[sortField] = sortOrder;
        const [data, total] = await Promise.all([
            this.prisma.alert.findMany({
                where,
                skip: query.skip || 0,
                take: query.take || 20,
                orderBy,
                include: { device: true, assignedUser: true, childAlerts: true },
            }),
            this.prisma.alert.count({ where }),
        ]);
        return [data, total];
    }
    async update(id, data) {
        const updateData = { ...data };
        delete updateData.id;
        delete updateData.incidentNumber;
        delete updateData.createdAt;
        return this.prisma.alert.update({
            where: { id },
            data: updateData,
        });
    }
    async incrementOccurrence(id) {
        return this.prisma.alert.update({
            where: { id },
            data: {
                occurrenceCount: { increment: 1 },
                lastOccurred: new Date(),
            },
        });
    }
    async addHistory(data) {
        return this.prisma.alertHistory.create({
            data: {
                alertId: data.alertId,
                action: data.action,
                performedBy: data.performedBy,
                oldValue: data.oldValue || null,
                newValue: data.newValue || null,
                ipAddress: data.ipAddress || null,
                browser: data.browser || null,
                correlationId: data.correlationId || null,
                comment: data.comment || null,
            },
        });
    }
    async addComment(data) {
        return this.prisma.alertComment.create({
            data: {
                alertId: data.alertId,
                userId: data.userId,
                userName: data.userName,
                comment: data.comment,
                isPrivate: data.isPrivate ?? false,
            },
        });
    }
    async findOpenByDeviceId(deviceId) {
        return this.prisma.alert.findMany({
            where: {
                deviceId,
                status: {
                    in: [client_1.AlertStatus.NEW, client_1.AlertStatus.OPEN, client_1.AlertStatus.ACKNOWLEDGED],
                },
            },
        });
    }
    async findEscalationCandidates(maxOpenMinutes) {
        const cutoff = new Date(Date.now() - maxOpenMinutes * 60 * 1000);
        return this.prisma.alert.findMany({
            where: {
                status: { in: [client_1.AlertStatus.NEW, client_1.AlertStatus.OPEN] },
                firstOccurred: { lte: cutoff },
                severity: { not: client_1.AlertSeverity.CRITICAL },
            },
        });
    }
    async getOverviewStatistics() {
        const now = new Date();
        const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        const [total, open, critical, warning, acked, resolvedToday, sumRepeats] = await Promise.all([
            this.prisma.alert.count(),
            this.prisma.alert.count({
                where: { status: { in: [client_1.AlertStatus.NEW, client_1.AlertStatus.OPEN] } },
            }),
            this.prisma.alert.count({
                where: {
                    status: { in: [client_1.AlertStatus.NEW, client_1.AlertStatus.OPEN] },
                    severity: client_1.AlertSeverity.CRITICAL,
                },
            }),
            this.prisma.alert.count({
                where: {
                    status: { in: [client_1.AlertStatus.NEW, client_1.AlertStatus.OPEN] },
                    severity: client_1.AlertSeverity.MEDIUM,
                },
            }),
            this.prisma.alert.count({
                where: { status: client_1.AlertStatus.ACKNOWLEDGED },
            }),
            this.prisma.alert.count({
                where: {
                    status: client_1.AlertStatus.RESOLVED,
                    resolvedAt: { gte: startOfToday },
                },
            }),
            this.prisma.alert.aggregate({ _sum: { occurrenceCount: true } }),
        ]);
        const totalOccurrences = sumRepeats._sum.occurrenceCount || 0;
        const repeated = Math.max(0, totalOccurrences - total);
        return {
            totalAlerts: total,
            openAlerts: open,
            criticalAlerts: critical,
            warningAlerts: warning,
            acknowledgedAlerts: acked,
            resolvedToday,
            repeatedIncidentCount: repeated,
        };
    }
    async bulkUpdateStatus(alertIds, status, timestamp = new Date()) {
        const data = {
            status: status,
        };
        if (status === "RESOLVED") {
            data.resolvedAt = timestamp;
        }
        else if (status === "ACKNOWLEDGED") {
            data.acknowledgedAt = timestamp;
        }
        const result = await this.prisma.alert.updateMany({
            where: { id: { in: alertIds } },
            data,
        });
        return result.count;
    }
    async delete(id) {
        try {
            await this.prisma.alert.delete({ where: { id } });
            return true;
        }
        catch {
            return false;
        }
    }
    async search(query, organizationId) {
        return this.prisma.alert.findMany({
            where: {
                device: { organizationId },
                OR: [
                    { title: { contains: query, mode: "insensitive" } },
                    { incidentNumber: { contains: query, mode: "insensitive" } },
                ],
            },
            take: 20,
        });
    }
};
exports.PrismaAlertRepository = PrismaAlertRepository;
exports.PrismaAlertRepository = PrismaAlertRepository = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], PrismaAlertRepository);
//# sourceMappingURL=prisma-alert.repository.js.map