import { PrismaService } from "../prisma.service";
import { IAlertRuleAuditRepository, AlertRuleAuditCreateInput } from "../../common/repositories/alert-rule-audit.repository.interface";
import { AlertRuleAuditLog } from "@prisma/client";
export declare class PrismaAlertRuleAuditRepository implements IAlertRuleAuditRepository {
    private readonly prisma;
    constructor(prisma: PrismaService);
    create(data: AlertRuleAuditCreateInput): Promise<AlertRuleAuditLog>;
    findByRuleId(ruleId: string, skip?: number, take?: number): Promise<[AlertRuleAuditLog[], number]>;
    findByAction(action: string, skip?: number, take?: number): Promise<[AlertRuleAuditLog[], number]>;
    findByPerformedBy(performedBy: string, skip?: number, take?: number): Promise<[AlertRuleAuditLog[], number]>;
}
