import { PrismaService } from "../prisma.service";
import { INotificationRepository, NotificationCreateInput } from "../../common/repositories/notification.repository.interface";
import { NotificationLog } from "@prisma/client";
export declare class PrismaNotificationRepository implements INotificationRepository {
    private readonly prisma;
    constructor(prisma: PrismaService);
    create(data: NotificationCreateInput): Promise<NotificationLog>;
    findById(id: string): Promise<NotificationLog | null>;
    findByAlertId(alertId: string): Promise<NotificationLog[]>;
    updateStatus(id: string, status: string, retryCount: number, isDlq?: boolean, response?: string): Promise<NotificationLog>;
    findDlqLogs(skip?: number, take?: number): Promise<[NotificationLog[], number]>;
}
