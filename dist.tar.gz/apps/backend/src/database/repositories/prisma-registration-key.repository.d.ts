import { PrismaService } from "../prisma.service";
import { IRegistrationKeyRepository } from "../../common/repositories/registration-key.repository.interface";
import { RegistrationKey } from "@prisma/client";
export declare class PrismaRegistrationKeyRepository implements IRegistrationKeyRepository {
    private readonly prisma;
    constructor(prisma: PrismaService);
    create(data: Omit<RegistrationKey, "id" | "createdAt">): Promise<RegistrationKey>;
    findById(id: string): Promise<RegistrationKey | null>;
    findByHash(keyHash: string): Promise<RegistrationKey | null>;
    findByOrganizationId(organizationId: string): Promise<RegistrationKey[]>;
    update(id: string, data: Partial<RegistrationKey>): Promise<RegistrationKey>;
    incrementUsage(id: string, deviceId: string, ipAddress?: string): Promise<void>;
    recordFailedAttempt(id: string): Promise<void>;
}
