"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrismaDeviceTimelineRepository = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma.service");
const client_1 = require("@prisma/client");
let PrismaDeviceTimelineRepository = class PrismaDeviceTimelineRepository {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async append(dto) {
        const record = await this.prisma.deviceTimelineEvent.create({
            data: {
                deviceId: dto.deviceId,
                eventType: dto.eventType,
                severity: (dto.severity || "INFO"),
                title: dto.title,
                detail: dto.detail,
                actorId: dto.actorId,
                actorName: dto.actorName,
                relatedId: dto.relatedId,
                relatedType: dto.relatedType,
                metadata: dto.metadata
                    ? dto.metadata
                    : client_1.Prisma.JsonNull,
            },
        });
        return this.mapToDto(record);
    }
    async getPaginated(options) {
        const limit = options.limit || 20;
        const page = options.page || 1;
        const skip = (page - 1) * limit;
        const where = {
            deviceId: options.deviceId,
        };
        if (options.eventTypes && options.eventTypes.length > 0) {
            where.eventType = { in: options.eventTypes };
        }
        if (options.severity) {
            where.severity = options.severity;
        }
        if (options.from || options.to) {
            where.timestamp = {};
            if (options.from)
                where.timestamp.gte = options.from;
            if (options.to)
                where.timestamp.lte = options.to;
        }
        const [items, total] = await Promise.all([
            this.prisma.deviceTimelineEvent.findMany({
                where,
                orderBy: { timestamp: "desc" },
                skip,
                take: limit,
            }),
            this.prisma.deviceTimelineEvent.count({ where }),
        ]);
        const totalPages = Math.ceil(total / limit) || 1;
        return {
            events: items.map((e) => this.mapToDto(e)),
            total,
            page,
            limit,
            totalPages,
        };
    }
    async getRecent(deviceId, limit = 10) {
        const records = await this.prisma.deviceTimelineEvent.findMany({
            where: { deviceId },
            orderBy: { timestamp: "desc" },
            take: limit,
        });
        return records.map((e) => this.mapToDto(e));
    }
    mapToDto(record) {
        return {
            id: record.id,
            deviceId: record.deviceId,
            eventType: record.eventType,
            severity: record.severity,
            title: record.title,
            detail: record.detail || undefined,
            actorId: record.actorId || undefined,
            actorName: record.actorName || undefined,
            relatedId: record.relatedId || undefined,
            relatedType: record.relatedType || undefined,
            metadata: record.metadata || undefined,
            timestamp: record.timestamp
                ? new Date(record.timestamp).toISOString()
                : new Date().toISOString(),
        };
    }
};
exports.PrismaDeviceTimelineRepository = PrismaDeviceTimelineRepository;
exports.PrismaDeviceTimelineRepository = PrismaDeviceTimelineRepository = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], PrismaDeviceTimelineRepository);
//# sourceMappingURL=prisma-device-timeline.repository.js.map