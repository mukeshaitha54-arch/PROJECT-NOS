import { PrismaService } from "../prisma.service";
import { IDeviceTimelineRepository, CreateTimelineEventDto, TimelineEventDto, TimelineQueryOptions, PaginatedTimelineResponse } from "../../common/repositories/device-timeline.repository.interface";
export declare class PrismaDeviceTimelineRepository implements IDeviceTimelineRepository {
    private readonly prisma;
    constructor(prisma: PrismaService);
    append(dto: CreateTimelineEventDto): Promise<TimelineEventDto>;
    getPaginated(options: TimelineQueryOptions): Promise<PaginatedTimelineResponse>;
    getRecent(deviceId: string, limit?: number): Promise<TimelineEventDto[]>;
    private mapToDto;
}
