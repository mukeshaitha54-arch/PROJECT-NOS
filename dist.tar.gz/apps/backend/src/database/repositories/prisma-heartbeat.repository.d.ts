import { Heartbeat } from "@prisma/client";
import { PrismaService } from "../prisma.service";
import { IHeartbeatRepository, CreateHeartbeatInput } from "../../common/repositories/heartbeat.repository.interface";
export declare class PrismaHeartbeatRepository implements IHeartbeatRepository {
    private readonly prisma;
    constructor(prisma: PrismaService);
    create(data: CreateHeartbeatInput): Promise<Heartbeat>;
    findLatestByDeviceId(deviceId: string): Promise<Heartbeat | null>;
    findLatestForDevices(deviceIds: string[]): Promise<Map<string, Heartbeat>>;
    findRecentByDeviceId(deviceId: string, limit?: number): Promise<Heartbeat[]>;
    deleteOldHeartbeats(olderThan: Date): Promise<number>;
}
