import { PrismaService } from "../prisma.service";
import { IUserSessionRepository } from "../../common/repositories/tenant.repository.interface";
import { UserSessionDto, UserActivityDto } from "@nos/shared-types";
export declare class PrismaUserSessionRepository implements IUserSessionRepository {
    private readonly prisma;
    constructor(prisma: PrismaService);
    private mapSession;
    create(data: {
        userId: string;
        organizationId: string;
        tokenHash: string;
        ipAddress: string;
        browser: string;
        os: string;
        expiresAt: Date;
        riskScore?: number;
    }): Promise<UserSessionDto>;
    listActiveSessions(organizationId: string, userId?: string): Promise<UserSessionDto[]>;
    revokeSession(id: string, organizationId: string): Promise<void>;
    revokeAllUserSessions(userId: string, organizationId?: string): Promise<void>;
    recordActivity(data: Omit<UserActivityDto, "id" | "timestamp">): Promise<void>;
    listUserActivities(organizationId: string, userId?: string, limit?: number): Promise<UserActivityDto[]>;
}
