"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var PrismaDashboardRepository_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrismaDashboardRepository = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma.service");
const client_1 = require("@prisma/client");
let PrismaDashboardRepository = PrismaDashboardRepository_1 = class PrismaDashboardRepository {
    prisma;
    logger = new common_1.Logger(PrismaDashboardRepository_1.name);
    constructor(prisma) {
        this.prisma = prisma;
    }
    async getOverviewCounts(organizationId) {
        const [total, statusGroups] = await Promise.all([
            this.prisma.device.count({ where: { organizationId } }),
            this.prisma.device.groupBy({
                by: ["status"],
                where: { organizationId },
                _count: { status: true },
            }),
        ]);
        const counts = {
            total,
            online: 0,
            offline: 0,
            critical: 0,
            warning: 0,
            degraded: 0,
            maintenance: 0,
        };
        for (const group of statusGroups) {
            const cnt = group._count.status;
            switch (group.status) {
                case client_1.DeviceStatus.ONLINE:
                    counts.online = cnt;
                    break;
                case client_1.DeviceStatus.OFFLINE:
                    counts.offline = cnt;
                    break;
                case client_1.DeviceStatus.CRITICAL:
                    counts.critical = cnt;
                    break;
                case client_1.DeviceStatus.DEGRADED:
                    counts.degraded = cnt;
                    counts.warning = cnt;
                    break;
                case client_1.DeviceStatus.MAINTENANCE:
                    counts.maintenance = cnt;
                    break;
            }
        }
        return counts;
    }
    async getDeviceRows(params) {
        const where = {
            organizationId: params.organizationId,
        };
        if (params.search && params.search.trim().length > 0) {
            const term = params.search.trim();
            where.OR = [
                { hostname: { contains: term, mode: "insensitive" } },
                { uuid: { contains: term, mode: "insensitive" } },
                { deviceName: { contains: term, mode: "insensitive" } },
                { os: { contains: term, mode: "insensitive" } },
            ];
        }
        if (params.status &&
            params.status !== "ALL" &&
            params.status.trim() !== "") {
            where.status = params.status.toUpperCase();
        }
        if (params.os && params.os !== "ALL" && params.os.trim() !== "") {
            where.os = { contains: params.os.trim(), mode: "insensitive" };
        }
        const [total, records] = await Promise.all([
            this.prisma.device.count({ where }),
            this.prisma.device.findMany({
                where,
                skip: params.skip,
                take: params.take,
                orderBy: [{ lastSeen: "desc" }, { hostname: "asc" }],
                select: {
                    id: true,
                    uuid: true,
                    hostname: true,
                    status: true,
                    lastSeen: true,
                    os: true,
                    osVersion: true,
                    agentVersion: true,
                    telemetrySnapshots: {
                        orderBy: { timestamp: "desc" },
                        take: 1,
                        select: {
                            cpuUsage: true,
                            memoryUsagePercent: true,
                            diskUsagePercent: true,
                            networkUploadSpeed: true,
                            networkDownloadSpeed: true,
                            ipAddress: true,
                            activeConnections: true,
                        },
                    },
                    heartbeats: {
                        orderBy: { timestamp: "desc" },
                        take: 1,
                        select: {
                            cpuUsage: true,
                            ramUsage: true,
                            ipAddress: true,
                            uptime: true,
                        },
                    },
                },
            }),
        ]);
        const devices = records.map((r) => ({
            id: r.id,
            uuid: r.uuid,
            hostname: r.hostname,
            status: r.status,
            lastSeen: r.lastSeen,
            os: r.os,
            osVersion: r.osVersion,
            agentVersion: r.agentVersion,
            latestSnapshot: r.telemetrySnapshots[0] || null,
            latestHeartbeat: r.heartbeats[0] || null,
        }));
        return { devices, total };
    }
    async getDeviceDetail(organizationId, deviceId) {
        const device = await this.prisma.device.findFirst({
            where: {
                organizationId,
                OR: [{ id: deviceId }, { uuid: deviceId }],
            },
            include: {
                telemetrySnapshots: {
                    orderBy: { timestamp: "desc" },
                    take: 1,
                },
                heartbeats: {
                    orderBy: { timestamp: "desc" },
                    take: 1,
                },
            },
        });
        if (!device)
            return null;
        const currentSnapshot = device.telemetrySnapshots[0] || null;
        const latestHeartbeat = device.heartbeats[0] || null;
        const cleanDevice = { ...device };
        delete cleanDevice.telemetrySnapshots;
        delete cleanDevice.heartbeats;
        return {
            device: cleanDevice,
            currentSnapshot,
            latestHeartbeat,
        };
    }
    async getTelemetryHistory(organizationId, deviceId, params) {
        const where = {
            device: {
                organizationId,
            },
            OR: [{ deviceId: deviceId }, { device: { uuid: deviceId } }],
        };
        if (params.from || params.to) {
            where.timestamp = {};
            if (params.from)
                where.timestamp.gte = params.from;
            if (params.to)
                where.timestamp.lte = params.to;
        }
        const [total, snapshots] = await Promise.all([
            this.prisma.telemetrySnapshot.count({ where }),
            this.prisma.telemetrySnapshot.findMany({
                where,
                skip: params.skip,
                take: params.take,
                orderBy: { timestamp: "desc" },
            }),
        ]);
        return { snapshots, total };
    }
};
exports.PrismaDashboardRepository = PrismaDashboardRepository;
exports.PrismaDashboardRepository = PrismaDashboardRepository = PrismaDashboardRepository_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], PrismaDashboardRepository);
//# sourceMappingURL=prisma-dashboard.repository.js.map