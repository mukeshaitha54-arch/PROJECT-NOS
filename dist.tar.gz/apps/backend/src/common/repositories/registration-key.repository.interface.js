"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IRegistrationKeyRepository = void 0;
exports.IRegistrationKeyRepository = Symbol("IRegistrationKeyRepository");
//# sourceMappingURL=registration-key.repository.interface.js.map