"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IDeviceRepositoryToken = void 0;
exports.IDeviceRepositoryToken = Symbol("IDeviceRepository");
//# sourceMappingURL=device.repository.interface.js.map