"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IDeviceTimelineRepository = void 0;
exports.IDeviceTimelineRepository = Symbol("IDeviceTimelineRepository");
//# sourceMappingURL=device-timeline.repository.interface.js.map