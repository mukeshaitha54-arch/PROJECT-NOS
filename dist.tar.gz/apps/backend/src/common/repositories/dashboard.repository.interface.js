"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IDashboardRepository = void 0;
exports.IDashboardRepository = Symbol("IDashboardRepository");
//# sourceMappingURL=dashboard.repository.interface.js.map