"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ITelemetryRepositoryToken = void 0;
exports.ITelemetryRepositoryToken = Symbol("ITelemetryRepository");
//# sourceMappingURL=telemetry.repository.interface.js.map