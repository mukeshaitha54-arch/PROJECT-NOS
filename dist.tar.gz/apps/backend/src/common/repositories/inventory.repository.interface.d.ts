import { SubmitInventoryPayload, DeviceInventoryDto, HardwareInventoryResponse, SoftwareInventoryResponse, NetworkInventoryResponse, SecurityInventoryResponse, InventoryHealthResponse, InventoryAuditLogDto } from "@nos/shared-types";
export declare const IInventoryRepository: unique symbol;
export type InventoryAuditAction = "Inventory Created" | "Inventory Updated" | "Inventory Refreshed" | "Hardware Added" | "Hardware Removed" | "Software Installed" | "Software Removed" | "BIOS Updated" | "Windows Updated" | "Network Changed";
export interface IInventoryRepository {
    upsertInventory(deviceId: string, payload: SubmitInventoryPayload, assetFingerprint: string): Promise<{
        inventory: DeviceInventoryDto;
        previousInventory: DeviceInventoryDto | null;
    }>;
    findCompleteInventory(deviceId: string): Promise<DeviceInventoryDto | null>;
    findHardwareInventory(deviceId: string): Promise<HardwareInventoryResponse | null>;
    findSoftwareInventory(deviceId: string, search?: string, page?: number, limit?: number): Promise<SoftwareInventoryResponse | null>;
    findNetworkInventory(deviceId: string): Promise<NetworkInventoryResponse | null>;
    findSecurityInventory(deviceId: string): Promise<SecurityInventoryResponse | null>;
    getInventoryHealth(deviceId?: string): Promise<InventoryHealthResponse>;
    createAuditLog(deviceId: string, action: InventoryAuditAction, changeDetails: string): Promise<void>;
    getRecentAuditLogs(deviceId: string, limit?: number): Promise<InventoryAuditLogDto[]>;
    search(query: string, organizationId: string): Promise<any[]>;
}
