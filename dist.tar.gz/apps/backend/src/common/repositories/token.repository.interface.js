"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ITokenRepositoryToken = void 0;
exports.ITokenRepositoryToken = Symbol("ITokenRepository");
//# sourceMappingURL=token.repository.interface.js.map