"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IAlertRuleAuditRepository = void 0;
exports.IAlertRuleAuditRepository = Symbol("IAlertRuleAuditRepository");
//# sourceMappingURL=alert-rule-audit.repository.interface.js.map