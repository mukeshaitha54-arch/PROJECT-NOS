"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IMaintenanceRepository = void 0;
exports.IMaintenanceRepository = Symbol("IMaintenanceRepository");
//# sourceMappingURL=maintenance.repository.interface.js.map