"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IDeviceGovernanceRepositoryToken = exports.IAuditLogRepositoryToken = exports.IUserSessionRepositoryToken = exports.IApiKeyRepositoryToken = exports.ITeamRepositoryToken = exports.IOrganizationRepositoryToken = void 0;
exports.IOrganizationRepositoryToken = Symbol("IOrganizationRepository");
exports.ITeamRepositoryToken = Symbol("ITeamRepository");
exports.IApiKeyRepositoryToken = Symbol("IApiKeyRepository");
exports.IUserSessionRepositoryToken = Symbol("IUserSessionRepository");
exports.IAuditLogRepositoryToken = Symbol("IAuditLogRepository");
exports.IDeviceGovernanceRepositoryToken = Symbol("IDeviceGovernanceRepository");
//# sourceMappingURL=tenant.repository.interface.js.map