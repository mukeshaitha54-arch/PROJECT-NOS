"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IAlertRepository = void 0;
exports.IAlertRepository = Symbol("IAlertRepository");
//# sourceMappingURL=alert.repository.interface.js.map