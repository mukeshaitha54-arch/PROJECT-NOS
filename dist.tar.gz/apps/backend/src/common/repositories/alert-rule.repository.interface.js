"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IAlertRuleRepository = void 0;
exports.IAlertRuleRepository = Symbol("IAlertRuleRepository");
//# sourceMappingURL=alert-rule.repository.interface.js.map