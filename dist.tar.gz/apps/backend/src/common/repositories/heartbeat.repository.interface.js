"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IHeartbeatRepositoryToken = void 0;
exports.IHeartbeatRepositoryToken = Symbol("IHeartbeatRepository");
//# sourceMappingURL=heartbeat.repository.interface.js.map