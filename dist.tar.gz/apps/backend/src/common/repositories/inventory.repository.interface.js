"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IInventoryRepository = void 0;
exports.IInventoryRepository = Symbol("IInventoryRepository");
//# sourceMappingURL=inventory.repository.interface.js.map