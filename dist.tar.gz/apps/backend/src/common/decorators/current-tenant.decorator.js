"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CurrentTenant = void 0;
const common_1 = require("@nestjs/common");
exports.CurrentTenant = (0, common_1.createParamDecorator)((_data, ctx) => {
    const request = ctx.switchToHttp().getRequest();
    if (request?.tenantContext) {
        return request.tenantContext;
    }
    return {
        organizationId: request?.user?.organizationId || "default-org",
        correlationId: "fallback-corr-id",
        requestId: "fallback-req-id",
    };
});
//# sourceMappingURL=current-tenant.decorator.js.map