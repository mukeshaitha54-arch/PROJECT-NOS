import { PermissionFlag } from "@nos/shared-types";
export declare const PERMISSIONS_KEY = "permissions";
export declare const RequirePermissions: (...permissions: PermissionFlag[]) => import("@nestjs/common").CustomDecorator<string>;
