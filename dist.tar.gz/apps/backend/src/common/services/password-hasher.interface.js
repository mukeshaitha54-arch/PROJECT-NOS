"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IPasswordHasherToken = void 0;
exports.IPasswordHasherToken = Symbol("IPasswordHasher");
//# sourceMappingURL=password-hasher.interface.js.map