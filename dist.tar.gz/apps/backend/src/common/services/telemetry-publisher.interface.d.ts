import { TelemetrySnapshot as TelemetrySnapshotDto } from "@nos/shared-types";
export interface ITelemetryPublisher {
    publish(snapshot: TelemetrySnapshotDto): Promise<void>;
}
export declare const ITelemetryPublisherToken: unique symbol;
