"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ITelemetryRetentionPolicyToken = void 0;
exports.ITelemetryRetentionPolicyToken = Symbol("ITelemetryRetentionPolicy");
//# sourceMappingURL=telemetry-retention.interface.js.map