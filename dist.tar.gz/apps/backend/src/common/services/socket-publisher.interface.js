"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ISocketPublisherToken = void 0;
exports.ISocketPublisherToken = Symbol("ISocketPublisher");
//# sourceMappingURL=socket-publisher.interface.js.map