import { Device } from "@prisma/client";
import { IDeviceAuthenticator, DeviceCredentials } from "./device-authenticator.interface";
import { IDeviceRepository } from "../repositories/device.repository.interface";
export declare class TokenDeviceAuthenticatorService implements IDeviceAuthenticator {
    private readonly logger;
    generateCredentials(uuid: string): Promise<DeviceCredentials>;
    authenticate(headers: Record<string, string | string[] | undefined>, repository: IDeviceRepository): Promise<Device | null>;
    private computeHash;
}
