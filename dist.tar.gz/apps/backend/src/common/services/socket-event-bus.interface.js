"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ISocketEventBusToken = void 0;
exports.ISocketEventBusToken = Symbol("ISocketEventBus");
//# sourceMappingURL=socket-event-bus.interface.js.map