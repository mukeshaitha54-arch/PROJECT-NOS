"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ITelemetryPublisherToken = void 0;
exports.ITelemetryPublisherToken = Symbol("ITelemetryPublisher");
//# sourceMappingURL=telemetry-publisher.interface.js.map