import { Device } from "@prisma/client";
import { IDeviceRepository } from "../repositories/device.repository.interface";
export declare const IDeviceAuthenticatorToken: unique symbol;
export interface DeviceCredentials {
    rawToken: string;
    tokenHash: string;
}
export interface IDeviceAuthenticator {
    generateCredentials(uuid: string): Promise<DeviceCredentials>;
    authenticate(headers: Record<string, string | string[] | undefined>, repository: IDeviceRepository): Promise<Device | null>;
}
