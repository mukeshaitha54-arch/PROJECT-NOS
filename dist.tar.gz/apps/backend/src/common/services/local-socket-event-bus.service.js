"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var LocalSocketEventBusService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.LocalSocketEventBusService = void 0;
const common_1 = require("@nestjs/common");
let LocalSocketEventBusService = LocalSocketEventBusService_1 = class LocalSocketEventBusService {
    logger = new common_1.Logger(LocalSocketEventBusService_1.name);
    subscribers = new Set();
    async publish(room, event, envelope) {
        for (const callback of this.subscribers) {
            try {
                callback(room, event, envelope);
            }
            catch (error) {
                this.logger.error(`Error delivering event [${event}] to bus subscriber: ${error.message}`, error.stack);
            }
        }
    }
    subscribe(callback) {
        this.subscribers.add(callback);
    }
    unsubscribe(callback) {
        this.subscribers.delete(callback);
    }
};
exports.LocalSocketEventBusService = LocalSocketEventBusService;
exports.LocalSocketEventBusService = LocalSocketEventBusService = LocalSocketEventBusService_1 = __decorate([
    (0, common_1.Injectable)()
], LocalSocketEventBusService);
//# sourceMappingURL=local-socket-event-bus.service.js.map