"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var TokenDeviceAuthenticatorService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.TokenDeviceAuthenticatorService = void 0;
const common_1 = require("@nestjs/common");
const crypto = require("crypto");
let TokenDeviceAuthenticatorService = TokenDeviceAuthenticatorService_1 = class TokenDeviceAuthenticatorService {
    logger = new common_1.Logger(TokenDeviceAuthenticatorService_1.name);
    async generateCredentials(uuid) {
        const rawToken = `nos_agent_${crypto.randomBytes(24).toString("hex")}`;
        const tokenHash = this.computeHash(rawToken);
        return { rawToken, tokenHash };
    }
    async authenticate(headers, repository) {
        let token;
        const authHeader = headers["authorization"] || headers["Authorization"];
        const deviceTokenHeader = headers["x-device-token"] || headers["X-Device-Token"];
        if (typeof deviceTokenHeader === "string" &&
            deviceTokenHeader.trim().length > 0) {
            token = deviceTokenHeader.trim();
        }
        else if (typeof authHeader === "string" &&
            authHeader.startsWith("Bearer ")) {
            token = authHeader.substring(7).trim();
        }
        if (!token) {
            this.logger.debug("No valid Device Token or Authorization header present on incoming heartbeat request.");
            return null;
        }
        const hash = this.computeHash(token);
        const device = await repository.findByTokenHash(hash);
        if (!device) {
            this.logger.warn(`Unrecognized device token presented during authentication verification.`);
            return null;
        }
        return device;
    }
    computeHash(token) {
        return crypto.createHash("sha256").update(token).digest("hex");
    }
};
exports.TokenDeviceAuthenticatorService = TokenDeviceAuthenticatorService;
exports.TokenDeviceAuthenticatorService = TokenDeviceAuthenticatorService = TokenDeviceAuthenticatorService_1 = __decorate([
    (0, common_1.Injectable)()
], TokenDeviceAuthenticatorService);
//# sourceMappingURL=token-device-authenticator.service.js.map