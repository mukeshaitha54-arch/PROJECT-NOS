import { ISocketEventBus, EventBusCallback } from "./socket-event-bus.interface";
import { SocketEventEnvelope } from "@nos/shared-types";
export declare class LocalSocketEventBusService implements ISocketEventBus {
    private readonly logger;
    private readonly subscribers;
    publish(room: string, event: string, envelope: SocketEventEnvelope): Promise<void>;
    subscribe(callback: EventBusCallback): void;
    unsubscribe(callback: EventBusCallback): void;
}
