import { IPasswordHasher } from "./password-hasher.interface";
export declare class Argon2PasswordHasherService implements IPasswordHasher {
    hash(plainText: string): Promise<string>;
    verify(hash: string, plainText: string): Promise<boolean>;
}
