import { ConfigService } from "@nestjs/config";
import { IMailService } from "./mail-service.interface";
export declare class SmtpMailService implements IMailService {
    private readonly configService;
    private readonly logger;
    private transporter;
    private readonly fromAddress;
    constructor(configService: ConfigService);
    private sendMailWithRetry;
    private logDevMail;
    private getHtmlTemplate;
    sendVerificationOtp(email: string, otp: string): Promise<void>;
    sendPasswordResetOtp(email: string, otp: string): Promise<void>;
    sendInvitationEmail(email: string, orgName: string, inviteUrl: string): Promise<void>;
    sendRegistrationKeyNotification(email: string, keyName: string, orgName: string): Promise<void>;
    sendWelcomeEmail(email: string, name: string): Promise<void>;
}
