import { SocketEventEnvelope } from "@nos/shared-types";
export declare const ISocketEventBusToken: unique symbol;
export type EventBusCallback = (room: string, event: string, envelope: SocketEventEnvelope) => void;
export interface ISocketEventBus {
    publish(room: string, event: string, envelope: SocketEventEnvelope): Promise<void>;
    subscribe(callback: EventBusCallback): void;
    unsubscribe(callback: EventBusCallback): void;
}
