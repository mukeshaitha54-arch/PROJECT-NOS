export interface ITelemetryRetentionPolicy {
    enforcePolicy(retentionDays: number): Promise<{
        deletedCount: number;
    }>;
}
export declare const ITelemetryRetentionPolicyToken: unique symbol;
