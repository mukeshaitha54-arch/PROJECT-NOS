"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IDeviceAuthenticatorToken = void 0;
exports.IDeviceAuthenticatorToken = Symbol("IDeviceAuthenticator");
//# sourceMappingURL=device-authenticator.interface.js.map