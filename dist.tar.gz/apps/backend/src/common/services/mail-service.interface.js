"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IMailServiceToken = void 0;
exports.IMailServiceToken = Symbol("IMailService");
//# sourceMappingURL=mail-service.interface.js.map