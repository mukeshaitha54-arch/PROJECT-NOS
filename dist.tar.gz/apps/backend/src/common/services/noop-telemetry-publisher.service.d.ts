import { TelemetrySnapshot as TelemetrySnapshotDto } from "@nos/shared-types";
import { ITelemetryPublisher } from "./telemetry-publisher.interface";
export declare class NoOpTelemetryPublisherService implements ITelemetryPublisher {
    private readonly logger;
    publish(snapshot: TelemetrySnapshotDto): Promise<void>;
}
