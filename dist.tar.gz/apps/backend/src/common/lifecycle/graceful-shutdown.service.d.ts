import { OnApplicationShutdown } from "@nestjs/common";
import { PrismaService } from "../../database/prisma.service";
import { RealtimeGateway } from "../../modules/realtime/realtime.gateway";
declare global {
    var isShuttingDown: boolean;
}
export declare class GracefulShutdownService implements OnApplicationShutdown {
    private readonly prisma;
    private readonly realtimeGateway?;
    private logger;
    constructor(prisma: PrismaService, realtimeGateway?: RealtimeGateway);
    onApplicationShutdown(signal?: string): Promise<void>;
}
