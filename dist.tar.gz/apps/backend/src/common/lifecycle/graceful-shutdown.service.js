"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var GracefulShutdownService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.GracefulShutdownService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../database/prisma.service");
const logger_service_1 = require("../logger/logger.service");
const realtime_gateway_1 = require("../../modules/realtime/realtime.gateway");
global.isShuttingDown = false;
let GracefulShutdownService = GracefulShutdownService_1 = class GracefulShutdownService {
    prisma;
    realtimeGateway;
    logger = new logger_service_1.LoggerService();
    constructor(prisma, realtimeGateway) {
        this.prisma = prisma;
        this.realtimeGateway = realtimeGateway;
        this.logger.setContext(GracefulShutdownService_1.name);
    }
    async onApplicationShutdown(signal) {
        global.isShuttingDown = true;
        this.logger.log(`SIGTERM/SIGINT received (${signal}). Starting graceful shutdown...`);
        const forceExitTimeout = setTimeout(() => {
            this.logger.error("Graceful shutdown took longer than 15s. Forcing exit.");
            process.exit(1);
        }, 15000);
        forceExitTimeout.unref();
        await new Promise((resolve) => setTimeout(resolve, 10000));
        try {
            if (this.realtimeGateway && this.realtimeGateway.server) {
                this.logger.log("Closing Socket.IO server connections...");
                this.realtimeGateway.server.close();
            }
            this.logger.log("Disconnecting from PostgreSQL database...");
            await this.prisma.$disconnect();
        }
        catch (err) {
            this.logger.error("Error during shutdown cleanup", err instanceof Error ? err.stack : undefined);
        }
        this.logger.log("Graceful shutdown complete. Exiting.");
        clearTimeout(forceExitTimeout);
        process.exit(0);
    }
};
exports.GracefulShutdownService = GracefulShutdownService;
exports.GracefulShutdownService = GracefulShutdownService = GracefulShutdownService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        realtime_gateway_1.RealtimeGateway])
], GracefulShutdownService);
//# sourceMappingURL=graceful-shutdown.service.js.map