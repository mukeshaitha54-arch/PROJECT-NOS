"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LoggerService = void 0;
const common_1 = require("@nestjs/common");
const winston = require("winston");
let LoggerService = class LoggerService {
    logger;
    context;
    constructor() {
        this.logger = winston.createLogger({
            level: process.env.NODE_ENV === "production" ? "info" : "debug",
            format: winston.format.combine(winston.format.timestamp(), winston.format.json()),
            transports: [new winston.transports.Console()],
            defaultMeta: {
                environment: process.env.NODE_ENV || "development",
            },
        });
    }
    setContext(context) {
        this.context = context;
    }
    log(message, ...optionalParams) {
        this.logger.info(message, this.buildMeta(optionalParams));
    }
    error(message, trace, context, ...optionalParams) {
        this.logger.error(message, {
            ...this.buildMeta(optionalParams, context),
            trace,
        });
    }
    warn(message, ...optionalParams) {
        this.logger.warn(message, this.buildMeta(optionalParams));
    }
    debug(message, ...optionalParams) {
        this.logger.debug(message, this.buildMeta(optionalParams));
    }
    verbose(message, ...optionalParams) {
        this.logger.verbose(message, this.buildMeta(optionalParams));
    }
    buildMeta(optionalParams, overrideContext) {
        const meta = {
            context: overrideContext || this.context || "Application",
        };
        if (optionalParams && optionalParams.length > 0) {
            const obj = optionalParams[0];
            if (typeof obj === "object" && obj !== null) {
                if (obj.traceId)
                    meta.traceId = obj.traceId;
                if (obj.tenantId)
                    meta.tenantId = obj.tenantId;
                for (const key of Object.keys(obj)) {
                    if (key !== "traceId" && key !== "tenantId") {
                        meta[key] = obj[key];
                    }
                }
            }
        }
        return meta;
    }
};
exports.LoggerService = LoggerService;
exports.LoggerService = LoggerService = __decorate([
    (0, common_1.Injectable)({ scope: common_1.Scope.TRANSIENT }),
    __metadata("design:paramtypes", [])
], LoggerService);
//# sourceMappingURL=logger.service.js.map