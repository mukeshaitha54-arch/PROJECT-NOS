import { LoggerService as NestLoggerService } from "@nestjs/common";
export declare class LoggerService implements NestLoggerService {
    private logger;
    private context?;
    constructor();
    setContext(context: string): void;
    log(message: any, ...optionalParams: any[]): void;
    error(message: any, trace?: string, context?: string, ...optionalParams: any[]): void;
    warn(message: any, ...optionalParams: any[]): void;
    debug(message: any, ...optionalParams: any[]): void;
    verbose(message: any, ...optionalParams: any[]): void;
    private buildMeta;
}
