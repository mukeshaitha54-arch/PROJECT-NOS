"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DomainEventNames = exports.DeviceTelemetryStatusEvent = exports.InventoryUpdatedEvent = exports.TelemetryReceivedEvent = exports.DeviceBulkStatusEvent = exports.DeviceClaimedEvent = exports.DeviceRetiredEvent = exports.DeviceMaintenanceEvent = exports.DeviceOfflineEvent = exports.HeartbeatReceivedEvent = exports.DeviceReconnectedEvent = exports.DeviceRegisteredEvent = exports.BaseDomainEvent = void 0;
const uuid_1 = require("uuid");
class BaseDomainEvent {
    organizationId;
    deviceId;
    eventId;
    timestamp;
    correlationId;
    constructor(organizationId, deviceId, correlationId) {
        this.organizationId = organizationId;
        this.deviceId = deviceId;
        this.eventId = (0, uuid_1.v4)();
        this.timestamp = new Date().toISOString();
        this.correlationId = correlationId || (0, uuid_1.v4)();
    }
}
exports.BaseDomainEvent = BaseDomainEvent;
class DeviceRegisteredEvent extends BaseDomainEvent {
    hostname;
    os;
    osVersion;
    architecture;
    agentVersion;
    eventType = "device.registered";
    constructor(organizationId, deviceId, hostname, os, osVersion, architecture, agentVersion, correlationId) {
        super(organizationId, deviceId, correlationId);
        this.hostname = hostname;
        this.os = os;
        this.osVersion = osVersion;
        this.architecture = architecture;
        this.agentVersion = agentVersion;
    }
}
exports.DeviceRegisteredEvent = DeviceRegisteredEvent;
class DeviceReconnectedEvent extends BaseDomainEvent {
    hostname;
    eventType = "device.reconnected";
    constructor(organizationId, deviceId, hostname, correlationId) {
        super(organizationId, deviceId, correlationId);
        this.hostname = hostname;
    }
}
exports.DeviceReconnectedEvent = DeviceReconnectedEvent;
class HeartbeatReceivedEvent extends BaseDomainEvent {
    ipAddress;
    cpuUsage;
    ramUsage;
    uptime;
    wasOffline;
    runningProcesses;
    activeConnections;
    diskReadSpeed;
    diskWriteSpeed;
    networkUploadSpeed;
    networkDownloadSpeed;
    processes;
    eventType = "heartbeat.received";
    constructor(organizationId, deviceId, ipAddress, cpuUsage, ramUsage, uptime, wasOffline, correlationId, runningProcesses, activeConnections, diskReadSpeed, diskWriteSpeed, networkUploadSpeed, networkDownloadSpeed, processes) {
        super(organizationId, deviceId, correlationId);
        this.ipAddress = ipAddress;
        this.cpuUsage = cpuUsage;
        this.ramUsage = ramUsage;
        this.uptime = uptime;
        this.wasOffline = wasOffline;
        this.runningProcesses = runningProcesses;
        this.activeConnections = activeConnections;
        this.diskReadSpeed = diskReadSpeed;
        this.diskWriteSpeed = diskWriteSpeed;
        this.networkUploadSpeed = networkUploadSpeed;
        this.networkDownloadSpeed = networkDownloadSpeed;
        this.processes = processes;
    }
}
exports.HeartbeatReceivedEvent = HeartbeatReceivedEvent;
class DeviceOfflineEvent extends BaseDomainEvent {
    reason;
    eventType = "device.offline";
    constructor(organizationId, deviceId, reason, correlationId) {
        super(organizationId, deviceId, correlationId);
        this.reason = reason;
    }
}
exports.DeviceOfflineEvent = DeviceOfflineEvent;
class DeviceMaintenanceEvent extends BaseDomainEvent {
    enabled;
    actorId;
    actorName;
    eventType = "device.maintenance";
    constructor(organizationId, deviceId, enabled, actorId, actorName, correlationId) {
        super(organizationId, deviceId, correlationId);
        this.enabled = enabled;
        this.actorId = actorId;
        this.actorName = actorName;
    }
}
exports.DeviceMaintenanceEvent = DeviceMaintenanceEvent;
class DeviceRetiredEvent extends BaseDomainEvent {
    actorId;
    actorName;
    eventType = "device.retired";
    constructor(organizationId, deviceId, actorId, actorName, correlationId) {
        super(organizationId, deviceId, correlationId);
        this.actorId = actorId;
        this.actorName = actorName;
    }
}
exports.DeviceRetiredEvent = DeviceRetiredEvent;
class DeviceClaimedEvent extends BaseDomainEvent {
    claimedByUserId;
    teamId;
    departmentId;
    eventType = "device.claimed";
    constructor(organizationId, deviceId, claimedByUserId, teamId, departmentId, correlationId) {
        super(organizationId, deviceId, correlationId);
        this.claimedByUserId = claimedByUserId;
        this.teamId = teamId;
        this.departmentId = departmentId;
    }
}
exports.DeviceClaimedEvent = DeviceClaimedEvent;
class DeviceBulkStatusEvent extends BaseDomainEvent {
    newStatus;
    actorId;
    actorName;
    eventType = "device.bulk_status";
    constructor(organizationId, deviceId, newStatus, actorId, actorName, correlationId) {
        super(organizationId, deviceId, correlationId);
        this.newStatus = newStatus;
        this.actorId = actorId;
        this.actorName = actorName;
    }
}
exports.DeviceBulkStatusEvent = DeviceBulkStatusEvent;
class TelemetryReceivedEvent extends BaseDomainEvent {
    snapshot;
    eventType = "telemetry.received";
    constructor(organizationId, deviceId, snapshot, correlationId) {
        super(organizationId, deviceId, correlationId);
        this.snapshot = snapshot;
    }
}
exports.TelemetryReceivedEvent = TelemetryReceivedEvent;
class InventoryUpdatedEvent extends BaseDomainEvent {
    inventoryVersion;
    fingerprint;
    diffDetected;
    changeSummary;
    eventType = "inventory.updated";
    constructor(organizationId, deviceId, inventoryVersion, fingerprint, diffDetected, changeSummary, correlationId) {
        super(organizationId, deviceId, correlationId);
        this.inventoryVersion = inventoryVersion;
        this.fingerprint = fingerprint;
        this.diffDetected = diffDetected;
        this.changeSummary = changeSummary;
    }
}
exports.InventoryUpdatedEvent = InventoryUpdatedEvent;
class DeviceTelemetryStatusEvent extends BaseDomainEvent {
    telemetryPaused;
    eventType = "device.telemetry.status";
    constructor(organizationId, deviceId, telemetryPaused, correlationId) {
        super(organizationId, deviceId, correlationId);
        this.telemetryPaused = telemetryPaused;
    }
}
exports.DeviceTelemetryStatusEvent = DeviceTelemetryStatusEvent;
exports.DomainEventNames = {
    DEVICE_REGISTERED: "device.registered",
    DEVICE_RECONNECTED: "device.reconnected",
    HEARTBEAT_RECEIVED: "heartbeat.received",
    DEVICE_OFFLINE: "device.offline",
    DEVICE_MAINTENANCE: "device.maintenance",
    DEVICE_RETIRED: "device.retired",
    DEVICE_CLAIMED: "device.claimed",
    DEVICE_BULK_STATUS: "device.bulk_status",
    DEVICE_TELEMETRY_STATUS: "device.telemetry.status",
    TELEMETRY_RECEIVED: "telemetry.received",
    INVENTORY_UPDATED: "inventory.updated",
};
//# sourceMappingURL=domain-events.js.map