export declare abstract class BaseDomainEvent {
    readonly organizationId: string;
    readonly deviceId: string;
    readonly eventId: string;
    readonly timestamp: string;
    readonly correlationId: string;
    abstract readonly eventType: string;
    constructor(organizationId: string, deviceId: string, correlationId?: string);
}
export declare class DeviceRegisteredEvent extends BaseDomainEvent {
    readonly hostname: string;
    readonly os: string;
    readonly osVersion: string;
    readonly architecture: string;
    readonly agentVersion: string;
    readonly eventType: "device.registered";
    constructor(organizationId: string, deviceId: string, hostname: string, os: string, osVersion: string, architecture: string, agentVersion: string, correlationId?: string);
}
export declare class DeviceReconnectedEvent extends BaseDomainEvent {
    readonly hostname: string;
    readonly eventType: "device.reconnected";
    constructor(organizationId: string, deviceId: string, hostname: string, correlationId?: string);
}
export declare class HeartbeatReceivedEvent extends BaseDomainEvent {
    readonly ipAddress: string;
    readonly cpuUsage: number;
    readonly ramUsage: number;
    readonly uptime: number;
    readonly wasOffline: boolean;
    readonly runningProcesses?: number;
    readonly activeConnections?: number;
    readonly diskReadSpeed?: number;
    readonly diskWriteSpeed?: number;
    readonly networkUploadSpeed?: number;
    readonly networkDownloadSpeed?: number;
    readonly processes?: any[];
    readonly eventType: "heartbeat.received";
    constructor(organizationId: string, deviceId: string, ipAddress: string, cpuUsage: number, ramUsage: number, uptime: number, wasOffline: boolean, correlationId?: string, runningProcesses?: number, activeConnections?: number, diskReadSpeed?: number, diskWriteSpeed?: number, networkUploadSpeed?: number, networkDownloadSpeed?: number, processes?: any[]);
}
export declare class DeviceOfflineEvent extends BaseDomainEvent {
    readonly reason: string;
    readonly eventType: "device.offline";
    constructor(organizationId: string, deviceId: string, reason: string, correlationId?: string);
}
export declare class DeviceMaintenanceEvent extends BaseDomainEvent {
    readonly enabled: boolean;
    readonly actorId?: string;
    readonly actorName?: string;
    readonly eventType: "device.maintenance";
    constructor(organizationId: string, deviceId: string, enabled: boolean, actorId?: string, actorName?: string, correlationId?: string);
}
export declare class DeviceRetiredEvent extends BaseDomainEvent {
    readonly actorId?: string;
    readonly actorName?: string;
    readonly eventType: "device.retired";
    constructor(organizationId: string, deviceId: string, actorId?: string, actorName?: string, correlationId?: string);
}
export declare class DeviceClaimedEvent extends BaseDomainEvent {
    readonly claimedByUserId: string;
    readonly teamId?: string;
    readonly departmentId?: string;
    readonly eventType: "device.claimed";
    constructor(organizationId: string, deviceId: string, claimedByUserId: string, teamId?: string, departmentId?: string, correlationId?: string);
}
export declare class DeviceBulkStatusEvent extends BaseDomainEvent {
    readonly newStatus: string;
    readonly actorId?: string;
    readonly actorName?: string;
    readonly eventType: "device.bulk_status";
    constructor(organizationId: string, deviceId: string, newStatus: string, actorId?: string, actorName?: string, correlationId?: string);
}
export declare class TelemetryReceivedEvent extends BaseDomainEvent {
    readonly snapshot: Record<string, any>;
    readonly eventType: "telemetry.received";
    constructor(organizationId: string, deviceId: string, snapshot: Record<string, any>, correlationId?: string);
}
export declare class InventoryUpdatedEvent extends BaseDomainEvent {
    readonly inventoryVersion: number;
    readonly fingerprint: string;
    readonly diffDetected: boolean;
    readonly changeSummary: string;
    readonly eventType: "inventory.updated";
    constructor(organizationId: string, deviceId: string, inventoryVersion: number, fingerprint: string, diffDetected: boolean, changeSummary: string, correlationId?: string);
}
export declare class DeviceTelemetryStatusEvent extends BaseDomainEvent {
    readonly telemetryPaused: boolean;
    readonly eventType: "device.telemetry.status";
    constructor(organizationId: string, deviceId: string, telemetryPaused: boolean, correlationId?: string);
}
export type DomainEvent = DeviceRegisteredEvent | DeviceReconnectedEvent | HeartbeatReceivedEvent | DeviceOfflineEvent | DeviceMaintenanceEvent | DeviceRetiredEvent | DeviceClaimedEvent | DeviceBulkStatusEvent | DeviceTelemetryStatusEvent | TelemetryReceivedEvent | InventoryUpdatedEvent;
export declare const DomainEventNames: {
    readonly DEVICE_REGISTERED: "device.registered";
    readonly DEVICE_RECONNECTED: "device.reconnected";
    readonly HEARTBEAT_RECEIVED: "heartbeat.received";
    readonly DEVICE_OFFLINE: "device.offline";
    readonly DEVICE_MAINTENANCE: "device.maintenance";
    readonly DEVICE_RETIRED: "device.retired";
    readonly DEVICE_CLAIMED: "device.claimed";
    readonly DEVICE_BULK_STATUS: "device.bulk_status";
    readonly DEVICE_TELEMETRY_STATUS: "device.telemetry.status";
    readonly TELEMETRY_RECEIVED: "telemetry.received";
    readonly INVENTORY_UPDATED: "inventory.updated";
};
