"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deviceLiveProcessesStore = void 0;
exports.deviceLiveProcessesStore = new Map();
//# sourceMappingURL=device-processes.store.js.map