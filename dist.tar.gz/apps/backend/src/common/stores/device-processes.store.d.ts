export declare const deviceLiveProcessesStore: Map<string, any[]>;
