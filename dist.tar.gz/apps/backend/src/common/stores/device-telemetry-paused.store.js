"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deviceTelemetryPausedStore = void 0;
const fs = require("fs");
const path = require("path");
class PersistentTelemetryPausedStore extends Map {
    filePath;
    constructor() {
        super();
        this.filePath = path.resolve(process.cwd(), "telemetry_paused.json");
        this.load();
    }
    load() {
        try {
            if (fs.existsSync(this.filePath)) {
                const content = fs.readFileSync(this.filePath, "utf-8");
                const data = JSON.parse(content);
                for (const [key, value] of Object.entries(data)) {
                    super.set(key, Boolean(value));
                }
            }
        }
        catch (e) {
        }
    }
    persist() {
        try {
            const obj = {};
            for (const [key, value] of this.entries()) {
                obj[key] = value;
            }
            fs.writeFileSync(this.filePath, JSON.stringify(obj, null, 2), "utf-8");
        }
        catch (e) {
        }
    }
    set(key, value) {
        super.set(key, value);
        this.persist();
        return this;
    }
    delete(key) {
        const result = super.delete(key);
        this.persist();
        return result;
    }
    clear() {
        super.clear();
        this.persist();
    }
}
exports.deviceTelemetryPausedStore = new PersistentTelemetryPausedStore();
//# sourceMappingURL=device-telemetry-paused.store.js.map