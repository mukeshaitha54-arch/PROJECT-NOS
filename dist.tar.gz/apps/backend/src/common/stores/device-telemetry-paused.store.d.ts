declare class PersistentTelemetryPausedStore extends Map<string, boolean> {
    private filePath;
    constructor();
    private load;
    private persist;
    set(key: string, value: boolean): this;
    delete(key: string): boolean;
    clear(): void;
}
export declare const deviceTelemetryPausedStore: PersistentTelemetryPausedStore;
export {};
