import { NestMiddleware } from "@nestjs/common";
export declare class CorrelationIdMiddleware implements NestMiddleware {
    private logger;
    constructor();
    use(req: any, res: any, next: () => void): void;
}
