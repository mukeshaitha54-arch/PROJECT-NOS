"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var CorrelationIdMiddleware_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.CorrelationIdMiddleware = void 0;
const common_1 = require("@nestjs/common");
const crypto = require("crypto");
const logger_service_1 = require("../logger/logger.service");
let CorrelationIdMiddleware = CorrelationIdMiddleware_1 = class CorrelationIdMiddleware {
    logger = new logger_service_1.LoggerService();
    constructor() {
        this.logger.setContext(CorrelationIdMiddleware_1.name);
    }
    use(req, res, next) {
        const headerId = req.headers["x-trace-id"] || req.headers["x-correlation-id"];
        const traceId = Array.isArray(headerId)
            ? headerId[0]
            : headerId || crypto.randomUUID();
        req["traceId"] = traceId;
        if (res.setHeader) {
            res.setHeader("x-trace-id", traceId);
        }
        else if (res.header) {
            res.header("x-trace-id", traceId);
        }
        const method = req.method;
        const path = req.originalUrl || req.url;
        const ip = req.ip || req.socket?.remoteAddress;
        const userAgent = req.headers["user-agent"] || "";
        this.logger.log(`Incoming Request: ${method} ${path}`, {
            traceId,
            method,
            path,
            ip,
            userAgent,
        });
        next();
    }
};
exports.CorrelationIdMiddleware = CorrelationIdMiddleware;
exports.CorrelationIdMiddleware = CorrelationIdMiddleware = CorrelationIdMiddleware_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [])
], CorrelationIdMiddleware);
//# sourceMappingURL=correlation-id.middleware.js.map