"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var GlobalExceptionFilter_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.GlobalExceptionFilter = void 0;
const common_1 = require("@nestjs/common");
let GlobalExceptionFilter = GlobalExceptionFilter_1 = class GlobalExceptionFilter {
    logger = new common_1.Logger(GlobalExceptionFilter_1.name);
    catch(exception, host) {
        const ctx = host.switchToHttp();
        const response = ctx.getResponse();
        const request = ctx.getRequest();
        const status = exception instanceof common_1.HttpException
            ? exception.getStatus()
            : common_1.HttpStatus.INTERNAL_SERVER_ERROR;
        const errorResponse = exception instanceof common_1.HttpException
            ? exception.getResponse()
            : { message: "Internal server error occurred" };
        const message = typeof errorResponse === "string"
            ? errorResponse
            : errorResponse?.message ||
                exception?.message ||
                "Unknown exception encountered";
        const details = typeof errorResponse === "object" && errorResponse !== null
            ? errorResponse
            : undefined;
        const requestId = (request.headers["x-request-id"] ||
            request.headers["x-correlation-id"] ||
            "untracked");
        const errorPayload = {
            code: status,
            message: Array.isArray(message) ? message.join(", ") : message,
            details,
            path: request.url,
        };
        const apiResponse = {
            success: false,
            error: errorPayload,
            timestamp: new Date().toISOString(),
            requestId,
        };
        if (status >= 500) {
            this.logger.error(`[Request ID: ${requestId}] Unhandled Server Exception at ${request.method} ${request.url}`, exception?.stack || exception);
        }
        else {
            this.logger.warn(`[Request ID: ${requestId}] Client HTTP Exception (${status}) at ${request.method} ${request.url}: ${apiResponse.error?.message}`);
        }
        response.status(status).send(apiResponse);
    }
};
exports.GlobalExceptionFilter = GlobalExceptionFilter;
exports.GlobalExceptionFilter = GlobalExceptionFilter = GlobalExceptionFilter_1 = __decorate([
    (0, common_1.Catch)()
], GlobalExceptionFilter);
//# sourceMappingURL=global-exception.filter.js.map