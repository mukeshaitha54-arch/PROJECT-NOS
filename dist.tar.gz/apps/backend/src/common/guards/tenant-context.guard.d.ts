import { CanActivate, ExecutionContext } from "@nestjs/common";
import { ITeamRepository, IApiKeyRepository } from "../repositories/tenant.repository.interface";
export declare class TenantContextGuard implements CanActivate {
    private readonly teamRepository;
    private readonly apiKeyRepository;
    constructor(teamRepository: ITeamRepository, apiKeyRepository: IApiKeyRepository);
    canActivate(context: ExecutionContext): Promise<boolean>;
}
