"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TenantContextGuard = void 0;
const common_1 = require("@nestjs/common");
const shared_types_1 = require("@nos/shared-types");
const crypto = require("crypto");
const tenant_repository_interface_1 = require("../repositories/tenant.repository.interface");
let TenantContextGuard = class TenantContextGuard {
    teamRepository;
    apiKeyRepository;
    constructor(teamRepository, apiKeyRepository) {
        this.teamRepository = teamRepository;
        this.apiKeyRepository = apiKeyRepository;
    }
    async canActivate(context) {
        const request = context.switchToHttp().getRequest();
        if (!request)
            return true;
        const orgId = request.headers?.["x-organization-id"] ||
            request.headers?.["x-tenant-id"] ||
            request.query?.organizationId ||
            request.body?.organizationId ||
            "default-org";
        const correlationId = request.headers?.["x-correlation-id"] || crypto.randomUUID();
        const requestId = request.headers?.["x-request-id"] || crypto.randomUUID();
        const ipAddress = request.ip ||
            request.headers?.["x-forwarded-for"] ||
            request.socket?.remoteAddress ||
            "127.0.0.1";
        const browser = request.headers?.["user-agent"] || "NOS-API-Client/6.0";
        const tenantContext = {
            organizationId: orgId,
            correlationId,
            requestId,
            ipAddress,
            browser,
        };
        if (request.user) {
            tenantContext.userId = request.user.id;
            if (request.user.role !== shared_types_1.UserRole.SUPER_ADMIN &&
                orgId !== "default-org") {
                const member = await this.teamRepository.findMember(orgId, request.user.id);
                if (!member || member.isSuspended) {
                    throw new common_1.ForbiddenException({
                        code: shared_types_1.ErrorCode.INSUFFICIENT_PERMISSIONS,
                        message: `User is not an active member of organization [${orgId}].`,
                    });
                }
                tenantContext.role = member.role;
            }
        }
        request.tenantContext = tenantContext;
        request.headers["x-correlation-id"] = correlationId;
        return true;
    }
};
exports.TenantContextGuard = TenantContextGuard;
exports.TenantContextGuard = TenantContextGuard = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(tenant_repository_interface_1.ITeamRepositoryToken)),
    __param(1, (0, common_1.Inject)(tenant_repository_interface_1.IApiKeyRepositoryToken)),
    __metadata("design:paramtypes", [Object, Object])
], TenantContextGuard);
//# sourceMappingURL=tenant-context.guard.js.map