"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RbacPermissionGuard = void 0;
const common_1 = require("@nestjs/common");
const core_1 = require("@nestjs/core");
const shared_types_1 = require("@nos/shared-types");
const require_permissions_decorator_1 = require("../decorators/require-permissions.decorator");
const rbac_evaluation_service_1 = require("../../modules/tenant/services/rbac-evaluation.service");
const tenant_repository_interface_1 = require("../repositories/tenant.repository.interface");
let RbacPermissionGuard = class RbacPermissionGuard {
    reflector;
    rbacService;
    teamRepository;
    constructor(reflector, rbacService, teamRepository) {
        this.reflector = reflector;
        this.rbacService = rbacService;
        this.teamRepository = teamRepository;
    }
    async canActivate(context) {
        const requiredPermissions = this.reflector.getAllAndOverride(require_permissions_decorator_1.PERMISSIONS_KEY, [context.getHandler(), context.getClass()]);
        if (!requiredPermissions || requiredPermissions.length === 0) {
            return true;
        }
        const request = context.switchToHttp().getRequest();
        const user = request?.user;
        if (!user) {
            throw new common_1.ForbiddenException({
                code: shared_types_1.ErrorCode.UNAUTHORIZED,
                message: "Authentication required for permission evaluation.",
            });
        }
        if (user.role === shared_types_1.UserRole.SUPER_ADMIN) {
            return true;
        }
        const tenantContext = request.tenantContext;
        const orgId = tenantContext?.organizationId || "default-org";
        let roleToEvaluate = user.role;
        let customRoleId = undefined;
        if (orgId !== "default-org") {
            const member = await this.teamRepository.findMember(orgId, user.id);
            if (member) {
                roleToEvaluate = member.role;
                customRoleId = member.customRoleId;
            }
        }
        if (roleToEvaluate === shared_types_1.UserRole.OWNER) {
            return true;
        }
        for (const flag of requiredPermissions) {
            const hasPerm = await this.rbacService.hasPermission(orgId, roleToEvaluate, flag, customRoleId);
            if (!hasPerm) {
                throw new common_1.ForbiddenException({
                    code: shared_types_1.ErrorCode.INSUFFICIENT_PERMISSIONS,
                    message: `Missing required enterprise permission: [${flag}].`,
                });
            }
        }
        return true;
    }
};
exports.RbacPermissionGuard = RbacPermissionGuard;
exports.RbacPermissionGuard = RbacPermissionGuard = __decorate([
    (0, common_1.Injectable)(),
    __param(2, (0, common_1.Inject)(tenant_repository_interface_1.ITeamRepositoryToken)),
    __metadata("design:paramtypes", [core_1.Reflector,
        rbac_evaluation_service_1.RbacEvaluationService, Object])
], RbacPermissionGuard);
//# sourceMappingURL=rbac-permission.guard.js.map