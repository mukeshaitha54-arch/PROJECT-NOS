import { CanActivate, ExecutionContext } from "@nestjs/common";
import { Reflector } from "@nestjs/core";
import { RbacEvaluationService } from "../../modules/tenant/services/rbac-evaluation.service";
import { ITeamRepository } from "../repositories/tenant.repository.interface";
export declare class RbacPermissionGuard implements CanActivate {
    private readonly reflector;
    private readonly rbacService;
    private readonly teamRepository;
    constructor(reflector: Reflector, rbacService: RbacEvaluationService, teamRepository: ITeamRepository);
    canActivate(context: ExecutionContext): Promise<boolean>;
}
