export interface ApiResponse<T = any> {
    success: boolean;
    data?: T;
    error?: ApiErrorPayload;
    meta?: PaginationMeta;
    timestamp: string;
    requestId?: string;
}
export interface ApiErrorPayload {
    code: string | number;
    message: string;
    details?: string[] | Record<string, any>;
    path?: string;
}
export interface PaginationMeta {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
}
export declare enum ErrorCode {
    UNAUTHORIZED = "UNAUTHORIZED",
    TOKEN_EXPIRED = "TOKEN_EXPIRED",
    TOKEN_REVOKED = "TOKEN_REVOKED",
    INVALID_CREDENTIALS = "INVALID_CREDENTIALS",
    USER_NOT_FOUND = "USER_NOT_FOUND",
    USER_ALREADY_EXISTS = "USER_ALREADY_EXISTS",
    EMAIL_NOT_VERIFIED = "EMAIL_NOT_VERIFIED",
    INVALID_OTP = "INVALID_OTP",
    OTP_EXPIRED = "OTP_EXPIRED",
    INSUFFICIENT_PERMISSIONS = "INSUFFICIENT_PERMISSIONS",
    VALIDATION_ERROR = "VALIDATION_ERROR",
    INTERNAL_SERVER_ERROR = "INTERNAL_SERVER_ERROR"
}
export declare enum UserRole {
    OWNER = "OWNER",
    SUPER_ADMIN = "SUPER_ADMIN",
    ADMIN = "ADMIN",
    MANAGER = "MANAGER",
    OPERATOR = "OPERATOR",
    ANALYST = "ANALYST",
    VIEWER = "VIEWER",
    AUDITOR = "AUDITOR",
    CUSTOM_ROLE = "CUSTOM_ROLE",
    USER = "USER"
}
export interface User {
    id: string;
    email: string;
    firstName: string;
    lastName: string;
    role: UserRole;
    isEmailVerified: boolean;
    createdAt: string;
    updatedAt: string;
    organizationId?: string;
}
export interface RegisterPayload {
    email: string;
    password: string;
    firstName: string;
    lastName: string;
}
export interface LoginPayload {
    email: string;
    password: string;
}
export interface VerifyEmailPayload {
    email: string;
    otp: string;
}
export interface ForgotPasswordPayload {
    email: string;
}
export interface ResetPasswordPayload {
    email: string;
    otp: string;
    newPassword: string;
}
export interface ChangePasswordPayload {
    currentPassword: string;
    newPassword: string;
}
export interface TokenResponsePayload {
    accessToken: string;
    refreshToken: string;
    user: User;
}
export interface RefreshTokenPayload {
    refreshToken: string;
}
export declare enum SystemStatus {
    HEALTHY = "HEALTHY",
    DEGRADED = "DEGRADED",
    CRITICAL = "CRITICAL",
    OFFLINE = "OFFLINE",
    MAINTENANCE = "MAINTENANCE"
}
export interface NodeIdentifier {
    id: string;
    hostname: string;
    ipAddress: string;
    status: SystemStatus;
    lastSeenAt?: string;
    createdAt: string;
    updatedAt: string;
}
export declare enum DeviceStatus {
    ONLINE = "ONLINE",
    OFFLINE = "OFFLINE",
    DEGRADED = "DEGRADED",
    CRITICAL = "CRITICAL",
    MAINTENANCE = "MAINTENANCE"
}
export interface Device {
    id: string;
    uuid: string;
    hostname: string;
    deviceName: string;
    os: string;
    osVersion: string;
    architecture: string;
    agentVersion: string;
    status: DeviceStatus;
    telemetryPaused?: boolean;
    lastSeen: string | null;
    registeredAt: string;
    organizationId?: string | null;
    claimStatus?: "UNASSIGNED" | "ASSIGNED";
    createdAt: string;
    updatedAt: string;
}
export interface Heartbeat {
    id: string;
    deviceId: string;
    cpuUsage: number;
    ramUsage: number;
    uptime: number;
    ipAddress: string;
    timestamp: string;
    agentVersion?: string | null;
    lastTelemetryId?: string | null;
}
export interface RegisterDevicePayload {
    uuid: string;
    hostname: string;
    deviceName: string;
    os: string;
    osVersion: string;
    architecture: string;
    agentVersion: string;
    registrationKey?: string;
    organizationId?: string;
}
export interface RegisterDeviceResponse {
    deviceId: string;
    registrationToken: string;
    device: Device;
}
export interface HeartbeatPayload {
    deviceId?: string;
    cpuUsage: number;
    ramUsage: number;
    uptime: number;
    ipAddress: string;
    timestamp: string;
    hostname?: string;
    os?: string;
    agentVersion?: string;
    lastTelemetryId?: string;
}
export interface HeartbeatResponse {
    success: boolean;
    status: DeviceStatus;
    lastSeen: string;
    heartbeatId: string;
    telemetryPaused?: boolean;
}
export interface DeviceStatusResponse {
    devices: (Device & {
        lastHeartbeat?: Heartbeat | null;
    })[];
    summary: DeviceSummaryStats;
    timestamp: string;
}
export interface DeviceSummaryStats {
    totalRegistered: number;
    totalOnline: number;
    totalOffline: number;
    totalDegraded: number;
}
export interface TelemetrySnapshot {
    id: string;
    deviceId: string;
    cpuUsage: number;
    cpuTemperature: number;
    cpuFrequency: number;
    logicalProcessors: number;
    physicalProcessors: number;
    memoryUsed: number;
    memoryFree: number;
    memoryTotal: number;
    memoryUsagePercent: number;
    diskReadSpeed: number;
    diskWriteSpeed: number;
    diskUsagePercent: number;
    diskFree: number;
    diskTotal: number;
    networkUploadSpeed: number;
    networkDownloadSpeed: number;
    bytesSent: number;
    bytesReceived: number;
    activeConnections: number;
    runningProcesses: number;
    systemUptime: number;
    bootTime: string;
    ipAddress: string;
    macAddress: string;
    timestamp: string;
    runningServices: number;
    gateway: string;
    dns: string;
}
export interface SubmitTelemetryPayload {
    deviceId?: string;
    cpuUsage: number;
    cpuTemperature: number;
    cpuFrequency: number;
    logicalProcessors: number;
    physicalProcessors: number;
    memoryUsed: number;
    memoryFree: number;
    memoryTotal: number;
    memoryUsagePercent: number;
    diskReadSpeed: number;
    diskWriteSpeed: number;
    diskUsagePercent: number;
    diskFree: number;
    diskTotal: number;
    networkUploadSpeed: number;
    networkDownloadSpeed: number;
    bytesSent: number;
    bytesReceived: number;
    activeConnections: number;
    runningProcesses: number;
    systemUptime: number;
    bootTime: string;
    ipAddress: string;
    macAddress: string;
    timestamp?: string;
    runningServices?: number;
    gateway?: string;
    dns?: string;
}
export interface SubmitTelemetryResponse {
    success: boolean;
    snapshotId: string;
    timestamp: string;
    message: string;
}
export interface TelemetryHistoryQuery {
    from?: string;
    to?: string;
    limit?: number;
    page?: number;
}
export interface PaginatedTelemetryResponse {
    snapshots: TelemetrySnapshot[];
    total: number;
    page: number;
    limit: number;
    totalPages: number;
}
export interface ReservedHardwareMetrics {
    gpuUsage?: number;
    gpuTemperature?: number;
    gpuMemoryUsed?: number;
    gpuMemoryTotal?: number;
    batteryPercentage?: number;
    batteryChargingStatus?: "CHARGING" | "DISCHARGING" | "FULL" | "NOT_PRESENT";
    virtualizationActive?: boolean;
    hypervisorPresent?: boolean;
    hypervisorVendor?: string;
    secureBootEnabled?: boolean;
    tpmPresent?: boolean;
    chassisIntrusionSensorTriggered?: boolean;
}
export interface DashboardOverviewResponse {
    totalDevices: number;
    online: number;
    offline: number;
    critical: number;
    warning: number;
    degraded: number;
    maintenance: number;
    lastUpdated: string;
}
export interface DashboardDeviceRow {
    id: string;
    uuid: string;
    hostname: string;
    status: DeviceStatus;
    cpu: number;
    ram: number;
    disk: number;
    network: {
        uploadSpeed: number;
        downloadSpeed: number;
        ipAddress: string;
        activeConnections: number;
    };
    lastSeen: string | null;
    os: string;
    osVersion: string;
    agentVersion: string;
}
export interface DashboardDevicesQuery {
    page?: number;
    limit?: number;
    search?: string;
    status?: string;
    os?: string;
}
export interface PaginatedDashboardDevicesResponse {
    devices: DashboardDeviceRow[];
    total: number;
    page: number;
    limit: number;
    totalPages: number;
}
export interface DashboardDeviceDetailResponse {
    device: Device;
    currentSnapshot: TelemetrySnapshot | null;
    latestHeartbeat: Heartbeat | null;
    currentCpu: number;
    currentRam: number;
    currentDisk: number;
    currentNetwork: {
        uploadSpeed: number;
        downloadSpeed: number;
        bytesSent: number;
        bytesReceived: number;
        activeConnections: number;
        ipAddress: string;
        macAddress: string;
    };
    deviceStatus: DeviceStatus;
    uptime: number;
    systemStatus: string;
    lastUpdated: string;
}
export interface DashboardHistoryQuery {
    from?: string;
    to?: string;
    page?: number;
    limit?: number;
}
export interface MemoryModuleDto {
    id?: string;
    slot?: string;
    capacityBytes?: number;
    speedMHz?: number;
    manufacturer?: string;
    partNumber?: string;
    serialNumber?: string;
}
export interface DiskDriveDto {
    id?: string;
    driveName?: string;
    model?: string;
    serialNumber?: string;
    mediaType?: string;
    sizeBytes?: number;
    fileSystem?: string;
    isSystemDrive?: boolean;
}
export interface GpuDto {
    id?: string;
    name?: string;
    manufacturer?: string;
    driverVersion?: string;
    vRamBytes?: number;
    resolution?: string;
}
export interface NetworkAdapterDto {
    id?: string;
    name?: string;
    description?: string;
    macAddress?: string;
    ipv4?: string;
    ipv6?: string;
    gateway?: string;
    dns?: string;
    speedMbps?: number;
    isWireless?: boolean;
    isPhysical?: boolean;
    isOperational?: boolean;
}
export interface InstalledSoftwareDto {
    id?: string;
    name?: string;
    publisher?: string;
    version?: string;
    installDate?: string;
    installLocation?: string;
}
export interface WindowsServiceDto {
    id?: string;
    serviceName?: string;
    displayName?: string;
    status?: string;
    startType?: string;
    account?: string;
}
export interface StartupApplicationDto {
    id?: string;
    name?: string;
    command?: string;
    location?: string;
    user?: string;
}
export interface SecurityInventoryDto {
    id?: string;
    windowsDefenderEnabled?: boolean;
    firewallEnabled?: boolean;
    bitLockerEnabled?: boolean;
    bitLockerDrive?: string;
    secureBootEnabled?: boolean;
    tpmEnabled?: boolean;
    tpmVersion?: string;
}
export interface DeviceCapabilitiesDto {
    id?: string;
    supportsGPU?: boolean;
    supportsBattery?: boolean;
    supportsTPM?: boolean;
    supportsVirtualization?: boolean;
    supportsDocker?: boolean;
    supportsWSL?: boolean;
    supportsWiFi?: boolean;
    supportsEthernet?: boolean;
    virtualMachineDetection?: boolean;
    vmVendor?: string;
}
export interface DeviceInventoryDto {
    id: string;
    deviceId: string;
    manufacturer: string;
    model: string;
    serialNumber: string;
    motherboard: string;
    biosVendor: string;
    biosVersion: string;
    biosReleaseDate?: string;
    cpuModel: string;
    cpuVendor: string;
    physicalCores: number;
    logicalCores: number;
    hostname: string;
    domain: string;
    workgroup: string;
    osEdition: string;
    osBuild: string;
    architecture: string;
    assetFingerprint: string;
    inventoryVersion: number;
    schemaVersion: string;
    lastScanAt: string;
    createdAt: string;
    updatedAt: string;
    memoryModules?: MemoryModuleDto[];
    diskDrives?: DiskDriveDto[];
    gpus?: GpuDto[];
    networkAdapters?: NetworkAdapterDto[];
    installedSoftware?: InstalledSoftwareDto[];
    windowsServices?: WindowsServiceDto[];
    startupApplications?: StartupApplicationDto[];
    security?: SecurityInventoryDto | null;
    capabilities?: DeviceCapabilitiesDto | null;
}
export interface InventoryAuditLogDto {
    id: string;
    deviceId: string;
    action: "Inventory Created" | "Inventory Updated" | "Inventory Refreshed";
    changeDetails: string;
    timestamp: string;
}
export interface SubmitInventoryPayload {
    deviceId?: string;
    manufacturer?: string;
    model?: string;
    serialNumber?: string;
    motherboard?: string;
    biosVendor?: string;
    biosVersion?: string;
    biosReleaseDate?: string;
    cpuModel?: string;
    cpuVendor?: string;
    physicalCores?: number;
    logicalCores?: number;
    hostname?: string;
    domain?: string;
    workgroup?: string;
    osEdition?: string;
    osBuild?: string;
    architecture?: string;
    agentVersion?: string;
    schemaVersion?: string;
    memoryModules?: MemoryModuleDto[];
    diskDrives?: DiskDriveDto[];
    gpus?: GpuDto[];
    networkAdapters?: NetworkAdapterDto[];
    installedSoftware?: InstalledSoftwareDto[];
    windowsServices?: WindowsServiceDto[];
    startupApplications?: StartupApplicationDto[];
    security?: SecurityInventoryDto;
    capabilities?: DeviceCapabilitiesDto;
}
export interface InventoryHealthResponse {
    deviceId?: string;
    inventoryVersion: number;
    inventorySchemaVersion: string;
    agentVersion: string;
    lastScan: string;
    inventoryAgeSeconds: number;
    status: "HEALTHY" | "STALE" | "NOT_INITIALIZED";
}
export interface CompleteInventoryResponse {
    inventory: DeviceInventoryDto;
    recentAuditLogs?: InventoryAuditLogDto[];
}
export interface HardwareInventoryResponse {
    deviceId: string;
    manufacturer: string;
    model: string;
    serialNumber: string;
    motherboard: string;
    biosVendor: string;
    biosVersion: string;
    cpuModel: string;
    cpuVendor: string;
    physicalCores: number;
    logicalCores: number;
    assetFingerprint: string;
    memoryModules: MemoryModuleDto[];
    diskDrives: DiskDriveDto[];
    gpus: GpuDto[];
}
export interface SoftwareInventoryResponse {
    deviceId: string;
    installedSoftware: InstalledSoftwareDto[];
    windowsServices: WindowsServiceDto[];
    startupApplications: StartupApplicationDto[];
    totalSoftware: number;
    totalServices: number;
    totalStartup: number;
}
export interface NetworkInventoryResponse {
    deviceId: string;
    networkAdapters: NetworkAdapterDto[];
    totalAdapters: number;
}
export interface SecurityInventoryResponse {
    deviceId: string;
    security: SecurityInventoryDto | null;
    capabilities: DeviceCapabilitiesDto | null;
}
export declare enum SocketEvents {
    DEVICE_CONNECTED = "device.connected",
    DEVICE_DISCONNECTED = "device.disconnected",
    DEVICE_ONLINE = "device.online",
    DEVICE_OFFLINE = "device.offline",
    HEARTBEAT_RECEIVED = "heartbeat.received",
    TELEMETRY_RECEIVED = "telemetry.received",
    INVENTORY_UPDATED = "inventory.updated",
    DASHBOARD_UPDATED = "dashboard.updated",
    SYSTEM_STATUS_CHANGED = "system.status.changed",
    TELEMETRY_STATUS = "device.telemetry.status",
    ALERT_CREATED = "alert.created",
    ALERT_UPDATED = "alert.updated",
    ALERT_ACKNOWLEDGED = "alert.acknowledged",
    ALERT_RESOLVED = "alert.resolved",
    ALERT_CLOSED = "alert.closed",
    ALERT_SUPPRESSED = "alert.suppressed",
    ALERT_ESCALATED = "alert.escalated",
    NOTIFICATION_SENT = "notification.sent"
}
export declare enum SocketRooms {
    DASHBOARD = "dashboard",
    ADMINS = "admins",
    OPERATORS = "operators"
}
export declare const DEVICE_ROOM_PREFIX = "device:";
export declare const getDeviceRoom: (deviceId: string) => string;
export interface SocketEventEnvelope<T = any> {
    eventId?: string;
    eventType?: string;
    version: number;
    event: string;
    timestamp: string;
    organizationId?: string;
    deviceId?: string;
    correlationId?: string;
    payload: T;
}
export interface SocketHealthResponse {
    connectedClients: number;
    rooms: number;
    namespaces: number;
    reconnectCount: number;
    disconnectCount: number;
    averageSessionTime: number;
    droppedEvents: number;
    memoryUsage: number;
    latency: number;
    gatewayUptime: number;
    authenticationFailures: number;
}
export interface SocketPresenceDto {
    socketId: string;
    userId?: string;
    deviceId?: string;
    role?: string;
    ipAddress?: string;
    onlineSince: string;
    lastActivity: string;
}
export interface SocketConnectionMetrics {
    connectedClients: number;
    reconnectCount: number;
    disconnectCount: number;
    averageSessionTimeMs: number;
    totalAuthFailures: number;
    droppedEvents: number;
}
export interface RealtimeDashboardEvent {
    overview: DashboardOverviewResponse;
    reason?: string;
    timestamp?: string;
}
export interface RealtimeTelemetryEvent {
    deviceId: string;
    snapshot: TelemetrySnapshot;
    alertState?: "NORMAL" | "WARNING" | "CRITICAL";
}
export interface RealtimeInventoryEvent {
    deviceId: string;
    inventoryVersion: number;
    timestamp: string;
    mutationDetected: boolean;
}
export interface RealtimeHeartbeatEvent {
    deviceId: string;
    cpuUsage: number;
    ramUsage: number;
    uptime: number;
    ipAddress: string;
    timestamp: string;
    status: "ONLINE" | "OFFLINE" | "DEGRADED";
}
export declare enum AlertSeverity {
    INFO = "INFO",
    LOW = "LOW",
    MEDIUM = "MEDIUM",
    HIGH = "HIGH",
    CRITICAL = "CRITICAL"
}
export declare enum AlertStatus {
    NEW = "NEW",
    OPEN = "OPEN",
    ACKNOWLEDGED = "ACKNOWLEDGED",
    RESOLVED = "RESOLVED",
    CLOSED = "CLOSED",
    SUPPRESSED = "SUPPRESSED",
    EXPIRED = "EXPIRED",
    SNOOZED = "SNOOZED"
}
export declare enum AlertCategory {
    CPU = "CPU",
    RAM = "RAM",
    DISK = "DISK",
    TEMPERATURE = "TEMPERATURE",
    NETWORK = "NETWORK",
    HEARTBEAT = "HEARTBEAT",
    INVENTORY = "INVENTORY",
    SECURITY = "SECURITY",
    WINDOWS_SERVICE = "WINDOWS_SERVICE",
    STARTUP_APP = "STARTUP_APP",
    SYSTEM = "SYSTEM",
    CORRELATION = "CORRELATION"
}
export declare enum NotificationProvider {
    EMAIL = "EMAIL",
    SLACK = "SLACK",
    DISCORD = "DISCORD",
    TEAMS = "TEAMS",
    SMS = "SMS",
    PUSH = "PUSH",
    WEBHOOK = "WEBHOOK"
}
export declare enum AlertOperatorRole {
    OPERATOR = "OPERATOR",
    SENIOR = "SENIOR",
    MANAGER = "MANAGER",
    DIRECTOR = "DIRECTOR",
    ON_CALL = "ON_CALL"
}
export declare enum AlertConfidence {
    LOW = "LOW",
    MEDIUM = "MEDIUM",
    HIGH = "HIGH"
}
export declare enum AlertRuleOperator {
    GREATER_THAN = ">",
    GREATER_THAN_OR_EQUAL = ">=",
    LESS_THAN = "<",
    LESS_THAN_OR_EQUAL = "<=",
    EQUAL = "==",
    NOT_EQUAL = "!=",
    CONTAINS = "CONTAINS",
    NOT_CONTAINS = "NOT_CONTAINS",
    MUTATED = "MUTATED"
}
export interface AlertDto {
    id: string;
    incidentNumber: string;
    deviceId: string;
    ruleId?: string | null;
    parentAlertId?: string | null;
    title: string;
    description: string;
    severity: AlertSeverity;
    status: AlertStatus;
    category: AlertCategory;
    source: string;
    occurrenceCount: number;
    fingerprint: string;
    riskScore: number;
    confidenceScore: AlertConfidence;
    recoveryTimerSeconds?: number | null;
    tags?: string[];
    runbookUrl?: string | null;
    firstOccurred: string;
    lastOccurred: string;
    acknowledgedAt?: string | null;
    resolvedAt?: string | null;
    suppressedUntil?: string | null;
    snoozedUntil?: string | null;
    assignedUserId?: string | null;
    assignedUserName?: string | null;
    createdAt: string;
    updatedAt: string;
    deviceName?: string;
    hostname?: string;
    ipAddress?: string;
    childAlertCount?: number;
    childAlerts?: AlertDto[];
}
export interface AlertRuleDto {
    id: string;
    version: number;
    name: string;
    metric: string;
    operator: string;
    threshold: number;
    durationSeconds: number;
    severity: AlertSeverity;
    enabled: boolean;
    cooldownSeconds: number;
    tags?: string[];
    templateName?: string | null;
    silentMode?: boolean;
    businessHoursOnly?: boolean;
    createdBy?: string | null;
    modifiedBy?: string | null;
    publishedAt?: string | null;
    createdAt: string;
    updatedAt: string;
}
export interface AlertHistoryDto {
    id: string;
    alertId: string;
    action: string;
    performedBy: string;
    oldValue?: string | null;
    newValue?: string | null;
    ipAddress?: string | null;
    browser?: string | null;
    correlationId?: string | null;
    comment?: string | null;
    timestamp: string;
}
export interface AlertCommentDto {
    id: string;
    alertId: string;
    userId: string;
    userName: string;
    comment: string;
    isPrivate: boolean;
    createdAt: string;
    updatedAt: string;
}
export interface NotificationLogDto {
    id: string;
    alertId: string;
    provider: NotificationProvider;
    recipient: string;
    status: "SUCCESS" | "FAILED" | "QUEUED" | "RETRYING" | "DLQ";
    response?: string | null;
    retryCount: number;
    isDlq: boolean;
    sentAt: string;
}
export interface MaintenanceWindowDto {
    id: string;
    deviceId?: string | null;
    deviceGroupId?: string | null;
    title: string;
    startTime: string;
    endTime: string;
    reason: string;
    type: "SCHEDULED" | "EMERGENCY" | "RECURRING";
    enabled: boolean;
    createdAt?: string;
    updatedAt?: string;
}
export interface AlertOverviewDto {
    totalAlerts: number;
    openAlerts: number;
    criticalAlerts: number;
    warningAlerts: number;
    acknowledgedAlerts: number;
    resolvedToday: number;
    fleetAlertScore: number;
    alertHeatLevel: "HOT" | "WARM" | "COLD";
    repeatedIncidentCount: number;
    lastUpdated: string;
}
export interface AlertAgingBuckets {
    bucket0to5m: number;
    bucket5to15m: number;
    bucket15to60m: number;
    bucket1to4h: number;
    bucket4to24h: number;
    bucket24hPlus: number;
}
export interface AlertStatisticsDto {
    bySeverity: Record<string, number>;
    byCategory: Record<string, number>;
    byStatus: Record<string, number>;
    agingBuckets: AlertAgingBuckets;
    topRules: {
        ruleId: string;
        ruleName: string;
        count: number;
    }[];
    topDevices: {
        deviceId: string;
        hostname: string;
        count: number;
    }[];
    averageResponseMinutes: number;
    averageResolveMinutes: number;
    slaViolations: number;
}
export interface AlertTimelineDto {
    items: AlertHistoryDto[];
    total: number;
}
export interface AlertHealthResponse {
    status: "HEALTHY" | "DEGRADED" | "CRITICAL";
    redisConnected: boolean;
    bullmqWorkersActive: boolean;
    activeQueuedCount: number;
    dlqCount: number;
    lastProcessedAt?: string | null;
    uptime: number;
}
export interface RuleSimulationReportDto {
    ruleId?: string;
    metric: string;
    operator: string;
    threshold: number;
    timeframeHours: number;
    wouldTriggerCount: number;
    suppressedCount: number;
    realAlertsCount: number;
    affectedDevices: string[];
    estimatedCooldownSaves: number;
}
export interface BulkAlertOperationRequest {
    alertIds: string[];
    action: "ACKNOWLEDGE" | "RESOLVE" | "SUPPRESS" | "DELETE" | "ASSIGN" | "TAG" | "SNOOZE";
    payload?: {
        userId?: string;
        tag?: string;
        snoozeMinutes?: number;
        reason?: string;
    };
}
export interface RealtimeAlertEvent {
    alert: AlertDto;
    eventType: "CREATED" | "UPDATED" | "ACKNOWLEDGED" | "RESOLVED" | "SUPPRESSED" | "ESCALATED";
    timestamp: string;
}
export declare enum AlertRulePriority {
    LOW = "LOW",
    NORMAL = "NORMAL",
    HIGH = "HIGH",
    CRITICAL = "CRITICAL"
}
export declare enum AlertRuleCategory {
    PERFORMANCE = "PERFORMANCE",
    SECURITY = "SECURITY",
    AVAILABILITY = "AVAILABILITY",
    INVENTORY = "INVENTORY",
    COMPLIANCE = "COMPLIANCE",
    MAINTENANCE = "MAINTENANCE",
    SYSTEM = "SYSTEM",
    NETWORK = "NETWORK"
}
export declare enum AlertRuleScheduleMode {
    ALWAYS = "ALWAYS",
    BUSINESS_HOURS = "BUSINESS_HOURS",
    NIGHT = "NIGHT",
    WEEKEND = "WEEKEND",
    CRON = "CRON"
}
export declare enum AlertRuleStatus {
    ACTIVE = "ACTIVE",
    DISABLED = "DISABLED",
    ARCHIVED = "ARCHIVED"
}
export declare enum RuleComplexityScore {
    SIMPLE = "SIMPLE",
    MEDIUM = "MEDIUM",
    COMPLEX = "COMPLEX",
    VERY_COMPLEX = "VERY_COMPLEX"
}
export declare enum RuleRecommendationType {
    MERGE = "MERGE",
    REMOVE_DUPLICATE = "REMOVE_DUPLICATE",
    NEVER_TRIGGERED = "NEVER_TRIGGERED",
    EXPENSIVE = "EXPENSIVE",
    HIGH_NOISE = "HIGH_NOISE",
    OVERLAPPING = "OVERLAPPING"
}
export interface AlertRuleEnhancedDto {
    id: string;
    version: number;
    name: string;
    description?: string | null;
    metric: string;
    operator: string;
    threshold: number;
    durationSeconds: number;
    severity: AlertSeverity;
    priority: AlertRulePriority;
    category: AlertRuleCategory;
    ruleStatus: AlertRuleStatus;
    enabled: boolean;
    cooldownSeconds: number;
    timeoutMs: number;
    scheduleMode: AlertRuleScheduleMode;
    cronExpression?: string | null;
    tags?: string[];
    templateName?: string | null;
    silentMode?: boolean;
    businessHoursOnly?: boolean;
    dependsOnIds?: string[];
    evaluationCount: number;
    triggerCount: number;
    suppressionCount: number;
    deduplicationCount: number;
    escalationCount: number;
    avgExecMs: number;
    maxExecMs: number;
    minExecMs: number;
    lastEvaluatedAt?: string | null;
    complexityScore: RuleComplexityScore;
    noiseScore: number;
    createdBy?: string | null;
    modifiedBy?: string | null;
    owner?: string | null;
    publishedAt?: string | null;
    archivedAt?: string | null;
    createdAt: string;
    updatedAt: string;
}
export type RuleTestTimeframe = "LAST_HOUR" | "LAST_6H" | "LAST_24H" | "LAST_7D" | "CUSTOM";
export interface RuleTestRequestDto {
    ruleId: string;
    timeframe: RuleTestTimeframe;
    from?: string;
    to?: string;
}
export interface RuleTestResultDto {
    ruleId: string;
    ruleName: string;
    timeframe: RuleTestTimeframe;
    fromDate: string;
    toDate: string;
    wouldTrigger: number;
    suppressed: number;
    correlated: number;
    deduplicated: number;
    escalated: number;
    estimatedNotifications: number;
    estimatedEmails: number;
    estimatedSocketEvents: number;
    estimatedQueueJobs: number;
    affectedDevices: string[];
    estimatedCooldownSaves: number;
    noiseReduction: number;
    simulationDurationMs: number;
}
export interface RuleValidationError {
    code: string;
    field?: string;
    message: string;
    conflictingRuleId?: string;
    conflictingRuleName?: string;
}
export interface RuleValidationResultDto {
    valid: boolean;
    errors: RuleValidationError[];
    warnings: RuleValidationError[];
    duplicateOf?: string | null;
    conflictsWith?: string[] | null;
    circularDependencies?: string[][];
    invalidMetrics?: string[];
    impossibleConditions?: string[];
}
export interface RulePreviewDto {
    estimatedDevices: number;
    estimatedAlertVolume: number;
    estimatedSuppression: number;
    estimatedCorrelation: number;
    estimatedCooldownSaves: number;
    estimatedImpact: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
    riskRating: number;
    complexityScore: RuleComplexityScore;
    noiseScore: number;
    affectedTags: string[];
    estimatedDailyAlerts: number;
    estimatedWeeklyAlerts: number;
}
export interface DryRunLogEntry {
    deviceId: string;
    metric: string;
    value: number;
    wouldTrigger: boolean;
    reason: string;
    timestamp: string;
}
export interface DryRunResultDto {
    ruleId?: string;
    ruleName?: string;
    stored: false;
    notified: false;
    wouldTriggerCount: number;
    suppressedCount: number;
    deduplications: number;
    logs: DryRunLogEntry[];
    executionTimeMs: number;
    evaluatedDevices: number;
    samplesProcessed: number;
}
export interface RuleFieldDiff {
    field: string;
    oldValue: string | number | boolean | null;
    newValue: string | number | boolean | null;
    changed: boolean;
}
export interface RuleDiffDto {
    ruleId: string;
    ruleName: string;
    fromVersion: number;
    toVersion: number;
    fromTimestamp: string;
    toTimestamp: string;
    diffs: RuleFieldDiff[];
    changedBy: string;
    changeReason?: string | null;
    totalChanges: number;
}
export interface RollbackPreviewDto {
    ruleId: string;
    ruleName: string;
    currentVersion: number;
    targetVersion: number;
    currentState: AlertRuleEnhancedDto;
    targetState: AlertRuleEnhancedDto;
    differences: RuleFieldDiff[];
    warnings: string[];
    estimatedImpact: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
    isRollbackSafe: boolean;
}
export interface ReplayRequestDto {
    ruleId: string;
    from: string;
    to: string;
    deviceIds?: string[];
}
export interface ReplayResultDto {
    ruleId: string;
    ruleName: string;
    from: string;
    to: string;
    stored: false;
    devicesReplayed: number;
    samplesReplayed: number;
    wouldTriggerCount: number;
    suppressedCount: number;
    correlatedCount: number;
    deduplicatedCount: number;
    estimatedAlertVolume: number;
    executionTimeMs: number;
    timeline: ReplayTimelineEntry[];
}
export interface ReplayTimelineEntry {
    timestamp: string;
    deviceId: string;
    metric: string;
    value: number;
    wouldTrigger: boolean;
    suppressReason?: string;
}
export interface RuleHealthQueueInfo {
    name: string;
    waiting: number;
    active: number;
    completed: number;
    failed: number;
    delayed: number;
}
export interface RuleHealthDto {
    activeRules: number;
    disabledRules: number;
    archivedRules: number;
    conflictingRules: number;
    duplicateRules: number;
    avgEvaluationMs: number;
    slowRules: Array<{
        id: string;
        name: string;
        avgExecMs: number;
    }>;
    fastRules: Array<{
        id: string;
        name: string;
        avgExecMs: number;
    }>;
    queues: RuleHealthQueueInfo[];
    redis: {
        connected: boolean;
        memoryUsageBytes: number;
        latencyMs: number;
        connectedClients: number;
        uptime: number;
    };
    overallStatus: "HEALTHY" | "DEGRADED" | "CRITICAL";
    lastCheckedAt: string;
}
export interface RulePerformanceMetricsDto {
    ruleId: string;
    ruleName: string;
    avgExecutionMs: number;
    maxExecutionMs: number;
    minExecutionMs: number;
    evaluationCount: number;
    triggerCount: number;
    suppressionCount: number;
    correlationCount: number;
    deduplicationCount: number;
    escalationCount: number;
    memoryUsageBytes: number;
    triggerRate: number;
    suppressionRate: number;
    lastEvaluatedAt?: string | null;
    p95ExecutionMs: number;
    p99ExecutionMs: number;
}
export interface RuleComplexityBreakdownDto {
    ruleId: string;
    ruleName: string;
    score: RuleComplexityScore;
    scoreValue: number;
    factors: {
        conditionComplexity: number;
        operatorWeight: number;
        hasDependencies: boolean;
        dependencyDepth: number;
        hasCorrelation: boolean;
        hasCooldown: boolean;
        hasDuration: boolean;
        scheduleModeComplexity: number;
    };
}
export interface RuleRecommendationDto {
    type: RuleRecommendationType;
    ruleId: string;
    ruleName: string;
    message: string;
    severity: "INFO" | "WARNING" | "CRITICAL";
    actionable: boolean;
    suggestedAction?: string;
    relatedRuleIds?: string[];
}
export interface RuleNoiseScoreDto {
    ruleId: string;
    ruleName: string;
    noiseScore: number;
    rating: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
    breakdown: {
        deduplicationFactor: number;
        suppressionFactor: number;
        cooldownFactor: number;
        correlationFactor: number;
        falsePositiveFactor: number;
        maintenanceFactor: number;
    };
    recommendation: string;
}
export interface RuleUsageStatisticsDto {
    ruleId: string;
    ruleName: string;
    totalEvaluations: number;
    totalTriggers: number;
    totalSuppressions: number;
    totalDeduplications: number;
    totalEscalations: number;
    dailyTriggerAverage: number;
    weeklyTriggerAverage: number;
    lastTriggeredAt?: string | null;
    lastEvaluatedAt?: string | null;
    neverTriggered: boolean;
    triggerTrend: "INCREASING" | "STABLE" | "DECREASING";
}
export interface RuleAuditEntryDto {
    id: string;
    ruleId: string;
    action: string;
    field?: string | null;
    oldValue?: string | null;
    newValue?: string | null;
    version: number;
    performedBy: string;
    reason?: string | null;
    correlationId?: string | null;
    ipAddress?: string | null;
    browser?: string | null;
    timestamp: string;
}
export interface RuleDependencyNode {
    ruleId: string;
    ruleName: string;
    priority: AlertRulePriority;
    category: AlertRuleCategory;
    dependsOn: string[];
    dependents: string[];
    depth: number;
    hasCircularDep: boolean;
}
export interface RuleDependencyGraphDto {
    nodes: RuleDependencyNode[];
    edges: Array<{
        from: string;
        to: string;
    }>;
    circularPaths: string[][];
    maxDepth: number;
    totalNodes: number;
    totalEdges: number;
}
export interface RuleExportDto {
    exportedAt: string;
    exportedBy: string;
    version: string;
    totalRules: number;
    rules: AlertRuleEnhancedDto[];
}
export interface RuleImportResultDto {
    imported: number;
    skipped: number;
    failed: number;
    errors: Array<{
        ruleName: string;
        reason: string;
    }>;
    warnings: Array<{
        ruleName: string;
        message: string;
    }>;
}
export interface RuleSearchQueryDto {
    name?: string;
    metric?: string;
    severity?: AlertSeverity;
    category?: AlertRuleCategory;
    tags?: string[];
    enabled?: boolean;
    owner?: string;
    version?: number;
    ruleStatus?: AlertRuleStatus;
    priority?: AlertRulePriority;
    skip?: number;
    take?: number;
}
export interface QueueDashboardDto {
    alertQueue: RuleHealthQueueInfo;
    notificationQueue: RuleHealthQueueInfo;
    retryQueue: RuleHealthQueueInfo;
    deadLetterQueue: RuleHealthQueueInfo;
    redis: {
        connected: boolean;
        memoryUsageBytes: number;
        latencyMs: number;
        connectedClients: number;
        uptimeSeconds: number;
        version: string;
    };
    totalWaiting: number;
    totalActive: number;
    totalFailed: number;
    healthStatus: "HEALTHY" | "DEGRADED" | "CRITICAL";
    lastUpdatedAt: string;
}
export interface TenantContext {
    organizationId: string;
    correlationId: string;
    requestId: string;
    userId?: string;
    role?: string;
    ipAddress?: string;
    browser?: string;
}
export interface TenantAwarePayload<T = any> {
    context: TenantContext;
    data: T;
}
export declare enum OrganizationStatus {
    ACTIVE = "ACTIVE",
    SUSPENDED = "SUSPENDED",
    ARCHIVED = "ARCHIVED",
    DELETED = "DELETED"
}
export interface OrganizationSettingsDto {
    timezone: string;
    language: string;
    retentionDays: number;
    notificationDefaults: {
        emailEnabled: boolean;
        webhookEnabled: boolean;
        silentHoursStart?: string;
        silentHoursEnd?: string;
    };
    maintenanceDefaults: {
        defaultDurationMinutes: number;
        requireApproval: boolean;
        autoNotify: boolean;
    };
    securityPolicies: {
        enforceMfa: boolean;
        sessionTimeoutMinutes: number;
        maxFailedLoginAttempts: number;
        allowedIpRanges?: string[];
    };
    passwordPolicies: {
        minLength: number;
        requireUppercase: boolean;
        requireNumbers: boolean;
        requireSymbols: boolean;
        expiryDays: number;
    };
}
export interface OrganizationQuotaDto {
    maxDevices: number;
    maxUsers: number;
    maxApiKeys: number;
    maxStorageMb: number;
    maxDailyTelemetry: number;
    maxDailyAlerts: number;
}
export interface OrganizationQuotaUsageDto extends OrganizationQuotaDto {
    currentDevices: number;
    currentUsers: number;
    currentApiKeys: number;
    currentStorageMb: number;
    currentDailyTelemetry: number;
    currentDailyAlerts: number;
    isApproachingLimit: boolean;
    isLimitExceeded: boolean;
    percentUsed: number;
}
export interface OrganizationDto {
    id: string;
    name: string;
    slug: string;
    status: OrganizationStatus;
    createdAt: string;
    updatedAt: string;
    deletedAt?: string | null;
    settings: OrganizationSettingsDto;
    quota: OrganizationQuotaDto;
    quotaUsage?: OrganizationQuotaUsageDto;
}
export interface DepartmentDto {
    id: string;
    organizationId: string;
    name: string;
    description?: string;
    headUserId?: string;
    createdAt: string;
    updatedAt: string;
}
export interface TeamDto {
    id: string;
    organizationId: string;
    departmentId?: string;
    name: string;
    description?: string;
    leadUserId?: string;
    createdAt: string;
    updatedAt: string;
}
export declare enum InvitationStatus {
    PENDING = "PENDING",
    ACCEPTED = "ACCEPTED",
    REVOKED = "REVOKED",
    EXPIRED = "EXPIRED"
}
export interface OrganizationInvitationDto {
    id: string;
    organizationId: string;
    email: string;
    role: UserRole;
    teamIds: string[];
    departmentIds: string[];
    invitedByUserId: string;
    status: InvitationStatus;
    tokenHash: string;
    expiresAt: string;
    createdAt: string;
    acceptedAt?: string | null;
}
export interface OrganizationMemberDto {
    id: string;
    organizationId: string;
    userId: string;
    role: UserRole;
    customRoleId?: string;
    teamIds: string[];
    departmentIds: string[];
    joinedAt: string;
    isSuspended: boolean;
    user?: {
        id: string;
        email: string;
        firstName: string;
        lastName: string;
        lastLoginAt?: string;
    };
}
export declare enum PermissionFlag {
    DEVICE_MANAGEMENT = "DEVICE_MANAGEMENT",
    INVENTORY_READ_WRITE = "INVENTORY_READ_WRITE",
    TELEMETRY_READ = "TELEMETRY_READ",
    ALERTS_MANAGE = "ALERTS_MANAGE",
    RULES_MANAGE = "RULES_MANAGE",
    MAINTENANCE_MANAGE = "MAINTENANCE_MANAGE",
    USERS_MANAGE = "USERS_MANAGE",
    TEAMS_MANAGE = "TEAMS_MANAGE",
    SETTINGS_MANAGE = "SETTINGS_MANAGE",
    API_KEYS_MANAGE = "API_KEYS_MANAGE",
    AUDIT_READ = "AUDIT_READ",
    ROLE_BUILDER_MANAGE = "ROLE_BUILDER_MANAGE"
}
export interface PermissionProfileDto {
    id: string;
    organizationId: string;
    name: string;
    description?: string;
    permissions: PermissionFlag[];
    abacConditions?: Record<string, any>;
    isBuiltIn: boolean;
    createdAt: string;
    updatedAt: string;
}
export interface RoleTemplateDto {
    id: string;
    name: string;
    baseRole: UserRole;
    defaultPermissions: PermissionFlag[];
    description: string;
}
export interface PermissionMatrixDto {
    roles: {
        role: UserRole | string;
        permissions: PermissionFlag[];
    }[];
    allPermissions: {
        flag: PermissionFlag;
        category: string;
        label: string;
        description: string;
    }[];
}
export declare enum DeviceGroupType {
    STATIC = "STATIC",
    DYNAMIC = "DYNAMIC",
    SMART = "SMART"
}
export interface DeviceGroupDto {
    id: string;
    organizationId: string;
    name: string;
    description?: string;
    groupType: DeviceGroupType;
    filterCriteria?: {
        os?: string[];
        status?: string[];
        tags?: string[];
        ipRange?: string;
        customRule?: string;
    };
    deviceCount?: number;
    deviceIds?: string[];
    createdAt: string;
    updatedAt: string;
}
export interface DeviceOwnershipDto {
    id: string;
    deviceId: string;
    organizationId: string;
    ownerUserId?: string | null;
    assignedTeamId?: string | null;
    assignedDepartmentId?: string | null;
    assignedOperatorId?: string | null;
    groupIds: string[];
    assignedAt: string;
    updatedAt: string;
}
export declare enum DeviceTransferStatus {
    PENDING_APPROVAL = "PENDING_APPROVAL",
    APPROVED = "APPROVED",
    REJECTED = "REJECTED",
    CANCELLED = "CANCELLED"
}
export interface DeviceTransferRequestDto {
    id: string;
    deviceId: string;
    fromOrganizationId: string;
    toOrganizationId: string;
    requestedByUserId: string;
    approvedByUserId?: string | null;
    status: DeviceTransferStatus;
    reason: string;
    createdAt: string;
    resolvedAt?: string | null;
}
export interface UserSessionDto {
    id: string;
    userId: string;
    organizationId: string;
    tokenHash: string;
    ipAddress: string;
    browser: string;
    os: string;
    isActive: boolean;
    isRevoked: boolean;
    lastUsedAt: string;
    expiresAt: string;
    createdAt: string;
    riskScore?: number;
}
export interface UserActivityDto {
    id: string;
    userId: string;
    organizationId: string;
    action: string;
    resourceType?: string;
    resourceId?: string;
    ipAddress: string;
    browser: string;
    timestamp: string;
}
export interface UserImpersonationDto {
    impersonatingUserId: string;
    targetUserId: string;
    organizationId: string;
    reason: string;
    startedAt: string;
    expiresAt: string;
    auditCorrelationId: string;
}
export declare enum ApiKeyScope {
    DEVICES_READ = "DEVICES_READ",
    DEVICES_WRITE = "DEVICES_WRITE",
    TELEMETRY_INGEST = "TELEMETRY_INGEST",
    ALERTS_READ = "ALERTS_READ",
    ALERTS_WRITE = "ALERTS_WRITE",
    INVENTORY_READ = "INVENTORY_READ",
    AUDIT_READ = "AUDIT_READ",
    WEBHOOKS_MANAGE = "WEBHOOKS_MANAGE"
}
export interface ApiKeyDto {
    id: string;
    organizationId: string;
    name: string;
    keyPrefix: string;
    tokenHash?: string;
    scopes: ApiKeyScope[];
    allowedIps?: string[];
    expiresAt: string;
    lastUsedAt?: string | null;
    usageCount: number;
    createdByUserId: string;
    isRevoked: boolean;
    createdAt: string;
    updatedAt: string;
}
export interface ApiKeyCreateRequestDto {
    name: string;
    scopes: ApiKeyScope[];
    allowedIps?: string[];
    expiryDays: number;
}
export declare enum AuditActionType {
    LOGIN = "LOGIN",
    LOGOUT = "LOGOUT",
    DEVICE_REGISTRATION = "DEVICE_REGISTRATION",
    DEVICE_TRANSFER = "DEVICE_TRANSFER",
    INVENTORY_UPDATE = "INVENTORY_UPDATE",
    TELEMETRY_INGEST = "TELEMETRY_INGEST",
    RULE_CREATE = "RULE_CREATE",
    RULE_UPDATE = "RULE_UPDATE",
    RULE_DELETE = "RULE_DELETE",
    ALERT_TRIGGER = "ALERT_TRIGGER",
    ALERT_ACKNOWLEDGE = "ALERT_ACKNOWLEDGE",
    MAINTENANCE_SCHEDULE = "MAINTENANCE_SCHEDULE",
    ORG_SETTINGS_UPDATE = "ORG_SETTINGS_UPDATE",
    USER_INVITED = "USER_INVITED",
    USER_REMOVED = "USER_REMOVED",
    USER_IMPERSONATION = "USER_IMPERSONATION",
    PERMISSION_CHANGE = "PERMISSION_CHANGE",
    API_KEY_CREATE = "API_KEY_CREATE",
    API_KEY_REVOKE = "API_KEY_REVOKE",
    SESSION_REVOKE = "SESSION_REVOKE",
    ORG_LIFECYCLE_CHANGE = "ORG_LIFECYCLE_CHANGE"
}
export interface AuditLogDto {
    id: string;
    organizationId: string;
    userId?: string | null;
    userEmail?: string | null;
    action: AuditActionType | string;
    resourceType?: string | null;
    resourceId?: string | null;
    reason?: string | null;
    ipAddress: string;
    browser: string;
    correlationId: string;
    details?: Record<string, any>;
    timestamp: string;
}
export interface AuditSearchRequestDto {
    organizationId?: string;
    userId?: string;
    action?: string;
    resourceType?: string;
    from?: string;
    to?: string;
    search?: string;
    page?: number;
    limit?: number;
}
export interface AuditSearchResultDto {
    items: AuditLogDto[];
    total: number;
    page: number;
    totalPages: number;
    limit: number;
}
export interface OrganizationHealthScoreDto {
    organizationId: string;
    overallHealthScore: number;
    deviceAvailabilityPercent: number;
    openCriticalAlertsCount: number;
    queueHealth: "HEALTHY" | "DEGRADED" | "CRITICAL";
    storageQuotaPercent: number;
    timestamp: string;
}
export interface OrganizationRiskScoreDto {
    organizationId: string;
    riskScore: number;
    unverifiedUsersCount: number;
    staleApiKeysCount: number;
    failedLogins24h: number;
    devicesOutsideMaintenance: number;
    impersonationCount24h: number;
    timestamp: string;
}
export interface SecurityScoreDto {
    organizationId: string;
    securityScore: number;
    mfaEnforcementEnabled: boolean;
    strictPasswordPolicy: boolean;
    ipWhiteListingActive: boolean;
    expiredInvitationsCount: number;
    openSessionAnomalies: number;
    timestamp: string;
}
export interface ComplianceScoreDto {
    organizationId: string;
    complianceScore: number;
    auditLoggingCoveragePercent: number;
    retentionCompliance: boolean;
    segregationOfDutiesVerified: boolean;
    zeroOrmLeakageVerified: boolean;
    tenantIsolationVerified: boolean;
    timestamp: string;
}
