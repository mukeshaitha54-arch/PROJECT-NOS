"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuditActionType = exports.ApiKeyScope = exports.DeviceTransferStatus = exports.DeviceGroupType = exports.PermissionFlag = exports.InvitationStatus = exports.OrganizationStatus = exports.RuleRecommendationType = exports.RuleComplexityScore = exports.AlertRuleStatus = exports.AlertRuleScheduleMode = exports.AlertRuleCategory = exports.AlertRulePriority = exports.AlertRuleOperator = exports.AlertConfidence = exports.AlertOperatorRole = exports.NotificationProvider = exports.AlertCategory = exports.AlertStatus = exports.AlertSeverity = exports.getDeviceRoom = exports.DEVICE_ROOM_PREFIX = exports.SocketRooms = exports.SocketEvents = exports.DeviceStatus = exports.SystemStatus = exports.UserRole = exports.ErrorCode = void 0;
var ErrorCode;
(function (ErrorCode) {
    ErrorCode["UNAUTHORIZED"] = "UNAUTHORIZED";
    ErrorCode["TOKEN_EXPIRED"] = "TOKEN_EXPIRED";
    ErrorCode["TOKEN_REVOKED"] = "TOKEN_REVOKED";
    ErrorCode["INVALID_CREDENTIALS"] = "INVALID_CREDENTIALS";
    ErrorCode["USER_NOT_FOUND"] = "USER_NOT_FOUND";
    ErrorCode["USER_ALREADY_EXISTS"] = "USER_ALREADY_EXISTS";
    ErrorCode["EMAIL_NOT_VERIFIED"] = "EMAIL_NOT_VERIFIED";
    ErrorCode["INVALID_OTP"] = "INVALID_OTP";
    ErrorCode["OTP_EXPIRED"] = "OTP_EXPIRED";
    ErrorCode["INSUFFICIENT_PERMISSIONS"] = "INSUFFICIENT_PERMISSIONS";
    ErrorCode["VALIDATION_ERROR"] = "VALIDATION_ERROR";
    ErrorCode["INTERNAL_SERVER_ERROR"] = "INTERNAL_SERVER_ERROR";
})(ErrorCode || (exports.ErrorCode = ErrorCode = {}));
var UserRole;
(function (UserRole) {
    UserRole["OWNER"] = "OWNER";
    UserRole["SUPER_ADMIN"] = "SUPER_ADMIN";
    UserRole["ADMIN"] = "ADMIN";
    UserRole["MANAGER"] = "MANAGER";
    UserRole["OPERATOR"] = "OPERATOR";
    UserRole["ANALYST"] = "ANALYST";
    UserRole["VIEWER"] = "VIEWER";
    UserRole["AUDITOR"] = "AUDITOR";
    UserRole["CUSTOM_ROLE"] = "CUSTOM_ROLE";
    UserRole["USER"] = "USER";
})(UserRole || (exports.UserRole = UserRole = {}));
var SystemStatus;
(function (SystemStatus) {
    SystemStatus["HEALTHY"] = "HEALTHY";
    SystemStatus["DEGRADED"] = "DEGRADED";
    SystemStatus["CRITICAL"] = "CRITICAL";
    SystemStatus["OFFLINE"] = "OFFLINE";
    SystemStatus["MAINTENANCE"] = "MAINTENANCE";
})(SystemStatus || (exports.SystemStatus = SystemStatus = {}));
var DeviceStatus;
(function (DeviceStatus) {
    DeviceStatus["ONLINE"] = "ONLINE";
    DeviceStatus["OFFLINE"] = "OFFLINE";
    DeviceStatus["DEGRADED"] = "DEGRADED";
    DeviceStatus["CRITICAL"] = "CRITICAL";
    DeviceStatus["MAINTENANCE"] = "MAINTENANCE";
})(DeviceStatus || (exports.DeviceStatus = DeviceStatus = {}));
var SocketEvents;
(function (SocketEvents) {
    SocketEvents["DEVICE_CONNECTED"] = "device.connected";
    SocketEvents["DEVICE_DISCONNECTED"] = "device.disconnected";
    SocketEvents["DEVICE_ONLINE"] = "device.online";
    SocketEvents["DEVICE_OFFLINE"] = "device.offline";
    SocketEvents["HEARTBEAT_RECEIVED"] = "heartbeat.received";
    SocketEvents["TELEMETRY_RECEIVED"] = "telemetry.received";
    SocketEvents["INVENTORY_UPDATED"] = "inventory.updated";
    SocketEvents["DASHBOARD_UPDATED"] = "dashboard.updated";
    SocketEvents["SYSTEM_STATUS_CHANGED"] = "system.status.changed";
    SocketEvents["TELEMETRY_STATUS"] = "device.telemetry.status";
    SocketEvents["ALERT_CREATED"] = "alert.created";
    SocketEvents["ALERT_UPDATED"] = "alert.updated";
    SocketEvents["ALERT_ACKNOWLEDGED"] = "alert.acknowledged";
    SocketEvents["ALERT_RESOLVED"] = "alert.resolved";
    SocketEvents["ALERT_CLOSED"] = "alert.closed";
    SocketEvents["ALERT_SUPPRESSED"] = "alert.suppressed";
    SocketEvents["ALERT_ESCALATED"] = "alert.escalated";
    SocketEvents["NOTIFICATION_SENT"] = "notification.sent";
})(SocketEvents || (exports.SocketEvents = SocketEvents = {}));
var SocketRooms;
(function (SocketRooms) {
    SocketRooms["DASHBOARD"] = "dashboard";
    SocketRooms["ADMINS"] = "admins";
    SocketRooms["OPERATORS"] = "operators";
})(SocketRooms || (exports.SocketRooms = SocketRooms = {}));
exports.DEVICE_ROOM_PREFIX = "device:";
const getDeviceRoom = (deviceId) => `${exports.DEVICE_ROOM_PREFIX}${deviceId}`;
exports.getDeviceRoom = getDeviceRoom;
var AlertSeverity;
(function (AlertSeverity) {
    AlertSeverity["INFO"] = "INFO";
    AlertSeverity["LOW"] = "LOW";
    AlertSeverity["MEDIUM"] = "MEDIUM";
    AlertSeverity["HIGH"] = "HIGH";
    AlertSeverity["CRITICAL"] = "CRITICAL";
})(AlertSeverity || (exports.AlertSeverity = AlertSeverity = {}));
var AlertStatus;
(function (AlertStatus) {
    AlertStatus["NEW"] = "NEW";
    AlertStatus["OPEN"] = "OPEN";
    AlertStatus["ACKNOWLEDGED"] = "ACKNOWLEDGED";
    AlertStatus["RESOLVED"] = "RESOLVED";
    AlertStatus["CLOSED"] = "CLOSED";
    AlertStatus["SUPPRESSED"] = "SUPPRESSED";
    AlertStatus["EXPIRED"] = "EXPIRED";
    AlertStatus["SNOOZED"] = "SNOOZED";
})(AlertStatus || (exports.AlertStatus = AlertStatus = {}));
var AlertCategory;
(function (AlertCategory) {
    AlertCategory["CPU"] = "CPU";
    AlertCategory["RAM"] = "RAM";
    AlertCategory["DISK"] = "DISK";
    AlertCategory["TEMPERATURE"] = "TEMPERATURE";
    AlertCategory["NETWORK"] = "NETWORK";
    AlertCategory["HEARTBEAT"] = "HEARTBEAT";
    AlertCategory["INVENTORY"] = "INVENTORY";
    AlertCategory["SECURITY"] = "SECURITY";
    AlertCategory["WINDOWS_SERVICE"] = "WINDOWS_SERVICE";
    AlertCategory["STARTUP_APP"] = "STARTUP_APP";
    AlertCategory["SYSTEM"] = "SYSTEM";
    AlertCategory["CORRELATION"] = "CORRELATION";
})(AlertCategory || (exports.AlertCategory = AlertCategory = {}));
var NotificationProvider;
(function (NotificationProvider) {
    NotificationProvider["EMAIL"] = "EMAIL";
    NotificationProvider["SLACK"] = "SLACK";
    NotificationProvider["DISCORD"] = "DISCORD";
    NotificationProvider["TEAMS"] = "TEAMS";
    NotificationProvider["SMS"] = "SMS";
    NotificationProvider["PUSH"] = "PUSH";
    NotificationProvider["WEBHOOK"] = "WEBHOOK";
})(NotificationProvider || (exports.NotificationProvider = NotificationProvider = {}));
var AlertOperatorRole;
(function (AlertOperatorRole) {
    AlertOperatorRole["OPERATOR"] = "OPERATOR";
    AlertOperatorRole["SENIOR"] = "SENIOR";
    AlertOperatorRole["MANAGER"] = "MANAGER";
    AlertOperatorRole["DIRECTOR"] = "DIRECTOR";
    AlertOperatorRole["ON_CALL"] = "ON_CALL";
})(AlertOperatorRole || (exports.AlertOperatorRole = AlertOperatorRole = {}));
var AlertConfidence;
(function (AlertConfidence) {
    AlertConfidence["LOW"] = "LOW";
    AlertConfidence["MEDIUM"] = "MEDIUM";
    AlertConfidence["HIGH"] = "HIGH";
})(AlertConfidence || (exports.AlertConfidence = AlertConfidence = {}));
var AlertRuleOperator;
(function (AlertRuleOperator) {
    AlertRuleOperator["GREATER_THAN"] = ">";
    AlertRuleOperator["GREATER_THAN_OR_EQUAL"] = ">=";
    AlertRuleOperator["LESS_THAN"] = "<";
    AlertRuleOperator["LESS_THAN_OR_EQUAL"] = "<=";
    AlertRuleOperator["EQUAL"] = "==";
    AlertRuleOperator["NOT_EQUAL"] = "!=";
    AlertRuleOperator["CONTAINS"] = "CONTAINS";
    AlertRuleOperator["NOT_CONTAINS"] = "NOT_CONTAINS";
    AlertRuleOperator["MUTATED"] = "MUTATED";
})(AlertRuleOperator || (exports.AlertRuleOperator = AlertRuleOperator = {}));
var AlertRulePriority;
(function (AlertRulePriority) {
    AlertRulePriority["LOW"] = "LOW";
    AlertRulePriority["NORMAL"] = "NORMAL";
    AlertRulePriority["HIGH"] = "HIGH";
    AlertRulePriority["CRITICAL"] = "CRITICAL";
})(AlertRulePriority || (exports.AlertRulePriority = AlertRulePriority = {}));
var AlertRuleCategory;
(function (AlertRuleCategory) {
    AlertRuleCategory["PERFORMANCE"] = "PERFORMANCE";
    AlertRuleCategory["SECURITY"] = "SECURITY";
    AlertRuleCategory["AVAILABILITY"] = "AVAILABILITY";
    AlertRuleCategory["INVENTORY"] = "INVENTORY";
    AlertRuleCategory["COMPLIANCE"] = "COMPLIANCE";
    AlertRuleCategory["MAINTENANCE"] = "MAINTENANCE";
    AlertRuleCategory["SYSTEM"] = "SYSTEM";
    AlertRuleCategory["NETWORK"] = "NETWORK";
})(AlertRuleCategory || (exports.AlertRuleCategory = AlertRuleCategory = {}));
var AlertRuleScheduleMode;
(function (AlertRuleScheduleMode) {
    AlertRuleScheduleMode["ALWAYS"] = "ALWAYS";
    AlertRuleScheduleMode["BUSINESS_HOURS"] = "BUSINESS_HOURS";
    AlertRuleScheduleMode["NIGHT"] = "NIGHT";
    AlertRuleScheduleMode["WEEKEND"] = "WEEKEND";
    AlertRuleScheduleMode["CRON"] = "CRON";
})(AlertRuleScheduleMode || (exports.AlertRuleScheduleMode = AlertRuleScheduleMode = {}));
var AlertRuleStatus;
(function (AlertRuleStatus) {
    AlertRuleStatus["ACTIVE"] = "ACTIVE";
    AlertRuleStatus["DISABLED"] = "DISABLED";
    AlertRuleStatus["ARCHIVED"] = "ARCHIVED";
})(AlertRuleStatus || (exports.AlertRuleStatus = AlertRuleStatus = {}));
var RuleComplexityScore;
(function (RuleComplexityScore) {
    RuleComplexityScore["SIMPLE"] = "SIMPLE";
    RuleComplexityScore["MEDIUM"] = "MEDIUM";
    RuleComplexityScore["COMPLEX"] = "COMPLEX";
    RuleComplexityScore["VERY_COMPLEX"] = "VERY_COMPLEX";
})(RuleComplexityScore || (exports.RuleComplexityScore = RuleComplexityScore = {}));
var RuleRecommendationType;
(function (RuleRecommendationType) {
    RuleRecommendationType["MERGE"] = "MERGE";
    RuleRecommendationType["REMOVE_DUPLICATE"] = "REMOVE_DUPLICATE";
    RuleRecommendationType["NEVER_TRIGGERED"] = "NEVER_TRIGGERED";
    RuleRecommendationType["EXPENSIVE"] = "EXPENSIVE";
    RuleRecommendationType["HIGH_NOISE"] = "HIGH_NOISE";
    RuleRecommendationType["OVERLAPPING"] = "OVERLAPPING";
})(RuleRecommendationType || (exports.RuleRecommendationType = RuleRecommendationType = {}));
var OrganizationStatus;
(function (OrganizationStatus) {
    OrganizationStatus["ACTIVE"] = "ACTIVE";
    OrganizationStatus["SUSPENDED"] = "SUSPENDED";
    OrganizationStatus["ARCHIVED"] = "ARCHIVED";
    OrganizationStatus["DELETED"] = "DELETED";
})(OrganizationStatus || (exports.OrganizationStatus = OrganizationStatus = {}));
var InvitationStatus;
(function (InvitationStatus) {
    InvitationStatus["PENDING"] = "PENDING";
    InvitationStatus["ACCEPTED"] = "ACCEPTED";
    InvitationStatus["REVOKED"] = "REVOKED";
    InvitationStatus["EXPIRED"] = "EXPIRED";
})(InvitationStatus || (exports.InvitationStatus = InvitationStatus = {}));
var PermissionFlag;
(function (PermissionFlag) {
    PermissionFlag["DEVICE_MANAGEMENT"] = "DEVICE_MANAGEMENT";
    PermissionFlag["INVENTORY_READ_WRITE"] = "INVENTORY_READ_WRITE";
    PermissionFlag["TELEMETRY_READ"] = "TELEMETRY_READ";
    PermissionFlag["ALERTS_MANAGE"] = "ALERTS_MANAGE";
    PermissionFlag["RULES_MANAGE"] = "RULES_MANAGE";
    PermissionFlag["MAINTENANCE_MANAGE"] = "MAINTENANCE_MANAGE";
    PermissionFlag["USERS_MANAGE"] = "USERS_MANAGE";
    PermissionFlag["TEAMS_MANAGE"] = "TEAMS_MANAGE";
    PermissionFlag["SETTINGS_MANAGE"] = "SETTINGS_MANAGE";
    PermissionFlag["API_KEYS_MANAGE"] = "API_KEYS_MANAGE";
    PermissionFlag["AUDIT_READ"] = "AUDIT_READ";
    PermissionFlag["ROLE_BUILDER_MANAGE"] = "ROLE_BUILDER_MANAGE";
})(PermissionFlag || (exports.PermissionFlag = PermissionFlag = {}));
var DeviceGroupType;
(function (DeviceGroupType) {
    DeviceGroupType["STATIC"] = "STATIC";
    DeviceGroupType["DYNAMIC"] = "DYNAMIC";
    DeviceGroupType["SMART"] = "SMART";
})(DeviceGroupType || (exports.DeviceGroupType = DeviceGroupType = {}));
var DeviceTransferStatus;
(function (DeviceTransferStatus) {
    DeviceTransferStatus["PENDING_APPROVAL"] = "PENDING_APPROVAL";
    DeviceTransferStatus["APPROVED"] = "APPROVED";
    DeviceTransferStatus["REJECTED"] = "REJECTED";
    DeviceTransferStatus["CANCELLED"] = "CANCELLED";
})(DeviceTransferStatus || (exports.DeviceTransferStatus = DeviceTransferStatus = {}));
var ApiKeyScope;
(function (ApiKeyScope) {
    ApiKeyScope["DEVICES_READ"] = "DEVICES_READ";
    ApiKeyScope["DEVICES_WRITE"] = "DEVICES_WRITE";
    ApiKeyScope["TELEMETRY_INGEST"] = "TELEMETRY_INGEST";
    ApiKeyScope["ALERTS_READ"] = "ALERTS_READ";
    ApiKeyScope["ALERTS_WRITE"] = "ALERTS_WRITE";
    ApiKeyScope["INVENTORY_READ"] = "INVENTORY_READ";
    ApiKeyScope["AUDIT_READ"] = "AUDIT_READ";
    ApiKeyScope["WEBHOOKS_MANAGE"] = "WEBHOOKS_MANAGE";
})(ApiKeyScope || (exports.ApiKeyScope = ApiKeyScope = {}));
var AuditActionType;
(function (AuditActionType) {
    AuditActionType["LOGIN"] = "LOGIN";
    AuditActionType["LOGOUT"] = "LOGOUT";
    AuditActionType["DEVICE_REGISTRATION"] = "DEVICE_REGISTRATION";
    AuditActionType["DEVICE_TRANSFER"] = "DEVICE_TRANSFER";
    AuditActionType["INVENTORY_UPDATE"] = "INVENTORY_UPDATE";
    AuditActionType["TELEMETRY_INGEST"] = "TELEMETRY_INGEST";
    AuditActionType["RULE_CREATE"] = "RULE_CREATE";
    AuditActionType["RULE_UPDATE"] = "RULE_UPDATE";
    AuditActionType["RULE_DELETE"] = "RULE_DELETE";
    AuditActionType["ALERT_TRIGGER"] = "ALERT_TRIGGER";
    AuditActionType["ALERT_ACKNOWLEDGE"] = "ALERT_ACKNOWLEDGE";
    AuditActionType["MAINTENANCE_SCHEDULE"] = "MAINTENANCE_SCHEDULE";
    AuditActionType["ORG_SETTINGS_UPDATE"] = "ORG_SETTINGS_UPDATE";
    AuditActionType["USER_INVITED"] = "USER_INVITED";
    AuditActionType["USER_REMOVED"] = "USER_REMOVED";
    AuditActionType["USER_IMPERSONATION"] = "USER_IMPERSONATION";
    AuditActionType["PERMISSION_CHANGE"] = "PERMISSION_CHANGE";
    AuditActionType["API_KEY_CREATE"] = "API_KEY_CREATE";
    AuditActionType["API_KEY_REVOKE"] = "API_KEY_REVOKE";
    AuditActionType["SESSION_REVOKE"] = "SESSION_REVOKE";
    AuditActionType["ORG_LIFECYCLE_CHANGE"] = "ORG_LIFECYCLE_CHANGE";
})(AuditActionType || (exports.AuditActionType = AuditActionType = {}));
//# sourceMappingURL=index.js.map